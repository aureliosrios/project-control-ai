# CONDICIONES TÉCNICAS DE SITIO, GEOTECNIA, ESTRUCTURA Y SECTORIZACIÓN (RESCATE CARPETA 01)

**Proyecto:** Edificio Educativo de 6 pisos, 2 sótanos y azotea  
**Ubicación:** Jr. Las Gardenias 480, Urb. La Calera de la Merced, Surquillo, Lima, Perú  
**Uso:** Educativo — Instituto de Educación Superior Tecnológica  
**Área de Lote:** 500.0 m² | **Área Techada Total:** 4500.0 m²  
**Configuración:** 6 pisos, 2 sótanos y azotea (18 sectores de 250 m² c/u)

---

## 1. Matriz Oficial de Sectores (LBS — Location Breakdown Structure)
| Nivel | Cota (m) | Sectores Oficiales | Área por Nivel (m²) | Área por Sector (m²) |
|---|---:|---|---:|---:|
| Sótano 2 | -5.6 m | S2-1, S2-2 | 500.0 m² | 250.0 m² |
| Sótano 1 | -2.8 m | S1-1, S1-2 | 500.0 m² | 250.0 m² |
| Piso 1 | 0.0 m | P1-1, P1-2 | 500.0 m² | 250.0 m² |
| Piso 2 | 3.5 m | P2-1, P2-2 | 500.0 m² | 250.0 m² |
| Piso 3 | 6.7 m | P3-1, P3-2 | 500.0 m² | 250.0 m² |
| Piso 4 | 9.9 m | P4-1, P4-2 | 500.0 m² | 250.0 m² |
| Piso 5 | 13.1 m | P5-1, P5-2 | 500.0 m² | 250.0 m² |
| Piso 6 | 16.3 m | P6-1, P6-2 | 500.0 m² | 250.0 m² |
| Azotea | 19.5 m | AZ-1, AZ-2 | 500.0 m² | 250.0 m² |

---

## 2. Geometría, Colindancias y Restricciones de Acceso (TOP-01)
* **Geometría del Terreno:** Frente 20.0 m x Fondo 20.0 m | Lados 25.0 m / 25.0 m | Perímetro: 90.0 m.
* **Cota de Referencia:** BM Oficial en vereda frontal cota absoluta +98.50 msnm (Nivel ±0.00 de obra).
* **Colindancias Críticas:** 3 frentes colindantes con edificaciones vecinas (Eje 1, Eje 6 y Eje E = 70.0 m lineales); 1 único frente libre de acceso vehicular y estacionamiento de bomba de concreto por Jr. Las Gardenias (20.0 m).
* **Impacto en el Cronograma:** Obliga a secuenciar los vaciados y excavaciones desde el fondo del lote (Sector 1) hacia la salida en Jr. Las Gardenias (Sector 2) y restringe el posicionamiento a 1 bomba telescópica y 1 grúa torre central.

---

## 3. Condiciones Geotécnicas e Hidrogeológicas (EMS-01)
* **Estratigrafía:** Grava aluvial densa del Cono de Lima (GP-GM).
* **Cota de Cimentación Oficial:** -5.80 m (En EMS-01 figura referencialmente -6.50 m (q_adm=3.50 kg/cm2), pero en Base de Diseño Rev. D, WBS-03.01 y Metrados rige oficialmente la cota -5.80 m (q_adm=4.00 kg/cm2).).
* **Nivel Freático:** No detectado hasta -12.00 m..
* **Agresividad Química:** Moderadamente agresivo a sales (uso de cemento Tipo MS/HS o aditivo impermeabilizante en elementos en contacto con suelo)..
* **Impactos Clave en Programación:**
  - 1. Ausencia de napa freática descarta sistema wellpoint previo a excavar; la partida 02.05 (Bombeo) actúa como actividad soporte (Level of Effort) para escorrentías y vaciado de pruebas hidrostáticas.
  - 2. Excavación hasta -5.80 m con 3 linderos vecinos exige proceso constructivo por ANILLOS (Banquetas Sótano 1 a -2.80 m y Sótano 2 a -5.60/-5.80 m), alternando Excavación Masiva (03.01) -> Sostenimiento Anclajes Dywidag (02.01) + Apuntalamiento (02.02) + Lag de fraguado de bulbo de lechada (3 días) -> Muros Pantalla (06.01-06.03).

---

## 4. Especificaciones de Concreto y Catálogo de Lags Normativos
* **Sistema Estructural:** Concreto Armado Dual (Pórticos y Placas E.030/E.060), Categoría A2 Educativo Esencial.
* **Resistencias de Concreto:**
  - Solados y Cimientos: f'c = 140 kg/cm2
  - Sobrecimientos: f'c = 175 kg/cm2
  - Zapatas, Vigas, Losas y Escaleras: f'c = 210 kg/cm2
  - Muros Pantalla, Columnas, Placas y Cisterna: f'c = 280 kg/cm2

### Catálogo de Lags Técnicos Obligatorios
| ID Lag | Proceso Constructivo y Restricción Normativa | Relación | Lag (días) |
|---|---|---|---:|
| LAG-01 | Fraguado de lechada en anclajes Dywidag (02.01) antes de tensado y excavación de anillo inferior | FS+3d | 3 |
| LAG-02 | Desencofrado de elementos verticales (columnas 07.02, placas 07.05, muros 06.02) | FS+1d tras vaciado | 1 |
| LAG-03 | Desencofrado/reapuntalamiento y espera estructural antes de iniciar Albañilería E.070 (09.01) para evitar fisuración por deflexión de losa | FS+10d tras vaciado de losa del nivel | 10 |
| LAG-04 | Curado de concreto f'c=280 en Cisterna (06.05) previo a Prueba Hidrostática de Estanqueidad 72h (13.04) | FS+7d | 7 |
| LAG-05 | Inspección y Protocolo Tripartito de Liberación QA/QC (13.01) embebidos MEP (10.01, 11.01, 12.01) previo a cada vaciado | FF / FS en mismo ciclo de tren | 0 |
