# MATRIZ MAESTRA CONSOLIDADA DE WBS Y METRADOS POR NIVEL Y SECTOR (CARPETAS 02 + 03 FUSIONADAS)

**Proyecto:** Edificio Educativo de 6 pisos, 2 sótanos y azotea  
**Código Documento:** MET-MAE-2026-REV-D | **Versión:** Rev. D  
**Capítulos Contractuales:** 13 | **Partidas Totales:** 78  
**Estado:** CONFORME SINTÉTICO (Conciliación Determinista con Diferencia = 0.00)

---

## 1. Resumen de Capítulos WBS y Cantidades
| Capítulo | Título Oficial | N° Partidas | Alcance Técnico Resumido |
|---|---|---:|---|
| **01.00** | TRABAJOS PRELIMINARES | 6 | Actividades preparatorias, movilización, habilitación de servicios provisionales, trazo y protección de interferencias. |
| **02.00** | OBRAS TEMPORALES, SOSTENIMIENTO Y MONITOREO GEOTÉCNICO | 5 | Protección de colindancias, muros de sostenimiento provisional y auscultación. |
| **03.00** | MOVIMIENTO DE TIERRAS | 5 | Excavaciones masivas y localizadas, relleno compactado y eliminación de excedentes. |
| **04.00** | CONCRETO SIMPLE Y PREPARACIÓN DE FONDO | 4 | Solados de cimentación, cimientos corridos y sobrecimientos de concreto ciclópeo/simple. |
| **05.00** | CIMENTACIONES DE CONCRETO ARMADO | 6 | Zapatas aisladas y combinadas, vigas de cimentación y amarre. |
| **06.00** | ESTRUCTURAS ESPECIALES DE SÓTANOS | 8 | Muros de contención perimetrales, losa de contacto, cisterna, foso de ascensor y rampa. |
| **07.00** | SUPERESTRUCTURA DE CONCRETO ARMADO | 16 | Columnas, placas, vigas, losas aligeradas, ladrillos de techo y escaleras del Piso 1 al 6. |
| **08.00** | AZOTEA Y ELEMENTOS TÉCNICOS | 4 | Losa de techo final, parapetos de concreto, cuarto de máquinas e impermeabilización. |
| **09.00** | ALBAÑILERÍA Y ACABADOS BÁSICOS EN CASCO | 4 | Muros de ladrillo pandereta confinado, columnetas, dinteles y solaqueo primario. |
| **10.00** | INTERFACES E INSTALACIONES SANITARIAS EMBEBIDAS | 5 | Mangas, sleeves, pasamuros rompeaguas, montantes verticales y pruebas hidrostáticas. |
| **11.00** | INTERFACES E INSTALACIONES ELÉCTRICAS Y COMUNICACIONES EMBEBIDAS | 5 | Red equipotencial de puesta a tierra Ufer, conduits, cajas galvanizadas y shafts. |
| **12.00** | INTERFACES MECÁNICAS, VENTILACIÓN Y CONTRA INCENDIOS EMBEBIDAS | 4 | Pases de presurización de escaleras, extracción de CO, montante ACI e insertos HVAC. |
| **13.00** | ASEGURAMIENTO Y CONTROL DE CALIDAD (QA/QC) | 6 | Control topográfico, ensayos de compresión de concreto, acero, densidades y protocolos. |

---

## 2. Catálogo Consolidado de las 78 Partidas (WBS + Metrado + Regla de Medición)
| Código | Capítulo | Descripción de Partida | Und | Metrado Oficial | Tipo de Partida | Regla de Medición / Observación |
|---|---|---|---|---:|---|---|
| `01.01` | 01.00 | Movilización y desmovilización de equipo pesado en cama baja de 30 Tn | glb | 1.00 | Contractual / Global | Suma global por traslado total de equipos a obra y retiro al finalizar casco. |
| `01.02` | 01.00 | Instalaciones provisionales de agua, energía y desagüe de faena con tablero general | glb | 1.00 | Contractual / Global | Suma global que incluye acometidas provisionales y tableros de faena. |
| `01.03` | 01.00 | Cerramiento provisional perimetral con parantes tubulares de acero 2" y Malla Raschel 80% | m | 90.00 | Medible / Unitario | Metro lineal de cerco perimetral de triplay/planchas metálicas h=2.40m. |
| `01.04` | 01.00 | Trazo, niveles y replanteo topográfico con Estación Total Láser Leica | m2 | 500.00 | Medible / Unitario | Área en proyección horizontal del lote replanteado. |
| `01.05` | 01.00 | Protección y desvío de interferencias de redes de servicios públicos (SEDAPAL/ENEL) | glb | 1.00 | Contractual / Global | Suma global por apuntalamiento y protección de redes aéreas y matrices. |
| `01.06` | 01.00 | Limpieza, desbroce manual y acondicionamiento del terreno | m2 | 450.00 | Medible / Unitario | Área neta de terreno desbrozado y limpio de basura superficial. |
| `02.01` | 02.00 | Sostenimiento perimetral con perforadora hidráulica, anclajes Dywidag 32mm L=9m e inyección de lechada | m2 | 522.00 | Medible / Unitario | Área de cara expuesta de taludes y muros sostenidos perimetralmente. |
| `02.02` | 02.00 | Apuntalamiento provisional de estructuras colindantes con puntales telescópicos Multiprop y vigas HEB | und | 12.00 | Medible / Unitario | Unidad de puntal telescópico o pie de amigo colocado y arriostrado. |
| `02.03` | 02.00 | Instrumentación geotécnica: inclinómetros biaxiales profundos (2 und) y piezómetro abierto PZ-1 | glb | 1.00 | Contractual / Global | Suma global por suministro, perforación, instalación y calibración de instrumentos. |
| `02.04` | 02.00 | Monitoreo topográfico continuo de hitos geodésicos en colindancias con estación total (8 hitos) | mes | 4.00 | Medible / Servicio | Meses de servicio continuo de lecturas topográficas semanales de 8 hitos. |
| `02.05` | 02.00 | Sistema provisional de bombeo y achique de aguas de escorrentía con electrobomba sumergible 5 HP | glb | 1.00 | Contractual / Global | Suma global por motobombas, mangueras y pozo sumidero de drenaje pluvial. |
| `03.01` | 03.00 | Excavación masiva con excavadora sobre orugas 200 HP hasta cota -5.80 m | m3 | 3,200.00 | Medible / Unitario | Volumen geométrico en banco de excavación a máquina. |
| `03.02` | 03.00 | Excavación manual localizada para zapatas, vigas de cimentación, foso y cisterna | m3 | 250.00 | Medible / Unitario | Volumen geométrico de zanjas y pozos excavados a pulso. |
| `03.03` | 03.00 | Carguío con cargador frontal CAT 950 y eliminación con volquetes de 15 m3 (d=10 km) | m3 | 4,100.00 | Medible / Unitario | Volumen esponjado (factor 1.20) de material transportado a botadero oficial. |
| `03.04` | 03.00 | Relleno compactado con afirmado seleccionado de cantera y plancha vibratoria al 95% PM | m3 | 180.00 | Medible / Unitario | Volumen compactado en capas de 20 cm medido en sitio. |
| `03.05` | 03.00 | Perfilado y compactación de fondo de excavación (subrasante) con equipo liviano | m2 | 500.00 | Medible / Unitario | Área de fondo de excavación perfilada y compactada con plancha vibratoria. |
| `04.01` | 04.00 | Solado de concreto premezclado f'c=140 kg/cm2 e=4" para zapatas, cisterna y fosos | m2 | 161.20 | Medible / Unitario | Área efectiva de solado vaciado bajo elementos de cimentación. |
| `04.02` | 04.00 | Cimientos corridos de concreto premezclado f'c=140 kg/cm2 + 30% piedra grande | m3 | 120.00 | Medible / Unitario | Volumen geométrico de zanjas vaciadas con concreto ciclópeo. |
| `04.03` | 04.00 | Sobrecimientos de concreto premezclado f'c=175 kg/cm2 + 25% piedra mediana | m3 | 45.00 | Medible / Unitario | Volumen geométrico de sobrecimientos vaciados. |
| `04.04` | 04.00 | Encofrado y desencofrado modular metálico con tablero fenólico para sobrecimientos | m2 | 180.00 | Medible / Unitario | Área de contacto de madera con el concreto en ambas caras. |
| `05.01` | 05.00 | Zapatas: Concreto premezclado f'c=210 kg/cm2 vaciado con bomba telescópica | m3 | 83.76 | Medible / Unitario | Volumen geométrico de zapatas según planos estructurales. |
| `05.02` | 05.00 | Zapatas: Encofrado y desencofrado modular metálico | m2 | 137.44 | Medible / Unitario | Área lateral de contacto de zapatas encofradas. |
| `05.03` | 05.00 | Zapatas: Acero de refuerzo corrugado fy=4200 kg/cm2 Grado 60 habilitado en banco CNC | kg | 7,119.60 | Medible / Unitario | Peso nominal en kilogramos según planilla de doblado y despiece. |
| `05.04` | 05.00 | Vigas de cimentación y amarre: Concreto premezclado f'c=210 kg/cm2 con bomba | m3 | 58.52 | Medible / Unitario | Volumen geométrico de vigas de cimentación vaciadas. |
| `05.05` | 05.00 | Vigas de cimentación y amarre: Encofrado y desencofrado modular fenólico 18mm | m2 | 258.40 | Medible / Unitario | Área de contacto lateral de encofrado. |
| `05.06` | 05.00 | Vigas de cimentación y amarre: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 6,437.20 | Medible / Unitario | Peso nominal de varillas longitudinales y estribos colocados. |
| `06.01` | 06.00 | Muros de contención / pantalla: Concreto premezclado f'c=280 kg/cm2 con bomba | m3 | 156.60 | Medible / Unitario | Volumen geométrico de muros perimetrales vaciados. |
| `06.02` | 06.00 | Muros de contención / pantalla: Encofrado modular fenólico a dos caras con sistema de trepa | m2 | 1,044.00 | Medible / Unitario | Área de contacto de encofrado metálico/fenólico en ambas caras. |
| `06.03` | 06.00 | Muros de contención / pantalla: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 14,094.00 | Medible / Unitario | Peso nominal de malla doble de refuerzo y bastones. |
| `06.04` | 06.00 | Losa de contacto de Sótano 2 e=15 cm concreto premezclado f'c=210 sobre lámina de polietileno HDPE 8 mils | m2 | 500.00 | Medible / Unitario | Área superficial de losa de fondo de sótano con frotachado mecánico. |
| `06.05` | 06.00 | Cisterna y cuarto de bombas: Estructura monolítica de concreto premezclado f'c=280 con impermeabilizante y waterstop | m3 | 42.50 | Contractual / Global | Suma global por concreto, encofrado y acero de cuba de cisterna 45 m3. |
| `06.06` | 06.00 | Cisterna y cuarto de bombas: Encofrado modular fenólico impermeable | m2 | 168.00 | Contractual / Global | Suma global por foso y sobre-recorrido de ascensor con sello estanco. |
| `06.07` | 06.00 | Rampa vehicular estructural: Losa inclinada e=18 cm concreto f'c=210 con acabado endurecido antideslizante | m2 | 125.00 | Medible / Unitario | Área en planta desarrollada de rampa con acabado peinado. |
| `06.08` | 06.00 | Sellos hidroexpansivos SikaSwell y cinta waterstop de PVC 6" en juntas frías de sótanos | m | 180.00 | Medible / Unitario | Metro lineal de junta sellada estancamente. |
| `07.01` | 07.00 | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m | m3 | 48.60 | Medible / Unitario | Volumen geométrico de columnas del Piso 1 al Piso 6. |
| `07.02` | 07.00 | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos | m2 | 324.00 | Medible / Unitario | Área de cara de contacto de columnas. |
| `07.03` | 07.00 | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica | kg | 7,290.00 | Medible / Unitario | Peso nominal de barras longitudinales y estribos. |
| `07.04` | 07.00 | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba | m3 | 72.90 | Medible / Unitario | Volumen de concreto premezclado vaciado en muros de corte. |
| `07.05` | 07.00 | Placas de concreto armado: Encofrado modular fenólico trepante | m2 | 486.00 | Medible / Unitario | Área de contacto a dos caras de placas. |
| `07.06` | 07.00 | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 8,748.00 | Medible / Unitario | Peso nominal de acero corrugado colocado. |
| `07.07` | 07.00 | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba | m3 | 126.00 | Medible / Unitario | Volumen geométrico de vigas principales y de amarre. |
| `07.08` | 07.00 | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos | m2 | 560.00 | Medible / Unitario | Área de fondo y laterales de vigas. |
| `07.09` | 07.00 | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 15,120.00 | Medible / Unitario | Peso nominal de acero colocado en vigas. |
| `07.10` | 07.00 | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 | m3 | 210.00 | Medible / Unitario | Volumen de concreto en viguetas y loseta superior de 5 cm. |
| `07.11` | 07.00 | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares | m2 | 2,400.00 | Medible / Unitario | Área en planta de fondo de losas aligeradas encofradas. |
| `07.12` | 07.00 | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 | kg | 12,600.00 | Medible / Unitario | Peso nominal de acero positivo, negativo y temperatura. |
| `07.13` | 07.00 | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre | und | 20,400.00 | Medible / Unitario | Conteo total de unidades de ladrillo hueco colocadas (8.33 und/m2). |
| `07.14` | 07.00 | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 | m3 | 18.90 | Medible / Unitario | Volumen geométrico de rampas y descansos de escaleras. |
| `07.15` | 07.00 | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos | m2 | 108.00 | Medible / Unitario | Área de fondos, contrapasos y costados de escaleras. |
| `07.16` | 07.00 | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 2,457.00 | Medible / Unitario | Peso nominal de acero longitudinal y transversal de escaleras. |
| `08.01` | 08.00 | Losa de techo de azotea e=20 cm concreto premezclado f'c=210 con membrana asfáltica e=3mm | m2 | 500.00 | Medible / Unitario | Área superficial de losa de azotea acabada. |
| `08.02` | 08.00 | Parapeto perimetral de concreto armado f'c=210 h=1.10 m en azotea | m | 90.00 | Medible / Unitario | Metro lineal de parapeto vaciado y desencofrado. |
| `08.03` | 08.00 | Caseta de sala de máquinas de ascensor y cuarto técnico de bombas en concreto f'c=280 | m3 | 12.50 | Contractual / Global | Suma global por estructura elevada en azotea para equipos técnicos. |
| `08.04` | 08.00 | Juntas de dilatación sísmica perimetral con tecnopor de 1" y sellador elastomérico de poliuretano | m | 65.00 | Medible / Unitario | Área neta tratada con imprimante y manto termosellado 4 mm. |
| `09.01` | 09.00 | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga | m2 | 1,850.00 | Medible / Unitario | Área de tabiques levantados con mortero 1:4 e=1.5 cm. |
| `09.02` | 09.00 | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) | m3 | 28.50 | Medible / Unitario | Volumen de concreto f'c=175 vaciado en confinamientos. |
| `09.03` | 09.00 | Encofrado y desencofrado modular para columnetas y vigas de amarre | m2 | 195.00 | Medible / Unitario | Metro lineal de dintel vaciado con apoyo mínimo 20 cm. |
| `09.04` | 09.00 | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex | m | 420.00 | Medible / Unitario | Área superficial perfilada y resanada con mortero fino. |
| `10.01` | 10.00 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) | und | 96.00 | Medible / Unitario | Conteo de sleeves de PVC instalados rígidamente antes de vaciar. |
| `10.02` | 10.00 | Red colectora de desagüe colgada PVC SAL 4" y 2" en sótanos | m | 280.00 | Medible / Unitario | Conteo de bridas metálicas/PVC fijadas con waterstop. |
| `10.03` | 10.00 | Montantes de ventilación y desagüe vertical PVC SAL 4" | m | 195.00 | Medible / Unitario | Metro lineal de tubería montante vertical colocada. |
| `10.04` | 10.00 | Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje | und | 24.00 | Medible / Unitario | Conteo de puntos de captación embebidos en losas. |
| `10.05` | 10.00 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM | m | 350.00 | Contractual / Global | Suma global por pruebas de presión manométrica a 100 psi en faena. |
| `11.01` | 11.00 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos | und | 120.00 | Medible / Unitario | Metro lineal de cable de cobre desnudo soldado a zapatas. |
| `11.02` | 11.00 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados | m | 1,850.00 | Medible / Unitario | Metro lineal de tubería conduit asegurada a armadura de acero. |
| `11.03` | 11.00 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) | m | 3,200.00 | Medible / Unitario | Conteo de cajas fijadas y selladas contra ingreso de lechada. |
| `11.04` | 11.00 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza | und | 210.00 | Medible / Unitario | Conteo de pases verticales para ductería de alta y baja tensión. |
| `11.05` | 11.00 | Sistema de puesta a tierra integral de baja resistencia (< 5 ohmios) en foso de sótanos | und | 4.00 | Medible / Unitario | Metro lineal de conduit exclusivo para corrientes débiles. |
| `12.01` | 12.00 | Pases estructurales coordinados BIM para ductos de presurización de escalera | und | 18.00 | Medible / Unitario | Conteo de aberturas circulares/rectangulares con marco metálico. |
| `12.02` | 12.00 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) | m | 850.00 | Medible / Unitario | Conteo de mangas rectangulares fijadas en encofrados. |
| `12.03` | 12.00 | Anclajes y soportes antivibratorios para equipos electromecánicos de bombeo | und | 8.00 | Medible / Unitario | Conteo de anclajes de acero estructural e insertos empotrados. |
| `12.04` | 12.00 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego | und | 64.00 | Medible / Unitario | Conteo de pases encamisados para refrigeración. |
| `13.01` | 13.00 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto | und | 144.00 | Medible / Servicio | Meses de control topográfico continuo y calibración de instrumentos. |
| `13.02` | 13.00 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) | und | 65.00 | Medible / Ensayo | Grupos de 4 probetas cilíndricas ensayadas a compresión axial. |
| `13.03` | 13.00 | Ensayos de tracción y doblado de acero de refuerzo en laboratorio acreditado | und | 12.00 | Medible / Ensayo | Ensayos de caracterización mecánica de barras corrugadas. |
| `13.04` | 13.00 | Pruebas hidrostáticas y de estanqueidad presurizada en redes y cisterna (72 horas) | glb | 1.00 | Medible / Ensayo | Determinación in situ de porcentaje de compactación Proctor. |
| `13.05` | 13.00 | Ensayos de densidad de campo (cono de arena) en rellenos y subrasante al 95% PM | und | 18.00 | Medible / Protocolo | Actas firmadas de liberación previa a cada vaciado de elemento. |
| `13.06` | 13.00 | Elaboración y entrega del Dossier Final de Calidad y Planos As-Built en formato BIM/CAD | glb | 1.00 | Contractual / Global | Suma global por compilación completa del dossier de calidad final. |
