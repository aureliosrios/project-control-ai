# PRESUPUESTO, APU Y RENDIMIENTOS OFICIALES

**Proyecto:** Edificio Educativo Multidisciplinario (Casco Estructural) — Jr. Las Gardenias 480, Surquillo, Lima  
**Versión:** Rev. E (APU borrador) | **Fecha Base:** 2026-10-12  
**Moneda:** PEN | **Plazo Contractual:** 240 días  
**Costo Directo:** S/ 3,053,039.84 | **Presupuesto Total:** S/ 4,251,052.67

---

## 1. Resumen Económico por Capítulos
| Código | Capítulo Contractual | Costo Directo (S/) | % Incidencia |
|---|---|---:|---:|
| **01.00** | TRABAJOS PRELIMINARES | S/ 27,979.58 | 0.92% |
| **02.00** | OBRAS TEMPORALES, SOSTENIMIENTO Y MONITOREO GEOTÉCNICO | S/ 337,710.70 | 11.06% |
| **03.00** | MOVIMIENTO DE TIERRAS | S/ 220,531.20 | 7.22% |
| **04.00** | CONCRETO SIMPLE Y PREPARACIÓN DE FONDO | S/ 66,690.28 | 2.18% |
| **05.00** | CIMENTACIONES DE CONCRETO ARMADO | S/ 201,017.81 | 6.58% |
| **06.00** | ESTRUCTURAS ESPECIALES DE SÓTANOS | S/ 484,677.97 | 15.88% |
| **07.00** | SUPERESTRUCTURA DE CONCRETO ARMADO | S/ 1,234,787.75 | 40.44% |
| **08.00** | AZOTEA Y ELEMENTOS TÉCNICOS | S/ 82,790.25 | 2.71% |
| **09.00** | ALBAÑILERÍA Y ACABADOS BÁSICOS EN CASCO | S/ 256,830.09 | 8.41% |
| **10.00** | INTERFACES E INSTALACIONES SANITARIAS EMBEBIDAS | S/ 57,394.27 | 1.88% |
| **11.00** | INTERFACES E INSTALACIONES ELÉCTRICAS Y COMUNICACIONES EMBEBIDAS | S/ 28,191.20 | 0.92% |
| **12.00** | INTERFACES MECÁNICAS, VENTILACIÓN Y CONTRA INCENDIOS EMBEBIDAS | S/ 24,914.14 | 0.82% |
| **13.00** | ASEGURAMIENTO Y CONTROL DE CALIDAD (QA/QC) | S/ 29,524.60 | 0.97% |
| **TOTAL** | **COSTO DIRECTO TOTAL** | **S/ 3,053,039.84** | **100.00%** |

---

## 2. Catálogo de Rendimientos APU y Cuadrillas Base (78 Partidas)
| Partida | APU ID | Descripción | Und | Metrado | Rend. (und/día) | Cuadrilla Base APU | C.U. (S/) | Parcial (S/) |
|---|---|---|---|---:|---:|---|---:|---:|
| `01.01` | APU-01.01 | Movilización y desmovilización de equipo pesado en cama baja de 30 Tn | glb | 1.00 | 0.50 | 1 MO-CAP + 1 MO-OPEQ + 2 MO-PEON | 7,314.72 | 7,314.72 |
| `01.02` | APU-01.02 | Instalaciones provisionales de agua, energía y desagüe de faena con tablero general | glb | 1.00 | 0.25 | 1 MO-CAP + 1 MO-OPER + 1 MO-ELECT + 2 MO-PEON | 4,306.56 | 4,306.56 |
| `01.03` | APU-01.03 | Cerramiento provisional perimetral con parantes tubulares de acero 2" y Malla Raschel 80% | m | 90.00 | 30.00 | 0.1 MO-CAP + 1 MO-OPER + 3 MO-PEON | 23.95 | 2,155.50 |
| `01.04` | APU-01.04 | Trazo, niveles y replanteo topográfico con Estación Total Láser Leica | m2 | 500.00 | 600.00 | 0.1 MO-CAP + 1 MO-TEC + 2 MO-PEON | 1.03 | 515.00 |
| `01.05` | APU-01.05 | Protección y desvío de interferencias de redes de servicios públicos (SEDAPAL/ENEL) | glb | 1.00 | 0.10 | 1 MO-CAP + 2 MO-OPER + 1 MO-OFIC + 2 MO-PEON | 12,112.80 | 12,112.80 |
| `01.06` | APU-01.06 | Limpieza, desbroce manual y acondicionamiento del terreno | m2 | 450.00 | 250.00 | 0.1 MO-CAP + 1 MO-OPER + 4 MO-PEON | 3.50 | 1,575.00 |
| `02.01` | APU-02.01 | Sostenimiento perimetral con perforadora hidráulica, anclajes Dywidag 32mm L=9m e inyección de lechada | m2 | 522.00 | 30.00 | 0.5 MO-CAP + 1 MO-TEC + 2 MO-OPER + 3 MO-PEON | 451.23 | 235,542.06 |
| `02.02` | APU-02.02 | Apuntalamiento provisional de estructuras colindantes con puntales telescópicos Multiprop y vigas HEB | und | 12.00 | 1.50 | 0.5 MO-CAP + 1 MO-ENCOF + 1 MO-OFIC + 2 MO-PEON | 2,732.32 | 32,787.84 |
| `02.03` | APU-02.03 | Instrumentación geotécnica: inclinómetros biaxiales profundos (2 und) y piezómetro abierto PZ-1 | glb | 1.00 | 0.10 | 0.5 MO-CAP + 2 MO-TEC + 1 MO-PEON | 8,487.20 | 8,487.20 |
| `02.04` | APU-02.04 | Monitoreo topográfico continuo de hitos geodésicos en colindancias con estación total (8 hitos) | mes | 4.00 | 0.04 | 0.1 MO-CAP + 1 MO-TEC | 7,663.20 | 30,652.80 |
| `02.05` | APU-02.05 | Sistema provisional de bombeo y achique de aguas de escorrentía con electrobomba sumergible 5 HP | glb | 1.00 | 0.01 | 0.1 MO-CAP + 0.5 MO-ELECT + 1 MO-PEON | 30,240.80 | 30,240.80 |
| `03.01` | APU-03.01 | Excavación masiva con excavadora sobre orugas 200 HP hasta cota -5.80 m | m3 | 3,200.00 | 480.00 | 0.1 MO-CAP + 1 MO-OPEQ + 1 MO-PEON | 6.45 | 20,640.00 |
| `03.02` | APU-03.02 | Excavación manual localizada para zapatas, vigas de cimentación, foso y cisterna | m3 | 250.00 | 3.50 | 0.1 MO-CAP + 0.5 MO-OPER + 2 MO-PEON | 128.78 | 32,195.00 |
| `03.03` | APU-03.03 | Carguío con cargador frontal CAT 950 y eliminación con volquetes de 15 m3 (d=10 km) | m3 | 4,100.00 | 600.00 | 0.1 MO-CAP + 5 MO-OPEQ + 1 MO-PEON | 37.14 | 152,274.00 |
| `03.04` | APU-03.04 | Relleno compactado con afirmado seleccionado de cantera y plancha vibratoria al 95% PM | m3 | 180.00 | 60.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-PEON | 78.79 | 14,182.20 |
| `03.05` | APU-03.05 | Perfilado y compactación de fondo de excavación (subrasante) con equipo liviano | m2 | 500.00 | 400.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-PEON | 2.48 | 1,240.00 |
| `04.01` | APU-04.01 | Solado de concreto premezclado f'c=140 kg/cm2 e=4" para zapatas, cisterna y fosos | m2 | 161.20 | 100.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-PEON | 33.40 | 5,384.08 |
| `04.02` | APU-04.02 | Cimientos corridos de concreto premezclado f'c=140 kg/cm2 + 30% piedra grande | m3 | 120.00 | 20.00 | 0.1 MO-CAP + 2 MO-OPER + 6 MO-PEON | 299.40 | 35,928.00 |
| `04.03` | APU-04.03 | Sobrecimientos de concreto premezclado f'c=175 kg/cm2 + 25% piedra mediana | m3 | 45.00 | 15.00 | 0.1 MO-CAP + 2 MO-OPER + 4 MO-PEON | 319.92 | 14,396.40 |
| `04.04` | APU-04.04 | Encofrado y desencofrado modular metálico con tablero fenólico para sobrecimientos | m2 | 180.00 | 14.00 | 0.1 MO-CAP + 1 MO-ENCOF + 1 MO-OFIC + 0.5 MO-PEON | 61.01 | 10,981.80 |
| `05.01` | APU-05.01 | Zapatas: Concreto premezclado f'c=210 kg/cm2 vaciado con bomba telescópica | m3 | 83.76 | 60.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-OFIC + 4 MO-PEON | 471.94 | 39,529.69 |
| `05.02` | APU-05.02 | Zapatas: Encofrado y desencofrado modular metálico | m2 | 137.44 | 14.00 | 0.1 MO-CAP + 1 MO-ENCOF + 1 MO-OFIC + 0.5 MO-PEON | 61.01 | 8,385.21 |
| `05.03` | APU-05.03 | Zapatas: Acero de refuerzo corrugado fy=4200 kg/cm2 Grado 60 habilitado en banco CNC | kg | 7,119.60 | 280.00 | 0.1 MO-CAP + 1 MO-FIERR + 1 MO-OFIC + 1 MO-PEON | 7.98 | 56,814.41 |
| `05.04` | APU-05.04 | Vigas de cimentación y amarre: Concreto premezclado f'c=210 kg/cm2 con bomba | m3 | 58.52 | 45.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-OFIC + 3 MO-PEON | 498.20 | 29,154.66 |
| `05.05` | APU-05.05 | Vigas de cimentación y amarre: Encofrado y desencofrado modular fenólico 18mm | m2 | 258.40 | 14.00 | 0.1 MO-CAP + 1 MO-ENCOF + 1 MO-OFIC + 0.5 MO-PEON | 61.01 | 15,764.98 |
| `05.06` | APU-05.06 | Vigas de cimentación y amarre: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 6,437.20 | 280.00 | 0.1 MO-CAP + 1 MO-FIERR + 1 MO-OFIC + 1 MO-PEON | 7.98 | 51,368.86 |
| `06.01` | APU-06.01 | Muros de contención / pantalla: Concreto premezclado f'c=280 kg/cm2 con bomba | m3 | 156.60 | 40.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-OFIC + 4 MO-PEON | 561.75 | 87,970.05 |
| `06.02` | APU-06.02 | Muros de contención / pantalla: Encofrado modular fenólico a dos caras con sistema de trepa | m2 | 1,044.00 | 12.00 | 0.1 MO-CAP + 1.5 MO-ENCOF + 1.5 MO-OFIC + 1 MO-PEON | 145.69 | 152,100.36 |
| `06.03` | APU-06.03 | Muros de contención / pantalla: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 14,094.00 | 260.00 | 0.1 MO-CAP + 1 MO-FIERR + 1 MO-OFIC + 1 MO-PEON | 8.21 | 115,711.74 |
| `06.04` | APU-06.04 | Losa de contacto de Sótano 2 e=15 cm concreto premezclado f'c=210 sobre lámina de polietileno HDPE 8 mils | m2 | 500.00 | 100.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-OFIC + 4 MO-PEON | 103.96 | 51,980.00 |
| `06.05` | APU-06.05 | Cisterna y cuarto de bombas: Estructura monolítica de concreto premezclado f'c=280 con impermeabilizante y waterstop | m3 | 42.50 | 15.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-OFIC + 3 MO-PEON | 805.38 | 34,228.65 |
| `06.06` | APU-06.06 | Cisterna y cuarto de bombas: Encofrado modular fenólico impermeable | m2 | 168.00 | 10.00 | 0.1 MO-CAP + 1.5 MO-ENCOF + 1 MO-OFIC + 0.5 MO-PEON | 87.54 | 14,706.72 |
| `06.07` | APU-06.07 | Rampa vehicular estructural: Losa inclinada e=18 cm concreto f'c=210 con acabado endurecido antideslizante | m2 | 125.00 | 60.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-OFIC + 3 MO-PEON | 89.29 | 11,161.25 |
| `06.08` | APU-06.08 | Sellos hidroexpansivos SikaSwell y cinta waterstop de PVC 6" en juntas frías de sótanos | m | 180.00 | 60.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 93.44 | 16,819.20 |
| `07.01` | APU-07.01 | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m | m3 | 48.60 | 40.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-OFIC + 4 MO-PEON | 561.75 | 27,301.05 |
| `07.02` | APU-07.02 | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos | m2 | 324.00 | 14.00 | 0.1 MO-CAP + 1.5 MO-ENCOF + 1 MO-OFIC + 0.5 MO-PEON | 115.88 | 37,545.12 |
| `07.03` | APU-07.03 | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica | kg | 7,290.00 | 250.00 | 0.1 MO-CAP + 1 MO-FIERR + 1 MO-OFIC + 1 MO-PEON | 8.34 | 60,798.60 |
| `07.04` | APU-07.04 | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba | m3 | 72.90 | 35.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-OFIC + 4 MO-PEON | 580.80 | 42,340.32 |
| `07.05` | APU-07.05 | Placas de concreto armado: Encofrado modular fenólico trepante | m2 | 486.00 | 14.00 | 0.1 MO-CAP + 1.5 MO-ENCOF + 1 MO-OFIC + 0.5 MO-PEON | 115.88 | 56,317.68 |
| `07.06` | APU-07.06 | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 8,748.00 | 250.00 | 0.1 MO-CAP + 1 MO-FIERR + 1 MO-OFIC + 1 MO-PEON | 8.34 | 72,958.32 |
| `07.07` | APU-07.07 | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba | m3 | 126.00 | 40.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-OFIC + 4 MO-PEON | 516.39 | 65,065.14 |
| `07.08` | APU-07.08 | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos | m2 | 560.00 | 12.00 | 0.1 MO-CAP + 1.5 MO-ENCOF + 1.5 MO-OFIC + 1 MO-PEON | 168.73 | 94,488.80 |
| `07.09` | APU-07.09 | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 15,120.00 | 260.00 | 0.1 MO-CAP + 1 MO-FIERR + 1 MO-OFIC + 1 MO-PEON | 8.21 | 124,135.20 |
| `07.10` | APU-07.10 | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 | m3 | 210.00 | 70.00 | 0.1 MO-CAP + 2 MO-OPER + 2 MO-OFIC + 5 MO-PEON | 464.50 | 97,545.00 |
| `07.11` | APU-07.11 | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares | m2 | 2,400.00 | 22.00 | 0.1 MO-CAP + 2 MO-ENCOF + 1.5 MO-OFIC + 1 MO-PEON | 123.05 | 295,320.00 |
| `07.12` | APU-07.12 | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 | kg | 12,600.00 | 300.00 | 0.1 MO-CAP + 1 MO-FIERR + 1 MO-OFIC + 1 MO-PEON | 7.78 | 98,028.00 |
| `07.13` | APU-07.13 | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre | und | 20,400.00 | 1,200.00 | 0.1 MO-CAP + 2 MO-OPER + 3 MO-PEON | 5.46 | 111,384.00 |
| `07.14` | APU-07.14 | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 | m3 | 18.90 | 15.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-OFIC + 3 MO-PEON | 451.77 | 8,538.45 |
| `07.15` | APU-07.15 | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos | m2 | 108.00 | 8.00 | 0.1 MO-CAP + 1 MO-ENCOF + 1 MO-OFIC + 0.5 MO-PEON | 198.38 | 21,425.04 |
| `07.16` | APU-07.16 | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 2,457.00 | 220.00 | 0.1 MO-CAP + 1 MO-FIERR + 1 MO-OFIC + 1 MO-PEON | 8.79 | 21,597.03 |
| `08.01` | APU-08.01 | Losa de techo de azotea e=20 cm concreto premezclado f'c=210 con membrana asfáltica e=3mm | m2 | 500.00 | 80.00 | 0.1 MO-CAP + 1 MO-OPER + 2 MO-OFIC + 4 MO-PEON | 126.56 | 63,280.00 |
| `08.02` | APU-08.02 | Parapeto perimetral de concreto armado f'c=210 h=1.10 m en azotea | m | 90.00 | 25.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-OFIC + 2 MO-PEON | 98.09 | 8,828.10 |
| `08.03` | APU-08.03 | Caseta de sala de máquinas de ascensor y cuarto técnico de bombas en concreto f'c=280 | m3 | 12.50 | 3.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-OFIC + 2 MO-PEON | 812.40 | 10,155.00 |
| `08.04` | APU-08.04 | Juntas de dilatación sísmica perimetral con tecnopor de 1" y sellador elastomérico de poliuretano | m | 65.00 | 50.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 8.11 | 527.15 |
| `09.01` | APU-09.01 | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga | m2 | 1,850.00 | 10.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 113.44 | 209,864.00 |
| `09.02` | APU-09.02 | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) | m3 | 28.50 | 6.00 | 0.1 MO-CAP + 1 MO-OPER + 0.5 MO-FIERR + 1.5 MO-PEON | 1,056.87 | 30,120.79 |
| `09.03` | APU-09.03 | Encofrado y desencofrado modular para columnetas y vigas de amarre | m2 | 195.00 | 12.00 | 0.1 MO-CAP + 1 MO-ENCOF + 1 MO-OFIC + 0.5 MO-PEON | 67.26 | 13,115.70 |
| `09.04` | APU-09.04 | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex | m | 420.00 | 50.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 8.88 | 3,729.60 |
| `10.01` | APU-10.01 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) | und | 96.00 | 20.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 20.27 | 1,945.92 |
| `10.02` | APU-10.02 | Red colectora de desagüe colgada PVC SAL 4" y 2" en sótanos | m | 280.00 | 25.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 16.22 | 4,541.60 |
| `10.03` | APU-10.03 | Montantes de ventilación y desagüe vertical PVC SAL 4" | m | 195.00 | 22.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 18.43 | 3,593.85 |
| `10.04` | APU-10.04 | Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje | und | 24.00 | 4.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 101.35 | 2,432.40 |
| `10.05` | APU-10.05 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM | m | 350.00 | 18.00 | 0.1 MO-CAP + 2 MO-OPER + 1 MO-PEON | 128.23 | 44,880.50 |
| `11.01` | APU-11.01 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos | und | 120.00 | 20.00 | 0.1 MO-CAP + 1 MO-ELECT + 1 MO-PEON | 21.09 | 2,530.80 |
| `11.02` | APU-11.02 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados | m | 1,850.00 | 120.00 | 0.1 MO-CAP + 1 MO-ELECT + 1 MO-PEON | 3.52 | 6,512.00 |
| `11.03` | APU-11.03 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) | m | 3,200.00 | 250.00 | 0.1 MO-CAP + 1 MO-ELECT + 1 MO-PEON | 1.69 | 5,408.00 |
| `11.04` | APU-11.04 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza | und | 210.00 | 25.00 | 0.1 MO-CAP + 1 MO-ELECT + 1 MO-PEON | 16.88 | 3,544.80 |
| `11.05` | APU-11.05 | Sistema de puesta a tierra integral de baja resistencia (< 5 ohmios) en foso de sótanos | und | 4.00 | 0.50 | 0.1 MO-CAP + 1 MO-ELECT + 2 MO-PEON | 2,548.90 | 10,195.60 |
| `12.01` | APU-12.01 | Pases estructurales coordinados BIM para ductos de presurización de escalera | und | 18.00 | 6.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 67.57 | 1,216.26 |
| `12.02` | APU-12.02 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) | m | 850.00 | 100.00 | 0.1 MO-CAP + 1 MO-ELECT + 1 MO-PEON | 4.22 | 3,587.00 |
| `12.03` | APU-12.03 | Anclajes y soportes antivibratorios para equipos electromecánicos de bombeo | und | 8.00 | 3.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 1,075.94 | 8,607.52 |
| `12.04` | APU-12.04 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego | und | 64.00 | 10.00 | 0.1 MO-CAP + 1 MO-OPER + 1 MO-PEON | 179.74 | 11,503.36 |
| `13.01` | APU-13.01 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto | und | 144.00 | 6.00 | 0.1 MO-CAP + 1 MO-TEC | 49.60 | 7,142.40 |
| `13.02` | APU-13.02 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) | und | 65.00 | 30.00 | 0.1 MO-CAP + 1 MO-TEC | 9.92 | 644.80 |
| `13.03` | APU-13.03 | Ensayos de tracción y doblado de acero de refuerzo en laboratorio acreditado | und | 12.00 | 4.00 | 0.1 MO-CAP + 1 MO-TEC | 87.65 | 1,051.80 |
| `13.04` | APU-13.04 | Pruebas hidrostáticas y de estanqueidad presurizada en redes y cisterna (72 horas) | glb | 1.00 | 0.10 | 0.1 MO-CAP + 1 MO-TEC + 1 MO-OPER | 5,136.00 | 5,136.00 |
| `13.05` | APU-13.05 | Ensayos de densidad de campo (cono de arena) en rellenos y subrasante al 95% PM | und | 18.00 | 8.00 | 0.1 MO-CAP + 1 MO-TEC | 37.20 | 669.60 |
| `13.06` | APU-13.06 | Elaboración y entrega del Dossier Final de Calidad y Planos As-Built en formato BIM/CAD | glb | 1.00 | 0.02 | 0.1 MO-CAP + 1 MO-TEC | 14,880.00 | 14,880.00 |
