# Núcleo determinista de presupuestos

Este es el único directorio operativo de `Agentes_de_Presupuesto`. El resto del contenido histórico se conserva fuera de las rutas activas y no constituye una fuente automática.

## Capacidades

- presupuesto jerárquico por WBS;
- análisis de precios unitarios;
- consolidado de insumos;
- gastos generales fijos y variables;
- utilidad e impuestos;
- fórmula polinómica;
- matriz de trazabilidad;
- JSON de cálculo y Excel con fórmulas vivas;
- validación de referencias y conciliación.

## Uso

```powershell
..\EJECUTAR_PRESUPUESTO_TRAZABLE.ps1 -Action validate -Input <proyecto.json> -Mode draft
..\EJECUTAR_PRESUPUESTO_TRAZABLE.ps1 -Action build -Input <proyecto.json> -OutputDir <salida> -Mode strict
..\EJECUTAR_PRESUPUESTO_TRAZABLE.ps1 -Action verify -Json <salida\budget_result.json> -Xlsx <salida\budget_live.xlsx>
```

En futuros proyectos, copia la plantilla a la carpeta del proyecto. No escribas datos particulares dentro de este núcleo.

## Política de emisión

- `draft` permite detectar vacíos sin presentar el archivo como presupuesto final.
- `strict` exige evidencia de metrados, EETT, fuentes de precios y referencias válidas.
- El resultado contractual está en inglés cuando `project.output_language` es `en`.
- Los catálogos históricos son solo referencias; nunca sustituyen una cotización o fuente aprobada sin registrar la decisión.
- El libro Excel conserva fórmulas cruzadas en APU, recursos, presupuesto, gastos generales, fórmula polinómica y controles.
