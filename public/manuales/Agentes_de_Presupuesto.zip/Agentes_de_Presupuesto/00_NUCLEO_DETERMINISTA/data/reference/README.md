# Catálogos de referencia

Los archivos de esta carpeta sirven únicamente para proponer candidatos de insumos y precios.

- Nunca se cargan automáticamente en un presupuesto.
- Cada recurso elegido debe registrarse en el JSON del proyecto con `price_source_id`, fecha y estado.
- En modo `strict`, una fuente `PENDING` bloquea la emisión final.
- Los precios históricos deben actualizarse o sustentarse mediante cotización local para la ubicación y fecha base del proyecto.

No se distribuye ningún catálogo dentro del núcleo activo. El catálogo anterior conservaba identificadores de licencia dentro de registros internos y fue archivado. Si se consulta manualmente, sus precios deben volver a sustentarse en el JSON del proyecto.
