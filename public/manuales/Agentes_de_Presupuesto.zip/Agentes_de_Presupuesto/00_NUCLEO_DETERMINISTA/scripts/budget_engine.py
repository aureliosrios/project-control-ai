#!/usr/bin/env python3
"""Deterministic, project-independent construction budget engine."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GENERIC_TERMS = {
    "materiales integrales", "equipos especiales", "operario especialista",
    "integral materials", "special equipment", "specialist operator",
}


def dec(value) -> Decimal:
    return Decimal(str(value))


def rounded(value: Decimal, places: int = 2) -> Decimal:
    quantum = Decimal(1).scaleb(-places)
    return value.quantize(quantum, rounding=ROUND_HALF_UP)


def plain(value):
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, dict):
        return {key: plain(item) for key, item in value.items()}
    if isinstance(value, list):
        return [plain(item) for item in value]
    return value


def load_json(path: Path):
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def unique_ids(rows, field, label, errors):
    seen = set()
    for row in rows:
        value = row.get(field)
        if not value:
            errors.append(f"{label}: missing {field}")
        elif value in seen:
            errors.append(f"{label}: duplicate {field} '{value}'")
        seen.add(value)


def validate(data, mode="strict"):
    errors, warnings = [], []
    required = {
        "schema_version", "project", "assumptions", "sources", "resources",
        "apus", "items", "general_conditions", "polynomial_groups",
    }
    missing = sorted(required - set(data))
    if missing:
        errors.append("Missing top-level fields: " + ", ".join(missing))
        return errors, warnings
    extra = sorted(set(data) - required)
    if extra:
        errors.append("Unknown top-level fields: " + ", ".join(extra))
    if not isinstance(data.get("project"), dict) or not isinstance(data.get("assumptions"), dict):
        errors.append("project and assumptions must be objects")
        return errors, warnings
    for field in ("sources", "resources", "apus", "items", "general_conditions", "polynomial_groups"):
        if not isinstance(data.get(field), list):
            errors.append(f"{field} must be an array")
    if errors:
        return errors, warnings
    nested_required = {
        "project": {"code", "name", "location", "client", "base_date", "currency", "output_language"},
        "assumptions": {"workday_hours", "profit_rate", "tax_rate", "contract_duration_months"},
        "sources": {"id", "kind", "title", "locator", "status"},
        "resources": {"id", "type", "description_es", "description_en", "unit", "unit_price", "price_source_id", "price_date", "index_code"},
        "apus": {"id", "wbs", "output_unit", "daily_output", "technical_source_ids", "components"},
        "items": {"wbs", "chapter", "description_es", "description_en", "unit", "quantity", "apu_id", "quantity_evidence_ids", "eett_source_ids"},
        "general_conditions": {"id", "class", "description_en", "quantity", "unit_price", "source_id"},
        "polynomial_groups": {"symbol", "index_code", "name_en", "resource_types"},
    }
    for section in ("project", "assumptions"):
        absent = sorted(nested_required[section] - set(data[section]))
        if absent:
            errors.append(f"{section}: missing fields " + ", ".join(absent))
    for section in ("sources", "resources", "apus", "items", "general_conditions", "polynomial_groups"):
        for position, row in enumerate(data[section], 1):
            if not isinstance(row, dict):
                errors.append(f"{section}[{position}] must be an object")
                continue
            absent = sorted(nested_required[section] - set(row))
            if absent:
                errors.append(f"{section}[{position}]: missing fields " + ", ".join(absent))
    if errors:
        return errors, warnings
    if data.get("schema_version") != "1.0":
        errors.append("schema_version must be 1.0")

    unique_ids(data["sources"], "id", "sources", errors)
    unique_ids(data["resources"], "id", "resources", errors)
    unique_ids(data["apus"], "id", "apus", errors)
    unique_ids(data["items"], "wbs", "items", errors)
    unique_ids(data["general_conditions"], "id", "general_conditions", errors)

    sources = {row.get("id"): row for row in data["sources"]}
    resources = {row.get("id"): row for row in data["resources"]}
    apus = {row.get("id"): row for row in data["apus"]}
    allowed_resource_types = {"LABOR", "MATERIAL", "EQUIPMENT", "SUBCONTRACT", "TOOLS"}

    for resource in data["resources"]:
        rid = resource.get("id", "?")
        if resource.get("type") not in allowed_resource_types:
            errors.append(f"Resource {rid}: invalid type")
        if dec(resource.get("unit_price", -1)) < 0:
            errors.append(f"Resource {rid}: unit_price cannot be negative")
        sid = resource.get("price_source_id")
        if sid not in sources:
            errors.append(f"Resource {rid}: unknown price source '{sid}'")
        elif mode == "strict" and sources[sid].get("status") == "PENDING":
            errors.append(f"Resource {rid}: price source '{sid}' is pending")
        descriptions = {str(resource.get("description_es", "")).strip().lower(), str(resource.get("description_en", "")).strip().lower()}
        if mode == "strict" and descriptions & GENERIC_TERMS:
            errors.append(f"Resource {rid}: generic resource descriptions are not allowed")

    for apu in data["apus"]:
        aid = apu.get("id", "?")
        if dec(apu.get("daily_output", 0)) <= 0:
            errors.append(f"APU {aid}: daily_output must be greater than zero")
        for sid in apu.get("technical_source_ids", []):
            if sid not in sources:
                errors.append(f"APU {aid}: unknown technical source '{sid}'")
            elif mode == "strict" and sources[sid].get("status") == "PENDING":
                errors.append(f"APU {aid}: technical source '{sid}' is pending")
        if mode == "strict" and not apu.get("technical_source_ids"):
            errors.append(f"APU {aid}: technical evidence is required")
        for pos, component in enumerate(apu.get("components", []), 1):
            rid = component.get("resource_id")
            if rid not in resources:
                errors.append(f"APU {aid}, component {pos}: unknown resource '{rid}'")
            has_crew = "crew" in component
            has_qty = "quantity" in component
            if has_crew == has_qty:
                errors.append(f"APU {aid}, component {pos}: provide either crew or quantity")

    for item in data["items"]:
        wbs = item.get("wbs", "?")
        if item.get("apu_id") not in apus:
            errors.append(f"Item {wbs}: unknown APU '{item.get('apu_id')}'")
        if dec(item.get("quantity", -1)) < 0:
            errors.append(f"Item {wbs}: quantity cannot be negative")
        evidence = item.get("quantity_evidence_ids", [])
        if mode == "strict" and not evidence:
            errors.append(f"Item {wbs}: quantity evidence is required")
        for sid in evidence + item.get("eett_source_ids", []):
            if sid not in sources:
                errors.append(f"Item {wbs}: unknown evidence source '{sid}'")
            elif mode == "strict" and sources[sid].get("status") == "PENDING":
                errors.append(f"Item {wbs}: evidence source '{sid}' is pending")

    for gc in data["general_conditions"]:
        sid = gc.get("source_id")
        if sid not in sources:
            errors.append(f"General condition {gc.get('id')}: unknown source '{sid}'")
        elif mode == "strict" and sources[sid].get("status") == "PENDING":
            errors.append(f"General condition {gc.get('id')}: source '{sid}' is pending")

    if not data["items"]:
        warnings.append("No budget items were provided")
    if not data["resources"]:
        warnings.append("No resources were provided")
    return errors, warnings


def calculate(data):
    assumptions = data["assumptions"]
    workday = dec(assumptions["workday_hours"])
    resources = {row["id"]: row for row in data["resources"]}
    apu_results = []
    apu_map = {}

    for apu in data["apus"]:
        daily_output = dec(apu["daily_output"])
        components = []
        total = Decimal("0")
        for component in apu["components"]:
            resource = resources[component["resource_id"]]
            waste = dec(component.get("waste_rate", 0))
            basis = "CREW" if "crew" in component else "EXPLICIT"
            base_qty = dec(component["crew"]) * workday / daily_output if basis == "CREW" else dec(component["quantity"])
            unit_qty = base_qty * (Decimal("1") + waste)
            partial = unit_qty * dec(resource["unit_price"])
            entry = {
                **component,
                "basis": basis,
                "resource_type": resource["type"],
                "resource_description_en": resource["description_en"],
                "resource_unit": resource["unit"],
                "calculated_unit_quantity": unit_qty,
                "unit_price": dec(resource["unit_price"]),
                "partial_cost": partial,
            }
            components.append(entry)
            total += partial
        result = {**apu, "components": components, "unit_cost": total}
        apu_results.append(result)
        apu_map[apu["id"]] = result

    items = []
    direct = Decimal("0")
    consolidated = defaultdict(lambda: Decimal("0"))
    for item in data["items"]:
        apu = apu_map[item["apu_id"]]
        qty = dec(item["quantity"])
        amount = qty * apu["unit_cost"]
        result = {**item, "unit_price": apu["unit_cost"], "amount": amount}
        items.append(result)
        direct += amount
        for component in apu["components"]:
            consolidated[component["resource_id"]] += qty * component["calculated_unit_quantity"]

    resource_results = []
    for resource in data["resources"]:
        qty = consolidated[resource["id"]]
        resource_results.append({**resource, "total_quantity": qty, "amount": qty * dec(resource["unit_price"])})

    gc_results, general_total = [], Decimal("0")
    for row in data["general_conditions"]:
        amount = dec(row["quantity"]) * dec(row["unit_price"])
        gc_results.append({**row, "amount": amount})
        general_total += amount

    profit = direct * dec(assumptions["profit_rate"])
    pre_tax = direct + general_total + profit
    tax = pre_tax * dec(assumptions["tax_rate"])
    grand_total = pre_tax + tax

    type_amounts = defaultdict(lambda: Decimal("0"))
    for row in resource_results:
        type_amounts[row["type"]] += row["amount"]
    polynomial = []
    for group in data["polynomial_groups"]:
        amount = sum((type_amounts[t] for t in group["resource_types"]), Decimal("0"))
        if not group["resource_types"]:
            amount += general_total + profit
        polynomial.append({**group, "amount": amount, "coefficient": Decimal("0")})
    for row in polynomial:
        row["coefficient"] = row["amount"] / pre_tax if pre_tax else Decimal("0")
    if polynomial:
        prior = sum((rounded(row["coefficient"], 3) for row in polynomial[:-1]), Decimal("0"))
        for row in polynomial[:-1]:
            row["rounded_coefficient"] = rounded(row["coefficient"], 3)
        polynomial[-1]["rounded_coefficient"] = Decimal("1.000") - prior if pre_tax else Decimal("0")
    formula = "K = " + " + ".join(f"{row['rounded_coefficient']:.3f}*{row['symbol']}r/{row['symbol']}o" for row in polynomial)

    source_map = {row["id"]: row for row in data["sources"]}
    traceability = []
    for item in items:
        ids = list(dict.fromkeys(item["quantity_evidence_ids"] + item["eett_source_ids"] + apu_map[item["apu_id"]]["technical_source_ids"]))
        traceability.append({
            "wbs": item["wbs"], "description_en": item["description_en"], "apu_id": item["apu_id"],
            "source_ids": ids, "sources": [source_map[sid] for sid in ids],
        })
    summary = {
        "direct_cost": direct, "general_conditions": general_total, "profit": profit,
        "pre_tax_total": pre_tax, "tax": tax, "grand_total": grand_total,
    }
    return {
        "schema_version": "1.0", "project": data["project"], "assumptions": assumptions,
        "sources": data["sources"], "apus": apu_results, "items": items,
        "resources": resource_results, "general_conditions": gc_results,
        "polynomial_formula": {"groups": polynomial, "expression": formula},
        "traceability": traceability, "summary": summary,
    }


def checksum_payload(data):
    payload = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def write_result(result, destination: Path, warnings, input_sha256):
    payload = plain(result)
    payload["validation"] = {"status": "PASS", "errors": [], "warnings": warnings}
    payload["input_sha256"] = input_sha256
    destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def find_node():
    configured = os.environ.get("CODEX_BUDGET_NODE")
    candidates = [configured, "node"] if configured else ["node"]
    for candidate in candidates:
        try:
            subprocess.run([candidate, "--version"], check=True, capture_output=True, text=True)
            return candidate
        except (OSError, subprocess.CalledProcessError):
            continue
    raise RuntimeError("Node.js not found. Set CODEX_BUDGET_NODE to the bundled Node executable.")


def command_validate(args):
    data = load_json(Path(args.input))
    errors, warnings = validate(data, args.mode)
    print(json.dumps({"status": "FAIL" if errors else "PASS", "errors": errors, "warnings": warnings}, ensure_ascii=False, indent=2))
    return 1 if errors else 0


def command_build(args):
    input_path = Path(args.input).resolve()
    output_dir = Path(args.output_dir).resolve()
    data = load_json(input_path)
    errors, warnings = validate(data, args.mode)
    if errors:
        print(json.dumps({"status": "FAIL", "errors": errors, "warnings": warnings}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 1
    output_dir.mkdir(parents=True, exist_ok=True)
    result_path = output_dir / "budget_result.json"
    workbook_path = output_dir / "budget_live.xlsx"
    write_result(calculate(data), result_path, warnings, checksum_payload(data))
    if not args.no_xlsx:
        fmt = getattr(args, "format", "presto")
        subprocess.run([find_node(), str(ROOT / "scripts" / "build_workbook.mjs"), str(result_path), str(workbook_path), fmt], check=True)
    print(json.dumps({"status": "PASS", "json": str(result_path), "xlsx": None if args.no_xlsx else str(workbook_path)}, ensure_ascii=False, indent=2))
    return 0


def command_verify(args):
    result = load_json(Path(args.json))
    errors = []
    summary = result.get("summary", {})
    expected = dec(summary.get("direct_cost", 0)) + dec(summary.get("general_conditions", 0)) + dec(summary.get("profit", 0)) + dec(summary.get("tax", 0))
    if abs(expected - dec(summary.get("grand_total", 0))) > Decimal("0.01"):
        errors.append("JSON summary does not reconcile")
    coeff = sum((dec(row["rounded_coefficient"]) for row in result.get("polynomial_formula", {}).get("groups", [])), Decimal("0"))
    if result.get("polynomial_formula", {}).get("groups") and coeff != Decimal("1.000"):
        errors.append(f"Polynomial coefficients sum to {coeff}, expected 1.000")
    xlsx_path = Path(args.xlsx)
    if not xlsx_path.exists() or xlsx_path.stat().st_size < 1000:
        errors.append("Workbook is missing or empty")
    else:
        try:
            completed = subprocess.run(
                [find_node(), str(ROOT / "scripts" / "verify_workbook.mjs"), str(xlsx_path.resolve())],
                check=False, capture_output=True, text=True,
            )
            if completed.returncode:
                errors.append("Workbook formula verification failed: " + (completed.stdout.strip() or completed.stderr.strip()))
        except RuntimeError as exc:
            errors.append(str(exc))
    print(json.dumps({"status": "FAIL" if errors else "PASS", "errors": errors, "grand_total": summary.get("grand_total"), "coefficient_sum": float(coeff)}, indent=2))
    return 1 if errors else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    validate_parser = sub.add_parser("validate")
    validate_parser.add_argument("--input", required=True)
    validate_parser.add_argument("--mode", choices=["draft", "strict"], default="strict")
    validate_parser.set_defaults(func=command_validate)
    build_parser = sub.add_parser("build")
    build_parser.add_argument("--input", required=True)
    build_parser.add_argument("--output-dir", required=True)
    build_parser.add_argument("--mode", choices=["draft", "strict"], default="strict")
    build_parser.add_argument("--format", choices=["s10", "presto"], default="presto")
    build_parser.add_argument("--no-xlsx", action="store_true")
    build_parser.set_defaults(func=command_build)
    verify_parser = sub.add_parser("verify")
    verify_parser.add_argument("--json", required=True)
    verify_parser.add_argument("--xlsx", required=True)
    verify_parser.set_defaults(func=command_verify)
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
