import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const [inputPath, outputPath, formatArg] = process.argv.slice(2);
if (!inputPath || !outputPath) throw new Error("Usage: build_workbook.mjs result.json output.xlsx [s10|presto]");
const fmt = (formatArg ?? "s10").toLowerCase();
const isPresto = fmt === "presto";

const data = JSON.parse(await fs.readFile(inputPath, "utf8"));
const wb = Workbook.create();

// Map items by apu_id so we get exact Partida Name for APU Card headers
const itemByApuIdMap = new Map();
data.items.forEach(it => itemByApuIdMap.set(it.apu_id, it));

// Official Sheet Names
const S_GEN = isPresto ? "DATOS_GENERALES_PRESTO" : "DATOS_GENERALES_S10";
const S_BUD = isPresto ? "PRESUPUESTO_Y_MEDICIONES" : "PRESUPUESTO_S10";
const S_CP1 = isPresto ? "CUADRO_PRECIOS_1" : null;
const S_APU = isPresto ? "DESCOMPOSICION_APU" : "ANALISIS_APU_S10";
const S_RES = isPresto ? "LISTADO_DE_CONCEPTOS" : "INSUMOS_RECURSOS_S10";
const S_GG  = isPresto ? "COSTES_INDIRECTOS" : "GASTOS_GENERALES_S10";

const sheetList = isPresto 
  ? [S_GEN, S_BUD, S_CP1, S_APU, S_RES, S_GG]
  : [S_GEN, S_BUD, S_APU, S_RES, S_GG];

for (const name of sheetList) wb.worksheets.add(name);

const navy = "#17365D", teal = "#0F6B66", pale = "#DCE6F1", white = "#FFFFFF";
const header = (sheet, range) => { 
  sheet.getRange(range).format = { fill: navy, font: { bold: true, color: white }, wrapText: true, borders: { preset: "inside", style: "thin", color: "#B4C6E7" } }; 
};
const subHeader = (sheet, range) => {
  sheet.getRange(range).format = { fill: teal, font: { bold: true, color: white }, wrapText: true };
};
const categoryHeader = (sheet, range) => {
  sheet.getRange(range).format = { fill: pale, font: { bold: true, color: navy } };
};
const finish = (sheet, used, widths = []) => {
  sheet.showGridLines = true;
  sheet.getRange(used).format.font = { name: "Aptos", size: 10 };
  widths.forEach(([range, width]) => { sheet.getRange(range).format.columnWidth = width; });
};
const title = (sheet, mainText, subText, endCol) => {
  sheet.getRange(`A1:${endCol}1`).merge();
  sheet.getRange("A1").values = [[mainText]];
  sheet.getRange(`A1:${endCol}1`).format = { fill: navy, font: { bold: true, color: white, size: 14 }, rowHeight: 24 };
  
  sheet.getRange(`A2:${endCol}2`).merge();
  sheet.getRange("A2").values = [[subText]];
  sheet.getRange(`A2:${endCol}2`).format = { fill: pale, font: { bold: true, color: navy, size: 9 }, rowHeight: 18 };
};
const money = '"S/" #,##0.00', pct = '0.00%', qtyFmt = '#,##0.0000', intFmt = '#,##0';

// ---------------------------------------------------------------------------
// 1. DATOS GENERALES (Linked Jornal cell B4 = 8.0)
// ---------------------------------------------------------------------------
{
  const s = wb.worksheets.getItem(S_GEN);
  const mainTitle = isPresto ? "DATOS GENERALES DE LA OBRA — PRESTO 2026" : "DATOS GENERALES DEL PROYECTO — S10 ERP";
  const subTitle = `PROYECTO: ${data.project.name} | CÓDIGO: ${data.project.code}`;
  title(s, mainTitle, subTitle, "C");

  s.getRange("A3:C3").values = [["PARÁMETRO DEL PROYECTO", "VALOR", "UNIDAD / DESCRIPCIÓN"]];
  header(s, "A3:C3");

  const areaTechada = data.project.area_techada_m2 ?? 4500.0;
  const plazoRef = data.project.plazo_meses_referencial ?? data.assumptions.contract_duration_months ?? 10.0;
  const costoM2Ref = data.project.costo_m2_referencial ?? 1260.00;
  const costoTotalRef = areaTechada * costoM2Ref;
  const grandTotal = data.summary.grand_total;
  const costoM2Real = grandTotal / areaTechada;
  const varM2Pct = (costoM2Real - costoM2Ref) / costoM2Ref;

  s.getRange("A4:C4").values = [["Jornada Laboral (Jornal)", data.assumptions.workday_hours, "Horas / Día (HH)"]];
  s.getRange("A5:C5").values = [["Duración del Contrato (Plazo de Obra)", data.assumptions.contract_duration_months, "Meses"]];
  s.getRange("A6:C6").values = [["Tasa de Utilidad / Beneficio", data.assumptions.profit_rate, "Porcentaje (%)"]];
  s.getRange("A7:C7").values = [["Tasa de IGV / IVA", data.assumptions.tax_rate, "Porcentaje (%)"]];
  s.getRange("A8:C8").values = [["Nombre del Proyecto", data.project.name, "Denominación Oficial"]];
  s.getRange("A9:C9").values = [["Código del Proyecto", data.project.code, "Identificador WBS"]];
  s.getRange("A10:C10").values = [["Cliente / Entidad", data.project.client, "Propietario"]];
  s.getRange("A11:C11").values = [["Lugar / Ubicación", data.project.location, "Ciudad, Región"]];
  s.getRange("A12:C12").values = [["Fecha Base de Presupuesto", data.project.base_date, "Vigencia de Precios"]];
  s.getRange("A13:C13").values = [["Moneda Oficial", data.project.currency, "Soles (PEN)"]];
  s.getRange("A14:C14").values = [["Área Techada Total de Construcción", areaTechada, "m²"]];
  s.getRange("A15:C15").values = [["Plazo Referencial Estimado (Gastos Generales)", plazoRef, "Meses (Estimación Agéntica / Mercado)"]];
  s.getRange("A16:C16").values = [["Costo Referencial Estimado por m²", costoM2Ref, "S/ por m² techado (Mercado Lima 2026)"]];
  s.getRange("A17:C17").values = [["Monto Referencial Estimado Total", costoTotalRef, "PEN (Área × Costo Ref/m²)"]];
  s.getRange("A18:C18").values = [["Costo Presupuestado Final por m²", costoM2Real, "S/ por m² techado (Presupuesto Final / Área)"]];
  s.getRange("A19:C19").values = [["Variación Presupuesto vs Estimación", varM2Pct, "Desviación Porcentual (Cálculo Agéntico)"]];

  s.getRange("B6:B7").format.numberFormat = pct;
  s.getRange("B19").format.numberFormat = "+0.00%;-0.00%;0.00%";
  s.getRange("B4:B5").format.numberFormat = "#,##0.0";
  s.getRange("B14").format.numberFormat = "#,##0.00";
  s.getRange("B15").format.numberFormat = "#,##0.0";
  s.getRange("B16").format.numberFormat = money;
  s.getRange("B17").format.numberFormat = money;
  s.getRange("B18").format.numberFormat = money;
  s.getRange("A4:C19").format.wrapText = true;
  s.getRange("A4:C19").format.rowHeight = 24;
  finish(s, "A1:C19", [["A:A", 38], ["B:B", 38], ["C:C", 38]]);
}

// Map of resource IDs to their row positions in INSUMOS/LISTADO
const resourceRowMap = new Map();
const resourceMap = new Map();
data.resources.forEach(r => resourceMap.set(r.id, r));

// ---------------------------------------------------------------------------
// 2. INSUMOS / LISTADO_DE_CONCEPTOS (Build first to map rows for APU formulas)
// ---------------------------------------------------------------------------
{
  const s = wb.worksheets.getItem(S_RES);
  const mainTitle = isPresto ? "LISTADO Y CUADRO DE CONCEPTOS / RECURSOS — PRESTO" : "LISTA CONSOLIDADA Y AGRUPADA DE INSUMOS DEL PROYECTO (S10 ERP)";
  const subTitle = isPresto ? `OBRA: ${data.project.name} | FECHA: ${data.project.base_date} | MONEDA: ${data.project.currency}` : `PROYECTO: ${data.project.name} | CLIENTE: ${data.project.client} | LUGAR: ${data.project.location}`;
  title(s, mainTitle, subTitle, "G");

  s.getRange("A4:G4").values = [["CÓDIGO", "DESCRIPCIÓN RECURSO / INSUMO", "UND.", "CANTIDAD TOTAL", "PRECIO UNIT. (S/)", "IMPORTE TOTAL (S/)", "ÍNDICE INEI"]];
  header(s, "A4:G4");

  const types = ["LABOR", "MATERIAL", "EQUIPMENT", "SUBCONTRACT"];
  const typeLabels = isPresto 
    ? { LABOR: "0 - MANO DE OBRA", MATERIAL: "1 - MATERIALES", EQUIPMENT: "2 - MAQUINARIA Y EQUIPO", SUBCONTRACT: "3 - SUBCONTRATOS" }
    : { LABOR: "MANO DE OBRA", MATERIAL: "MATERIALES", EQUIPMENT: "EQUIPOS Y HERRAMIENTAS", SUBCONTRACT: "SUBCONTRATOS" };

  let rRow = 5;
  for (const t of types) {
    const list = data.resources.filter(r => r.type === t);
    if (!list.length) continue;

    s.getRange(`A${rRow}:G${rRow}`).merge();
    s.getRange(`A${rRow}`).values = [[typeLabels[t]]];
    categoryHeader(s, `A${rRow}:G${rRow}`);
    rRow++;

    for (const r of list) {
      const cur = rRow++;
      resourceRowMap.set(r.id, cur);
      s.getRange(`A${cur}:C${cur}`).values = [[r.id, r.description_es || r.description_en, r.unit]];
      const totalQty = Number(r.total_quantity || 0);
      s.getRange(`D${cur}`).formulas = [[`=${totalQty}`]];
      s.getRange(`E${cur}`).values = [[r.unit_price]];
      s.getRange(`F${cur}`).formulas = [[`=D${cur}*E${cur}`]];
      s.getRange(`G${cur}`).values = [[r.index_code]];
      s.getRange(`D${cur}`).format.numberFormat = qtyFmt;
      s.getRange(`E${cur}:F${cur}`).format.numberFormat = money;
    }
  }

  s.getRange(`B5:B${Math.max(5, rRow - 1)}`).format.wrapText = true;
  s.getRange(`B5:B${Math.max(5, rRow - 1)}`).format.rowHeight = 28;
  finish(s, `A1:G${Math.max(5, rRow - 1)}`, [["A:A", 14], ["B:B", 62], ["C:C", 10], ["D:F", 18], ["G:G", 14]]);
}

// ---------------------------------------------------------------------------
// 3. ANALISIS_APU / DESCOMPOSICION_APU (Con Nombre Oficial Completo de Partida/Actividad)
// ---------------------------------------------------------------------------
const apuTotalRowMap = new Map();
const apuComponentCellMap = new Map();
{
  const s = wb.worksheets.getItem(S_APU);
  const mainTitle = isPresto ? "DESCOMPOSICIÓN Y ANÁLISIS DE PRECIOS UNITARIOS (APU) — PRESTO" : "ANÁLISIS DE PRECIOS UNITARIOS (APU) — S10 ERP";
  const subTitle = `PROYECTO: ${data.project.name} | VIGENCIA: ${data.project.base_date} | MONEDA: SOLES (S/)`;
  title(s, mainTitle, subTitle, "G");

  let cardRow = 4;
  for (const apu of data.apus) {
    // Get matching partida description from data.items
    const matchingItem = itemByApuIdMap.get(apu.id);
    const partidaName = matchingItem?.description_es || matchingItem?.description_en || apu.description_es || apu.description_en || apu.id;
    const fullPartidaTitle = `PARTIDA ${apu.wbs}: ${partidaName}`;

    // Card Header Row 1: FULL PARTIDA WBS CODE AND DESCRIPTION
    s.getRange(`A${cardRow}:G${cardRow}`).merge();
    s.getRange(`A${cardRow}`).values = [[fullPartidaTitle]];
    s.getRange(`A${cardRow}:G${cardRow}`).format = { fill: navy, font: { bold: true, color: white, size: 11 }, rowHeight: 22 };
    cardRow++;

    // Card Header Row 2: Metadata (Rendimiento, Unidad, Costo Unitario)
    const metaRow = cardRow++;
    s.getRange(`A${metaRow}:C${metaRow}`).merge();
    s.getRange(`A${metaRow}`).values = [[`Rendimiento: ${apu.daily_output} ${apu.output_unit}/día`]];
    s.getRange(`D${metaRow}:E${metaRow}`).merge();
    s.getRange(`D${metaRow}`).values = [[`Unidad: ${apu.output_unit}`]];
    s.getRange(`F${metaRow}:G${metaRow}`).merge();
    s.getRange(`A${metaRow}:G${metaRow}`).format = { fill: pale, font: { bold: true, color: navy }, rowHeight: 18 };

    // Sub-header row: Columns
    const colHeadRow = cardRow++;
    s.getRange(`A${colHeadRow}:G${colHeadRow}`).values = [["CÓDIGO", "DESCRIPCIÓN DEL RECURSO", "UNIDAD", "CUADRILLA", "CANTIDAD", "PRECIO (S/)", "PARCIAL (S/)"]];
    subHeader(s, `A${colHeadRow}:G${colHeadRow}`);

    const cardStartRow = cardRow;
    const types = ["LABOR", "MATERIAL", "EQUIPMENT", "SUBCONTRACT"];
    const typeLabels = isPresto 
      ? { LABOR: "0 - MANO DE OBRA", MATERIAL: "1 - MATERIALES", EQUIPMENT: "2 - MAQUINARIA Y EQUIPO", SUBCONTRACT: "3 - SUBCONTRATOS" }
      : { LABOR: "MANO DE OBRA", MATERIAL: "MATERIALES", EQUIPMENT: "EQUIPOS Y HERRAMIENTAS", SUBCONTRACT: "SUBCONTRATOS" };

    for (const t of types) {
      const components = apu.components.filter(c => resourceMap.get(c.resource_id)?.type === t);
      if (!components.length) continue;

      s.getRange(`A${cardRow}:G${cardRow}`).merge();
      s.getRange(`A${cardRow}`).values = [[typeLabels[t]]];
      categoryHeader(s, `A${cardRow}:G${cardRow}`);
      cardRow++;

      for (const c of components) {
        const row = cardRow++;
        apuComponentCellMap.set(`${apu.id}|${c.resource_id}`, row);
        const res = resourceMap.get(c.resource_id);
        const inRow = resourceRowMap.get(c.resource_id);

        s.getRange(`A${row}:C${row}`).values = [[c.resource_id, res?.description_es || res?.description_en, res?.unit]];
        
        // LIVE FORMULA LINKED TO JORNAL CELL B4 IN DATOS_GENERALES: Cantidad = Jornal * Cuadrilla / Rendimiento
        if (c.basis === "CREW") {
          s.getRange(`D${row}`).values = [[c.crew]];
          s.getRange(`E${row}`).formulas = [[`='${S_GEN}'!$B$4*D${row}/${apu.daily_output}*(1+${c.waste_rate || 0})`]];
        } else {
          s.getRange(`D${row}`).values = [[null]];
          s.getRange(`E${row}`).formulas = [[`=${c.quantity}*(1+${c.waste_rate || 0})`]];
        }
        
        s.getRange(`F${row}`).formulas = [[`='${S_RES}'!E${inRow}`]];
        s.getRange(`G${row}`).formulas = [[`=E${row}*F${row}`]];

        s.getRange(`E${row}`).format.numberFormat = qtyFmt;
        s.getRange(`F${row}:G${row}`).format.numberFormat = money;
      }
    }

    // Card Total Row
    const totalRow = cardRow++;
    apuTotalRowMap.set(apu.id, totalRow);

    // Link Costo Unitario formula in header meta row
    s.getRange(`F${metaRow}`).formulas = [[`="Costo Unitario: S/ " & TEXT(G${totalRow},"#,##0.00")`]];

    s.getRange(`A${totalRow}:F${totalRow}`).merge();
    s.getRange(`A${totalRow}`).values = [[`COSTO DIRECTO UNITARIO POR ${apu.output_unit.toUpperCase()}`]];
    s.getRange(`G${totalRow}`).formulas = [[`=SUM(G${cardStartRow}:G${totalRow - 1})`]];

    s.getRange(`A${totalRow}:G${totalRow}`).format = { fill: pale, font: { bold: true, color: navy }, borders: { preset: "doubleBottom", style: "thin", color: navy } };
    s.getRange(`G${totalRow}`).format.numberFormat = money;

    cardRow++;
  }

  s.getRange(`B4:B${Math.max(4, cardRow - 1)}`).format.wrapText = true;
  s.getRange(`B4:B${Math.max(4, cardRow - 1)}`).format.rowHeight = 28;
  finish(s, `A1:G${Math.max(4, cardRow - 1)}`, [["A:A", 14], ["B:B", 62], ["C:C", 10], ["D:D", 12], ["E:E", 14], ["F:G", 18]]);
}

// ---------------------------------------------------------------------------
// 4. CUADRO_PRECIOS_1 (Exclusivo PRESTO - Con Nombre Completo de Partida)
// ---------------------------------------------------------------------------
if (isPresto && S_CP1) {
  const s = wb.worksheets.getItem(S_CP1);
  title(s, "CUADRO DE PRECIOS Nº 1 — FORMATO PRESTO", `OBRA: ${data.project.name} | FECHA: ${data.project.base_date}`, "E");
  s.getRange("A4:E4").values = [["CÓDIGO", "RESUMEN DE PARTIDA", "UD", "PRECIO EN LETRA / CONCEPTO", "PRECIO EN CIFRA (S/)"]];
  header(s, "A4:E4");

  let cpRow = 5;
  for (const it of data.items) {
    const apuRow = apuTotalRowMap.get(it.apu_id);
    const row = cpRow++;
    const partidaName = it.description_es || it.description_en;
    s.getRange(`A${row}:D${row}`).values = [[it.wbs, partidaName, it.unit, `Precio Unitario Oficial de la Partida ${it.wbs}`]];
    s.getRange(`E${row}`).formulas = [[`='${S_APU}'!G${apuRow}`]];
    s.getRange(`E${row}`).format.numberFormat = money;
  }
  finish(s, `A1:E${Math.max(5, cpRow - 1)}`, [["A:A", 14], ["B:B", 50], ["C:C", 10], ["D:D", 40], ["E:E", 20]]);
}

// ---------------------------------------------------------------------------
// 5. GASTOS_GENERALES / COSTES_INDIRECTOS
// ---------------------------------------------------------------------------
let ggfTotalRow = 0, ggvTotalRow = 0;
{
  const s = wb.worksheets.getItem(S_GG);
  const mainTitle = isPresto ? "DESGLOSE DE COSTES INDIRECTOS (FIJOS Y VARIABLES) — PRESTO" : "DESGLOSE DE GASTOS GENERALES FIJOS (GGF) Y VARIABLES (GGV) — S10 ERP";
  const subTitle = "CÁLCULO CON SUELDOS EN VALORES ENTEROS Y ABSORCIÓN AUTOMATIZADA DE CENTAVOS";
  title(s, mainTitle, subTitle, "H");

  s.getRange("A4:B4").values = [["PARÁMETROS CONTRACTUALES (VINCULADOS)", "VALOR"]];
  header(s, "A4:B4");
  s.getRange("A5:A8").values = [
    ["Duración de Contrato (Meses)"],
    ["Jornada Laboral (Horas/Día)"],
    ["Tasa de Utilidad (%)"],
    ["Tasa de IGV / IVA (%)"]
  ];
  s.getRange("B5").formulas = [[`='${S_GEN}'!B5`]];
  s.getRange("B6").formulas = [[`='${S_GEN}'!B4`]];
  s.getRange("B7").formulas = [[`='${S_GEN}'!B6`]];
  s.getRange("B8").formulas = [[`='${S_GEN}'!B7`]];
  s.getRange("B7:B8").format.numberFormat = pct;

  const varHead = 10;
  const varLabel = isPresto ? "1.00 GASTOS INDIRECTOS VARIABLES (GIV)" : "1.00 GASTOS GENERALES VARIABLES (GGV)";
  s.getRange(`A${varHead}:H${varHead}`).merge();
  s.getRange(`A${varHead}`).values = [[varLabel]];
  s.getRange(`A${varHead}:H${varHead}`).format = { fill: navy, font: { bold: true, color: white }, rowHeight: 20 };

  const varStart = 11;
  s.getRange(`A${varStart}:H${varStart}`).values = [["ÍTEM", "DESCRIPCIÓN DEL GASTO", "CANT.", "UND.", "TIEMPO (MESES)", "% PARTICIP.", "COSTO MENSUAL (S/)", "IMPORTE TOTAL (S/)"]];
  subHeader(s, `A${varStart}:H${varStart}`);

  const variable = data.general_conditions.filter(g => g.class === "VARIABLE");
  variable.forEach((g, i) => {
    const row = varStart + 1 + i;
    const monthlyPrice = g.unit_price;
    s.getRange(`A${row}:D${row}`).values = [[`1.${String(i+1).padStart(2,"0")}`, g.description_en, 1.0, "mes"]];
    s.getRange(`E${row}`).formulas = [[`='${S_GEN}'!B5`]];
    s.getRange(`F${row}:G${row}`).values = [[1.0, monthlyPrice]];
    s.getRange(`H${row}`).formulas = [[`=C${row}*E${row}*F${row}*G${row}`]];
    s.getRange(`G${row}`).format.numberFormat = intFmt;
    s.getRange(`H${row}`).format.numberFormat = money;
  });

  ggvTotalRow = varStart + 1 + variable.length;
  s.getRange(`A${ggvTotalRow}:G${ggvTotalRow}`).merge();
  s.getRange(`A${ggvTotalRow}`).values = [[isPresto ? "TOTAL GASTOS INDIRECTOS VARIABLES (GIV)" : "TOTAL GASTOS GENERALES VARIABLES (GGV)"]];
  s.getRange(`H${ggvTotalRow}`).formulas = [[`=SUM(H${varStart + 1}:H${ggvTotalRow - 1})`]];
  s.getRange(`A${ggvTotalRow}:H${ggvTotalRow}`).format = { fill: pale, font: { bold: true, color: navy } };
  s.getRange(`H${ggvTotalRow}`).format.numberFormat = money;

  const fixedHead = ggvTotalRow + 2;
  const fixedLabel = isPresto ? "2.00 GASTOS INDIRECTOS FIJOS (GIF)" : "2.00 GASTOS GENERALES FIJOS (GGF)";
  s.getRange(`A${fixedHead}:H${fixedHead}`).merge();
  s.getRange(`A${fixedHead}`).values = [[fixedLabel]];
  s.getRange(`A${fixedHead}:H${fixedHead}`).format = { fill: navy, font: { bold: true, color: white }, rowHeight: 20 };

  const fixedStart = fixedHead + 1;
  s.getRange(`A${fixedStart}:H${fixedStart}`).values = [["ÍTEM", "DESCRIPCIÓN DEL GASTO", "CANT.", "UND.", "TIEMPO (MESES)", "% PARTICIP.", "COSTO UNITARIO (S/)", "IMPORTE TOTAL (S/)"]];
  subHeader(s, `A${fixedStart}:H${fixedStart}`);

  const fixed = data.general_conditions.filter(g => g.class === "FIXED");
  fixed.forEach((g, i) => {
    const row = fixedStart + 1 + i;
    s.getRange(`A${row}:G${row}`).values = [[`2.${String(i+1).padStart(2,"0")}`, g.description_en, g.quantity, "glb", 1, 1.0, g.unit_price]];
    s.getRange(`H${row}`).formulas = [[`=C${row}*G${row}`]];
    s.getRange(`G${row}:H${row}`).format.numberFormat = money;
  });

  ggfTotalRow = fixedStart + 1 + fixed.length;
  s.getRange(`A${ggfTotalRow}:G${ggfTotalRow}`).merge();
  s.getRange(`A${ggfTotalRow}`).values = [[isPresto ? "TOTAL GASTOS INDIRECTOS FIJOS (GIF)" : "TOTAL GASTOS GENERALES FIJOS (GGF)"]];
  s.getRange(`H${ggfTotalRow}`).formulas = [[`=SUM(H${fixedStart + 1}:H${ggfTotalRow - 1})`]];
  s.getRange(`A${ggfTotalRow}:H${ggfTotalRow}`).format = { fill: pale, font: { bold: true, color: navy } };
  s.getRange(`H${ggfTotalRow}`).format.numberFormat = money;

  const ggGrandRow = ggfTotalRow + 2;
  s.getRange(`A${ggGrandRow}:G${ggGrandRow}`).merge();
  s.getRange(`A${ggGrandRow}`).values = [[isPresto ? "TOTAL GENERAL DE GASTOS INDIRECTOS (GIF + GIV)" : "TOTAL GENERAL DE GASTOS GENERALES (GGF + GGV)"]];
  s.getRange(`H${ggGrandRow}`).formulas = [[`=H${ggvTotalRow}+H${ggfTotalRow}`]];
  s.getRange(`A${ggGrandRow}:H${ggGrandRow}`).format = { fill: navy, font: { bold: true, color: white }, borders: { preset: "doubleBottom", style: "thin", color: navy } };
  s.getRange(`H${ggGrandRow}`).format.numberFormat = money;

  s.getRange(`A4:B${ggGrandRow}`).format.wrapText = true;
  s.getRange(`A4:B${ggGrandRow}`).format.rowHeight = 26;
  finish(s, `A1:H${ggGrandRow}`, [["A:A", 22], ["B:B", 62], ["C:G", 14], ["H:H", 20]]);
}

// ---------------------------------------------------------------------------
// 6. PRESUPUESTO (Estándar Cliente S10 / Presto)
// ---------------------------------------------------------------------------
let budgetCDRow = 0;
{
  const s = wb.worksheets.getItem(S_BUD);
  const mainTitle = isPresto ? "PRESUPUESTO Y MEDICIONES — FORMATO PRESTO" : "PRESUPUESTO OFICIAL S10 ERP — ESTÁNDAR CLIENTE";
  const subTitle = `PROYECTO: ${data.project.name} | LUGAR: ${data.project.location} | FECHA: ${data.project.base_date} | MONEDA: SOLES (S/)`;
  title(s, mainTitle, subTitle, "F");

  s.getRange("A4:F4").values = [["ÍTEM", "DESCRIPCIÓN DE PARTIDA", "UND.", "METRADO", "PRECIO UNIT. (S/)", "IMPORTE (S/)"]];
  header(s, "A4:F4");

  let bRow = 5;
  const itemsByChapter = new Map();
  data.items.forEach(it => {
    const ch = it.wbs.split(".")[0] + ".00";
    if (!itemsByChapter.has(ch)) itemsByChapter.set(ch, []);
    itemsByChapter.get(ch).push(it);
  });

  const chapterNames = {
    "01.00": "TRABAJOS PRELIMINARES Y MOVIMIENTO DE TIERRAS",
    "02.00": "ESTRUCTURAS - DEBAJO DEL NIVEL CERO (SÓTANOS)",
    "03.00": "ESTRUCTURAS - SUPERESTRUCTURA (PISOS 1 AL 6 Y AZOTEA)",
    "04.00": "ARQUITECTURA - ALBAÑILERÍA Y TABIQUERÍA",
    "05.00": "ARQUITECTURA - REVOQUES, ENLUCIDOS Y REVESTIMIENTOS",
    "06.00": "ARQUITECTURA - PISOS, CONTRAPISOS Y ZÓCALOS",
    "07.00": "ARQUITECTURA - CARPINTERÍA Y CERRAJERÍA",
    "08.00": "INSTALACIONES SANITARIAS - AGUA Y DESAGÜE",
    "09.00": "INSTALACIONES ELÉCTRICAS Y COMUNICACIONES",
    "10.00": "INSTALACIONES MECÁNICAS Y CLIMATIZACIÓN",
    "11.00": "PROTECCIÓN CONTRA INCENDIOS",
    "12.00": "SEGURIDAD, SALUD Y MEDIO AMBIENTE EN TRABAJO",
    "13.00": "CONTROL DE CALIDAD Y DOSSIER DE OBRA"
  };

  for (const [chWbs, items] of itemsByChapter.entries()) {
    const chRow = bRow++;
    s.getRange(`A${chRow}:F${chRow}`).values = [[chWbs, chapterNames[chWbs] || items[0]?.chapter || "CAPÍTULO", null, null, null, null]];
    categoryHeader(s, `A${chRow}:F${chRow}`);

    for (const it of items) {
      const row = bRow++;
      const apuRow = apuTotalRowMap.get(it.apu_id);

      s.getRange(`A${row}:D${row}`).values = [[it.wbs, it.description_es || it.description_en, it.unit, it.quantity]];
      s.getRange(`E${row}`).formulas = [[`='${S_APU}'!G${apuRow}`]];
      s.getRange(`F${row}`).formulas = [[`=D${row}*E${row}`]];

      s.getRange(`D${row}`).format.numberFormat = qtyFmt;
      s.getRange(`E${row}:F${row}`).format.numberFormat = money;
    }
  }

  budgetCDRow = bRow++;
  s.getRange(`A${budgetCDRow}:E${budgetCDRow}`).merge();
  s.getRange(`A${budgetCDRow}`).values = [["COSTO DIRECTO TOTAL"]];
  s.getRange(`F${budgetCDRow}`).formulas = [[`=SUM(F5:F${budgetCDRow - 1})`]];
  s.getRange(`A${budgetCDRow}:F${budgetCDRow}`).format = { fill: pale, font: { bold: true, color: navy } };

  const ggfRow = bRow++;
  s.getRange(`A${ggfRow}:E${ggfRow}`).merge();
  s.getRange(`A${ggfRow}`).values = [[isPresto ? "GASTOS INDIRECTOS FIJOS (GIF)" : "GASTOS GENERALES FIJOS (GGF)"]];
  s.getRange(`F${ggfRow}`).formulas = [[`='${S_GG}'!H${ggfTotalRow}`]];

  const ggvRow = bRow++;
  s.getRange(`A${ggvRow}:E${ggvRow}`).merge();
  s.getRange(`A${ggvRow}`).values = [[isPresto ? "GASTOS INDIRECTOS VARIABLES (GIV)" : "GASTOS GENERALES VARIABLES (GGV)"]];
  s.getRange(`F${ggvRow}`).formulas = [[`='${S_GG}'!H${ggvTotalRow}`]];

  const profitRow = bRow++;
  s.getRange(`A${profitRow}:E${profitRow}`).merge();
  s.getRange(`A${profitRow}`).values = [[isPresto ? "BENEFICIO INDUSTRIAL (10.00%)" : "UTILIDAD (10.00%)"]];
  s.getRange(`F${profitRow}`).formulas = [[`=F${budgetCDRow}*'${S_GEN}'!$B$6`]];

  const subtotalRow = bRow++;
  s.getRange(`A${subtotalRow}:E${subtotalRow}`).merge();
  s.getRange(`A${subtotalRow}`).values = [["SUBTOTAL / VALOR REFERENCIAL (SIN IGV)"]];
  s.getRange(`F${subtotalRow}`).formulas = [[`=SUM(F${budgetCDRow}:F${profitRow})`]];
  s.getRange(`A${subtotalRow}:F${subtotalRow}`).format = { fill: pale, font: { bold: true, color: navy } };

  const taxRow = bRow++;
  s.getRange(`A${taxRow}:E${taxRow}`).merge();
  s.getRange(`A${taxRow}`).values = [[isPresto ? "IMPUESTO VALOR AÑADIDO (IGV 18%)" : "IMPUESTO GENERAL A LAS VENTAS (IGV 18%)"]];
  s.getRange(`F${taxRow}`).formulas = [[`=F${subtotalRow}*'${S_GEN}'!$B$7`]];

  const totalRow = bRow++;
  s.getRange(`A${totalRow}:E${totalRow}`).merge();
  s.getRange(`A${totalRow}`).values = [["PRESUPUESTO TOTAL DE LA OBRA (CON IGV)"]];
  s.getRange(`F${totalRow}`).formulas = [[`=F${subtotalRow}+F${taxRow}`]];
  s.getRange(`A${totalRow}:F${totalRow}`).format = { fill: navy, font: { bold: true, color: white, size: 11 }, borders: { preset: "doubleBottom", style: "thin", color: navy } };

  s.getRange(`F${budgetCDRow}:F${totalRow}`).format.numberFormat = money;

  s.getRange(`B4:B${totalRow}`).format.wrapText = true;
  s.getRange(`B4:B${totalRow}`).format.rowHeight = 30;
  finish(s, `A1:F${totalRow}`, [["A:A", 12], ["B:B", 72], ["C:C", 10], ["D:F", 18]]);
}

await fs.mkdir(path.dirname(outputPath), { recursive: true });
const out = await SpreadsheetFile.exportXlsx(wb); 
await out.save(outputPath);

console.log(`Workbook generated successfully: ${outputPath} (Format: ${fmt.toUpperCase()})`);
