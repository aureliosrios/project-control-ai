#!/usr/bin/env python3
"""Create a deterministic SHA-256 inventory before archiving legacy content."""

import argparse
import hashlib
import json
from pathlib import Path


def digest(path):
    sha = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            sha.update(block)
    return sha.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--exclude", action="append", default=[])
    args = parser.parse_args()
    root = Path(args.root).resolve()
    excluded = {name.casefold() for name in args.exclude}
    files = []
    for path in sorted(root.rglob("*"), key=lambda p: str(p).casefold()):
        relative = path.relative_to(root)
        if not path.is_file() or relative.parts[0].casefold() in excluded:
            continue
        files.append({"path": relative.as_posix(), "bytes": path.stat().st_size, "sha256": digest(path)})
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({"root": str(root), "file_count": len(files), "total_bytes": sum(x["bytes"] for x in files), "files": files}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"file_count": len(files), "total_bytes": sum(x["bytes"] for x in files), "output": str(output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
