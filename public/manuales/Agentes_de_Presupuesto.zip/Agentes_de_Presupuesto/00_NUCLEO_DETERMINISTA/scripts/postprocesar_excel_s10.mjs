// Postproceso genérico de la presentación Excel S10. No contiene datos de ninguna obra:
// todo se lee de la entrada canónica, del resultado del motor, de pendientes, del informe de supuestos y de meta.json.
import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const [inputXlsx, canonicalPath, resultPath, pendingPath, metaPath, supuestosPath, outputXlsx, qaDir] = process.argv.slice(2);
if (!inputXlsx || !canonicalPath || !resultPath || !pendingPath || !metaPath || !supuestosPath || !outputXlsx || !qaDir) {
  throw new Error("Uso: postprocesar_excel_s10.mjs entrada.xlsx canonica.json resultado.json pendientes.json meta.json supuestos_informe.json|- salida.xlsx qa_dir");
}

const readJson = async (p) => JSON.parse((await fs.readFile(p, "utf8")).replace(/^﻿/, ""));
const canonical = await readJson(canonicalPath);
const result = await readJson(resultPath);
const pending = await readJson(pendingPath);
const meta = await readJson(metaPath);
const supuestos = supuestosPath === "-" ? [] : await readJson(supuestosPath);
const wb = await SpreadsheetFile.importXlsx(await FileBlob.load(inputXlsx));

const ESTADO = meta.estado_etiqueta || "BORRADOR";
const REV = meta.revision || "R??";

const navy = "#17365D";
const lightGray = "#F2F2F2";
const amber = "#FFF2CC";
const amberText = "#9C6500";
const white = "#FFFFFF";
const redFill = "#FCE4D6";
const redText = "#9C0006";
const money = '"S/" #,##0.00';
const qtyFmt = "#,##0.0000";

function formatTitle(sheet, range, text) {
  const r = sheet.getRange(range);
  r.merge();
  r.values = [[text]];
  r.format = { fill: navy, font: { name: "Arial", size: 14, bold: true, color: white }, verticalAlignment: "center", rowHeight: 24 };
}
function formatHeader(sheet, range) {
  sheet.getRange(range).format = {
    fill: navy, font: { name: "Arial", size: 10, bold: true, color: white },
    horizontalAlignment: "center", verticalAlignment: "center", wrapText: true,
    borders: { preset: "all", style: "thin", color: "#B4C6E7" },
  };
}
function finishSheet(sheet, usedRange) {
  sheet.showGridLines = false;
  sheet.freezePanes.unfreeze();
  const target = typeof usedRange === "string" ? sheet.getRange(usedRange) : usedRange;
  target.format.font = { name: "Arial" };
  target.format.verticalAlignment = "center";
}
const addSheet = (name) => wb.worksheets.add(name);

const sourceById = Object.fromEntries(canonical.sources.map((s) => [s.id, s]));
const resourceById = Object.fromEntries(canonical.resources.map((r) => [r.id, r]));
const referenciales = new Set(pending.recursos_referenciales || []);
const profitPct = (Number(canonical.assumptions.profit_rate) * 100).toFixed(2);

// ---- Hojas S10 de la plantilla del motor ----
const gen = wb.worksheets.getItem("DATOS_GENERALES_S10");
formatTitle(gen, "A1:C1", `DATOS GENERALES DEL PROYECTO — S10 — ${ESTADO}`);
gen.getRange("B16:B17").clear({ applyTo: "contents" });
gen.getRange("B19").clear({ applyTo: "contents" });
gen.getRange("C16:C17").values = [["No proporcionado por el proyecto"], ["No calculado sin costo referencial aprobado"]];
gen.getRange("C19").values = [["No aplica sin costo referencial aprobado"]];
gen.getRange("C15").values = [["Meses (fuente: datos del proyecto)"]];
gen.getRange("A21:C21").values = [["CONTROL DE EMISIÓN", "VALOR", "ESTADO"]];
formatHeader(gen, "A21:C21");
gen.getRange("A22:C27").values = [
  ["Revisión", REV, ESTADO],
  ["Validación draft", meta.validacion_draft || "PASS", "Entrada canónica coherente"],
  ["Validación strict", meta.validacion_strict || "FAIL", meta.nota_strict || ""],
  ["Naturaleza de metrados", meta.naturaleza_metrados || "SIN CLASIFICAR", "Requiere aprobación"],
  ["Utilidad", Number(canonical.assumptions.profit_rate) * 100, meta.nota_utilidad || "Porcentaje sobre costo directo + gastos generales"],
  ["Gastos generales", result.summary.general_conditions, meta.nota_gg || ""],
];
gen.getRange("B26:B27").format.numberFormat = money;
gen.getRange("A24:C27").format.fill = amber;
gen.getRange("A24:C27").format.font = { name: "Arial", size: 10, color: amberText };
finishSheet(gen, "A1:C27");

const sheetTitles = {
  PRESUPUESTO_S10: `PRESUPUESTO S10 — ${ESTADO}`,
  ANALISIS_APU_S10: `ANÁLISIS DE PRECIOS UNITARIOS — S10 — ${ESTADO}`,
  INSUMOS_RECURSOS_S10: `INSUMOS Y RECURSOS — S10 — ${ESTADO}`,
  GASTOS_GENERALES_S10: `GASTOS GENERALES — S10 — ${ESTADO}`,
};
for (const name of Object.keys(sheetTitles)) {
  const sheet = wb.worksheets.getItem(name);
  const endCol = name === "GASTOS_GENERALES_S10" ? "H" : (name === "PRESUPUESTO_S10" ? "F" : "G");
  formatTitle(sheet, `A1:${endCol}1`, sheetTitles[name]);
  const used = sheet.getUsedRange();
  const values = used.values;
  let seq = 0;
  let lastGrp = "";
  for (let r = 0; r < values.length; r++) {
    const label = String(values[r]?.[0] ?? "");
    if (name === "PRESUPUESTO_S10" && label.startsWith("UTILIDAD")) {
      sheet.getRange(`A${r + 1}`).values = [[`UTILIDAD (${profitPct}%${meta.utilidad_pendiente ? " — PENDIENTE DE CONFIRMACIÓN" : ""})`]];
      if (meta.utilidad_pendiente) {
        sheet.getRange(`A${r + 1}:F${r + 1}`).format.fill = amber;
        sheet.getRange(`A${r + 1}:F${r + 1}`).format.font = { name: "Arial", size: 10, color: amberText, bold: true };
      }
    }
    if (name === "PRESUPUESTO_S10" && label.startsWith("PRESUPUESTO TOTAL")) {
      sheet.getRange(`A${r + 1}`).values = [[`TOTAL ${meta.estado_corto || "PROVISIONAL"} (CON IGV)`]];
    }
    if (name === "PRESUPUESTO_S10" && /^\d{2}\.00$/.test(label)) {
      const chapterItem = canonical.items.find((it) => it.wbs.startsWith(label.slice(0, 2) + "."));
      if (chapterItem) sheet.getRange(`B${r + 1}`).values = [[chapterItem.chapter]];
    }
    if (name === "INSUMOS_RECURSOS_S10" && resourceById[label]) {
      const res = resourceById[label];
      const src = sourceById[res.price_source_id];
      if ((src && src.status === "PENDING") || String(res.price_source_id).startsWith("SRC-SUP") || referenciales.has(label)) {
        sheet.getRange(`A${r + 1}:G${r + 1}`).format.fill = amber;
        sheet.getRange(`A${r + 1}:G${r + 1}`).format.font = { name: "Arial", size: 10, color: amberText };
      }
    }
    if (name === "GASTOS_GENERALES_S10" && /^[12]\.\d+$/.test(label) && !/\.0+$/.test(label)) {
      const grp = label[0];
      if (grp !== lastGrp) { seq = 0; lastGrp = grp; }
      seq++;
      const cell = sheet.getRange(`A${r + 1}`);
      cell.format.numberFormat = "@";
      cell.formulas = [[`="${grp}.${String(seq).padStart(2, "0")}"`]];
    }
  }
  if (name === "GASTOS_GENERALES_S10" && meta.nota_gg_hoja) {
    sheet.getRange("A2").values = [[meta.nota_gg_hoja]];
    sheet.getRange("A2:H2").format.fill = amber;
    sheet.getRange("A2:H2").format.font = { name: "Arial", size: 9, color: amberText, bold: true };
  }
  if (name === "ANALISIS_APU_S10" || name === "INSUMOS_RECURSOS_S10") {
    sheet.getRange("A:A").format.columnWidth = 24;
    sheet.getRange("B:B").format.columnWidth = 62;
  }
  finishSheet(sheet, used);
}

// ---- Hojas de apoyo ----
{
  const s = addSheet("SUBPARTIDAS_S10");
  formatTitle(s, "A1:F1", `ANÁLISIS DE SUBPARTIDAS — S10 — ${ESTADO}`);
  s.getRange("A3:F3").values = [["CÓDIGO", "DESCRIPCIÓN", "UND.", "CANTIDAD", "PRECIO UNIT.", "PARCIAL"]];
  formatHeader(s, "A3:F3");
  s.getRange("A5:F6").values = [
    ["N/A", "No se declararon subpartidas sustentadas en la entrada del proyecto.", null, null, null, null],
    ["CONTROL", "No se fabricaron subpartidas para completar esta hoja.", null, null, null, null],
  ];
  s.getRange("A5:F6").format.fill = lightGray;
  s.getRange("B:B").format.columnWidth = 70;
  s.getRange("A:A").format.columnWidth = 16;
  s.getRange("C:F").format.columnWidth = 16;
  finishSheet(s, "A1:F6");
}
{
  const s = addSheet("LISTADO_SUBPARTIDAS_S10");
  formatTitle(s, "A1:E1", `LISTADO DE SUBPARTIDAS — S10 — ${ESTADO}`);
  s.getRange("A3:E3").values = [["CÓDIGO", "DESCRIPCIÓN", "UND.", "PRECIO UNIT.", "ESTADO"]];
  formatHeader(s, "A3:E3");
  s.getRange("A5:E5").values = [["N/A", "Sin subpartidas declaradas y sustentadas", null, null, "NO APLICA"]];
  s.getRange("B:B").format.columnWidth = 70;
  s.getRange("A:A").format.columnWidth = 16;
  s.getRange("C:E").format.columnWidth = 18;
  finishSheet(s, "A1:E5");
}
const nItems = canonical.items.length;
{
  const s = addSheet("METRADOS_TRAZABLES");
  formatTitle(s, "A1:G1", `METRADOS TRAZABLES — ${ESTADO}`);
  s.getRange("A3:G3").values = [["WBS", "DESCRIPCIÓN", "UND.", "METRADO", "EVIDENCIA", "EETT", "CLASIFICACIÓN"]];
  formatHeader(s, "A3:G3");
  const rows = canonical.items.map((it) => [
    it.wbs, it.description_es, it.unit, it.quantity,
    it.quantity_evidence_ids.join(", "), it.eett_source_ids.join(", "), meta.naturaleza_metrados || "SIN CLASIFICAR",
  ]);
  s.getRange("A4").write(rows);
  s.getRange(`D4:D${3 + rows.length}`).format.numberFormat = qtyFmt;
  s.getRange(`B4:B${3 + rows.length}`).format.wrapText = true;
  s.getRange("A:A").format.columnWidth = 12;
  s.getRange("B:B").format.columnWidth = 70;
  s.getRange("C:D").format.columnWidth = 14;
  s.getRange("E:G").format.columnWidth = 25;
  finishSheet(s, `A1:G${3 + rows.length}`);
}
const nSources = canonical.sources.length;
{
  const s = addSheet("TRAZABILIDAD_REVISION");
  formatTitle(s, "A1:G1", `TRAZABILIDAD DE FUENTES — ${REV} ${ESTADO}`);
  s.getRange("A3:G3").values = [["ID", "TIPO", "ESTADO", "TÍTULO", "LOCALIZADOR", "FECHA", "SHA-256"]];
  formatHeader(s, "A3:G3");
  const rows = canonical.sources.map((src) => [src.id, src.kind, src.status, src.title, src.locator, src.date ?? "", src.sha256 ?? ""]);
  s.getRange("A4").write(rows);
  for (let i = 0; i < rows.length; i++) {
    if (rows[i][2] === "PENDING") {
      s.getRange(`A${4 + i}:G${4 + i}`).format.fill = redFill;
      s.getRange(`A${4 + i}:G${4 + i}`).format.font = { name: "Arial", size: 10, color: redText };
    } else if (rows[i][2] === "ASSUMPTION") {
      s.getRange(`A${4 + i}:G${4 + i}`).format.fill = amber;
      s.getRange(`A${4 + i}:G${4 + i}`).format.font = { name: "Arial", size: 10, color: amberText };
    }
  }
  s.getRange("A:A").format.columnWidth = 24;
  s.getRange("B:C").format.columnWidth = 14;
  s.getRange("D:E").format.columnWidth = 44;
  s.getRange("F:F").format.columnWidth = 14;
  s.getRange("G:G").format.columnWidth = 68;
  finishSheet(s, `A1:G${3 + rows.length}`);
}
{
  const s = addSheet("SUPUESTOS");
  formatTitle(s, "A1:J1", `SUPUESTOS DEL AGENTE — ${REV} — ORDENADOS POR IMPACTO`);
  s.getRange("A2").values = [["Cada supuesto completa información que no vino en la entrada. Los impactos se calculan por separado y pueden solaparse: no son sumables."]];
  s.getRange("A4:J4").values = [["Nº", "ID", "TEMA", "VALOR SUPUESTO", "BASE", "CONFIANZA", "IMPACTO (S/)", "% SOBRE SUBTOTAL SIN IGV", "ESTADO", "SUSTENTO"]];
  formatHeader(s, "A4:J4");
  const sub = result.summary.pre_tax_total || 1;
  const rows = supuestos.length
    ? supuestos.map((x, i) => [i + 1, x.id, x.tema, `${x.valor ?? ""} ${x.unidad ?? ""}`.trim(), x.base, x.confianza, x.impacto_importe ?? 0, (x.impacto_importe ?? 0) / sub, x.estado || "ABIERTO", x.sustento || ""])
    : [[1, "—", "Sin supuestos registrados", "", "", "", 0, 0, "", ""]];
  s.getRange("A5").write(rows);
  s.getRange(`G5:G${4 + rows.length}`).format.numberFormat = money;
  s.getRange(`H5:H${4 + rows.length}`).format.numberFormat = "0.00%";
  s.getRange(`A5:J${4 + rows.length}`).format.wrapText = true;
  s.getRange(`A5:J${4 + rows.length}`).format.fill = amber;
  s.getRange("A:A").format.columnWidth = 6;
  s.getRange("B:B").format.columnWidth = 12;
  s.getRange("C:C").format.columnWidth = 46;
  s.getRange("D:D").format.columnWidth = 24;
  s.getRange("E:F").format.columnWidth = 14;
  s.getRange("G:H").format.columnWidth = 16;
  s.getRange("I:I").format.columnWidth = 12;
  s.getRange("J:J").format.columnWidth = 80;
  finishSheet(s, `A1:J${4 + rows.length}`);
}
let nObs = 0;
{
  const s = addSheet("OBSERVACIONES");
  formatTitle(s, "A1:D1", `OBSERVACIONES Y PENDIENTES — ${REV}`);
  s.getRange("A3:D3").values = [["Nº", "TIPO", "OBSERVACIÓN", "ESTADO"]];
  formatHeader(s, "A3:D3");
  const rows = [];
  (pending.pendientes || []).forEach((text, i) => rows.push([i + 1, "CONTROL", text, "PENDIENTE"]));
  if ((pending.recursos_estimados_sin_precio_web || []).length) {
    rows.push([rows.length + 1, "PRECIOS", `${pending.recursos_estimados_sin_precio_web.length} recursos con estimación sin precio web: ${pending.recursos_estimados_sin_precio_web.join(", ")}`, "PENDIENTE"]);
  }
  if (supuestos.length) rows.push([rows.length + 1, "SUPUESTOS", `${supuestos.length} supuestos registrados; ver hoja SUPUESTOS.`, "REVISAR"]);
  rows.push([rows.length + 1, "VALIDACIÓN", meta.nota_validacion || "Ver manifiesto de la revisión.", "OBSERVADO"]);
  rows.push([rows.length + 1, "ALCANCE", "Presentación Excel contractual local S10; no es archivo nativo ni certifica importación.", "INFORMATIVO"]);
  nObs = rows.length;
  s.getRange("A4").write(rows);
  s.getRange(`A4:D${3 + rows.length}`).format.wrapText = true;
  s.getRange(`A4:D${2 + rows.length}`).format.fill = amber;
  s.getRange("A:A").format.columnWidth = 8;
  s.getRange("B:B").format.columnWidth = 18;
  s.getRange("C:C").format.columnWidth = 100;
  s.getRange("D:D").format.columnWidth = 18;
  finishSheet(s, `A1:D${3 + rows.length}`);
}

wb.recalculate();

// ---- Rangos de revisión visual dinámicos ----
const nChapters = new Set(canonical.items.map((i) => i.wbs.split(".")[0])).size;
const nApuRows = canonical.apus.reduce((a, x) => a + x.components.length + 6, 0) + 8;
const rBudget = nItems + nChapters + 16;
const rInsumos = canonical.resources.length + 14;
const rGG = canonical.general_conditions.length + 22;
const previews = [
  ["DATOS_GENERALES_S10", "A1:C27"],
  ["PRESUPUESTO_S10", `A1:F${rBudget}`],
  ["ANALISIS_APU_S10", `A1:G${Math.min(nApuRows, 120)}`],
  ["INSUMOS_RECURSOS_S10", `A1:G${rInsumos}`],
  ["GASTOS_GENERALES_S10", `A1:H${rGG}`],
  ["SUBPARTIDAS_S10", "A1:F6"],
  ["LISTADO_SUBPARTIDAS_S10", "A1:E5"],
  ["METRADOS_TRAZABLES", `A1:G${3 + nItems}`],
  ["TRAZABILIDAD_REVISION", `A1:G${3 + nSources}`],
  ["SUPUESTOS", `A1:J${4 + Math.max(supuestos.length, 1)}`],
  ["OBSERVACIONES", `A1:D${3 + nObs}`],
];

const keyChecks = {
  budget: (await wb.inspect({ kind: "table", sheetId: "PRESUPUESTO_S10", range: `A1:F${rBudget}`, include: "values,formulas", tableMaxRows: rBudget, tableMaxCols: 6, maxChars: 40000 })).ndjson,
  general: (await wb.inspect({ kind: "table", sheetId: "DATOS_GENERALES_S10", range: "A1:C27", include: "values,formulas", tableMaxRows: 30, tableMaxCols: 3, maxChars: 12000 })).ndjson,
  errors: (await wb.inspect({ kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!", options: { useRegex: true, maxResults: 300 }, summary: "final formula error scan" })).ndjson,
};
await fs.mkdir(qaDir, { recursive: true });
await fs.writeFile(path.join(qaDir, "inspeccion_clave.json"), JSON.stringify(keyChecks, null, 2));

for (const [sheetName, range] of previews) {
  const blob = await wb.render({ sheetName, range, scale: 1, format: "png" });
  await fs.writeFile(path.join(qaDir, `${sheetName}.png`), new Uint8Array(await blob.arrayBuffer()));
}

await fs.mkdir(path.dirname(outputXlsx), { recursive: true });
const out = await SpreadsheetFile.exportXlsx(wb);
await out.save(outputXlsx);
console.log(JSON.stringify({ status: "PASS", output: outputXlsx, sheets: previews.length, direct_cost: result.summary.direct_cost, grand_total: result.summary.grand_total }));
