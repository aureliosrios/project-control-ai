import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const [xlsxPath] = process.argv.slice(2);
if (!xlsxPath) throw new Error("Usage: verify_workbook.mjs workbook.xlsx");
const wb = await SpreadsheetFile.importXlsx(await FileBlob.load(xlsxPath));

// Auto-detect format (Presto vs S10)
let isPresto = false;
try { wb.worksheets.getItem("PRESUPUESTO_Y_MEDICIONES"); isPresto = true; } catch { isPresto = false; }

const S_GEN = isPresto ? "DATOS_GENERALES_PRESTO" : "DATOS_GENERALES_S10";
const S_BUD = isPresto ? "PRESUPUESTO_Y_MEDICIONES" : "PRESUPUESTO_S10";
const S_CP1 = isPresto ? "CUADRO_PRECIOS_1" : null;
const S_APU = isPresto ? "DESCOMPOSICION_APU" : "ANALISIS_APU_S10";
const S_RES = isPresto ? "LISTADO_DE_CONCEPTOS" : "INSUMOS_RECURSOS_S10";
const S_GG  = isPresto ? "COSTES_INDIRECTOS" : "GASTOS_GENERALES_S10";

const required = isPresto 
  ? [S_GEN, S_BUD, S_CP1, S_APU, S_RES, S_GG]
  : [S_GEN, S_BUD, S_APU, S_RES, S_GG];

const errors = [];
for (const name of required) {
  try { wb.worksheets.getItem(name); } catch { errors.push(`Missing sheet: ${name}`); }
}

const norm = (f) => (typeof f === "string" ? f.replace(/['$]/g, "") : f);
const getFormula = (sheetName, cell) => {
  try { return wb.worksheets.getItem(sheetName).getRange(cell).formulas?.[0]?.[0]; } catch { return undefined; }
};
const linksTo = (f, sheet, col) => typeof f === "string" && norm(f).includes(`${sheet}!${col}`);
const starts = (f, prefix) => typeof f === "string" && f.startsWith(prefix);

// scan a column range for any formula containing needle
function colHas(sheetName, col, from, to, needle) {
  const s = wb.worksheets.getItem(sheetName);
  for (let r = from; r <= to; r++) {
    const f = s.getRange(`${col}${r}`).formulas?.[0]?.[0];
    if (typeof f === "string" && f.includes(needle)) return true;
  }
  return false;
}

// 1. DATOS GENERALES verification
try {
  const sGen = wb.worksheets.getItem(S_GEN);
  const jornalVal = sGen.getRange("B4").values?.[0]?.[0];
  if (Number(jornalVal) !== 8) errors.push(`${S_GEN}!B4 must be 8.0 (Jornada laboral)`);
} catch (e) {
  errors.push(`Error checking ${S_GEN}: ${e.message}`);
}

// 2. APU Live Formula verification. The first APU may legitimately start with a
// material, equipment or subcontract component, so locate the first CREW row
// instead of assuming that row 8 is always labor.
let crewRow = null;
for (let r = 4; r <= 600; r++) {
  if (linksTo(getFormula(S_APU, `E${r}`), S_GEN, "B4")) {
    crewRow = r;
    break;
  }
}
if (crewRow === null) {
  errors.push(`${S_APU} has no crew quantity formula linked to ${S_GEN}!B4 (Jornal)`);
} else {
  if (!linksTo(getFormula(S_APU, `F${crewRow}`), S_RES, "E")) errors.push(`${S_APU}!F${crewRow} price formula must link to ${S_RES} unit price (col E)`);
  if (!starts(getFormula(S_APU, `G${crewRow}`), `=E${crewRow}*F${crewRow}`)) errors.push(`${S_APU}!G${crewRow} missing live formula =E${crewRow}*F${crewRow}`);
}

// 3. PRESUPUESTO verification (Precio Unitario links to APU total col G; Parcial = D*E)
if (!linksTo(getFormula(S_BUD, "E6"), S_APU, "G")) errors.push(`${S_BUD}!E6 must link to APU total (col G)`);
if (!starts(getFormula(S_BUD, "F6"), "=D6*E6")) errors.push(`${S_BUD}!F6 must be =D6*E6`);

// 4. INSUMOS / LISTADO verification (Total Quantity col D and Monto col F are live)
if (!starts(getFormula(S_RES, "D6"), "=")) errors.push(`${S_RES}!D6 (cantidad total) missing live formula`);
if (!starts(getFormula(S_RES, "F6"), "=D6*E6")) errors.push(`${S_RES}!F6 (monto total) missing live formula =D6*E6`);

// 5. GASTOS GENERALES / COSTES INDIRECTOS verification (Linked to DATOS_GENERALES!B5 for contract duration)
if (!linksTo(getFormula(S_GG, "E12"), S_GEN, "B5")) errors.push(`${S_GG}!E12 (duración meses) must link to ${S_GEN}!B5`);

// 6. Presto CUADRO_PRECIOS_1 verification
if (isPresto && S_CP1) {
  if (!linksTo(getFormula(S_CP1, "E5"), S_APU, "G")) errors.push(`${S_CP1}!E5 must link to APU total (col G)`);
}

// 7. Reconciliation scans
if (!colHas(S_APU, "G", 4, 600, "=SUM")) errors.push(`${S_APU} missing APU total =SUM formula`);
if (!colHas(S_BUD, "F", 4, 600, "=SUM")) errors.push(`${S_BUD} missing summary =SUM formula`);

// Formula error scan (parsing actual match objects)
const errorScan = await wb.inspect({ kind: "match", searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A", options: { useRegex: true, maxResults: 100 }, summary: "formula error scan" });
const scanText = errorScan.ndjson ?? String(errorScan);
const actualMatches = scanText.split(/\r?\n/).filter(line => {
  if (!line.trim()) return false;
  try {
    const parsed = JSON.parse(line);
    return parsed.cell || parsed.range || (parsed.text && /#REF!|#DIV\/0!|#VALUE!|#NAME\?|#N\/A/.test(parsed.text) && !parsed.searchTerm);
  } catch {
    return false;
  }
});
if (actualMatches.length) errors.push(`Formula error scan returned ${actualMatches.length} match(es)`);

console.log(JSON.stringify({ status: errors.length ? "FAIL" : "PASS", errors, format: isPresto ? "PRESTO" : "S10", required_sheets: required.length }));
process.exitCode = errors.length ? 1 : 0;
