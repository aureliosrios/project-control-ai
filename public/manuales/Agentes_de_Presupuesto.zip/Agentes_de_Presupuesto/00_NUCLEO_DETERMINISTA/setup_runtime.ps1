$ErrorActionPreference='Stop'
# Enlaza node_modules del núcleo con una carpeta node_modules que contenga @oai/artifact-tool.
# Defina CODEX_BUDGET_NODE_MODULES con esa carpeta si no está en la ubicación habitual del runtime de Codex.
$Default=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules'
$DependencyPath=if($env:CODEX_BUDGET_NODE_MODULES){$env:CODEX_BUDGET_NODE_MODULES}else{$Default}
$LinkPath=Join-Path $PSScriptRoot 'node_modules'
if(-not(Test-Path -LiteralPath (Join-Path $DependencyPath '@oai\artifact-tool'))){throw "No se encontró @oai/artifact-tool en '$DependencyPath'. Defina CODEX_BUDGET_NODE_MODULES con la carpeta node_modules que lo contiene. Sin él se genera y valida el JSON (generar_presupuesto.py --sin-excel), pero no el Excel."}
if(-not(Test-Path -LiteralPath $LinkPath)){New-Item -ItemType Junction -Path $LinkPath -Target $DependencyPath | Out-Null}
Write-Host "Runtime disponible: $LinkPath"
