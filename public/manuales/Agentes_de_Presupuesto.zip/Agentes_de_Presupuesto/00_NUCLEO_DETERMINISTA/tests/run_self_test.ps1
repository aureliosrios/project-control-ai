$ErrorActionPreference = "Stop"
$Core = Split-Path -Parent $PSScriptRoot
$Python = if ($env:CODEX_BUDGET_PYTHON) { $env:CODEX_BUDGET_PYTHON } else { "python" }
& $Python "$Core\scripts\budget_engine.py" validate --input "$PSScriptRoot\fixture_minimal.json" --mode strict
& $Python "$Core\scripts\budget_engine.py" build --input "$PSScriptRoot\fixture_minimal.json" --output-dir "$PSScriptRoot\output" --mode strict
& $Python "$Core\scripts\budget_engine.py" verify --json "$PSScriptRoot\output\budget_result.json" --xlsx "$PSScriptRoot\output\budget_live.xlsx"
