#!/usr/bin/env python3
import copy
import importlib.util
import json
from pathlib import Path

CORE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("budget_engine", CORE / "scripts" / "budget_engine.py")
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
fixture = json.loads((Path(__file__).parent / "fixture_minimal.json").read_text(encoding="utf-8"))

errors, _ = engine.validate(fixture, "strict")
assert not errors, errors
result = engine.calculate(fixture)
assert engine.rounded(result["summary"]["grand_total"], 2) == engine.dec("122222.04")
assert sum((row["rounded_coefficient"] for row in result["polynomial_formula"]["groups"]), engine.dec(0)) == engine.dec("1.000")

no_evidence = copy.deepcopy(fixture)
no_evidence["items"][0]["quantity_evidence_ids"] = []
assert any("quantity evidence" in message for message in engine.validate(no_evidence, "strict")[0])
assert not engine.validate(no_evidence, "draft")[0]

pending_price = copy.deepcopy(fixture)
pending_price["sources"][2]["status"] = "PENDING"
assert any("price source" in message for message in engine.validate(pending_price, "strict")[0])

generic = copy.deepcopy(fixture)
generic["resources"][0]["description_en"] = "Special equipment"
assert any("generic resource" in message for message in engine.validate(generic, "strict")[0])

print("PASS: deterministic calculations and strict blocking controls")
