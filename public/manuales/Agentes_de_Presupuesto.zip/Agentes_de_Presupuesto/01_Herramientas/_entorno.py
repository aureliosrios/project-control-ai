"""Localización portátil de Python, Node y dependencias. Sin rutas fijas de una PC.

Orden de búsqueda: variable de entorno > ejecutable actual/PATH > ubicación habitual del runtime de Codex.
"""

from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
NUCLEO = ROOT / "Agentes_de_Presupuesto" / "00_NUCLEO_DETERMINISTA"
HERRAMIENTAS = ROOT / "Agentes_de_Presupuesto" / "01_Herramientas"


def _codex_runtime() -> Path:
    return Path.home() / ".cache" / "codex-runtimes" / "codex-primary-runtime" / "dependencies"


def find_python() -> str:
    env = os.environ.get("CODEX_BUDGET_PYTHON")
    if env and Path(env).is_file():
        return env
    return sys.executable


def find_node() -> str:
    env = os.environ.get("CODEX_BUDGET_NODE")
    if env and Path(env).is_file():
        return env
    found = shutil.which("node")
    if found:
        return found
    candidate = _codex_runtime() / "node" / "bin" / ("node.exe" if os.name == "nt" else "node")
    if candidate.is_file():
        return str(candidate)
    raise RuntimeError("Node.js no encontrado. Instalar Node o definir CODEX_BUDGET_NODE con la ruta de node.")


def artifact_tool_ok() -> bool:
    return (NUCLEO / "node_modules" / "@oai" / "artifact-tool").exists()


def diagnostico() -> dict:
    """Informe de requisitos para llevar el agente a otra PC."""
    info = {"python": find_python(), "node": None, "artifact_tool": artifact_tool_ok(), "problemas": []}
    try:
        info["node"] = find_node()
    except RuntimeError as exc:
        info["problemas"].append(str(exc))
    if not info["artifact_tool"]:
        info["problemas"].append(
            "Falta el paquete @oai/artifact-tool en 00_NUCLEO_DETERMINISTA/node_modules. "
            "Ejecutar 00_NUCLEO_DETERMINISTA/setup_runtime.ps1 (define CODEX_BUDGET_NODE_MODULES con la carpeta node_modules que lo contiene). "
            "Sin él se genera el JSON y se valida, pero no el Excel."
        )
    return info


if __name__ == "__main__":
    import json

    print(json.dumps(diagnostico(), ensure_ascii=False, indent=2))
