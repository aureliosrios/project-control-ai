"""Migración trazable USD autorizada. Conserva PEN y convierte sólo importes."""
import argparse, datetime, json, re, subprocess
from pathlib import Path
import openpyxl
from openpyxl.styles import Font, Alignment
from generar_presentacion import ROOT, digest, equivalent

def monetary(sheet,cell):
    if isinstance(cell.value,bool) or not isinstance(cell.value,(int,float)):return False
    if 'S/' in cell.number_format:return True
    if sheet.title=='COMPARATIVO' and cell.row>=5 and cell.column in (4,5):return True
    if sheet.title=='ANALISIS_APU_S10' and cell.column==7:return True
    if sheet.title=='CONFIG_HSE_QA' and cell.column==2:return str(sheet.cell(cell.row,3).value or '').startswith('S/')
    return False

def main():
    a=argparse.ArgumentParser();a.add_argument('--proyecto',required=True);a.add_argument('--tipo-cambio',type=float,required=True);args=a.parse_args()
    if args.tipo_cambio<=0:a.error('Tipo de cambio positivo requerido')
    p=ROOT/'Proyectos'/args.proyecto;meta_path=p/'proyecto.json';meta=json.loads(meta_path.read_text(encoding='utf-8-sig'))
    if meta.get('moneda_entregables')=='USD':raise ValueError('Ya está activado USD; editar su tipo de cambio vivo, no convertir otra vez')
    source=p/meta['entregables']['excel']; original_json=p/meta['entregables']['json'];canonical=p/meta['entradas']['canonico']
    folder=source.parent/f'USD_{datetime.datetime.now():%Y%m%d_%H%M%S}'
    folder.mkdir();out=folder/'R02_USD.xlsx';snapshot_path=folder/'R02_USD.json'
    w=openpyxl.load_workbook(source);cache_original=openpyxl.load_workbook(source,data_only=True)
    gen=w['DATOS_GENERALES_S10'];gen['A20']='Tipo de cambio PEN por US$';gen['B20']=args.tipo_cambio;gen['C20']='Valor 3,40 confirmado por el usuario. Editable.'
    gen['A21']='Moneda del entregable';gen['B21']='USD';gen['C21']='Cotizaciones base conservadas en BASE_PRECIOS_PEN'
    base=w.create_sheet('BASE_PRECIOS_PEN');base.append(['HOJA ORIGEN','CELDA','DESCRIPCIÓN / CONTEXTO','PRECIO BASE PEN'])
    converted={};rates="'DATOS_GENERALES_S10'!$B$20"
    for s in list(w):
        if s==base:continue
        for row in s:
            for c in row:
                if monetary(s,c):
                    pen=c.value;desc=s.cell(c.row,3).value or s.cell(c.row,2).value or s.title
                    base.append([s.title,c.coordinate,str(desc),pen]);ref=f"='BASE_PRECIOS_PEN'!D{base.max_row}/{rates}"
                    converted[f'{s.title}!{c.coordinate}']={'pen':pen,'usd':pen/args.tipo_cambio,'formula':ref}
                    c.value=ref;c.number_format='"US$" #,##0.00'
                elif 'S/' in c.number_format:c.number_format='"US$" #,##0.00'
                if c.data_type!='f' and isinstance(c.value,str) and 'S/' in c.value and len(c.value)<=80:
                    amount=re.fullmatch(r'S/\s*([\d,]+(?:\.\d+)?)',c.value.strip())
                    if amount:c.value=f'US$ {float(amount[1].replace(",",""))/args.tipo_cambio:,.2f}'
                    else:c.value=re.sub(r'S/\.?(?=[A-Za-z])','US$/',c.value);c.value=re.sub(r'S/\.?','US$',c.value)
        s.freeze_panes=None;s.sheet_view.pane=None
    for col,width in {'A':26,'B':14,'C':78,'D':23}.items():base.column_dimensions[col].width=width
    for row in base:
        for c in row:c.font=Font(name='Arial',size=10);c.alignment=Alignment(wrap_text=True)
    base['D1']='PRECIO BASE PEN (ORIGEN)';base.sheet_view.showGridLines=False
    w['PRESUPUESTO_S10']['B2']='PRESUPUESTO S10 — R02 USD — PROVISIONAL OBSERVADO'
    w['PRESUPUESTO_S10']['B8']='Moneda:';w['PRESUPUESTO_S10']['C8']='USD — DÓLARES AMERICANOS'
    w.save(out)
    subprocess.run(['powershell','-NoProfile','-File',str(Path(__file__).with_name('recalcular_presentacion.ps1')),str(out)],check=True)
    final=openpyxl.load_workbook(out);cached=openpyxl.load_workbook(out,data_only=True)
    errors=[f'{s.title}!{c.coordinate}' for s in cached for row in s for c in row if c.data_type=='e']
    expected=cache_original['PRESUPUESTO_S10']['G108'].value/args.tipo_cambio
    total=cached['PRESUPUESTO_S10']['G108'].value
    if errors or abs(total-expected)>0.01:raise ValueError(f'Conversión no concilia: {total} / {expected}, {errors}')
    original=openpyxl.load_workbook(source)
    for s in original:
        for row in s:
            for c in row:
                if c.data_type=='f' and not equivalent(c.value,final[s.title][c.coordinate].value):raise ValueError(f'Fórmula original alterada: {s.title}!{c.coordinate}')
    sheets=[]
    for s in final:
        cells=[]
        for row in s:
            for c in row:
                if c.value is None:continue
                value=c.value.isoformat() if isinstance(c.value,datetime.datetime) else c.value
                result=cached[s.title][c.coordinate].value
                if isinstance(result,datetime.datetime):result=result.isoformat()
                cells.append({'celda':c.coordinate,'valor':value,'resultado':result,'formato_numero':c.number_format,'es_formula':c.data_type=='f'})
        sheets.append({'nombre':s.title,'moneda_importes':'PEN' if s.title=='BASE_PRECIOS_PEN' else 'USD','filas':s.max_row,'columnas':s.max_column,'celdas':cells,'rangos_combinados':[str(r) for r in s.merged_cells.ranges]})
    snapshot={'version':'R02-USD-vivo','moneda':'USD','tipo_cambio_pen_por_usd':args.tipo_cambio,'dictamen':'BORRADOR_OBSERVADO','proyecto':meta['nombre'],'totales':{'total':{'despues':total,'moneda':'USD'}},'libro_excel':{'archivo':str(out.relative_to(p)),'sha256':digest(out),'hojas':sheets},'trazabilidad':{'fuente_pen_xlsx':str(source.relative_to(p)),'sha256_fuente_pen':digest(source),'json_pen_evidencia':str(original_json.relative_to(p)),'sha256_json_pen':digest(original_json),'nota':'JSON USD derivado del Excel vivo; las bases PEN sólo son evidencia/inputs explícitamente etiquetados.'},'conversiones':converted}
    snapshot_path.write_text(json.dumps(snapshot,ensure_ascii=False,indent=2),encoding='utf-8')
    canonical_usd=canonical.with_name('entrada_presupuesto_USD.json');canonical_data=json.loads(canonical.read_text(encoding='utf-8-sig'))
    canonical_data['project']['currency']='USD'
    def prices(obj):
        if isinstance(obj,dict):
            for key,value in obj.items():
                if key=='unit_price' and isinstance(value,(int,float)):obj[key]=value/args.tipo_cambio
                else:prices(value)
        elif isinstance(obj,list):
            for value in obj:prices(value)
    prices(canonical_data);canonical_usd.write_text(json.dumps(canonical_data,ensure_ascii=False,indent=2),encoding='utf-8')
    meta['fuente_economica_pen']={'excel':meta['entregables']['excel'],'json':meta['entregables']['json'],'canonico':meta['entradas']['canonico']}
    meta['entregables']['excel']=out.relative_to(p).as_posix();meta['entregables']['json']=snapshot_path.relative_to(p).as_posix();meta['entradas']['canonico']=canonical_usd.relative_to(p).as_posix()
    meta['moneda_entregables']='USD';meta['tipo_cambio_pen_por_usd']=args.tipo_cambio;meta['total_provisional']=total
    meta_path.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    datos_path=p/meta['entradas']['datos'];datos=json.loads(datos_path.read_text(encoding='utf-8-sig'));datos['moneda']='USD';datos['tipo_cambio_pen_por_usd']=args.tipo_cambio;datos_path.write_text(json.dumps(datos,ensure_ascii=False,indent=2),encoding='utf-8')
    manifest_path=p/'05_Trazabilidad/manifest_archivos.json';manifest=json.loads(manifest_path.read_text(encoding='utf-8-sig'))
    for f in [out,snapshot_path,canonical_usd,meta_path,datos_path]:
        rel=f.relative_to(p).as_posix();manifest['archivos']=[r for r in manifest['archivos'] if r['ruta']!=rel];manifest['archivos'].append({'ruta':rel,'sha256':digest(f),'bytes':f.stat().st_size})
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'moneda':'USD','tipo_cambio':args.tipo_cambio,'total_usd':total,'excel':str(out),'json':str(snapshot_path),'celdas_convertidas':len(converted)},ensure_ascii=False))

if __name__=='__main__':main()
