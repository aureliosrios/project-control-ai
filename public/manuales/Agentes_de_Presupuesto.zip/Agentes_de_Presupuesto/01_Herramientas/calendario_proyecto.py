"""Calendario del proyecto proporcionado por el usuario.

Las herramientas de cronograma no asumen días laborables, jornada, refrigerio,
feriados, fecha de inicio ni nombre del proyecto: todo se lee de
``Proyectos/<codigo>/06_Cronograma/calendario_proyecto.json``. Un campo en ``null``
significa "el usuario aún no lo proporcionó" y detiene el proceso con la lista de
datos que faltan. Plantilla: ``Agentes_de_Presupuesto/02_Plantillas/calendario_proyecto.plantilla.json``.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from pathlib import Path
import hashlib
import json
import math

SCHEMA = "calendario_proyecto/1.0"
DIAS = ["lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo"]
_NORMALIZAR = str.maketrans("áéíóú", "aeiou")
# Constantes PjWeekday de MS Project: domingo = 1 ... sábado = 7.
PJ_WEEKDAY = {"domingo": 1, "lunes": 2, "martes": 3, "miercoles": 4, "jueves": 5, "viernes": 6, "sabado": 7}


class CalendarioIncompleto(ValueError):
    """El usuario todavía no proporcionó todos los datos del calendario."""


@dataclass(frozen=True)
class Calendario:
    ruta: Path
    sha256: str
    datos: dict
    codigo_proyecto: str
    nombre_proyecto: str
    nombre_calendario: str
    fecha_inicio: date
    dias_laborables: tuple[str, ...]
    hora_inicio: time
    hora_fin: time
    refrigerio: tuple[time, time] | None
    feriados: frozenset[date]
    dias_laborables_por_mes: float
    proporcionado_por: str

    @property
    def minutos_dia(self) -> int:
        total = _minutos(self.hora_fin) - _minutos(self.hora_inicio)
        if self.refrigerio:
            total -= _minutos(self.refrigerio[1]) - _minutos(self.refrigerio[0])
        return total

    @property
    def horas_dia(self) -> float:
        return self.minutos_dia / 60

    @property
    def horas_semana(self) -> float:
        return self.horas_dia * len(self.dias_laborables)

    @property
    def turnos(self) -> list[tuple[time, time]]:
        if self.refrigerio:
            return [(self.hora_inicio, self.refrigerio[0]), (self.refrigerio[1], self.hora_fin)]
        return [(self.hora_inicio, self.hora_fin)]

    def es_laborable(self, dia: date) -> bool:
        return DIAS[dia.weekday()] in self.dias_laborables and dia not in self.feriados

    def fecha_de_dia(self, numero: int) -> date:
        """Fecha del día laborable ``numero`` (1 = primer día laborable desde la fecha de inicio)."""
        if numero < 1:
            raise ValueError("El día laborable debe ser mayor o igual a 1")
        dia = self.fecha_inicio - timedelta(days=1)
        contados = 0
        while contados < numero:
            dia += timedelta(days=1)
            if self.es_laborable(dia):
                contados += 1
        return dia

    def dias_laborables_en_dias_calendario(self, dias_calendario: float) -> int:
        """Equivalente en días laborables de una espera expresada en días calendario."""
        return max(1, math.ceil(dias_calendario * len(self.dias_laborables) / 7 - 1e-9))

    def resumen(self) -> dict:
        return {
            "fuente": "USUARIO",
            "ruta": str(self.ruta),
            "sha256": self.sha256,
            "proporcionado_por": self.proporcionado_por,
            "nombre_calendario": self.nombre_calendario,
            "fecha_inicio": self.fecha_inicio.isoformat(),
            "dias_laborables": list(self.dias_laborables),
            "dias_laborables_semana": len(self.dias_laborables),
            "hora_inicio": self.hora_inicio.strftime("%H:%M"),
            "hora_fin": self.hora_fin.strftime("%H:%M"),
            "refrigerio": None if not self.refrigerio else {
                "inicio": self.refrigerio[0].strftime("%H:%M"), "fin": self.refrigerio[1].strftime("%H:%M")},
            "jornada_horas": self.horas_dia,
            "feriados": sorted(d.isoformat() for d in self.feriados),
            "dias_laborables_mes": self.dias_laborables_por_mes,
        }


def _minutos(valor: time) -> int:
    return valor.hour * 60 + valor.minute


def _hora(texto, campo: str, errores: list[str]) -> time | None:
    try:
        return datetime.strptime(str(texto), "%H:%M").time()
    except ValueError:
        errores.append(f"{campo}: formato HH:MM inválido ({texto!r})")
        return None


def _fecha(texto, campo: str, errores: list[str]) -> date | None:
    try:
        return date.fromisoformat(str(texto))
    except ValueError:
        errores.append(f"{campo}: formato AAAA-MM-DD inválido ({texto!r})")
        return None


def cargar(ruta: Path) -> Calendario:
    ruta = Path(ruta)
    if not ruta.exists():
        raise CalendarioIncompleto(
            f"No existe {ruta}. Copie la plantilla calendario_proyecto.plantilla.json y pida los datos al usuario.")
    contenido = ruta.read_bytes()
    datos = json.loads(contenido.decode("utf-8-sig"))
    faltantes: list[str] = []
    errores: list[str] = []

    def requerido(clave: str, objeto: dict = datos, prefijo: str = ""):
        valor = objeto.get(clave) if isinstance(objeto, dict) else None
        if valor is None or (isinstance(valor, str) and not valor.strip()):
            faltantes.append(prefijo + clave)
        return valor

    if datos.get("schema") != SCHEMA:
        errores.append(f"schema debe ser {SCHEMA!r}")
    proporcionado_por = requerido("proporcionado_por")
    requerido("fecha_registro")
    codigo = requerido("codigo_proyecto")
    nombre = requerido("nombre_proyecto")
    nombre_cal = requerido("nombre_calendario_msproject")
    inicio_txt = requerido("fecha_inicio")
    dias = requerido("dias_laborables")
    jornada = requerido("jornada") or {}
    hi_txt = requerido("hora_inicio", jornada, "jornada.")
    hf_txt = requerido("hora_fin", jornada, "jornada.")
    refr = requerido("refrigerio", jornada, "jornada.")
    feriados_txt = requerido("feriados")
    por_mes = requerido("dias_laborables_por_mes")

    inicio = _fecha(inicio_txt, "fecha_inicio", errores) if inicio_txt is not None else None
    hi = _hora(hi_txt, "jornada.hora_inicio", errores) if hi_txt is not None else None
    hf = _hora(hf_txt, "jornada.hora_fin", errores) if hf_txt is not None else None

    dias_norm: list[str] = []
    if dias is not None:
        if not isinstance(dias, list) or not dias:
            errores.append("dias_laborables debe ser una lista no vacía")
        else:
            for d in dias:
                n = str(d).strip().lower().translate(_NORMALIZAR)
                if n not in DIAS:
                    errores.append(f"dias_laborables: día desconocido {d!r}")
                elif n not in dias_norm:
                    dias_norm.append(n)
            dias_norm.sort(key=DIAS.index)

    refrigerio = None
    if isinstance(refr, dict):
        aplica = requerido("aplica", refr, "jornada.refrigerio.")
        if aplica is True:
            ri_txt = requerido("inicio", refr, "jornada.refrigerio.")
            rf_txt = requerido("fin", refr, "jornada.refrigerio.")
            if ri_txt is not None and rf_txt is not None:
                ri = _hora(ri_txt, "jornada.refrigerio.inicio", errores)
                rf = _hora(rf_txt, "jornada.refrigerio.fin", errores)
                if ri and rf:
                    refrigerio = (ri, rf)
        elif aplica is not None and aplica is not False:
            errores.append("jornada.refrigerio.aplica debe ser true o false")
    elif refr is not None:
        errores.append('jornada.refrigerio debe ser {"aplica": false} o {"aplica": true, "inicio": "HH:MM", "fin": "HH:MM"}')

    feriados: set[date] = set()
    if feriados_txt is not None:
        if not isinstance(feriados_txt, list):
            errores.append("feriados debe ser una lista (use [] si el usuario confirma que no hay feriados)")
        else:
            for i, f in enumerate(feriados_txt):
                valor = f.get("fecha") if isinstance(f, dict) else f
                d = _fecha(valor, f"feriados[{i}]", errores)
                if d:
                    feriados.add(d)

    if hi and hf and not hi < hf:
        errores.append("jornada.hora_inicio debe ser anterior a jornada.hora_fin")
    if refrigerio and hi and hf and not (hi < refrigerio[0] < refrigerio[1] < hf):
        errores.append("el refrigerio debe quedar dentro de la jornada")
    if por_mes is not None and not (isinstance(por_mes, (int, float)) and 0 < por_mes <= 31):
        errores.append("dias_laborables_por_mes debe ser un número entre 1 y 31")

    if faltantes or errores:
        partes = []
        if faltantes:
            partes.append("Datos que debe proporcionar el usuario: " + ", ".join(faltantes))
        if errores:
            partes.append("Datos inválidos: " + "; ".join(errores))
        raise CalendarioIncompleto(f"{ruta}: " + " | ".join(partes))

    cal = Calendario(
        ruta=ruta, sha256=hashlib.sha256(contenido).hexdigest(), datos=datos,
        codigo_proyecto=str(codigo), nombre_proyecto=str(nombre), nombre_calendario=str(nombre_cal),
        fecha_inicio=inicio, dias_laborables=tuple(dias_norm), hora_inicio=hi, hora_fin=hf,
        refrigerio=refrigerio, feriados=frozenset(feriados), dias_laborables_por_mes=float(por_mes),
        proporcionado_por=str(proporcionado_por))
    if not cal.es_laborable(cal.fecha_inicio):
        raise CalendarioIncompleto(f"{ruta}: la fecha de inicio {cal.fecha_inicio} no es un día laborable del calendario")
    return cal


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Valida el calendario proporcionado por el usuario.")
    parser.add_argument("calendario", type=Path)
    args = parser.parse_args()
    try:
        c = cargar(args.calendario)
    except CalendarioIncompleto as exc:
        print(f"CALENDARIO_INCOMPLETO: {exc}")
        raise SystemExit(2)
    print(json.dumps(c.resumen(), ensure_ascii=False, indent=2))
