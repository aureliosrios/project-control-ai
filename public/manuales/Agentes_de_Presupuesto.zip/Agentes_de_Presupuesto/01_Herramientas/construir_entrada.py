"""Compila el cerebro digital de un proyecto en la entrada canónica del motor.

Entrada : Proyectos/<codigo>/03_Cerebro/cerebro_digital/*.json
Salida  : Proyectos/<codigo>/03_Cerebro/entrada_presupuesto.json (o --salida)

Esta herramienta es determinista y no inventa datos: ensambla, calcula hashes de fuentes,
registra cada supuesto abierto como fuente ASSUMPTION y verifica referencias. La interpretación
de la información del usuario y la formulación de APU la hace el agente al escribir el cerebro.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

STD_POLY = [
    {"symbol": "J", "index_code": "MO", "name_en": "Labor", "resource_types": ["LABOR"]},
    {"symbol": "M", "index_code": "MAT", "name_en": "Materials", "resource_types": ["MATERIAL"]},
    {"symbol": "E", "index_code": "EQ", "name_en": "Equipment", "resource_types": ["EQUIPMENT"]},
    {"symbol": "S", "index_code": "SC", "name_en": "Subcontracts and balance", "resource_types": ["SUBCONTRACT"]},
]
SUPUESTO_BASES = {"USUARIO", "WEB", "MERCADO", "RATIO_TECNICO", "CRITERIO"}
CONFIANZAS = {"ALTA", "MEDIA", "BAJA"}


def load(path: Path, default=None):
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding="utf-8-sig"))


def dump(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def source_id_for(supuesto_id: str) -> str:
    return "SRC-" + supuesto_id


def compile_brain(brain: Path, project_dir: Path):
    errors, warnings = [], []
    proyecto = load(brain / "proyecto.json")
    if proyecto is None:
        return None, ["Falta cerebro_digital/proyecto.json"], warnings
    fuentes = load(brain / "fuentes.json", [])
    recursos = load(brain / "recursos.json", [])
    partidas = load(brain / "partidas.json", [])
    gg_in = load(brain / "gastos_generales.json", [])
    supuestos = load(brain / "supuestos.json", [])
    poly = load(brain / "formula_polinomica.json", STD_POLY)

    for req in ("code", "name", "base_date", "currency", "assumptions"):
        if req not in proyecto:
            errors.append(f"proyecto.json: falta '{req}'")
    assumptions = proyecto.get("assumptions", {})
    for req in ("workday_hours", "profit_rate", "tax_rate", "contract_duration_months"):
        if assumptions.get(req) is None:
            errors.append(f"proyecto.json: assumptions.{req} vacío; registrarlo como dato del usuario o como supuesto")
    if errors:
        return None, errors, warnings
    months = assumptions["contract_duration_months"]

    # ---- Fuentes ----
    sources, seen = [], set()
    for s in fuentes:
        row = dict(s)
        rel = row.get("file_or_url", "")
        if rel and not rel.startswith(("http://", "https://")) and "sha256" not in row:
            target = ROOT / rel
            if target.is_file():
                row["sha256"] = sha256(target)
        if row["id"] in seen:
            errors.append(f"Fuente duplicada: {row['id']}")
        seen.add(row["id"])
        sources.append(row)

    # ---- Supuestos como fuentes ASSUMPTION ----
    sup_path = brain / "supuestos.json"
    sup_hash = sha256(sup_path) if sup_path.is_file() else None
    sup_rel = ""
    if sup_path.is_file():
        try:
            sup_rel = str(sup_path.resolve().relative_to(ROOT)).replace("\\", "/")
        except ValueError:
            sup_rel = str(sup_path.resolve()).replace("\\", "/")
    referenced = set()
    for sp in supuestos:
        for req in ("id", "tema", "valor", "base", "confianza"):
            if sp.get(req) in (None, ""):
                errors.append(f"Supuesto {sp.get('id', '?')}: falta '{req}'")
        if sp.get("base") not in SUPUESTO_BASES:
            errors.append(f"Supuesto {sp.get('id')}: base debe ser una de {sorted(SUPUESTO_BASES)}")
        if sp.get("confianza") not in CONFIANZAS:
            errors.append(f"Supuesto {sp.get('id')}: confianza debe ser ALTA, MEDIA o BAJA")
        if sp.get("estado", "ABIERTO") == "CERRADO":
            continue
        sid = source_id_for(sp["id"])
        if sid in seen:
            continue
        seen.add(sid)
        sources.append({
            "id": sid, "kind": "ASSUMPTION", "title": f"Supuesto {sp['id']}: {sp['tema']}",
            "file_or_url": sup_rel, "locator": sp["id"], **({"sha256": sup_hash} if sup_hash else {}),
            "status": "ASSUMPTION", "date": sp.get("fecha", proyecto["base_date"]),
        })

    # ---- Recursos ----
    res_ids = set()
    for r in recursos:
        if r["id"] in res_ids:
            errors.append(f"Recurso duplicado: {r['id']}")
        res_ids.add(r["id"])
        if not r.get("unit_price"):
            warnings.append(f"Recurso {r['id']} con precio 0 o vacío: debe tener precio o un supuesto registrado")

    # ---- Partidas y APU ----
    apus, items = [], []
    wbs_seen = set()
    for p in partidas:
        wbs = p["wbs"]
        if wbs in wbs_seen:
            errors.append(f"Partida duplicada: {wbs}")
        wbs_seen.add(wbs)
        apu = p.get("apu")
        if not apu:
            errors.append(f"Partida {wbs}: sin APU; formularlo (o supuesto) antes de compilar")
            continue
        apu_id = p.get("apu_id", f"APU-{wbs}")
        apus.append({
            "id": apu_id, "wbs": wbs, "output_unit": apu.get("output_unit", p["unit"]),
            "daily_output": apu["daily_output"], "technical_source_ids": apu["technical_source_ids"],
            "components": apu["components"],
        })
        items.append({
            "wbs": wbs, "chapter": p["chapter"], "description_es": p["description_es"],
            "description_en": p.get("description_en", p["description_es"]), "unit": p["unit"],
            "quantity": p["quantity"], "apu_id": apu_id,
            "quantity_evidence_ids": p["quantity_evidence_ids"], "eett_source_ids": p["eett_source_ids"],
        })

    # ---- Gastos generales ----
    general = []
    for g in gg_in:
        if "costo_mensual" in g:
            personas = g.get("personas", 1)
            line = {"id": g["id"], "class": "VARIABLE", "description_en": g.get("description") or g["descripcion"],
                    "quantity": months, "unit_price": round(g["costo_mensual"] * personas, 2), "source_id": g["source_id"]}
        else:
            line = {"id": g["id"], "class": g["class"], "description_en": g.get("description_en") or g.get("description") or g["descripcion"],
                    "quantity": g["quantity"], "unit_price": g["unit_price"], "source_id": g["source_id"]}
        general.append(line)

    data = {
        "schema_version": "1.0",
        "project": {k: proyecto[k] for k in ("code", "name", "location", "client", "base_date", "currency", "output_language") if k in proyecto},
        "assumptions": assumptions,
        "sources": sources, "resources": recursos, "apus": apus, "items": items,
        "general_conditions": general, "polynomial_groups": poly,
    }

    # ---- Referencias y uso de supuestos ----
    src_ids = {s["id"] for s in sources}
    for r in recursos:
        referenced.add(r.get("price_source_id"))
    for a in apus:
        referenced.update(a["technical_source_ids"])
    for i in items:
        referenced.update(i["quantity_evidence_ids"])
        referenced.update(i["eett_source_ids"])
    for g in general:
        referenced.add(g["source_id"])
    for sp in supuestos:
        sid = source_id_for(sp["id"])
        if sp.get("estado", "ABIERTO") != "CERRADO" and sid not in referenced and not sp.get("afecta"):
            warnings.append(f"Supuesto {sp['id']} no se usa en recursos, APU, partidas ni gastos generales (usar 'SRC-{sp['id']}' como fuente o declarar 'afecta')")
    for ref in sorted(x for x in referenced if x and x not in src_ids):
        errors.append(f"Referencia a fuente inexistente: {ref}")
    return data, errors, warnings


def write_summary(brain: Path, data: dict, supuestos: list, warnings: list):
    lines = [f"# Cerebro digital — {data['project']['name']}", "",
             f"- Código: `{data['project']['code']}`", f"- Fecha base: {data['project']['base_date']}",
             f"- Partidas: {len(data['items'])} · APU: {len(data['apus'])} · Recursos: {len(data['resources'])} · Fuentes: {len(data['sources'])}",
             f"- Plazo: {data['assumptions']['contract_duration_months']} meses · Utilidad: {data['assumptions']['profit_rate']*100:.2f}% · IGV: {data['assumptions']['tax_rate']*100:.0f}%", ""]
    open_s = [s for s in supuestos if s.get("estado", "ABIERTO") != "CERRADO"]
    lines += [f"## Supuestos abiertos ({len(open_s)})", ""]
    if open_s:
        lines += ["| ID | Tema | Valor | Base | Confianza |", "|---|---|---|---|---|"]
        lines += [f"| {s['id']} | {s['tema']} | {s['valor']} {s.get('unidad','')} | {s['base']} | {s['confianza']} |" for s in open_s]
    else:
        lines.append("Ninguno.")
    if warnings:
        lines += ["", "## Avisos de compilación", ""] + [f"- {w}" for w in warnings]
    (brain / "cerebro_resumen.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--proyecto", required=True, help="Código del proyecto o ruta")
    ap.add_argument("--cerebro", help="Carpeta del cerebro (por defecto 03_Cerebro/cerebro_digital)")
    ap.add_argument("--salida", help="Entrada canónica de salida (por defecto 03_Cerebro/entrada_presupuesto.json)")
    args = ap.parse_args(argv)
    p = Path(args.proyecto)
    project = p if p.is_dir() else ROOT / "Proyectos" / args.proyecto
    brain = Path(args.cerebro) if args.cerebro else project / "03_Cerebro" / "cerebro_digital"
    dest = Path(args.salida) if args.salida else project / "03_Cerebro" / "entrada_presupuesto.json"
    data, errors, warnings = compile_brain(brain, project)
    if errors:
        print(json.dumps({"status": "FAIL", "errores": errors, "avisos": warnings}, ensure_ascii=False, indent=2))
        return 1
    dump(dest, data)
    write_summary(brain, data, load(brain / "supuestos.json", []), warnings)
    print(json.dumps({"status": "PASS", "entrada": str(dest), "partidas": len(data["items"]), "recursos": len(data["resources"]),
                      "supuestos_abiertos": sum(1 for s in load(brain / "supuestos.json", []) if s.get("estado", "ABIERTO") != "CERRADO"),
                      "avisos": warnings}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
