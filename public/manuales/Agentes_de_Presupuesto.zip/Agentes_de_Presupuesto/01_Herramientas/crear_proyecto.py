"""Inicializa un proyecto vacío sin heredar datos económicos ni técnicos."""
from pathlib import Path
import argparse,json,re
ROOT=Path(__file__).resolve().parents[2]
def put(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
def create(code,name):
 if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{2,63}',code):raise ValueError('Código: 3–64 caracteres, inicia con letra; sólo letras, números, guion y subrayado.')
 if code.upper().split('.')[0] in ['CON','PRN','AUX','NUL'] or re.fullmatch(r'(COM|LPT)[1-9]',code.upper()):raise ValueError('Nombre reservado de Windows')
 p=ROOT/'Proyectos'/code
 if p.exists():raise FileExistsError('El proyecto ya existe; no se sobrescribe.')
 for sub in ['01_Entrada_Minima/Precios','02_EETT','03_Cerebro','04_Presupuesto','05_Trazabilidad']:(p/sub).mkdir(parents=True)
 manifest={'codigo':code,'nombre':name,'estado':'PENDIENTE_DATOS','revision_vigente':None,'entradas':{'datos':'01_Entrada_Minima/datos_proyecto.json','wbs':'01_Entrada_Minima/wbs.json','metrados':'01_Entrada_Minima/metrados.json','eett_indice':'02_EETT/indice_eett.json','canonico':'03_Cerebro/entrada_presupuesto.json'},'entregables':{}}
 put(p/'proyecto.json',manifest)
 put(p/'01_Entrada_Minima/datos_proyecto.json',{'codigo':code,'nombre':name,'ubicacion':None,'cliente':None,'alcance':None,'restricciones':[],'condiciones_presupuestacion':{'workday_hours':None,'profit_rate':None,'tax_rate':None,'contract_duration_months':None},'fecha_base':None,'moneda':None,'fuentes':[]})
 put(p/'01_Entrada_Minima/wbs.json',{'capitulos':[],'total_partidas':0,'estado':'PENDIENTE'})
 put(p/'01_Entrada_Minima/metrados.json',{'partidas':[],'estado':'PENDIENTE_MEDICION'})
 put(p/'02_EETT/indice_eett.json',{'total':0,'partidas':[],'estado':'PENDIENTE_DOCUMENTACION'})
 template=json.loads((ROOT/'Agentes_de_Presupuesto/00_NUCLEO_DETERMINISTA/templates/budget_input.template.json').read_text(encoding='utf-8-sig'))
 template['project'].update(code=code,name=name);put(p/'03_Cerebro/entrada_presupuesto.json',template)
 put(p/'03_Cerebro/pendientes.json',{'estado':'PENDIENTE_DATOS','pendientes':['Completar ubicación, alcance y condiciones contractuales','Adjuntar WBS y medición respaldada','Consolidar EETT en MD y Word','Investigar precios y formular APUs y gastos generales','Calibrar HSE/QA según procedimientos y frentes']})
 cb=p/'03_Cerebro/cerebro_digital';cb.mkdir()
 put(cb/'proyecto.json',{'code':code,'name':name,'location':None,'client':None,'base_date':None,'currency':None,'output_language':'es','naturaleza_metrados':None,'utilidad_pendiente':True,'assumptions':{'workday_hours':None,'profit_rate':None,'tax_rate':None,'contract_duration_months':None}})
 for fname in ('fuentes','recursos','partidas','gastos_generales','supuestos'):put(cb/(fname+'.json'),[])
 put(cb/'pendientes.json',{'pendientes':[]})
 mapa=ROOT/'Agentes_de_Presupuesto/02_Plantillas/ingesta/00_MAPA_INGESTA.plantilla.md'
 if mapa.is_file():(p/'01_Entrada_Minima/00_MAPA_INGESTA.md').write_text(mapa.read_text(encoding='utf-8'),encoding='utf8')
 (p/'README.md').write_text('# '+name+'\n\nProyecto vacío. Completar las entradas de proyecto.json; no usar como presupuesto. Seguir AGENTS.md en la raíz.\n',encoding='utf8')
 indexpath=ROOT/'Proyectos/indice_proyectos.json';index=json.loads(indexpath.read_text(encoding='utf8')) if indexpath.exists() else {'proyectos':[]}
 index['proyectos'].append({'codigo':code,'nombre':name,'ruta':str(p.relative_to(ROOT)).replace('\\','/'),'estado':'PENDIENTE_DATOS'});put(indexpath,index)
 return p
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--codigo',required=True);a.add_argument('--nombre',required=True);v=a.parse_args();print(create(v.codigo,v.nombre))

