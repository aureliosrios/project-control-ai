# -*- coding: utf-8 -*-
"""Excel S10 (PRESUPUESTO_S10 / ANALISIS_APU_S10 / SUBPARTIDAS_S10 / LISTADO_SUBPARTIDAS_S10 / INSUMOS_RECURSOS_S10)
-> JSON estructurado 'trazable' (presupuesto_master_trazable.json + presupuesto_wbs.json).

Es el paso 1 del flujo: Excel -> JSON (conserva partida -> APU -> insumo/subpartida/subcontrato, con hoja y fila de origen)
-> carga nativa S10 con el adaptador `json_trazable` de presupuesto-a-base-s10.

Lee valores calculados guardados (data_only) en modo read_only (rapido). No inventa datos: cualquier supuesto queda
registrado en metadatos.supuestos. Uso:
  python -X utf8 excel_s10_a_json_trazable.py --excel <xlsx> --salida <carpeta> [--nombre-obra ...]
"""
import argparse, collections, hashlib, json, os, re, sys
import openpyxl

SEC = {'mano de obra': 'mano_de_obra', 'materiales': 'materiales', 'equipos': 'equipos',
       'subcontratos': 'subcontratos', 'subpartidas': 'subpartidas'}
PREFIJO_CAT = {'01': 'mano_de_obra', '02': 'materiales', '03': 'equipos', '04': 'subcontratos'}


def num(x):
    return float(x) if isinstance(x, (int, float)) and not isinstance(x, bool) else None


def unidad_de(txt):
    """'m3 1,047,178.6094' (columna contaminada del listado) -> 'm3'."""
    return str(txt or '').strip().split(' ')[0]


def rend_txt(val, und):
    if isinstance(val, (int, float)):
        return f'{val:g} {und or ""}'.strip()
    return None


def sha256(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def leer_bloques(filas, prefijo, nombre_hoja, supuestos, advert):
    """Devuelve {clave: bloque}; bloque = cabecera + recursos por seccion con hoja/fila de origen."""
    bloques, actual, sec = collections.OrderedDict(), None, None
    for n, r in enumerate(filas, 1):
        b, c = r[1], r[2]
        if isinstance(b, str) and b.startswith(prefijo):
            m = re.match(prefijo + r'\s*(\S+)\s+-\s+(.*)$', b)
            if not m:
                raise SystemExit(f'{nombre_hoja} fila {n}: cabecera no reconocida: {b!r}')
            actual = dict(clave=m.group(1), descripcion=m.group(2).strip(), fila=n, rend_mo=None, rend_eq=None, unidad=None,
                          pu=None, recursos={k: [] for k in (*SEC.values(), 'otros')}, totales={})
            if actual['clave'] in bloques:
                raise SystemExit(f'{nombre_hoja}: bloque duplicado {actual["clave"]}')
            bloques[actual['clave']] = actual
            sec = None
            continue
        if actual is None:
            continue
        if b == 'Rendimiento MO.':
            und_r = r[3]
            m = re.match(r'C\.U\.D\. por (.*)$', str(r[6] or ''))
            actual['unidad'] = m.group(1).strip() if m else None
            actual['rend_mo'] = rend_txt(r[2], und_r)
            actual['rend_eq'] = rend_txt(r[5], und_r)
            actual['pu'] = num(r[7])
            continue
        if b is None and isinstance(c, str):
            if c.startswith('Total '):
                actual['totales'][c[6:].strip().lower()] = num(r[7])
                sec = None
                continue
            if c.strip().lower() in SEC:
                sec = SEC[c.strip().lower()]
                continue
        if isinstance(b, str) and b[:1].isdigit() and sec:
            cant, precio, parcial = num(r[5]), num(r[6]), num(r[7])
            if None in (cant, precio, parcial):
                raise SystemExit(f'{nombre_hoja} fila {n}: linea sin cantidad/precio/parcial ({b})')
            actual['recursos'][sec].append(dict(
                codigo=b.strip(), descripcion=str(c).strip(), unidad=str(r[3] or '').strip(), cuadrilla=num(r[4]),
                cantidad=cant, precio_unitario=precio, parcial=parcial, hoja=nombre_hoja, fila=n))
    return bloques


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--excel', required=True)
    ap.add_argument('--salida', required=True)
    a = ap.parse_args()
    wb = openpyxl.load_workbook(a.excel, data_only=True, read_only=True)
    H = {ws.title: [list(r) for r in ws.iter_rows(values_only=True)] for ws in wb}
    faltan = [h for h in ('DATOS_GENERALES_S10', 'PRESUPUESTO_S10', 'ANALISIS_APU_S10', 'INSUMOS_RECURSOS_S10') if h not in H]
    if faltan:
        raise SystemExit('Faltan hojas: ' + ', '.join(faltan))
    supuestos, advert = [], []

    # ---------------- datos generales
    dg = {}
    for r in H['DATOS_GENERALES_S10'][3:]:
        if r[0] and r[1] is not None:
            dg[str(r[0]).strip()] = r[1]
    jornada = num(dg.get('Jornada Laboral Oficial (Jornal)')) or 8.0
    meses = num(dg.get('Duración Estimada del Contrato'))
    ggf, ggv = num(dg.get('Tasa de Gastos Generales Fijos (GGF)')), num(dg.get('Tasa de Gastos Generales Variables (GGV)'))
    util, igv = num(dg.get('Tasa de Utilidad')), num(dg.get('Tasa de IGV / Impuesto'))

    # ---------------- insumos (catalogo)
    cat_ins, sec_ins = [], None
    for n, r in enumerate(H['INSUMOS_RECURSOS_S10'], 1):
        if r[1] is None and isinstance(r[2], str):
            t = r[2].strip().upper()
            if t.startswith('TOTAL'):
                sec_ins = None
            elif t.startswith('TOTAL INSUMOS'):
                pass
            else:
                sec_ins = {'MANO DE OBRA': 'Mano de Obra', 'MATERIALES': 'Materiales', 'EQUIPOS': 'Equipos', 'SUBCONTRATOS': 'Subcontratos',
                           'OTROS': 'Otros'}.get(t, 'Subpartidas sin desglose' if t.startswith('SUBPARTIDAS SIN DESGLOSE') else None)
            continue
        if isinstance(r[1], str) and r[1][:1].isdigit() and sec_ins:
            cat_ins.append(dict(codigo=r[1].strip(), descripcion=str(r[2]).strip(), unidad=str(r[3] or '').strip(), categoria=sec_ins,
                                cantidad=num(r[4]), precio_unitario=num(r[5]), parcial=num(r[6]), hoja='INSUMOS_RECURSOS_S10', fila=n))

    # ---------------- APU y subpartidas
    apus = leer_bloques(H['ANALISIS_APU_S10'], 'Partida:', 'ANALISIS_APU_S10', supuestos, advert)
    subs = leer_bloques(H['SUBPARTIDAS_S10'], 'Subpartida:', 'SUBPARTIDAS_S10', supuestos, advert) if 'SUBPARTIDAS_S10' in H else {}
    listado = {}
    for r in H.get('LISTADO_SUBPARTIDAS_S10', [])[7:]:
        if isinstance(r[1], str) and r[1][:1].isdigit():
            listado[r[1].strip()] = r
    if listado and set(listado) != set(subs):
        raise SystemExit(f'LISTADO_SUBPARTIDAS vs bloques SUBPARTIDAS: {sorted(set(listado) ^ set(subs))[:10]}')

    # ---------------- presupuesto (hoja): titulos y partidas
    lineas, partidas, vistos = [], [], set()
    cd_hoja = None
    for n, r in enumerate(H['PRESUPUESTO_S10'], 1):
        if r[2] == 'COSTO DIRECTO' and r[1] is None:
            cd_hoja = num(r[6])
            break
        if n < 8 or not r[1] or not re.match(r'^\d{2}(\.\d{2})*$', str(r[1])):
            continue
        item = str(r[1])
        if item in vistos:
            raise SystemExit(f'Item duplicado en PRESUPUESTO_S10: {item}')
        vistos.add(item)
        if r[3] is None:
            lineas.append(dict(type='TITLE', item=item, desc=str(r[2]).strip(), parc=num(r[6]), fila=n, cod_origen=r[7]))
        else:
            if item not in apus:
                raise SystemExit(f'Partida {item} (fila {n}) sin APU en ANALISIS_APU_S10')
            ap_ = apus[item]
            partidas.append(dict(item=item, descripcion=str(r[2]).strip(), unidad=str(r[3]).strip(), metrado=num(r[4]),
                                 precio_unitario=num(r[5]), parcial=num(r[6]), codigo_origen=r[7], hoja='PRESUPUESTO_S10', fila=n,
                                 apu_enlazado=dict(hoja='ANALISIS_APU_S10', fila_cabecera=ap_['fila'], recursos=ap_['recursos'],
                                                   precio_unitario_pdf=ap_['pu'], rendimiento=ap_['rend_mo'], jornada=jornada)))
            lineas.append(dict(type='ITEM', item=item, desc=str(r[2]).strip(), parc=num(r[6]), fila=n))
    sin_hoja = set(apus) - vistos
    if sin_hoja:
        raise SystemExit(f'APU sin fila en PRESUPUESTO_S10: {sorted(sin_hoja)[:10]}')
    if cd_hoja is None:
        raise SystemExit('No se encontro la fila COSTO DIRECTO en PRESUPUESTO_S10')

    # ---------------- subpartidas -> catalogo (unidad desde C.U.D. por <und>, no desde el listado contaminado)
    cat_sub = []
    for c, b in subs.items():
        und = b['unidad'] or unidad_de(listado[c][3])
        if und != unidad_de(listado[c][3]):
            advert.append(f'Subpartida {c}: unidad del listado {listado[c][3]!r} distinta del bloque {und!r}; se usa la del bloque.')
        cat_sub.append(dict(codigo=c, descripcion=b['descripcion'], unidad=und, precio_unitario=b['pu'] if b['pu'] is not None else num(listado[c][5]),
                            rendimiento=b['rend_mo'], jornada=jornada, recursos=b['recursos'], hoja='SUBPARTIDAS_S10', fila_cabecera=b['fila']))
    vacias = [s['codigo'] for s in cat_sub if not any(s['recursos'].values())]
    if vacias:
        supuestos.append(f'{len(vacias)} subpartidas sin desglose en la fuente ({", ".join(vacias)}) se cargan como INSUMO con su precio directo (no pueden ser Partida).')

    # ---------------- controles de coherencia (con valores exactos del Excel)
    prefijo_incoh = collections.Counter()
    for p in partidas:
        for k, ls in p['apu_enlazado']['recursos'].items():
            for l in ls:
                if '%' in l['codigo'] or k == 'subpartidas':
                    continue
                if PREFIJO_CAT.get(l['codigo'][:2]) != k:
                    prefijo_incoh[(l['codigo'][:2], k)] += 1
    if prefijo_incoh:
        advert.append('Lineas cuyo bloque del APU no coincide con el prefijo del codigo (S10 clasifica por codigo): ' + json.dumps({f'{a}/{b}': n for (a, b), n in prefijo_incoh.items()}))
    cd_sum = sum(p['parcial'] for p in partidas)
    if abs(cd_sum - cd_hoja) > 0.05:
        raise SystemExit(f'Suma de partidas {cd_sum} no concilia con COSTO DIRECTO de la hoja {cd_hoja}')
    for p in partidas:
        s = sum(l['parcial'] for ls in p['apu_enlazado']['recursos'].values() for l in ls)
        if abs(s - p['apu_enlazado']['precio_unitario_pdf']) > 0.05:
            raise SystemExit(f'APU {p["item"]}: suma de lineas {s} != PU {p["apu_enlazado"]["precio_unitario_pdf"]}')
        if abs(p['metrado'] * p['precio_unitario'] - p['parcial']) > 0.05:
            raise SystemExit(f'Partida {p["item"]}: metrado*PU != parcial')

    supuestos += [
        'Cada item WBS de PRESUPUESTO_S10 es una partida propia con su APU (554 APU para 554 partidas); el codigo de origen (p. ej. 503.H) se conserva como dato, no como clave.',
        'Los valores son los calculados guardados en el Excel (DATOS_GENERALES_S10!B18 = %s decimales por linea).' % dg.get('Decimales de cálculo por línea (15 = cálculo exacto | 2 = modo S10)', '?'),
        'Gastos generales: solo hay tasas globales (GGF %s + GGV %s); no hay desglose por rubros, el desglose analitico queda PENDIENTE y se carga el porcentaje total.' % (ggf, ggv),
        'Insumos porcentuales (%MO, %EQ, %MT) se conservan como lineas porcentuales (cantidad = porcentaje) y se mapean a codigos S10 de 10 digitos en el adaptador.',
        'El Excel indica que el JSON fuente original difiere del Excel recalculado en 114,449.47 S/ (0.046 %) por redondeo de precios; el control de la carga es el Excel vivo.',
    ]
    os.makedirs(a.salida, exist_ok=True)
    master = dict(
        schema_version='presupuesto_master_trazable/excel_s10-1.0',
        metadatos=dict(obra=dg.get('Nombre Oficial de la Obra'), codigo_obra=dg.get('Código de Obra'), cliente=dg.get('Cliente / Entidad Licitante'),
                       ubicacion=dg.get('Ubicación del Proyecto'), fecha_base=dg.get('Fecha Base de Precios'), moneda=dg.get('Moneda de Contrato'),
                       jornada_laboral_hh=jornada, duracion_meses=meses, gg_fijos=ggf, gg_variables=ggv, utilidad=util, igv=igv,
                       costo_directo_control=cd_hoja, costo_directo_meta_referencia=num(dg.get('Presupuesto Costo Directo Meta')),
                       fuente=dict(excel=os.path.abspath(a.excel), sha256=sha256(a.excel)), supuestos=supuestos, advertencias=advert),
        partidas_trazables=partidas, catalogo_subpartidas=cat_sub, catalogo_insumos=cat_ins,
        resumen_conciliacion=dict(costo_directo_hoja=cd_hoja, suma_partidas=cd_sum, partidas=len(partidas), titulos=sum(1 for l in lineas if l['type'] == 'TITLE'),
                                  subpartidas=len(cat_sub), subpartidas_sin_desglose=len(vacias), insumos=len(cat_ins), redondeo_presto=None))
    wbs = dict(schema_version='presupuesto_wbs/excel_s10-1.0', lineas_secuencia=lineas)
    with open(os.path.join(a.salida, 'presupuesto_master_trazable.json'), 'w', encoding='utf-8') as f:
        json.dump(master, f, ensure_ascii=False, indent=1)
    with open(os.path.join(a.salida, 'presupuesto_wbs.json'), 'w', encoding='utf-8') as f:
        json.dump(wbs, f, ensure_ascii=False, indent=1)
    print(json.dumps(dict(salida=os.path.abspath(a.salida), **master['resumen_conciliacion'], advertencias=advert), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
