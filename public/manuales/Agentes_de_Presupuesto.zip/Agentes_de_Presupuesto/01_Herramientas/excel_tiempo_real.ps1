param(
    [Parameter(Mandatory=$true)][string]$Plantilla,
    [Parameter(Mandatory=$true)][string]$Salida,
    [Parameter(Mandatory=$true)][string]$Orden,
    [double]$Velocidad=4,
    [double]$Adelanto=0.2,
    [int]$MesesCobranza=2,
    [switch]$PruebaOculta,
    [switch]$CerrarAlFinal
)
# Construccion visible, fila a fila, de una plantilla Excel con formulas vivas (PV, curva S, flujo de caja).
# El libro se guarda completo antes de las pruebas de propagacion. No se sobrescribe ninguna salida.
$ErrorActionPreference='Stop'
if($Velocidad -le 0){throw 'Velocidad debe ser mayor que cero'}
if(Test-Path -LiteralPath $Salida){throw 'La salida ya existe; no se sobrescribe'}
$excel=$null; $source=$null; $book=$null; $ok=$false
$sheetsOrder=$Orden.Split(',')
try {
    $excel=New-Object -ComObject Excel.Application
    $excel.Visible=$false; $excel.DisplayAlerts=$false; $excel.AskToUpdateLinks=$false
    $source=$excel.Workbooks.Open($Plantilla,0,$true)
    $snapshots=@{}
    foreach($sheet in $source.Worksheets){
        $range=$sheet.UsedRange
        $data=$range.Formula
        if($range.Rows.Count -eq 1 -and $range.Columns.Count -eq 1 -and -not $range.HasFormula){$data=$range.Value2}
        $snapshots[$sheet.Name]=@{data=$data; values=$range.Value2; firstRow=$range.Row; firstCol=$range.Column; rows=$range.Rows.Count; cols=$range.Columns.Count}
    }
    # Copiar todas las hojas juntas conserva estilos, graficos y referencias internas.
    $source.Worksheets.Copy()
    $book=$excel.ActiveWorkbook
    $source.Close($false); $source=$null
    foreach($sheet in $book.Worksheets){[void]$sheet.UsedRange.ClearContents()}
    $excel.Calculation=-4135
    $excel.Visible=(-not $PruebaOculta)
    if(-not $PruebaOculta){$excel.WindowState=-4137}
    $excel.ScreenUpdating=(-not $PruebaOculta)
    Write-Host 'CONSTRUCCION CORRIDA: datos, actividades, PV semanal, flujo de caja y curva S.'
    $written=0; $formulaCount=0; $visibleRows=0
    foreach($name in $sheetsOrder){
        $sheet=$book.Worksheets.Item($name);$sheet.Activate()
        $excel.ActiveWindow.FreezePanes=$false
        $excel.ActiveWindow.SplitRow=0;$excel.ActiveWindow.SplitColumn=0
        $excel.ActiveWindow.DisplayFormulas=$false
        $excel.ActiveWindow.Zoom=90
        $snapshot=$snapshots[$name];$data=$snapshot.data
        Write-Host "Construyendo $name ..."
        if(-not $PruebaOculta){
            $excel.ActiveWindow.ScrollRow=[Math]::Max(1,$snapshot.firstRow)
            $excel.ActiveWindow.ScrollColumn=1
        }
        for($r=0;$r -lt $snapshot.rows;$r++){
            $hasContent=$false
            $actualRow=$snapshot.firstRow+$r
            $rowRange=$sheet.Range($sheet.Cells.Item($actualRow,$snapshot.firstCol),$sheet.Cells.Item($actualRow,$snapshot.firstCol+$snapshot.cols-1))
            if(-not $PruebaOculta){
                $vis=$excel.ActiveWindow.VisibleRange
                $maxVisRow=$vis.Row+$vis.Rows.Count-2
                if($actualRow -lt $vis.Row -or $actualRow -gt $maxVisRow){
                    # Al llegar al final de la pantalla, la fila nueva pasa a la cabecera y el recorrido sigue hacia abajo.
                    $excel.ActiveWindow.ScrollRow=[Math]::Max(1,$actualRow)
                    $excel.ActiveWindow.ScrollColumn=1
                }
                $excel.Goto($sheet.Cells.Item($actualRow,$snapshot.firstCol),$false)
                $visible=$excel.ActiveWindow.VisibleRange
                if($actualRow -lt $visible.Row -or $actualRow -ge ($visible.Row+$visible.Rows.Count)){throw "Fila fuera de vista antes de escribir: $name $actualRow"}
                $visibleRows++
                $excel.StatusBar="CONSTRUYENDO $name - fila $actualRow"
            }
            $batch=($snapshot.cols -gt 1 -and $rowRange.MergeCells -eq $false)
            $rowData=[Array]::CreateInstance([object],[int[]]@(1,$snapshot.cols),[int[]]@(1,1))
            for($c=0;$c -lt $snapshot.cols;$c++){
                if($data -is [Array]){$value=$data.GetValue($r+$data.GetLowerBound(0),$c+$data.GetLowerBound(1))}else{$value=$data}
                if($value -isnot [string] -or -not $value.StartsWith('=')){
                    $values=$snapshot.values
                    if($values -is [Array]){$value=$values.GetValue($r+$values.GetLowerBound(0),$c+$values.GetLowerBound(1))}else{$value=$values}
                }
                if($null -eq $value -or ($value -is [string] -and $value.Length -eq 0)){continue}
                $isFormula=($value -is [string] -and $value.StartsWith('='))
                if($isFormula){$formulaCount++}
                if($batch){
                    if($value -is [string] -and -not $isFormula){$rowData.SetValue("'"+$value,1,$c+1)}else{$rowData.SetValue($value,1,$c+1)}
                } elseif($isFormula){$sheet.Cells.Item($actualRow,$snapshot.firstCol+$c).Formula=$value}
                elseif($value -is [string]){$sheet.Cells.Item($actualRow,$snapshot.firstCol+$c).Value2=[string]("'"+$value)}
                else{$sheet.Cells.Item($actualRow,$snapshot.firstCol+$c).Value2=[double]$value}
                $written++;$hasContent=$true
            }
            if($batch -and $hasContent){[void]$rowRange.GetType().InvokeMember('Formula',[Reflection.BindingFlags]::SetProperty,$null,$rowRange,[object[]]@(,$rowData))}
            if($hasContent -and -not $PruebaOculta){$rowRange.Calculate()}
            if($hasContent -and -not $PruebaOculta){
                Start-Sleep -Milliseconds ([int][Math]::Max(1,35/$Velocidad))
            }
        }
    }
    $excel.Calculation=-4105;$excel.CalculateFullRebuild()
    $book.Worksheets.Item('CURVA_S').Activate()
    $book.SaveAs($Salida,51)
    Write-Host 'LIBRO COMPLETO GUARDADO. VERIFICACION DE FORMULAS Y PRUEBAS DE PROPAGACION.'
    # 1) Errores de Excel y formulas conservadas.
    $errors=@();$formulasFinal=0
    foreach($sheet in $book.Worksheets){
        $f=$null
        try{$f=$sheet.UsedRange.SpecialCells(-4123)}catch{}
        if($null -ne $f){$formulasFinal+=$f.Count}
        $e=$null
        try{$e=$sheet.UsedRange.SpecialCells(-4123,16)}catch{}
        if($null -ne $e){foreach($cell in $e.Cells){$errors+=($sheet.Name+'!'+$cell.Address($false,$false))}}
    }
    if($errors.Count){throw "Errores Excel: $($errors[0..9] -join ', ')"}
    if($formulasFinal -ne $formulaCount){throw "Formulas escritas $formulaCount distintas de las del libro $formulasFinal"}
    $datos=$book.Worksheets.Item('DATOS');$flujo=$book.Worksheets.Item('FLUJO_CAJA');$sem=$book.Worksheets.Item('PV_SEMANAL');$res=$book.Worksheets.Item('RESUMEN')
    # 2) Controles de la hoja RESUMEN.
    $reviews=@()
    for($row=5;$row -le 12;$row++){ if($res.Cells.Item($row,5).Text -ne 'OK'){$reviews+=($res.Cells.Item($row,2).Text)} }
    if($reviews.Count){throw "Controles de RESUMEN sin OK: $($reviews -join '; ')"}
    # 3) Pruebas de propagacion (se restauran los datos originales).
    $adelantoOrig=$datos.Range('C9').Value2;$lagOrig=$datos.Range('C10').Value2;$fechaOrig=$datos.Range('C5').Value2
    if([Math]::Abs($adelantoOrig-$Adelanto) -gt 1e-9){throw 'DATOS!C9 no coincide con el adelanto solicitado'}
    if([int]$lagOrig -ne $MesesCobranza){throw 'DATOS!C10 no coincide con el plazo de cobranza solicitado'}
    $base=[double]$flujo.Range('I6').Value2
    if([Math]::Abs($base-($adelantoOrig*[double]$datos.Range('C21').Value2)) -gt 0.01){throw 'Adelanto del periodo 0 no es 20% del contrato'}
    $firstCash=$null
    for($row=6;$row -le 30;$row++){ if([double]$flujo.Cells.Item($row,10).Value2 -gt 0){$firstCash=[int]$flujo.Cells.Item($row,1).Value2;break} }
    if($firstCash -ne ($MesesCobranza+1)){throw "La primera cobranza esta en el periodo $firstCash y debia ser $($MesesCobranza+1)"}
    try {
        $datos.Range('C9').Value2=0.3;$excel.CalculateFullRebuild()
        $changedAdv=[double]$flujo.Range('I6').Value2
        if([Math]::Abs($changedAdv-(0.3*[double]$datos.Range('C21').Value2)) -gt 0.01){throw 'El adelanto no se propaga'}
        $datos.Range('C9').Value2=$adelantoOrig
        $datos.Range('C10').Value2=[double]($MesesCobranza+1);$excel.CalculateFullRebuild()
        $moved=$null
        for($row=6;$row -le 30;$row++){ if([double]$flujo.Cells.Item($row,10).Value2 -gt 0){$moved=[int]$flujo.Cells.Item($row,1).Value2;break} }
        if($moved -ne ($MesesCobranza+2)){throw 'El plazo de cobranza no desplaza la primera cobranza'}
        $datos.Range('C10').Value2=$lagOrig
        $d0=[double]$sem.Range('D6').Value2
        $datos.Range('C5').Value2=($fechaOrig+1);$excel.CalculateFullRebuild()
        if([Math]::Abs([double]$sem.Range('D6').Value2-($d0+1)) -gt 1e-9){throw 'La fecha de inicio no se propaga al PV semanal'}
    } finally {
        $datos.Range('C9').Value2=$adelantoOrig;$datos.Range('C10').Value2=$lagOrig;$datos.Range('C5').Value2=$fechaOrig
        $excel.CalculateFullRebuild()
    }
    if([Math]::Abs([double]$flujo.Range('I6').Value2-$base) -gt 0.01){throw 'No se restituyen los datos originales'}
    $res.Activate();$excel.ActiveWindow.Zoom=90;$excel.StatusBar=$false
    $book.Worksheets.Item('CURVA_S').Activate()
    $book.Save()
    $summary=[ordered]@{
        estado='PASS'
        orden=@('construccion_corrida','guardado_completo','errores_y_formulas','controles_resumen','prueba_adelanto','prueba_plazo_cobranza','prueba_fecha_inicio','guardado_verificado')
        celdas_escritas=$written;formulas_escritas=$formulaCount;formulas_en_libro=$formulasFinal
        pv_usd_total=[double]$sem.Cells.Item($sem.UsedRange.Rows.Count+$sem.UsedRange.Row-1,9).Value2
        contrato_usd=[double]$datos.Range('C21').Value2;adelanto_usd=[double]$flujo.Range('I6').Value2
        primera_cobranza_periodo=$firstCash;errores=$errors;filas_visibles_antes_de_escribir=$visibleRows;velocidad=$Velocidad;prueba_oculta=[bool]$PruebaOculta
    }
    $summary | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path ([IO.Path]::GetDirectoryName($Salida)) 'verificacion_tiempo_real.json') -Encoding UTF8
    $ok=$true
    Write-Host "VERIFICACION COMPLETA. Entregable: $Salida"
} catch {
    Write-Host $_.InvocationInfo.PositionMessage
    Write-Host $_.ScriptStackTrace
    throw
} finally {
    if($null -ne $source){$source.Close($false)}
    if($null -ne $excel -and ($PruebaOculta -or $CerrarAlFinal -or -not $ok)){
        if($null -ne $book){$book.Close($false)}
        $excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)
    }
}
