"""Descompone una entrada canónica existente en archivos de cerebro digital.

Sirve para migrar un proyecto previo al formato de cerebro y como prueba de ida y vuelta:
exportar -> construir_entrada.py debe reproducir los mismos recursos, APU, partidas y gastos generales.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def dump(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def export(entrada: Path, cerebro: Path):
    d = json.loads(entrada.read_text(encoding="utf-8-sig"))
    apu_by_id = {a["id"]: a for a in d["apus"]}
    partidas = []
    for it in d["items"]:
        apu = apu_by_id[it["apu_id"]]
        row = {k: it[k] for k in ("wbs", "chapter", "description_es", "description_en", "unit", "quantity")}
        row["apu_id"] = it["apu_id"]
        row["quantity_evidence_ids"] = it["quantity_evidence_ids"]
        row["eett_source_ids"] = it["eett_source_ids"]
        row["apu"] = {"output_unit": apu["output_unit"], "daily_output": apu["daily_output"],
                      "technical_source_ids": apu["technical_source_ids"], "components": apu["components"]}
        partidas.append(row)
    proyecto = dict(d["project"])
    proyecto["assumptions"] = d["assumptions"]
    dump(cerebro / "proyecto.json", proyecto)
    dump(cerebro / "fuentes.json", d["sources"])
    dump(cerebro / "recursos.json", d["resources"])
    dump(cerebro / "partidas.json", partidas)
    dump(cerebro / "gastos_generales.json", d["general_conditions"])
    dump(cerebro / "formula_polinomica.json", d["polynomial_groups"])
    if not (cerebro / "supuestos.json").exists():
        dump(cerebro / "supuestos.json", [])
    return {"partidas": len(partidas), "recursos": len(d["resources"]), "fuentes": len(d["sources"])}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--entrada", required=True)
    ap.add_argument("--cerebro", required=True)
    args = ap.parse_args(argv)
    print(json.dumps(export(Path(args.entrada), Path(args.cerebro)), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
