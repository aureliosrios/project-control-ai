"""Genera un cronograma CPM trazable desde metrados y rendimientos de un presupuesto.

La lógica productiva (cuadrillas, topes y precedencias) queda declarada y visible
en el JSON. No modifica el presupuesto de origen ni inventa datos de calendario: días laborables,
jornada, feriados, fecha de inicio y días por mes se leen del calendario que proporciona
el usuario (``calendario_proyecto.json``, ver ``calendario_proyecto.py``).
"""
from __future__ import annotations
from pathlib import Path
from collections import defaultdict, deque
import argparse, hashlib, json, math, re, sys
from datetime import datetime
from calendario_proyecto import cargar as cargar_calendario, CalendarioIncompleto

LEVEL_ORDER={"Sótano 2":0,"Sótano 1":1,"Piso 1":2,"Piso 2":3,"Piso 3":4,"Piso 4":5,"Piso 5":6,"Piso 6":7,"Azotea":8}
VERTICAL={"07.01","07.02","07.03","07.04","07.05","07.06"}
HORIZONTAL={"07.07","07.08","07.09","07.10","07.11","07.12","07.13","07.14","07.15","07.16","10.01","11.01","11.02","12.01","12.02"}

def load(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def nlevel(s):
    for k,v in LEVEL_ORDER.items():
        if k in s:return v
    return 99
def level_code(s):
    names={0:"S2",1:"S1",2:"P1",3:"P2",4:"P3",5:"P4",6:"P5",7:"P6",8:"AZ"}
    return names.get(nlevel(s),re.sub(r"[^A-Z0-9]+","",s.upper())[:10] or "GEN")
def relation_key(e): return (e["predecesora"],e["sucesora"],e["tipo"],e["desfase_dias"])

def crew_policy(code,description):
    # Días objetivo por frente y máximo físicamente razonable de cuadrillas base por frente.
    if code=="07.13": return 20,12,"Colocación de ladrillo de techo intensiva; hasta 12 cuadrillas base por sector."
    if code=="09.01": return 6,4,"Albañilería por paños; hasta 4 cuadrillas base por sector."
    if code.startswith(("10.","11.","12.")): return 6,6 if code=="11.03" else 4,"Instalaciones por sector con frentes coordinados."
    if code in {"07.02","07.05","07.08","07.11","07.15","09.03","04.04","05.02","05.05","06.02","06.06"}: return 5,4,"Encofrado modular con cuadrillas paralelas limitadas por espacio y juego de moldes."
    if code in {"05.03","05.06","06.03","07.03","07.06","07.09","07.12","07.16"}: return 5,2,"Acero habilitado y montado con hasta dos cuadrillas base por sector."
    if code in {"03.02","03.04","03.05"}: return 8,4,"Trabajo localizado/manual por sectores."
    if code in {"02.01","02.02"}: return 10,2,"Sostenimiento por paneles; límite por equipo, acceso y control geotécnico."
    if "Concreto" in description or "concreto" in description: return 3,1,"Un frente de vaciado por sector para no duplicar bomba ni liberación."
    if code in {"03.01","03.03"}: return 10,1,"Equipo principal único respetando el APU."
    if code.startswith("13."): return 2,1,"Control o ensayo independiente; una cuadrilla por evento."
    return 5,2,"Máximo de dos cuadrillas base por frente salvo restricción específica."

def build(metrados,budget,cal):
    parts={x["wbs"]:x for x in budget["partidas"]}; mparts={x["codigo_partida"]:x for x in metrados["partidas"]}
    if set(parts)!=set(mparts): raise ValueError("WBS del presupuesto y metrados no coinciden")
    activities=[]; crewplans={}
    for code in sorted(parts,key=lambda x:tuple(map(int,x.split('.')))):
        p=parts[code]; m=mparts[code]; rendimiento=float(p["apu"]["rendimiento_mo"])
        if rendimiento<=0: raise ValueError(f"Rendimiento no positivo {code}")
        target,cap,basis=crew_policy(code,p["descripcion"])
        raw=[]
        for si,sub in enumerate(m["desglose_detallado_por_piso"],1):
            elems=sub.get("elementos") or [{"id_elemento":sub["id_subtotal"],"item":p["descripcion"],"parcial":sub["subtotal"],"clasificacion_dato":"SINTETICO_APROXIMADO"}]
            for ei,el in enumerate(elems,1):
                secmatch=re.search(r"(?:Sector|Sectores)\s+(?:[A-Z0-9]+-)?([12])(?:\D*$)",el.get("item","") or "")
                sector=int(secmatch.group(1)) if secmatch else (ei if len(elems)==2 else 0)
                quantity=float(el["parcial"])
                variants=[("",quantity,el["id_elemento"])]
                if code=="13.01": variants=[("V",quantity/2,el["id_elemento"]+"-V"),("H",quantity/2,el["id_elemento"]+"-H")]
                for suffix,q,source_id in variants:
                    raw_days=q/rendimiento
                    crews=max(1,min(cap,math.ceil(raw_days/target)))
                    exact=raw_days/crews
                    programmed=max(1,math.ceil(exact-1e-12)); override=None; atype="TAREA"
                    if code=="02.04":
                        programmed=max(1,round(q*cal.dias_laborables_por_mes));override=f"Unidad mes: seguimiento continuo de {cal.dias_laborables_por_mes:g} días laborables/mes (calendario del usuario); el APU define esfuerzo, no la ventana de observación.";atype="NIVEL_DE_ESFUERZO"
                    elif code=="13.04":
                        programmed=max(programmed,cal.dias_laborables_en_dias_calendario(3));override=f"Prueba de estanqueidad de 72 horas (3 días calendario): mínimo técnico de {cal.dias_laborables_en_dias_calendario(3)} días laborables."
                    elif code=="13.06":
                        programmed=max(programmed,10);override="Compilación y cierre documental: ventana mínima de 10 días laborables." 
                    lid=level_code(sub["nivel"]); sid=f"S{sector}" if sector else "G"; aid=f"ACT-{code}-{lid}-{sid}{('-'+suffix) if suffix else ''}"
                    raw.append(dict(id=aid,wbs=code,capitulo=p["capitulo"],descripcion=p["descripcion"]+(" — liberación vertical" if suffix=="V" else " — liberación horizontal" if suffix=="H" else ""),nivel=sub["nivel"],cota=sub.get("cota"),sector=sector or "General",unidad=p["unidad"],metrado=q,fuente_metrado=dict(id_subtotal=sub["id_subtotal"],id_elemento=source_id,clasificacion=el.get("clasificacion_dato")),rendimiento_apu_efectivo=rendimiento,cuadrillas_asignadas_frente=crews,duracion_productiva_exacta_dias=exact,duracion_programada_dias=programmed,formula_duracion=f"{q:.6f} / ({rendimiento:.12f} x {crews})",tipo_actividad=atype,ajuste_calendario=override,predecesoras=[],sucesoras=[]))
        concurrent=2 if any(isinstance(x["sector"],int) for x in raw) and len(raw)>1 else 1
        perfront=max(x["cuadrillas_asignadas_frente"] for x in raw)
        labor=[];equipment=[]
        for c in p["apu"]["componentes"]:
            row=dict(descripcion=c.get("descripcion",c.get("criterio",c.get("recurso_id"))),unidad=c.get("unidad"),dotacion_base=c.get("cuadrilla",0),cobertura=c.get("cobertura"))
            if c.get("unidad")=="hh" and c.get("cuadrilla",0):labor.append(row)
            elif c.get("unidad")=="hm" and c.get("cuadrilla",0):equipment.append(row)
        crewplans[code]=dict(wbs=code,descripcion=p["descripcion"],rendimiento_apu_efectivo=rendimiento,unidad=p["unidad"],cuadrillas_por_frente_max=perfront,frentes_simultaneos_max=concurrent,cuadrillas_totales_disponibles=perfront*concurrent,criterio=basis,composicion_cuadrilla_base_mano_obra=labor,composicion_cuadrilla_base_equipos=equipment,advertencia="Cada cuadrilla conserva la composición y rendimiento del APU R02; multiplicar cuadrillas aumenta producción, no el rendimiento unitario.")
        activities.extend(raw)
    return activities,crewplans,parts

def schedule(activities,crewplans,cal):
    test_lag=cal.dias_laborables_en_dias_calendario(28)
    byid={a["id"]:a for a in activities}; byw=defaultdict(list)
    for a in activities:byw[a["wbs"]].append(a)
    edges=[];seen=set()
    def edge(u,v,typ="FS",lag=0,reason="Secuencia constructiva"):
        if not u or not v or u==v:return
        e=dict(predecesora=u,sucesora=v,tipo=typ,desfase_dias=lag,motivo=reason)
        k=relation_key(e)
        if k not in seen:seen.add(k);edges.append(e)
    def allink(a,b,typ="FS",lag=0,reason="Secuencia entre partidas"):
        for u in byw.get(a,[]):
            for v in byw.get(b,[]):edge(u["id"],v["id"],typ,lag,reason)
    # Preparación y subestructura.
    for b in ["01.02","01.03","01.05"]:allink("01.01",b)
    allink("01.03","01.06");allink("01.05","01.04");allink("01.06","01.04")
    for b in ["02.01","02.02","02.03"]:allink("01.04",b)
    allink("02.03","02.04","SS",0,"Monitoreo inicia con instrumentación")
    allink("02.01","03.01");allink("02.03","03.01");allink("03.01","03.03","SS",0,"Carguío acompaña excavación")
    allink("03.01","03.02");allink("03.02","03.05");allink("03.03","03.05");allink("03.05","13.05");allink("13.05","04.01")
    for b in ["04.02","05.03","05.06","06.06"]:allink("04.01",b)
    allink("04.02","04.04");allink("04.04","04.03")
    allink("05.03","05.02");allink("05.02","05.01");allink("05.06","05.05");allink("05.05","05.04")
    for a in ["05.01","05.04","04.02"]:
        for b in ["06.03","06.04"]:allink(a,b)
    allink("06.03","06.02");allink("06.02","06.08");allink("06.08","06.01");allink("06.06","06.05")
    for a in ["06.01","06.04","06.05"]:allink(a,"06.07")
    # Mapa exacto nivel-sector para el tren de estructura.
    loc=defaultdict(dict)
    for code,rows in byw.items():
        for a in rows:
            key=(nlevel(a["nivel"]),a["sector"])
            # 13.01 conserva V/H por ID, demás un registro por localización.
            loc[code][key+("V" if a["id"].endswith("-V") else "H" if a["id"].endswith("-H") else "",)]=a
    subgate=[x["id"] for c in ["06.01","06.04","06.05","06.07"] for x in byw.get(c,[])]
    def get(code,lev,sec,suf=""):
        return loc.get(code,{}).get((lev,sec,suf)) or loc.get(code,{}).get((lev,"General",suf))
    for lev in range(2,8):
        for sec in [1,2]:
            prev=[]
            if lev==2:prev=subgate
            else:
                for c in ["07.07","07.10"]:
                    x=get(c,lev-1,sec);prev += [x["id"]] if x else []
            for c in ["07.03","07.06"]:
                x=get(c,lev,sec)
                for u in prev:
                    if x:edge(u,x["id"],"FS",0,"Ascenso estructural por nivel y sector")
            for a,b in [("07.03","07.02"),("07.06","07.05")]:
                u,v=get(a,lev,sec),get(b,lev,sec)
                if u and v:edge(u["id"],v["id"])
            qv=get("13.01",lev,sec,"V")
            if qv:
                for c in ["07.02","07.05"]:
                    u=get(c,lev,sec)
                    if u:edge(u["id"],qv["id"],"FS",0,"Hold Point vertical")
            for c in ["07.01","07.04"]:
                v=get(c,lev,sec)
                if qv and v:edge(qv["id"],v["id"],"FS",0,"Liberación antes de concreto vertical")
            verts=[get(c,lev,sec) for c in ["07.01","07.04"]]
            for c in ["07.08","07.11","07.15"]:
                v=get(c,lev,sec)
                for u in verts:
                    if u and v:edge(u["id"],v["id"],"FS",0,"Estructura horizontal después de verticales")
            for a,b in [("07.08","07.09"),("07.11","07.12"),("07.11","07.13"),("07.15","07.16")]:
                u,v=get(a,lev,sec),get(b,lev,sec)
                if u and v:edge(u["id"],v["id"])
            qh=get("13.01",lev,sec,"H")
            if qh:
                for c in ["07.09","07.12","07.13","07.16","10.01","11.01","11.02","12.01","12.02"]:
                    u=get(c,lev,sec)
                    if u:edge(u["id"],qh["id"],"FS",0,"Hold Point de losa, vigas, pases y armaduras")
            for c in ["07.07","07.10","07.14"]:
                v=get(c,lev,sec)
                if qh and v:edge(qh["id"],v["id"],"FS",0,"Liberación antes de vaciado horizontal")
            # Ensayo de concreto a 28 días: control posterior, no bloquea el piso siguiente.
            test=get("13.02",lev,sec)
            if test:
                for c in ["07.01","07.04","07.07","07.10","07.14"]:
                    u=get(c,lev,sec)
                    if u:edge(u["id"],test["id"],"FS",test_lag,f"Edad de ensayo 28 días calendario = {test_lag} días laborables con {len(cal.dias_laborables)} días/semana")
            masonry=get("09.01",lev,sec)
            slab=get("07.10",lev,sec) or get("07.07",lev,sec)
            if slab and masonry:edge(slab["id"],masonry["id"],"FS",0,"Albañilería tras liberar estructura del nivel")
            for a,b in [("09.01","09.03"),("09.03","09.02"),("09.02","09.04")]:
                u,v=get(a,lev,sec),get(b,lev,sec)
                if u and v:edge(u["id"],v["id"])
            gate=get("09.04",lev,sec) or masonry or slab
            mep=[]
            for c in ["10.03","10.05","11.03","11.04"]:
                v=get(c,lev,sec)
                if gate and v:edge(gate["id"],v["id"],"FS",0,"Instalación posterior a estructura/albañilería")
                if v:mep.append(v)
            fire=get("12.04",lev,sec)
            if fire:
                for u in mep:edge(u["id"],fire["id"],"FS",0,"Sellado cortafuego después de instalaciones")
    # Instalaciones en sótanos/azotea y cubierta.
    for c in ["10.02","11.05","12.03"]:
        for v in byw.get(c,[]):
            for u in subgate:edge(u,v["id"],"FS",0,"Frente liberado en subestructura")
    allink("03.01","02.05","SS",0,"Achique disponible durante excavación")
    for a in ["06.01","06.04","06.05","06.07"]:allink(a,"03.04","FS",0,"Relleno después de liberar estructuras enterradas")
    # Sótanos: albañilería e instalaciones posteriores a la estructura enterrada.
    for lev in [0,1]:
        for sec in [1,2]:
            masonry=get("09.01",lev,sec)
            if masonry:
                for u in subgate:edge(u,masonry["id"],"FS",0,"Albañilería de sótano después de estructura enterrada")
            for a,b in [("09.01","09.03"),("09.03","09.02"),("09.02","09.04")]:
                u,v=get(a,lev,sec),get(b,lev,sec)
                if u and v:edge(u["id"],v["id"])
            gate=get("09.04",lev,sec) or masonry
            for c in ["10.03","10.04","10.05","11.02","11.03","11.04","12.02","12.04"]:
                v=get(c,lev,sec)
                if v:
                    for u in ([gate["id"]] if gate else subgate):edge(u,v["id"],"FS",0,"Instalaciones de sótano tras liberar frente")
            qv,qh=get("13.01",lev,sec,"V"),get("13.01",lev,sec,"H")
            if qv:
                for c in ["06.02","06.03"]:
                    for u in byw.get(c,[]):
                        if nlevel(u["nivel"])==lev:edge(u["id"],qv["id"],"FS",0,"Hold Point de muros de sótano")
                for v in byw.get("06.01",[]):
                    if nlevel(v["nivel"])==lev:edge(qv["id"],v["id"],"FS",0,"Liberación antes de concreto de muro")
            if qh:
                for c in ["05.02","05.03","05.05","05.06","11.01","12.01"]:
                    u=get(c,lev,sec)
                    if u:edge(u["id"],qh["id"],"FS",0,"Hold Point de cimentación y pases")
                for c in ["05.01","05.04","06.04"]:
                    v=get(c,lev,sec)
                    if v:edge(qh["id"],v["id"],"FS",0,"Liberación antes de concreto de cimentación/losa")
            test=get("13.02",lev,sec)
            if test:
                for c in ["05.01","05.04","06.01","06.04","06.05","06.07"]:
                    u=get(c,lev,sec)
                    if u:edge(u["id"],test["id"],"FS",test_lag,f"Edad de ensayo 28 días calendario = {test_lag} días laborables con {len(cal.dias_laborables)} días/semana")
    for v in byw.get("08.01",[]):
        for c in ["07.07","07.10"]:
            for u in byw.get(c,[]):
                if nlevel(u["nivel"])==7:edge(u["id"],v["id"],"FS",0,"Cubierta después de estructura de piso 6")
    for c in ["08.02","08.03"]:allink("08.01",c)
    allink("08.02","08.04");allink("08.03","08.04")
    # Azotea: pases y canalizaciones antes de cubierta; elementos posteriores después de ella.
    roof_inputs=[]
    for c in ["10.01","11.01","11.02","12.01","12.02"]:
        for u in byw.get(c,[]):
            if nlevel(u["nivel"])==8:roof_inputs.append(u)
    for u in roof_inputs:
        for c in ["07.07","07.10"]:
            for p6 in byw.get(c,[]):
                if nlevel(p6["nivel"])==7:edge(p6["id"],u["id"],"FS",0,"Embebidos de azotea después de estructura de piso 6")
        for v in byw.get("08.01",[]):edge(u["id"],v["id"],"FS",0,"Embebidos de azotea antes de cubierta")
    for c in ["09.01","10.03","10.04","10.05","11.03","11.04","12.04"]:
        for v in byw.get(c,[]):
            if nlevel(v["nivel"])==8:
                for u in byw.get("08.01",[]):edge(u["id"],v["id"],"FS",0,"Trabajo de azotea tras liberar cubierta")
    for v in byw.get("13.03",[]):
        for u in byw.get("05.03",[]):edge(u["id"],v["id"],"SS",0,"Muestreo de acero desde el inicio del armado")
    # Pruebas y cierre.
    for c in ["10.02","10.03","10.04","10.05","11.03","11.04","11.05","12.03","12.04"]:allink(c,"13.04")
    # Orden topológico de lógica antes de nivelación.
    def topo(es):
        inc={i:0 for i in byid};out=defaultdict(list)
        for e in es:inc[e["sucesora"]]+=1;out[e["predecesora"]].append(e["sucesora"])
        q=deque(sorted((i for i,v in inc.items() if v==0),key=lambda x:(nlevel(byid[x]["nivel"]),byid[x]["wbs"],x)));order=[]
        while q:
            u=q.popleft();order.append(u)
            for v in out[u]:
                inc[v]-=1
                if inc[v]==0:q.append(v)
        if len(order)!=len(byid):raise ValueError(f"Ciclo en lógica: {len(order)}/{len(byid)}")
        return order
    order=topo(edges);rank={x:i for i,x in enumerate(order)}
    # Nivelación por conjunto de cuadrillas de cada partida.
    for code,rows in byw.items():
        lanes=max(1,crewplans[code]["frentes_simultaneos_max"]);last=[None]*lanes;finish=[0]*lanes
        for a in sorted(rows,key=lambda x:rank[x["id"]]):
            lane=min(range(lanes),key=lambda i:finish[i])
            if last[lane]:edge(last[lane],a["id"],"FS",0,"Continuidad del conjunto de cuadrillas de la partida")
            last[lane]=a["id"];finish[lane]+=a["duracion_programada_dias"]
    # Toda actividad debe quedar conectada al inicio; esta relación sólo cubre
    # servicios generales sin una restricción física más específica.
    current_in={e["sucesora"] for e in edges};project_start=byw["01.01"][0]["id"]
    for a in activities:
        if a["id"]!=project_start and a["id"] not in current_in:edge(project_start,a["id"],"FS",0,"Disponibilidad general después de movilización")
    # El dossier sucede a todo el alcance; se excluye a sí mismo.
    dossier=byw["13.06"][0]
    for a in activities:
        if a["id"]!=dossier["id"]:edge(a["id"],dossier["id"],"FS",0,"Cierre del dossier después de ejecución, ensayos y registros")
    order=topo(edges); incoming=defaultdict(list);outgoing=defaultdict(list)
    for e in edges:incoming[e["sucesora"]].append(e);outgoing[e["predecesora"]].append(e)
    start={}
    for u in order:
        es=incoming[u];st=0
        for e in es:
            pred=e["predecesora"]
            val=start[pred]+(byid[pred]["duracion_programada_dias"] if e["tipo"]=="FS" else 0)+e["desfase_dias"]
            st=max(st,val)
        start[u]=st
    duration=max(start[i]+byid[i]["duracion_programada_dias"] for i in byid)
    late={i:duration-byid[i]["duracion_programada_dias"] for i in byid}
    for u in reversed(order):
        for e in outgoing[u]:
            v=e["sucesora"]
            candidate=late[v]-(byid[u]["duracion_programada_dias"] if e["tipo"]=="FS" else 0)-e["desfase_dias"]
            late[u]=min(late[u],candidate)
    for a in activities:
        i=a["id"];a["inicio_dia_proyecto"]=start[i]+1;a["fin_dia_proyecto"]=start[i]+a["duracion_programada_dias"];a["holgura_total_dias"]=max(0,late[i]-start[i]);a["critica"]=a["holgura_total_dias"]==0
        a["predecesoras"]=[{k:e[k] for k in ["predecesora","tipo","desfase_dias","motivo"]} for e in incoming[i]]
        a["sucesoras"]=[{k:e[k] for k in ["sucesora","tipo","desfase_dias","motivo"]} for e in outgoing[i]]
    return duration,edges

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--metrados",type=Path,required=True);ap.add_argument("--presupuesto",type=Path,required=True);ap.add_argument("--calendario",type=Path,required=True,help="calendario_proyecto.json proporcionado por el usuario");ap.add_argument("--revision",required=True,help="Identificador de revisión del cronograma, p. ej. R02-CRONOGRAMA-AAAAMMDD");ap.add_argument("--salida",type=Path,required=True);args=ap.parse_args()
    try: cal=cargar_calendario(args.calendario)
    except CalendarioIncompleto as exc: print(f"CALENDARIO_INCOMPLETO: {exc}",file=sys.stderr); raise SystemExit(2)
    m=load(args.metrados);b=load(args.presupuesto);activities,crewplans,parts=build(m,b,cal);duration,edges=schedule(activities,crewplans,cal)
    def fecha_hora(dia,hora): return datetime.combine(cal.fecha_de_dia(dia),hora).isoformat(timespec="minutes")
    for a in activities:
        a["inicio_fecha"]=fecha_hora(a["inicio_dia_proyecto"],cal.hora_inicio);a["fin_fecha"]=fecha_hora(a["fin_dia_proyecto"],cal.hora_fin)
    summaries=[];byid={a["id"]:a for a in activities}
    for code in sorted(parts,key=lambda x:tuple(map(int,x.split('.')))):
        rows=[a for a in activities if a["wbs"]==code];pred=sorted({e["predecesora"] for a in rows for e in a["predecesoras"] if byid[e["predecesora"]]["wbs"]!=code});succ=sorted({e["sucesora"] for a in rows for e in a["sucesoras"] if byid[e["sucesora"]]["wbs"]!=code})
        summaries.append(dict(wbs=code,capitulo=parts[code]["capitulo"],descripcion=parts[code]["descripcion"],unidad=parts[code]["unidad"],metrado_total=sum(a["metrado"] for a in rows),rendimiento_apu_efectivo=parts[code]["apu"]["rendimiento_mo"],plan_cuadrillas=crewplans[code],inicio_dia_proyecto=min(a["inicio_dia_proyecto"] for a in rows),fin_dia_proyecto=max(a["fin_dia_proyecto"] for a in rows),duracion_ventana_dias=max(a["fin_dia_proyecto"] for a in rows)-min(a["inicio_dia_proyecto"] for a in rows)+1,trabajo_total_cuadrilla_dias=sum(a["metrado"]/a["rendimiento_apu_efectivo"] for a in rows),actividades_detalle=[a["id"] for a in rows],predecesoras_externas=pred,sucesoras_externas=succ,critica=any(a["critica"] for a in rows)))
    target=round(float(b["presupuesto_canonico"]["assumptions"]["contract_duration_months"])*cal.dias_laborables_por_mes)
    critical_wbs=[]
    for s in summaries:
        critical_rows=[a for a in activities if a["wbs"]==s["wbs"] and a["critica"]]
        if critical_rows:
            critical_wbs.append(dict(wbs=s["wbs"],descripcion=s["descripcion"],actividades_criticas=len(critical_rows),inicio_dia=min(a["inicio_dia_proyecto"] for a in critical_rows),fin_dia=max(a["fin_dia_proyecto"] for a in critical_rows),cuadrillas_totales_disponibles=s["plan_cuadrillas"]["cuadrillas_totales_disponibles"]))
    critical_wbs.sort(key=lambda x:(-x["actividades_criticas"],x["wbs"]))
    cycles=[]
    for lev in range(2,8):
        rows=[a for a in activities if a["wbs"].startswith("07.") and nlevel(a["nivel"])==lev]
        if rows:cycles.append(dict(nivel=level_code(rows[0]["nivel"]),inicio_dia=min(a["inicio_dia_proyecto"] for a in rows),fin_dia=max(a["fin_dia_proyecto"] for a in rows),duracion_ventana_dias=max(a["fin_dia_proyecto"] for a in rows)-min(a["inicio_dia_proyecto"] for a in rows)+1))
    brick=[a for a in activities if a["wbs"]=="07.13"]
    brick_diag=None
    if brick:
        sample=max(brick,key=lambda x:x["metrado"])
        crews_5=math.ceil(sample["metrado"]/(sample["rendimiento_apu_efectivo"]*5))
        brick_diag=dict(wbs="07.13",rendimiento_apu_efectivo=sample["rendimiento_apu_efectivo"],metrado_representativo_por_sector=sample["metrado"],cuadrillas_actuales_por_sector=sample["cuadrillas_asignadas_frente"],duracion_actual_por_sector_dias=sample["duracion_programada_dias"],cuadrillas_teoricas_para_5_dias_por_sector=crews_5,conclusion="El rendimiento R02 hace que el ladrillo de techo gobierne el ciclo estructural. La cantidad teórica de cuadrillas para cinco días por sector no se adopta porque debe validarse espacio, suministro, izaje y seguridad.")
    gap=dict(reduccion_requerida_dias=max(0,duration-target),reduccion_porcentual_sobre_programa=round(max(0,duration-target)/duration*100,2) if duration else 0,ciclos_estructura=cycles,partidas_con_actividades_criticas=critical_wbs,cuello_botella_identificado=brick_diag,recomendacion="No aprobar como línea base hasta validar el rendimiento 07.13, estrategia de sectorización, disponibilidad real de cuadrillas/equipos y solapes con especialidades.")
    result=dict(schema="cronograma_trazable/1.0",revision=args.revision,estado="BORRADOR_PARA_CALIBRACION",proyecto=b["proyecto"],fuentes=[dict(tipo="METRADOS",ruta=str(args.metrados),sha256=sha(args.metrados),partidas=len(m["partidas"]),clasificacion="SINTETICO_APROXIMADO"),dict(tipo="PRESUPUESTO_R02",ruta=str(args.presupuesto),sha256=sha(args.presupuesto),partidas=len(b["partidas"]),estado=b["resumen_cumplimiento"]["dictamen"])],calendario=cal.resumen()|dict(tipo="CALENDARIO_DEL_USUARIO",convencion="Día 1 es la fecha de inicio indicada por el usuario; los días siguientes saltan los días no laborables y los feriados del calendario proporcionado."),metodologia=dict(formula="duracion_productiva_exacta_dias = metrado_elemento / (rendimiento_APU_R02 * cuadrillas_asignadas_al_frente); duración programada = techo, mínimo 1 día",criterio_cuadrillas="Se conservan rendimiento y composición de la cuadrilla base del APU. El número de cuadrillas se calcula por frente con una duración objetivo y un tope físico declarado; hasta dos sectores operan en paralelo cuando el metrado los identifica.",relaciones="CPM con FS y SS; nivelación por conjuntos de cuadrillas; esperas de ensayo se registran como desfases.",excepciones=[f"02.04 se modela como nivel de esfuerzo continuo: {cal.dias_laborables_por_mes:g} días laborables por mes de metrado (dato del usuario).",f"13.02 incorpora {cal.dias_laborables_en_dias_calendario(28)} días laborables de desfase para representar ensayo a 28 días calendario.",f"13.04 respeta el mínimo de 72 horas de la prueba de estanqueidad ({cal.dias_laborables_en_dias_calendario(3)} días laborables).","13.06 usa una ventana mínima de 10 días para compilar y cerrar el dossier."]),diagnostico_plazo=dict(plazo_presupuesto_meses=b["presupuesto_canonico"]["assumptions"]["contract_duration_months"],plazo_objetivo_dias_laborables=target,duracion_calculada_dias_laborables=duration,diferencia_dias=duration-target,cumple_plazo_objetivo=duration<=target,nota=f"El plazo de {b['presupuesto_canonico']['assumptions']['contract_duration_months']} meses proviene del presupuesto y no de un cronograma aprobado; se convierte con {cal.dias_laborables_por_mes:g} días laborables/mes del calendario del usuario. La comparación es diagnóstica."),analisis_brecha_plazo=gap,resumen=dict(partidas=len(summaries),actividades_detalle=len(activities),relaciones=len(edges),actividades_criticas=sum(a["critica"] for a in activities),inicio=1,fin=duration,inicio_fecha=fecha_hora(1,cal.hora_inicio),fin_fecha=fecha_hora(duration,cal.hora_fin)),partidas=summaries,actividades=activities,relaciones=edges,observaciones=["Los metrados son sintéticos y no acreditan medición de planos originales.","Rendimientos R02 incluyen castigos HSE/QA propuestos y pendientes de calibración con partes diarios.","Las cuadrillas múltiples son una hipótesis de planificación; validar disponibilidad, espacio, izaje, bomba, equipos y personal.","Las precedencias se deducen de la naturaleza constructiva y EETT; validar con el responsable de producción y el plan de fases.","Las fechas usan el calendario proporcionado por el usuario; las restricciones municipales y de acceso no están modeladas.","El cronograma no corrige APUs observados; las 126 observaciones R01 y seis R02 permanecen vigentes."])
    args.salida.parent.mkdir(parents=True,exist_ok=True);args.salida.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf8")
    print(json.dumps(result["resumen"]|result["diagnostico_plazo"],ensure_ascii=True))
if __name__=="__main__":main()
