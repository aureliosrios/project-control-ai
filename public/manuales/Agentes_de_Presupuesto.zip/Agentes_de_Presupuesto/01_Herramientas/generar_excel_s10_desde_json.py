#!/usr/bin/env python
"""Genera el Excel de presupuesto en formato S10 (hojas *_S10) desde la base JSON de un proyecto.

Entradas (carpeta --json-dir):
  presupuesto_wbs.json       lineas_secuencia (titulos y partidas) y metrados
  catalogo_apus.json         APU por partida (misma secuencia que las partidas)
  subpartidas_arbol.json     APU de subpartidas y listado
  insumos_explotados.json    precios de insumos y categorias
  jerarquia_wbs.json         arbol de titulos (raices / hijos por indice de lineas_secuencia)
  datos_generales.json       filas de DATOS_GENERALES_S10 (parametros del proyecto)

Diseno de hojas = layout del lector de S10 del agente (s10_nativo.cargar_excel): columna A separadora,
contenido desde B; items jerarquicos 01 / 01.01 / 01.01.01; APU con 'Partida:', 'Rendimiento MO.',
secciones Mano de Obra / Materiales / Equipos / Subcontratos y columnas Codigo-Descripcion-Und-Cuadrilla-
Cantidad-Precio-Parcial. Formato visual segun 02_Plantillas/formatos_s10_presto.json (Arial 10).
Todo el calculo es por formulas vivas; el modelo en Python solo sirve de control y para el texto SON.
"""
import argparse, json, os, re, sys, math, collections
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L

HERE = os.path.dirname(os.path.abspath(__file__))
FMT = json.load(open(os.path.join(HERE, '..', '02_Plantillas', 'formatos_s10_presto.json'), encoding='utf-8'))['s10']

NEGRO = '000000'
F_N = Font(name=FMT['font'], size=FMT['font_size'])
F_B = Font(name=FMT['font'], size=FMT['font_size'], bold=True)
F_T = Font(name=FMT['font'], size=14, bold=True)
F_G = Font(name=FMT['font'], size=8, italic=True, color='666666')
F_I = Font(name=FMT['font'], size=FMT['font_size'], color='0000FF')       # entradas literales (precios/cantidades de la fuente)
FILL_SEC = PatternFill('solid', fgColor=FMT['section_fill'])
FILL_APOYO = PatternFill('solid', fgColor='F7F7F7')
THIN = Side(style='thin', color='000000')
HAIR = Side(style='hair', color='999999')
B_HEAD = Border(top=THIN, bottom=THIN)
B_BOT = Border(bottom=HAIR)
B_TOT = Border(top=THIN)
NUM2, NUM4, NUM6 = '#,##0.00', '#,##0.0000', '#,##0.000000'
MON = '"S/" #,##0.00'

DG = "DATOS_GENERALES_S10"
S_PRE, S_APU, S_INS, S_GG, S_SUB, S_LST, S_RES, S_CON = ("PRESUPUESTO_S10", "ANALISIS_APU_S10", "INSUMOS_RECURSOS_S10",
    "GASTOS_GENERALES_S10", "SUBPARTIDAS_S10", "LISTADO_SUBPARTIDAS_S10", "RESUMEN_S10", "CONCILIACION_JSON")
JORN, PLAZO, GGF, GGV, UTIL, IGV, DEC = (f"{DG}!$B${r}" for r in (4, 5, 6, 7, 8, 9, 18))
GRUPOS = [('mano_de_obra', 'Mano de Obra'), ('materiales', 'Materiales'), ('equipos', 'Equipos'), ('subcontratos', 'Subcontratos'), ('subpartidas', 'Subpartidas')]
BASE_GRUPO = {'MANO_DE_OBRA': 'mano_de_obra', 'MATERIALES': 'materiales', 'EQUIPOS': 'equipos'}
PCT_EN = {'MANO_DE_OBRA': 'equipos', 'MATERIALES': 'materiales', 'EQUIPOS': 'equipos'}   # S10 muestra herramientas/lubricantes bajo Equipos


def natkey(s):
    return [int(t) if t.isdigit() else t for t in re.split(r'(\d+)', s or '')]


def parse_rend(txt):
    m = re.match(r'\s*([\d.,]+)\s*(.*)', str(txt or ''))
    if not m:
        return None, ''
    return float(m.group(1).replace(',', '')), m.group(2).strip()


def son(valor):
    U = ['', 'UN', 'DOS', 'TRES', 'CUATRO', 'CINCO', 'SEIS', 'SIETE', 'OCHO', 'NUEVE', 'DIEZ', 'ONCE', 'DOCE', 'TRECE', 'CATORCE', 'QUINCE',
         'DIECISEIS', 'DIECISIETE', 'DIECIOCHO', 'DIECINUEVE', 'VEINTE', 'VEINTIUN', 'VEINTIDOS', 'VEINTITRES', 'VEINTICUATRO', 'VEINTICINCO',
         'VEINTISEIS', 'VEINTISIETE', 'VEINTIOCHO', 'VEINTINUEVE']
    D = ['', '', '', 'TREINTA', 'CUARENTA', 'CINCUENTA', 'SESENTA', 'SETENTA', 'OCHENTA', 'NOVENTA']
    C = ['', 'CIENTO', 'DOSCIENTOS', 'TRESCIENTOS', 'CUATROCIENTOS', 'QUINIENTOS', 'SEISCIENTOS', 'SETECIENTOS', 'OCHOCIENTOS', 'NOVECIENTOS']

    def b1000(n):
        if n == 100: return 'CIEN'
        c, r = divmod(n, 100)
        t = C[c]
        if r < 30: t += (' ' if t and r else '') + U[r]
        else:
            d, u = divmod(r, 10)
            t += (' ' if t else '') + D[d] + (' Y ' + U[u] if u else '')
        return t.strip()

    def f(n):
        if n == 0: return 'CERO'
        if n >= 1000000:
            m, r = divmod(n, 1000000)
            return ('UN MILLON' if m == 1 else f(m) + ' MILLONES') + (' ' + f(r) if r else '')
        if n >= 1000:
            m, r = divmod(n, 1000)
            return ('MIL' if m == 1 else b1000(m) + ' MIL') + (' ' + b1000(r) if r else '')
        return b1000(n)
    ent = int(valor); cent = int(round((valor - ent) * 100))
    if cent == 100: ent, cent = ent + 1, 0
    return f"{f(ent)} CON {cent:02d}/100 SOLES"


def cargar(args):
    j = lambda n: json.load(open(os.path.join(args.json_dir, n), encoding='utf-8'))
    return dict(wbs=j('presupuesto_wbs.json'), apus=j('catalogo_apus.json')['apus'], sub=j('subpartidas_arbol.json'),
                ins=j('insumos_explotados.json')['recursos'], jer=j('jerarquia_wbs.json'), dg=j('datos_generales.json')['filas'],
                master=j('presupuesto_master_trazable.json')['metadatos'])


class Libro:
    def __init__(self, D, args):
        self.D, self.args = D, args
        self.seq = D['wbs']['lineas_secuencia']
        self.wb = openpyxl.Workbook()
        self.wb.remove(self.wb.active)
        self.msgs = []

    # ---------------------------------------------------------------- utilidades de hoja
    def hoja(self, nombre, anchos, titulo, sub=None, filas_enc=None):
        ws = self.wb.create_sheet(nombre)
        ws.sheet_view.showGridLines = False
        for k, v in anchos.items(): ws.column_dimensions[k].width = v
        ws['B1'] = titulo; ws['B1'].font = F_T
        if sub: ws['B2'] = sub; ws['B2'].font = F_N
        ws.page_setup.orientation = 'landscape'; ws.page_setup.paperSize = 9
        ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        return ws

    def put(self, ws, r, c, v, font=F_N, fmt=None, al=None, fill=None, border=None):
        x = ws.cell(r, c, v); x.font = font
        if fmt: x.number_format = fmt
        if al: x.alignment = al
        if fill: x.fill = fill
        if border: x.border = border
        return x

    def membrete(self, ws, nombre_doc, ncols):
        """Membrete S10: Presupuesto / Subpresupuesto / Cliente / Lugar / Costo al."""
        ws['B1'] = nombre_doc; ws['B1'].font = F_T
        filas = [('Presupuesto', f'={DG}!$B$11&"  "&{DG}!$B$10'), ('Cliente', f'={DG}!$B$12'),
                 ('Lugar', f'={DG}!$B$13'), ('Costo al', f'={DG}!$B$14')]
        for i, (a, b) in enumerate(filas):
            self.put(ws, 2 + i, 2, a, F_B); self.put(ws, 2 + i, 3, b, F_N)
        ws.row_dimensions[1].height = 24

    # ---------------------------------------------------------------- modelo
    def preparar(self):
        D = self.D
        seq = self.seq
        jer = D['jer']
        hijos = {int(k): v for k, v in jer['hijos'].items()}
        # orden de emision: DFS; hermanos todos-titulos se ordenan por codigo natural
        def orden(hs):
            if hs and all(seq[h]['type'] == 'TITLE' for h in hs):
                return sorted(hs, key=lambda h: natkey(seq[h]['item']))
            return hs
        self.arbol = []          # (idx, nivel, item_s10, padre_idx)
        def dfs(i, nivel, pref, padre):
            self.arbol.append((i, nivel, pref, padre))
            if seq[i]['type'] == 'TITLE':
                for n, h in enumerate(orden(hijos[i]), 1):
                    dfs(h, nivel + 1, f'{pref}.{n:02d}', i)
        for n, r in enumerate(orden(jer['raices']), 1):
            dfs(r, 1, f'{n:02d}', None)
        assert len(self.arbol) == len(seq)
        self.partidas_idx = [i for i, l in enumerate(seq) if l['type'] == 'PARTIDA']
        pj = D['wbs']['partidas']
        assert len(pj) == len(self.partidas_idx) == len(D['apus'])
        self.part = {}           # idx secuencia -> dict(partida json, apu json)
        for k, i in enumerate(self.partidas_idx):
            p, a = pj[k], D['apus'][k]
            assert p['item'] == seq[i]['item'] == a['item'], (k, p['item'], seq[i]['item'], a['item'])
            self.part[i] = dict(p=p, a=a)
        self.item_s10 = {i: it for i, n, it, pa in self.arbol}
        # subpartidas
        sa = D['sub']['subpartidas_apus']
        self.subs = collections.OrderedDict((x['codigo'], x) for x in sa if any(x['recursos'].values()))
        self.sub_lista = [x for x in D['sub']['subpartidas_lista'] if re.fullmatch(r'[0-9A-Z]{10,14}', str(x['codigo']))]
        self.sub_sin = [x for x in sa if not any(x['recursos'].values())]   # sin APU propio: precio directo de la fuente
        self.ins = collections.OrderedDict()
        for r in D['ins']:
            self.ins[r['codigo']] = r

    # ---------------------------------------------------------------- DATOS GENERALES
    def datos(self):
        ws = self.hoja(DG, {'A': 46, 'B': 40, 'C': 70}, 'DATOS GENERALES DEL PRESUPUESTO — S10',
                       'Parámetros maestros del libro. Los valores en azul son entradas del proyecto; todo lo demás se calcula por fórmula.')
        ws['B1'].value = None
        ws['A1'] = 'DATOS GENERALES DEL PRESUPUESTO — S10'; ws['A1'].font = F_T; ws['A2'] = ws['B2'].value; ws['B2'].value = None; ws['A2'].font = F_G
        for c, t in enumerate(['PARÁMETRO', 'VALOR', 'DESCRIPCIÓN'], 1):
            self.put(ws, 3, c, t, F_B, border=B_HEAD, al=Alignment(horizontal='left'))
        rows = self.D['dg']
        assert len(rows) == 15
        for k, (a, b, c) in enumerate(rows):
            r = 4 + k
            self.put(ws, r, 1, a); x = self.put(ws, r, 2, b, F_I, al=Alignment(horizontal='left'))
            self.put(ws, r, 3, c)
            if r in (6, 7, 8, 9): x.number_format = '0.00%'
            if r == 17: x.number_format = NUM2
        ws['B18'].number_format = '0'
        self.put(ws, 20, 1, 'Moneda de presentación: Soles (S/). Estado: BORRADOR REFERENCIAL (caso didáctico). Fuentes: JSON del proyecto.', F_G)
        self.put(ws, 21, 1, 'B18 = decimales por línea: 15 = cálculo exacto; 2 = redondeo operativo estilo S10.', F_G)

    # ---------------------------------------------------------------- PRESUPUESTO
    def presupuesto(self):
        ws = self.hoja(S_PRE, {'A': 3, 'B': 13, 'C': 78, 'D': 9, 'E': 17, 'F': 18, 'G': 20, 'H': 14}, '')
        self.membrete(ws, 'Presupuesto', 8)
        hr = 7
        for c, t in enumerate(['Item', 'Descripción', 'Und.', 'Metrado', 'Precio S/.', 'Parcial S/.', 'Cód. origen'], 2):
            self.put(ws, hr, c, t, F_B, border=B_HEAD, al=Alignment(horizontal='center' if c != 3 else 'left', vertical='center'))
        ws.row_dimensions[hr].height = FMT['row_height'] * 0.7
        ws.freeze_panes = ws.cell(hr + 1, 1)
        self.row_pre = {}
        fila = hr + 1
        for i, n, item, padre in self.arbol:
            self.row_pre[i] = fila; fila += 1
        self.fila_fin_pre = fila - 1
        hijos_ord = collections.defaultdict(list)
        for i, n, item, padre in self.arbol:
            hijos_ord[padre].append(i)
        self.hijos_ord = hijos_ord
        for i, n, item, padre in self.arbol:
            r = self.row_pre[i]; l = self.seq[i]
            ind = Alignment(indent=min(n - 1, 4), vertical='center')
            if l['type'] == 'TITLE':
                for c in range(2, 9): ws.cell(r, c).fill = FILL_SEC
                self.put(ws, r, 2, item, F_B, fill=FILL_SEC); self.put(ws, r, 3, l['desc'], F_B, al=ind, fill=FILL_SEC)
                hs = hijos_ord[i]
                refs = ','.join(f'G{self.row_pre[h]}' for h in hs)
                ws.cell(r, 7, f'=SUM({refs})' if len(refs) < 7000 else '=0').font = F_B
                ws.cell(r, 7).number_format = NUM2; ws.cell(r, 7).fill = FILL_SEC
                self.put(ws, r, 8, l['item'], F_G, fill=FILL_SEC)
                ws.row_dimensions[r].height = 20
            else:
                p = self.part[i]['p']
                self.put(ws, r, 2, item); self.put(ws, r, 3, l['desc'], al=Alignment(indent=min(n - 1, 4), wrap_text=True, vertical='center'))
                self.put(ws, r, 4, l['und'], al=Alignment(horizontal='center'))
                self.put(ws, r, 5, p['metrado'], F_I, NUM2)
                # F: precio unitario enlazado al APU (se completa en apu())
                self.put(ws, r, 7, f'=ROUND(E{r}*F{r},{DEC})', fmt=NUM2)
                self.put(ws, r, 8, l['item'], F_G)
                for c in range(2, 9): ws.cell(r, c).border = B_BOT
        # pie de presupuesto (S10)
        r = self.fila_fin_pre + 2
        raices = hijos_ord[None]
        self.put(ws, r, 3, 'COSTO DIRECTO', F_B, border=B_TOT)
        ws.cell(r, 7, '=SUM(' + ','.join(f'G{self.row_pre[x]}' for x in raices) + ')').number_format = NUM2
        ws.cell(r, 7).font = F_B; ws.cell(r, 7).border = B_TOT
        self.r_cd = r
        pie = [('GASTOS GENERALES FIJOS', f'=ROUND(G{r}*{GGF},{DEC})', f'={GGF}'), ('GASTOS GENERALES VARIABLES', f'=ROUND(G{r}*{GGV},{DEC})', f'={GGV}'),
               ('UTILIDAD', f'=ROUND(G{r}*{UTIL},{DEC})', f'={UTIL}')]
        for k, (t, f, tasa) in enumerate(pie, 1):
            self.put(ws, r + k, 3, t); self.put(ws, r + k, 6, tasa, fmt='0.00%'); self.put(ws, r + k, 7, f, fmt=NUM2)
        self.r_sub = r + 4
        self.put(ws, self.r_sub, 3, 'SUB TOTAL', F_B, border=B_TOT)
        ws.cell(self.r_sub, 7, f'=SUM(G{r}:G{r+3})').number_format = NUM2; ws.cell(self.r_sub, 7).font = F_B; ws.cell(self.r_sub, 7).border = B_TOT
        self.r_igv = r + 5
        self.put(ws, self.r_igv, 3, 'IGV'); self.put(ws, self.r_igv, 6, f'={IGV}', fmt='0.00%')
        self.put(ws, self.r_igv, 7, f'=ROUND(G{self.r_sub}*{IGV},{DEC})', fmt=NUM2)
        self.r_tot = r + 6
        self.put(ws, self.r_tot, 3, 'PRESUPUESTO TOTAL', F_B, border=B_HEAD)
        ws.cell(self.r_tot, 7, f'=G{self.r_sub}+G{self.r_igv}').number_format = NUM2; ws.cell(self.r_tot, 7).font = F_B; ws.cell(self.r_tot, 7).border = B_HEAD
        self.r_son = r + 8
        self.ws_pre = ws

    # ---------------------------------------------------------------- bloques APU
    def bloque(self, ws, r, rotulo, a, jornada_unit, metrado_ref, es_sub=False):
        """Escribe un bloque APU desde la fila r. Devuelve (fila_siguiente, fila_cud, filas_por_grupo)."""
        item_txt = a.get('_item', a.get('item', a.get('codigo')))
        self.put(ws, r, 2, f"{rotulo}: {item_txt} - {a['descripcion']}", F_B)
        for c in range(2, 11): ws.cell(r, c).fill = FILL_SEC
        ws.row_dimensions[r].height = 20
        rend, runit = parse_rend(a.get('rendimiento'))
        und = a['unidad']
        r1 = r + 1
        self.put(ws, r1, 2, 'Rendimiento MO.');
        if rend is not None: self.put(ws, r1, 3, rend, F_I, NUM4, Alignment(horizontal='left'))
        else: self.put(ws, r1, 3, '---', al=Alignment(horizontal='left'))
        self.put(ws, r1, 4, runit)
        self.put(ws, r1, 5, 'Rend. EQ.'); self.put(ws, r1, 6, f'=C{r1}' if rend is not None else '---', fmt=NUM4, al=Alignment(horizontal='left'))
        self.put(ws, r1, 7, f'C.U.D. por {und}', F_B, al=Alignment(horizontal='right'))
        cud = r1
        hdr = r + 2
        for c, t in enumerate(['Código', 'Descripción Recurso', 'Unidad', 'Cuadrilla', 'Cantidad', 'Precio S/.', 'Parcial S/.'], 2):
            self.put(ws, hdr, c, t, F_B, border=B_HEAD, al=Alignment(horizontal='left' if c <= 3 else 'center'))
        self.put(ws, hdr, 9, 'Metrado (apoyo)', F_G, border=B_HEAD, al=Alignment(horizontal='center'))
        self.put(ws, hdr, 10, 'Consumo total (apoyo)', F_G, border=B_HEAD, al=Alignment(horizontal='center'))
        rr = hdr + 1
        grupos = {k: [] for k, _ in GRUPOS}
        std = {k: [] for k, _ in GRUPOS}
        lineas = {k: list(a['recursos'].get(k, [])) for k, _ in GRUPOS}
        pct = collections.defaultdict(list)
        for x in a['recursos'].get('otros', []):
            pct[PCT_EN.get(x.get('base_calculo'), 'equipos')].append(x)
        subtot_rows = []
        rowsub = {}
        for k, nombre in GRUPOS:
            if not lineas[k] and not pct.get(k):
                continue
            self.put(ws, rr, 3, nombre, F_B); rr += 1
            ini = rr
            for x in lineas[k]:
                self.linea_std(ws, rr, x, k, rend, es_sub, metrado_ref, a)
                std[k].append(rr); rr += 1
            std_ini, std_fin = (std[k][0], std[k][-1]) if std[k] else (None, None)
            if std[k]: rowsub[k] = (std_ini, std_fin)
            for x in pct.get(k, []):
                grupo_base = BASE_GRUPO[x['base_calculo']]
                base_rows = rowsub.get(grupo_base)
                self.put(ws, rr, 2, x['codigo']); self.put(ws, rr, 3, x['descripcion']); self.put(ws, rr, 4, x['unidad'])
                self.put(ws, rr, 6, x['cantidad'], F_I, NUM4)
                base = f'=SUM(H{base_rows[0]}:H{base_rows[1]})' if base_rows else 0
                self.put(ws, rr, 7, base, fmt=NUM2)
                self.put(ws, rr, 8, f'=ROUND(F{rr}/100*G{rr},{DEC})', fmt=NUM2)
                self.put(ws, rr, 9, metrado_ref, fmt=NUM2)
                self.put(ws, rr, 10, f'=H{rr}*I{rr}', fmt=NUM2)       # consumo monetario (precio 1.00 en INSUMOS «Otros»)
                for c in range(2, 11): ws.cell(rr, c).border = B_BOT
                rr += 1
            fin = rr - 1
            self.put(ws, rr, 3, f'Total {nombre}', F_B, al=Alignment(horizontal='right'))
            self.put(ws, rr, 8, f'=SUM(H{ini}:H{fin})', F_B, NUM2, border=B_TOT)
            subtot_rows.append(rr); rr += 1
        ws.cell(cud, 8, '=' + ('+'.join(f'H{x}' for x in subtot_rows) if subtot_rows else '0')).number_format = NUM2
        ws.cell(cud, 8).font = F_B
        return rr + 1, cud

    def linea_std(self, ws, rr, x, k, rend, es_sub, metrado_ref, a):
        cod = x['codigo']
        self.put(ws, rr, 2, cod); self.put(ws, rr, 3, x['descripcion']); self.put(ws, rr, 4, x['unidad'], al=Alignment(horizontal='center'))
        cu = x.get('cuadrilla')
        qty = x['cantidad']
        usa_form = False
        if cu is not None and rend:
            if abs(self.jornada * cu / rend - qty) <= max(1e-5, abs(qty) * 5e-6):
                usa_form = True
        if cu is not None: self.put(ws, rr, 5, cu, F_I, NUM4)
        if usa_form:
            self.put(ws, rr, 6, f'={JORN}*E{rr}/$C${self._cur_rend_row}', fmt=NUM4)
        else:
            self.put(ws, rr, 6, qty, F_I, NUM6 if abs(qty) < 1 and k != 'subcontratos' else NUM4)
        # precio
        if cod in self.subs or cod in self.sub_sin_cod:
            ref = self.sub_cud[cod]
            self.put(ws, rr, 7, f'={S_SUB}!$H${ref}', fmt=NUM2)
        else:
            if cod not in self.row_ins:
                self.msgs.append(f'AVISO insumo sin fila en INSUMOS: {cod} {x["descripcion"]} (partida {a.get("item")})')
                self.put(ws, rr, 7, x['precio_unitario'], F_I, NUM2)
            else:
                self.put(ws, rr, 7, f'={S_INS}!$F${self.row_ins[cod]}', fmt=NUM2)
        self.put(ws, rr, 8, f'=ROUND(F{rr}*G{rr},{DEC})', fmt=NUM2)
        self.put(ws, rr, 9, metrado_ref, fmt=NUM2)
        self.put(ws, rr, 10, f'=F{rr}*I{rr}', fmt=NUM4)
        for c in range(2, 11): ws.cell(rr, c).border = B_BOT

    # ---------------------------------------------------------------- insumos (primero se asignan filas)
    def asignar_insumos(self):
        cats = collections.OrderedDict([('Mano de Obra', []), ('Materiales', []), ('Equipos', []), ('Subcontratos', []), ('Otros', [])])
        for cod, r in self.ins.items():
            cats.setdefault(r['categoria'], []).append(r)
        self.cats = cats
        self.row_ins = {}
        fila = 8
        self.ins_layout = []
        for nombre, lst in cats.items():
            if not lst: continue
            self.ins_layout.append(('grupo', nombre, fila)); fila += 1
            for r in lst:
                self.row_ins[r['codigo']] = fila; self.ins_layout.append(('ins', r, fila)); fila += 1
            self.ins_layout.append(('total', nombre, fila)); fila += 2
        self.ins_layout.append(('grupo', 'Subpartidas sin desglose (precio directo de la fuente)', fila)); fila += 1
        self.row_ins_sin = {}
        for s in self.sub_sin:
            self.row_ins_sin[s['codigo']] = fila; self.ins_layout.append(('sin', s, fila)); fila += 1
        self.ins_layout.append(('total', 'Subpartidas sin desglose', fila)); fila += 2
        self.fila_total_ins = fila

    def nrows(self):
        pass

    # ---------------------------------------------------------------- APU y SUBPARTIDAS
    def apu_subpartidas(self):
        D = self.D
        # --- layout previo de SUBPARTIDAS para conocer las filas CUD
        self.sub_cud = {}
        self.sub_sin_cod = {s['codigo'] for s in self.sub_sin}
        wsS = self.hoja(S_SUB, {'A': 3, 'B': 15, 'C': 60, 'D': 10, 'E': 12, 'F': 14, 'G': 16, 'H': 16, 'I': 14, 'J': 18}, '')
        self.membrete(wsS, 'Análisis de subpartidas', 10)
        # filas del listado (para metrado de apoyo)
        self.row_lst = {}
        for k, s in enumerate(self.sub_lista): self.row_lst[s['codigo']] = 8 + k
        # primera pasada: calcular alturas para fijar filas CUD sin escribir
        fila = 7
        self.sub_inicio = {}
        for cod, a in self.subs.items():
            self.sub_inicio[cod] = fila
            self.sub_cud[cod] = fila + 1
            fila += self.altura(a)
        for s in self.sub_sin:
            self.sub_inicio[s['codigo']] = fila; self.sub_cud[s['codigo']] = fila + 1; fila += 4
        wsA = self.hoja(S_APU, {'A': 3, 'B': 15, 'C': 60, 'D': 10, 'E': 12, 'F': 14, 'G': 16, 'H': 16, 'I': 14, 'J': 18}, '')
        self.membrete(wsA, 'Análisis de precios unitarios', 10)
        wsA.freeze_panes = 'A7'
        wsS.freeze_panes = 'A7'
        self.jornada = float(self.D['master'].get('jornada_laboral_hh', 8.0))
        # --- APU de partidas
        r = 7
        self.apu_cud = {}
        for i in self.partidas_idx:
            pa = self.part[i]
            a = dict(pa['a']); a['_item'] = self.item_s10[i]
            self._cur_rend_row = r + 1
            rr, cud = self.bloque(wsA, r, 'Partida', a, None, f"={S_PRE}!$E${self.row_pre[i]}")
            self.apu_cud[i] = cud
            self.ws_pre.cell(self.row_pre[i], 6, f'={S_APU}!$H${cud}').number_format = NUM2
            self.ws_pre.cell(self.row_pre[i], 6).font = F_N
            self.ws_pre.cell(self.row_pre[i], 6).border = B_BOT
            r = rr
        self.fin_apu = r
        # --- subpartidas con desglose
        for cod, a in self.subs.items():
            aa = dict(a); aa['_item'] = cod
            rr0 = self.sub_inicio[cod]
            self._cur_rend_row = rr0 + 1
            rr, cud = self.bloque(wsS, rr0, 'Subpartida', aa, None, f"={S_LST}!$E${self.row_lst[cod]}", es_sub=True)
            assert cud == self.sub_cud[cod], (cod, cud, self.sub_cud[cod])
            assert rr - rr0 == self.altura(a), (cod, rr - rr0, self.altura(a))
            # H del CUD: la columna del precio usado por referencias es H
        for s in self.sub_sin:
            rr0 = self.sub_inicio[s['codigo']]
            self.put(wsS, rr0, 2, f"Subpartida: {s['codigo']} - {s['descripcion']}", F_B)
            for c in range(2, 11): wsS.cell(rr0, c).fill = FILL_SEC
            self.put(wsS, rr0 + 1, 2, 'Sin desglose: precio directo de la fuente (no tiene APU propio).', F_G)
            self.put(wsS, rr0 + 1, 7, f"Costo unitario directo por : {s['unidad']}", F_B, al=Alignment(horizontal='right'))
            self.put(wsS, rr0 + 1, 8, s['precio_unitario'], Font(name=FMT['font'], size=10, bold=True, color='0000FF'), NUM2)
        self.fin_sub = fila
        self.wsA, self.wsS = wsA, wsS

    def altura(self, a):
        """Filas que ocupa un bloque: rotulo + rend + encabezado + (grupo + lineas + total)*grupos + 1 blanco."""
        n = 3
        pct = collections.defaultdict(int)
        for x in a['recursos'].get('otros', []): pct[PCT_EN.get(x.get('base_calculo'), 'equipos')] += 1
        for k, _ in GRUPOS:
            m = len(a['recursos'].get(k, [])) + pct.get(k, 0)
            if m: n += m + 2
        return n + 1

    # ---------------------------------------------------------------- LISTADO SUBPARTIDAS
    def listado(self):
        ws = self.hoja(S_LST, {'A': 3, 'B': 15, 'C': 60, 'D': 10, 'E': 18, 'F': 16, 'G': 18}, '')
        self.membrete(ws, 'Listado de subpartidas', 7)
        for c, t in enumerate(['Código', 'Descripción de la subpartida', 'Und.', 'Cantidad total', 'Precio S/.', 'Parcial S/.'], 2):
            self.put(ws, 7, c, t, F_B, border=B_HEAD, al=Alignment(horizontal='center' if c > 3 else 'left'))
        ra, rs = f'{S_APU}!$B$1:$B${self.fin_apu}', f'{S_SUB}!$B$1:$B${self.fin_sub}'
        ja, js = f'{S_APU}!$J$1:$J${self.fin_apu}', f'{S_SUB}!$J$1:$J${self.fin_sub}'
        for s in self.sub_lista:
            r = self.row_lst[s['codigo']]
            self.put(ws, r, 2, s['codigo']); self.put(ws, r, 3, s['descripcion']); self.put(ws, r, 4, s['unidad'], al=Alignment(horizontal='center'))
            self.put(ws, r, 5, f'=SUMIF({ra},$B{r},{ja})+SUMIF({rs},$B{r},{js})', fmt=NUM4)
            self.put(ws, r, 6, f'={S_SUB}!$H${self.sub_cud[s["codigo"]]}', fmt=NUM2)
            self.put(ws, r, 7, f'=ROUND(E{r}*F{r},{DEC})', fmt=NUM2)
            for c in range(2, 8): ws.cell(r, c).border = B_BOT
        self.fin_lst = 8 + len(self.sub_lista) - 1
        ws.freeze_panes = 'A8'

    # ---------------------------------------------------------------- INSUMOS
    def insumos(self):
        ws = self.hoja(S_INS, {'A': 3, 'B': 15, 'C': 62, 'D': 9, 'E': 18, 'F': 16, 'G': 20}, '')
        self.membrete(ws, 'Consolidado de insumos', 7)
        for c, t in enumerate(['Código', 'Descripción del recurso', 'Und.', 'Cantidad', 'Precio S/.', 'Parcial S/.'], 2):
            self.put(ws, 7, c, t, F_B, border=B_HEAD, al=Alignment(horizontal='center' if c > 3 else 'left'))
        ws.freeze_panes = 'A8'
        ra, rs = f'{S_APU}!$B$1:$B${self.fin_apu}', f'{S_SUB}!$B$1:$B${self.fin_sub}'
        ja, js = f'{S_APU}!$J$1:$J${self.fin_apu}', f'{S_SUB}!$J$1:$J${self.fin_sub}'
        ini = {}
        self.tot_rows = []
        for tipo, obj, fila in self.ins_layout:
            if tipo == 'grupo':
                self.put(ws, fila, 3, obj.upper(), F_B); ini[obj] = fila + 1
                for c in range(2, 8): ws.cell(fila, c).fill = FILL_SEC
            elif tipo == 'ins':
                r = obj
                self.put(ws, fila, 2, r['codigo']); self.put(ws, fila, 3, r['descripcion']); self.put(ws, fila, 4, r['unidad'], al=Alignment(horizontal='center'))
                self.put(ws, fila, 5, f'=SUMIF({ra},$B{fila},{ja})+SUMIF({rs},$B{fila},{js})', fmt=NUM4)
                self.put(ws, fila, 6, r['precio_unitario'], F_I, NUM2 if r['categoria'] != 'Otros' else NUM4)
                self.put(ws, fila, 7, f'=ROUND(E{fila}*F{fila},{DEC})', fmt=NUM2)
                for c in range(2, 8): ws.cell(fila, c).border = B_BOT
            elif tipo == 'sin':
                s = obj
                self.put(ws, fila, 2, s['codigo']); self.put(ws, fila, 3, s['descripcion']); self.put(ws, fila, 4, s['unidad'], al=Alignment(horizontal='center'))
                self.put(ws, fila, 5, f'={S_LST}!$E${self.row_lst[s["codigo"]]}', fmt=NUM4)
                self.put(ws, fila, 6, f'={S_SUB}!$H${self.sub_cud[s["codigo"]]}', fmt=NUM2)
                self.put(ws, fila, 7, f'=ROUND(E{fila}*F{fila},{DEC})', fmt=NUM2)
                for c in range(2, 8): ws.cell(fila, c).border = B_BOT
            elif tipo == 'total':
                key = obj
                # buscar inicio del grupo
                gi = [x for x in self.ins_layout if x[0] == 'grupo' and (x[1] == key or x[1].startswith(key))][0][2] + 1
                self.put(ws, fila, 3, f'Total {key}', F_B, al=Alignment(horizontal='right'))
                self.put(ws, fila, 7, f'=SUM(G{gi}:G{fila-1})', F_B, NUM2, border=B_TOT)
                self.tot_rows.append((key, fila))
        r = self.fila_total_ins
        self.put(ws, r, 3, 'TOTAL INSUMOS (costo directo por recursos)', F_B, al=Alignment(horizontal='right'))
        self.put(ws, r, 7, '=' + '+'.join(f'G{x}' for _, x in self.tot_rows), F_B, NUM2, border=B_HEAD)
        self.r_ins_total = r
        self.tot_ins = dict(self.tot_rows)

    # ---------------------------------------------------------------- GASTOS GENERALES
    def gastos(self):
        ws = self.hoja(S_GG, {'A': 3, 'B': 50, 'C': 22, 'D': 22, 'E': 70}, '')
        self.membrete(ws, 'Gastos generales', 5)
        for c, t in enumerate(['Concepto', 'Porcentaje', 'Importe S/.', 'Base / fuente'], 2):
            self.put(ws, 7, c, t, F_B, border=B_HEAD, al=Alignment(horizontal='left' if c in (2, 5) else 'center'))
        cd = f'{S_PRE}!$G${self.r_cd}'
        rows = [('Costo directo', None, f'={cd}', 'PRESUPUESTO_S10 (suma de capítulos)'),
                ('Gastos generales fijos (GGF)', f'={GGF}', f'=ROUND(D8*C9,{DEC})', 'Costo directo × tasa GGF'),
                ('Gastos generales variables (GGV)', f'={GGV}', f'=ROUND(D8*C10,{DEC})', 'Costo directo × tasa GGV'),
                ('Total de gastos generales', None, '=D9+D10', 'GGF + GGV'),
                ('Utilidad', f'={UTIL}', f'=ROUND(D8*C12,{DEC})', 'Costo directo × tasa de utilidad')]
        for k, (a, b, c, d) in enumerate(rows):
            r = 8 + k
            self.put(ws, r, 2, a, F_B if k in (0, 3) else F_N)
            if b: self.put(ws, r, 3, b, fmt='0.00%')
            self.put(ws, r, 4, c, F_B if k in (0, 3) else F_N, NUM2); self.put(ws, r, 5, d, F_G)
        self.put(ws, 14, 2, 'Estado del desglose analítico: PENDIENTE', F_B)
        self.put(ws, 15, 2, 'La fuente (JSON) sólo aporta tasas globales de GGF/GGV; no se fabrica un desglose por rubros (personal, oficina, seguros, fianzas). '
                              'Cuando existan los rubros, se incorporan aquí por mes × participación × costo mensual (ver agente de gastos generales).', F_G)

    # ---------------------------------------------------------------- RESUMEN
    def resumen(self):
        ws = self.hoja(S_RES, {'A': 3, 'B': 52, 'C': 22, 'D': 22, 'E': 22, 'F': 60}, '')
        self.membrete(ws, 'Resumen del presupuesto (procesamiento)', 6)
        for c, t in enumerate(['Concepto', 'Costo S/.', '% del CD', '', 'Origen de la fórmula'], 2):
            self.put(ws, 7, c, t, F_B, border=B_HEAD)
        t = self.tot_ins
        cd = f'{S_PRE}!$G${self.r_cd}'
        filas = [('Mano de obra', f'={S_INS}!G{t["Mano de Obra"]}', 'INSUMOS_RECURSOS_S10'),
                 ('Materiales', f'={S_INS}!G{t["Materiales"]}', 'INSUMOS_RECURSOS_S10'),
                 ('Equipos', f'={S_INS}!G{t["Equipos"]}', 'INSUMOS_RECURSOS_S10'),
                 ('Subcontratos', f'={S_INS}!G{t["Subcontratos"]}', 'INSUMOS_RECURSOS_S10'),
                 ('Otros (% herramientas, lubricantes, accesorios)', f'={S_INS}!G{t["Otros"]}', 'INSUMOS_RECURSOS_S10'),
                 ('Subpartidas sin desglose', f'={S_INS}!G{t["Subpartidas sin desglose"]}', 'INSUMOS_RECURSOS_S10')]
        for k, (a, f, o) in enumerate(filas):
            r = 8 + k
            self.put(ws, r, 2, a); self.put(ws, r, 3, f, fmt=NUM2); self.put(ws, r, 4, f'=IF({cd}=0,0,C{r}/{cd})', fmt='0.00%'); self.put(ws, r, 6, o, F_G)
        self.put(ws, 14, 2, 'Σ recursos (cierre por insumos)', F_B, border=B_TOT); self.put(ws, 14, 3, '=SUM(C8:C13)', F_B, NUM2, border=B_TOT)
        self.put(ws, 15, 2, 'Costo directo del presupuesto', F_B); self.put(ws, 15, 3, f'={cd}', F_B, NUM2)
        self.put(ws, 16, 2, 'Error de cierre (CD − Σ recursos)', F_B); self.put(ws, 16, 3, '=C15-C14', F_B, NUM2)
        self.put(ws, 16, 6, '=IF(ABS(C16)<0.01,"CIERRE EXACTO (< S/ 0.01)",IF(' + f'{DEC}' + '<15,"Diferencia por redondeo por línea (B18 < 15)","REVISAR"))', F_B)
        self.put(ws, 18, 2, 'Pie del presupuesto', F_B)
        pie = [('Costo directo', f'={S_PRE}!G{self.r_cd}'), ('Gastos generales fijos', f'={S_PRE}!G{self.r_cd+1}'), ('Gastos generales variables', f'={S_PRE}!G{self.r_cd+2}'),
               ('Utilidad', f'={S_PRE}!G{self.r_cd+3}'), ('Sub total', f'={S_PRE}!G{self.r_sub}'), ('IGV', f'={S_PRE}!G{self.r_igv}'), ('Presupuesto total', f'={S_PRE}!G{self.r_tot}')]
        for k, (a, f) in enumerate(pie):
            self.put(ws, 19 + k, 2, a, F_B if k in (4, 6) else F_N); self.put(ws, 19 + k, 3, f, F_B if k in (4, 6) else F_N, NUM2)
        self.put(ws, 27, 2, 'Control de estructura', F_B)
        ctl = [('Títulos y subtítulos', f'=COUNTBLANK({S_PRE}!D8:D{self.fila_fin_pre})-COUNTBLANK({S_PRE}!B8:B{self.fila_fin_pre})' ),
               ('Partidas', f'=COUNTA({S_PRE}!D8:D{self.fila_fin_pre})'),
               ('Subpartidas con desglose / sin desglose', f'={len(self.subs)} & " / " & {len(self.sub_sin)}')]
        self.put(ws, 28, 2, 'Títulos y subtítulos'); self.put(ws, 28, 3, f'=COUNTA({S_PRE}!B8:B{self.fila_fin_pre})-COUNTA({S_PRE}!D8:D{self.fila_fin_pre})')
        self.put(ws, 29, 2, 'Partidas'); self.put(ws, 29, 3, f'=COUNTA({S_PRE}!D8:D{self.fila_fin_pre})')
        self.put(ws, 30, 2, 'Subpartidas con desglose'); self.put(ws, 30, 3, len(self.subs))
        self.put(ws, 31, 2, 'Subpartidas sin desglose (precio directo)'); self.put(ws, 31, 3, len(self.sub_sin))

    # ---------------------------------------------------------------- CONCILIACION con el JSON fuente
    def conciliacion(self):
        ws = self.hoja(S_CON, {'A': 3, 'B': 14, 'C': 62, 'D': 22, 'E': 22, 'F': 20, 'G': 14}, '')
        self.membrete(ws, 'Conciliación contra el JSON fuente', 7)
        for c, t in enumerate(['Item', 'Capítulo raíz', 'Excel (vivo) S/.', 'JSON fuente S/.', 'Diferencia S/.', 'Dif. %'], 2):
            self.put(ws, 7, c, t, F_B, border=B_HEAD)
        raices = self.hijos_ord[None]
        r = 8
        wbs = {x['item']: x for x in self.D['wbs']['wbs_titulos']}
        for x in raices:
            l = self.seq[x]
            self.put(ws, r, 2, self.item_s10[x]); self.put(ws, r, 3, l['desc'])
            self.put(ws, r, 4, f'={S_PRE}!G{self.row_pre[x]}', fmt=NUM2)
            self.put(ws, r, 5, wbs[l['item']]['parcial'] if l['item'] in wbs else None, F_I, NUM2)
            self.put(ws, r, 6, f'=D{r}-E{r}', fmt=NUM2); self.put(ws, r, 7, f'=IF(E{r}=0,0,F{r}/E{r})', fmt='0.000%')
            r += 1
        self.put(ws, r, 3, 'COSTO DIRECTO', F_B, border=B_TOT)
        for c, col in ((4, 'D'), (5, 'E')): self.put(ws, r, c, f'=SUM({col}8:{col}{r-1})', F_B, NUM2, border=B_TOT)
        self.put(ws, r, 6, f'=D{r}-E{r}', F_B, NUM2, border=B_TOT); self.put(ws, r, 7, f'=IF(E{r}=0,0,F{r}/E{r})', F_B, '0.000%', border=B_TOT)
        self.put(ws, r + 2, 2, 'Lectura: el JSON fuente trae precios unitarios redondeados a 2 decimales por línea (estilo Presto/S10); este libro recalcula con '
                               'B18 de DATOS_GENERALES_S10 (15 = exacto). Con B18 = 2 la diferencia se reduce al redondeo operativo. El JSON es la fuente; no se sobrescribe.', F_G)
        self.put(ws, r + 3, 2, 'Nota: los capítulos del JSON se comparan por código de origen; las diferencias son de redondeo, no de metrado ni de precio de insumo.', F_G)

    # ---------------------------------------------------------------- modelo de control en Python
    def modelo(self):
        """Recalcula en Python (decimales exactos) el costo directo para contrastar con Excel y fijar el texto SON."""
        jor = self.jornada
        sub_price = {}
        def ins_price(c): return self.ins[c]['precio_unitario']
        def cud(a):
            rend, _ = parse_rend(a.get('rendimiento'))
            tot = {}
            for k, _n in GRUPOS:
                s = 0.0
                for x in a['recursos'].get(k, []):
                    cu = x.get('cuadrilla'); qty = x['cantidad']
                    if cu is not None and rend and abs(jor * cu / rend - qty) <= max(1e-5, abs(qty) * 5e-6): qty = jor * cu / rend
                    c = x['codigo']
                    pr = sub_price[c] if c in sub_price else (ins_price(c) if c in self.ins else x['precio_unitario'])
                    s += qty * pr
                tot[k] = s
            std = dict(tot)                 # la base de los % es la suma de líneas estándar del grupo
            for x in a['recursos'].get('otros', []):
                tot[PCT_EN.get(x['base_calculo'], 'equipos')] += x['cantidad'] / 100 * std.get(BASE_GRUPO[x['base_calculo']], 0.0)
            return sum(tot.values())
        pend = dict(self.subs)
        for s in self.sub_sin: sub_price[s['codigo']] = s['precio_unitario']
        for _ in range(10):
            for c in list(pend):
                refs = [x['codigo'] for k in pend[c]['recursos'] for x in pend[c]['recursos'][k] if k == 'subpartidas' or x['codigo'] in self.subs]
                if all(r in sub_price or r == c for r in refs):
                    sub_price[c] = cud(pend[c]); del pend[c]
        assert not pend, f'ciclo/ref no resuelta: {list(pend)[:3]}'
        cd = 0.0; dif = []
        for i in self.partidas_idx:
            pu = cud(self.part[i]['a']); cd += pu * self.part[i]['p']['metrado']
            pj = self.part[i]['p']['precio_unitario']
            if pj and abs(pu - pj) / pj > 0.002: dif.append((self.seq[i]['item'], round(pu, 4), pj))
        self.cd_py = cd
        g = float(next(r[1] for r in self.D['dg'] if str(r[0]).startswith('Tasa de Gastos Generales Fijos')))
        v = float(next(r[1] for r in self.D['dg'] if str(r[0]).startswith('Tasa de Gastos Generales Variables')))
        u = float(next(r[1] for r in self.D['dg'] if str(r[0]).startswith('Tasa de Utilidad')))
        i_ = float(next(r[1] for r in self.D['dg'] if str(r[0]).startswith('Tasa de IGV')))
        sub = cd * (1 + g + v + u); self.total_py = sub * (1 + i_)
        self.dif_pu = dif
        return cd

    def pie_son(self):
        ws = self.ws_pre
        self.put(ws, self.r_son, 3, 'SON: ' + son(self.total_py), F_B)
        self.put(ws, self.r_son + 1, 3, 'Texto SON calculado con el modelo de control en Python (decimales exactos); si cambia B18 o algún dato, actualizar con el generador.', F_G)

    def orden_hojas(self):
        orden = [DG, S_PRE, S_APU, S_INS, S_GG, S_SUB, S_LST, S_RES, S_CON]
        self.wb._sheets = [self.wb[n] for n in orden]
        for ws in self.wb.worksheets:
            ws.sheet_properties.tabColor = '808080' if ws.title in (S_RES, S_CON) else None

    def construir(self):
        self.preparar()
        self.datos()
        self.presupuesto()
        self.asignar_insumos()
        self.apu_subpartidas()
        self.listado()
        self.insumos()
        self.gastos()
        self.resumen()
        self.conciliacion()
        self.modelo()
        self.pie_son()
        self.orden_hojas()
        self.wb.save(self.args.salida)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--json-dir', required=True)
    ap.add_argument('--salida', required=True)
    args = ap.parse_args()
    if os.path.exists(args.salida):
        sys.exit('El archivo de salida ya existe; no se sobrescribe: ' + args.salida)
    D = cargar(args)
    lb = Libro(D, args)
    lb.construir()
    print('OK', args.salida)
    print('CD (modelo Python, exacto): {:,.2f}'.format(lb.cd_py), '| Total con IGV: {:,.2f}'.format(lb.total_py))
    print('Partidas con PU distinto del JSON > 0.2 %:', len(lb.dif_pu), lb.dif_pu[:8])
    for m in lb.msgs[:20]: print(m)
    print('Avisos:', len(lb.msgs))


if __name__ == '__main__':
    main()
