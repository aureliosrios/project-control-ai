"""Motor histórico retirado: no contiene ni genera datos de otra obra."""
import sys
from pathlib import Path
package = Path(__file__).resolve().parents[2] / ".agents/skills/primavera-p6-xer-generation"
print("Use el agente portátil: " + str(package / "SKILL.md"))
print("CLI: python " + str(package / "scripts/p6_agente.py") + " --help")
sys.exit(2)
