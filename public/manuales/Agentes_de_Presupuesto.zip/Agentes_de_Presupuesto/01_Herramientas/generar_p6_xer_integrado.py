"""Fachada compatible por ubicación; el motor reutilizable está en el paquete portátil."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[2] / ".agents/skills/primavera-p6-xer-generation"
sys.path.insert(0, str(PACKAGE / "scripts"))
from p6_comun import ErrorP6, exigir, leer_json
from p6_entorno import perfil
from p6_motor import generar
from p6_adaptadores import adaptar_integrado, contrastar_bas

def main():
    ap = argparse.ArgumentParser(description=__doc__, epilog="Sin precios, calendario ni código de otro proyecto. Ver el README del paquete.")
    ap.add_argument("--integrado", required=True, type=Path)
    ap.add_argument("--salida", required=True, type=Path)
    ap.add_argument("--calendario", required=True, type=Path)
    ap.add_argument("--fecha-inicio")
    ap.add_argument("--codigo-corto", required=True)
    ap.add_argument("--revision", required=True)
    ap.add_argument("--nombre-calendario")
    ap.add_argument("--dias-mes", type=float)
    ap.add_argument("--dias-anio", type=float)
    ap.add_argument("--bas", action="append", default=[], type=Path)
    ap.add_argument("--con-udf", action="store_true")
    ap.add_argument("--perfil", type=Path)
    ap.add_argument("--p6-db", type=Path)
    ap.add_argument("--referencia-xer", type=Path)
    ap.add_argument("--version-p6")
    ap.add_argument("--motor-p6", choices=["SQLite", "Oracle", "SQL Server", "desconocido"])
    a = ap.parse_args()
    exigir(not a.salida.exists(), "Salida existente: use una revisión nueva")
    pr = leer_json(a.perfil) if a.perfil else perfil(a.version_p6, a.motor_p6, a.referencia_xer, a.p6_db)
    doc = adaptar_integrado(leer_json(a.integrado), leer_json(a.calendario), a.codigo_corto, a.revision, a.integrado,
                            inicio=a.fecha_inicio, nombre=a.nombre_calendario, dias_mes=a.dias_mes, dias_anio=a.dias_anio)
    if a.bas:
        doc["comparacion_bas"] = contrastar_bas(doc, a.bas)
    result = generar(doc, pr, a.salida, udf=a.con_udf)
    print(json.dumps(result, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    try:
        sys.exit(main())
    except (ErrorP6, KeyError, ValueError, TypeError, OSError) as e:
        print("DETENIDO: " + str(e), file=sys.stderr)
        sys.exit(2)
