// Entrada Node.js/MJS del mismo generador: un único cálculo económico y contrato JSON.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { planFormato } from '../02_Plantillas/formato_presentacion.js';
const dir = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const tipo = args[args.indexOf('--formato') + 1];
planFormato(JSON.parse(fs.readFileSync(path.join(dir, '../02_Plantillas/formatos_s10_presto.json'), 'utf8')), tipo);
const home = process.env.USERPROFILE || process.env.HOME || '';
const codexPython = path.join(home, '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe');
const python = process.env.PRESUPUESTO_PYTHON || process.env.CODEX_BUDGET_PYTHON || (fs.existsSync(codexPython) ? codexPython : 'python');
const result = spawnSync(python, [path.join(dir, 'generar_presentacion.py'), ...args], { stdio: 'inherit', shell: false });
if (result.error) throw result.error;
process.exit(result.status ?? 1);
