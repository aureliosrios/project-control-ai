"""Presentaciones S10/Presto desde el Excel activo; conserva sus coeficientes vivos.
El usuario ha solicitado plantillas Python y JavaScript: openpyxl implementa PY.
No interpreta una captura JSON R02 como sustituto del libro vivo.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, re, subprocess
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.workbook.properties import CalcProperties
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / 'Agentes_de_Presupuesto/02_Plantillas/formatos_s10_presto.json'

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def remap(value, names):
    if not isinstance(value, str): return value
    for old,new in names.items(): value=value.replace(old,new)
    return value

def normalized(value):
    if isinstance(value,str) and value.startswith('='):
        return re.sub(r"'([A-Za-z_][A-Za-z_0-9]*)'!",r'\1!',value)
    return value

def equivalent(a,b):
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):
        return abs(a-b)<=max(1e-9,abs(b)*1e-13)
    return normalized(a)==normalized(b)

def build(project, fmt, output=None, recalc=True):
    p=ROOT/'Proyectos'/project
    index=json.loads((ROOT/'Proyectos/indice_proyectos.json').read_text(encoding='utf-8-sig'))
    if project not in json.dumps(index): raise ValueError('Proyecto ausente del índice')
    meta=json.loads((p/'proyecto.json').read_text(encoding='utf-8-sig'))
    source=p/meta['entregables']['excel']
    for name in ('01_Entrada_Minima/LEER_PRIMERO.md','03_Cerebro/pendientes.json'):
        (p/name).read_text(encoding='utf-8-sig')
    if output:
        out=Path(output).resolve()
        if out.exists(): raise FileExistsError('No se sobrescriben entregables')
    else:
        folder=p/'04_Presupuesto'/f'{meta["revision_vigente"]}_Vigente'/'Salidas'/('P_'+fmt.upper()+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3])
        out=folder/f'Presupuesto_{meta["revision_vigente"]}_{fmt.upper()}_PROVISIONAL.xlsx'
    if out==source.resolve(): raise ValueError('El maestro no puede sobrescribirse')
    out.parent.mkdir(parents=True,exist_ok=True)
    cfg=json.loads(CONFIG.read_text(encoding='utf-8'))[fmt]
    w=openpyxl.load_workbook(source)
    names=cfg['names']
    for s in w:
        original=s.title
        for row in s:
            for c in row:
                if c.value is not None: c.value=remap(c.value,names)
                if fmt=='presto' and c.row<=2 and isinstance(c.value,str) and c.data_type!='f': c.value=c.value.replace('S10 ERP','PRESTO')
        s.title=names.get(original,original)
    for defined in w.defined_names.values(): defined.attr_text=remap(defined.attr_text,names)
    budget=w[names.get('PRESUPUESTO_S10','PRESUPUESTO_S10')]
    budget['B2']=f'PRESUPUESTO {fmt.upper()} — {meta.get("moneda_entregables", "PEN")} — {meta["revision_vigente"]} PROVISIONAL'
    w[names.get('ANALISIS_APU_S10','ANALISIS_APU_S10')]['B2']=f'{fmt.upper()} — ANÁLISIS DE PRECIOS UNITARIOS'
    if fmt=='presto':
        cp=w.create_sheet('CUADRO_PRECIOS_1')
        cp.append(['CUADRO DE PRECIOS Nº 1 — PRESTO / PROVISIONAL'])
        cp.append(['Código','Resumen','Ud','Precio'])
        for r in range(10,budget.max_row+1):
            if re.fullmatch(r'\d{2}\.\d{2}',str(budget.cell(r,2).value or '')) and budget.cell(r,4).value:
                cp.append([f"='{budget.title}'!B{r}",f"='{budget.title}'!C{r}",f"='{budget.title}'!D{r}",f"='{budget.title}'!F{r}"])
    # No se fabrican descomposiciones: únicamente bloques explícitos de subpartidas.
    sub=w.create_sheet(cfg['subapu']); listing=w.create_sheet(cfg['sublist'])
    sub.append(['ANÁLISIS DE SUBPARTIDAS — PROVISIONAL'])
    listing.append(['LISTADO DE SUBPARTIDAS — PROVISIONAL'])
    headers=['APU padre','Código','Descripción','Ud','Cantidad','Precio','Parcial']
    sub.append(headers); listing.append(headers)
    apu=w[names.get('ANALISIS_APU_S10','ANALISIS_APU_S10')]
    active=False; parent=''; count=0
    for r in range(1,apu.max_row+1):
        b=str(apu.cell(r,2).value or ''); desc=str(apu.cell(r,3).value or '')
        if b.startswith('Partida:'): parent=b; active=False
        if desc.casefold()=='subpartidas': active=True; continue
        if desc.casefold() in ('mano de obra','materiales','equipos','herramientas','subcontratos'): active=False
        if active and apu.cell(r,2).value and apu.cell(r,4).value:
            vals=[parent]+[f"='{apu.title}'!{col}{r}" for col in ('B','C','D','F','G','H')]
            sub.append(vals); listing.append(vals); count+=1
    gen=w[names.get('DATOS_GENERALES_S10','DATOS_GENERALES_S10')]
    for s in w:
        s.sheet_view.showGridLines=False
        # El rediseño de presentación sustituye colores condicionales históricos.
        s.conditional_formatting._cf_rules.clear()
        s.sheet_properties.pageSetUpPr.fitToPage=True
        s.page_setup.orientation='landscape'; s.page_setup.paperSize=s.PAPERSIZE_A4
        s.page_setup.fitToWidth=1; s.page_setup.fitToHeight=0
        s.print_options.horizontalCentered=True
        s.print_area=s.calculate_dimension()
        s.oddFooter.center.text='Página &P de &N — PROVISIONAL'
        for row in s:
            for c in row:
                if c.value is None: continue
                bold=c.font.bold
                c.font=Font(name=cfg['font'],size=cfg['font_size'],bold=bold,color=cfg['header_color'] if bold else '000000')
                c.fill=PatternFill('solid',fgColor=cfg['section_fill'] if bold else 'FFFFFF')
                c.alignment=Alignment(vertical='center',wrap_text=True)
                if c.data_type=='f' or isinstance(c.value,(int,float)):
                    if '%' not in c.number_format and 'US$' not in c.number_format: c.number_format='#,##0.00'
                if bold: c.border=Border(bottom=Side(style='thin',color='A0A0A0'))
        for r in range(1,s.max_row+1): s.row_dimensions[r].height=cfg['row_height']
        for r in (1,2):
            nonempty=[c for c in s[r] if c.value is not None]
            if len(nonempty)==1 and isinstance(nonempty[0].value,str) and nonempty[0].data_type!='f':
                c=nonempty[0]
                end=s.max_column
                if end>c.column:
                    conflicts=[m for m in s.merged_cells.ranges if m.min_row<=r<=m.max_row]
                    for m in conflicts: s.unmerge_cells(str(m))
                    s.merge_cells(start_row=r,start_column=c.column,end_row=r,end_column=end)
                c.font=Font(name=cfg['font'],size=12 if r==1 else 10,bold=True,color=cfg['header_color'])
                c.fill=PatternFill('solid',fgColor=cfg['header_fill'])
                s.row_dimensions[r].height=45
        for col,dim in s.column_dimensions.items():
            if dim.width: dim.width=max(12,min(dim.width,85))
        s.freeze_panes=None
        s.sheet_view.pane=None
    for col,width in cfg['budget_widths'].items(): budget.column_dimensions[col].width=width
    for s in (sub,listing):
        s.column_dimensions['A'].width=65; s.column_dimensions['B'].width=16; s.column_dimensions['C'].width=70
        for col in ('D','E','F','G'): s.column_dimensions[col].width=18
        s.row_dimensions[3].height=45
    if fmt=='presto':
        cp.column_dimensions['A'].width=15; cp.column_dimensions['B'].width=78
        cp.column_dimensions['C'].width=10; cp.column_dimensions['D'].width=20
    # Formato extendido de partidas en análisis de PU: combinación y estilo de columnas B a H para ver el nombre completo sin truncar ni arrumar
    for r in range(1,apu.max_row+1):
        b=str(apu.cell(r,2).value or '')
        if b.startswith('Partida:'):
            apu.merge_cells(start_row=r,start_column=2,end_row=r,end_column=8)
            for c_idx in range(2,9):
                cell=apu.cell(row=r,column=c_idx)
                cell.font=Font(name=cfg['font'],size=cfg['font_size'],bold=True,color=cfg['header_color'])
                cell.fill=PatternFill('solid',fgColor=cfg['section_fill'])
                cell.border=Border(top=Side(style='thin',color='D0D0D0'),bottom=Side(style='thin',color='A0A0A0'))
            apu.cell(r,2).alignment=Alignment(vertical='center',horizontal='left',wrap_text=False)
    # Datos generales primero, preservando B4 Jornal y todas las referencias.
    ordered=[gen,budget]+([w['CUADRO_PRECIOS_1']] if fmt=='presto' else [])
    w._sheets=ordered+[s for s in w if s not in ordered]
    w.calculation=CalcProperties(calcId=191029,fullCalcOnLoad=True)
    w.save(out)
    status='NO_VERIFICADO_EN_EXCEL'
    if recalc:
        proc=subprocess.run(['powershell','-NoProfile','-File',str(Path(__file__).with_name('recalcular_presentacion.ps1')),str(out)],capture_output=True,text=True)
        if proc.returncode: raise RuntimeError(proc.stdout+proc.stderr)
        status='RECALCULADO_EXCEL'
    # Verificación de preservación inversa de cada entrada y fórmula del maestro.
    original=openpyxl.load_workbook(source); generated=openpyxl.load_workbook(out)
    inverse={new:old for old,new in names.items()}; formulas=0
    for s in original:
        target=generated[names.get(s.title,s.title)]
        for row in s:
            for c in row:
                if c.value is None: continue
                if c.coordinate=='B2' and s.title in ('PRESUPUESTO_S10','ANALISIS_APU_S10'): continue
                expected=c.value
                if fmt=='presto' and c.row<=2 and isinstance(expected,str) and c.data_type!='f': expected=expected.replace('S10 ERP','PRESTO')
                if not equivalent(remap(target[c.coordinate].value,inverse),expected): raise ValueError(f'Alteración de dato: {s.title}!{c.coordinate}')
                formulas+=c.data_type=='f'
    cached=openpyxl.load_workbook(out,data_only=True)
    errors=[f'{s.title}!{c.coordinate}:{c.value}' for s in cached for row in s for c in row if c.data_type=='e']
    if errors: raise ValueError(str(errors[:15]))
    master_cached=openpyxl.load_workbook(source,data_only=True)
    total_original=master_cached['PRESUPUESTO_S10']['G108'].value
    total_new=cached[budget.title]['G108'].value
    if recalc and (not isinstance(total_new,(int,float)) or abs(total_new-total_original)>0.01): raise ValueError(f'Total no conciliado: {total_original} / {total_new}')
    propagation=None
    if recalc:
        test=subprocess.run(['powershell','-NoProfile','-File',str(Path(__file__).with_name('probar_formulas_presentacion.ps1')),'-Path',str(out),'-Formato',fmt],capture_output=True,text=True)
        if test.returncode: raise RuntimeError(test.stdout+test.stderr)
        propagation=json.loads(test.stdout)
    report={'estado':status,'fuente':str(source),'sha256_fuente':digest(source),'salida':str(out),'sha256_salida':digest(out),'formulas_preservadas':formulas,'subpartidas_explicitas':count,'errores_excel':errors,'total_original':total_original,'total_presentacion':total_new,'prueba_propagacion':propagation,'dictamen':'BORRADOR_OBSERVADO'}
    (out.parent/'verificacion.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    project_manifest=p/'05_Trazabilidad/manifest_archivos.json'
    manifest=json.loads(project_manifest.read_text(encoding='utf-8-sig'))
    for file in (out,out.parent/'verificacion.json'):
        manifest['archivos'].append({'ruta':file.relative_to(p).as_posix(),'sha256':digest(file),'bytes':file.stat().st_size})
    project_manifest.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))
    return out

if __name__=='__main__':
    a=argparse.ArgumentParser(); a.add_argument('--proyecto',required=True); a.add_argument('--formato',required=True,choices=['s10','presto']); a.add_argument('--salida'); a.add_argument('--sin-excel',action='store_true')
    args=a.parse_args(); build(args.proyecto,args.formato,args.salida,not args.sin_excel)
