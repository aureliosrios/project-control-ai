"""Orquesta cerebro digital -> entrada canónica -> validación -> Excel -> verificación -> manifiesto.

Ejemplo:
  python generar_presupuesto.py --proyecto OBRA_002 --revision R01_Borrador --estado BORRADOR_REFERENCIAL --vigente

No sobrescribe revisiones: la carpeta 04_Presupuesto/<revision> debe estar vacía o no existir.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import _entorno as env  # noqa: E402
import informe_supuestos  # noqa: E402
import ingesta_mapa  # noqa: E402

ROOT = env.ROOT
ENGINE = env.NUCLEO / "scripts" / "budget_engine.py"
POST = env.NUCLEO / "scripts" / "postprocesar_excel_s10.mjs"
CONSTRUIR = env.HERRAMIENTAS / "construir_entrada.py"


def load(p: Path, default=None):
    if not p.is_file():
        return default
    return json.loads(p.read_text(encoding="utf-8-sig"))


def dump(p: Path, d):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run(cmd: list, cwd=None, allow_fail=False):
    proc = subprocess.run([str(c) for c in cmd], cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if proc.returncode != 0 and not allow_fail:
        raise RuntimeError(f"Falló: {' '.join(str(c) for c in cmd)}\n{proc.stdout}\n{proc.stderr}")
    return proc


def engine(*args, allow_fail=False):
    return run([env.find_python(), ENGINE, *args], allow_fail=allow_fail)


def parse_json_output(proc):
    text = proc.stdout.strip()
    start = text.find("{")
    return json.loads(text[start:]) if start >= 0 else {}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--proyecto", required=True)
    ap.add_argument("--revision", required=True, help="Nombre de la carpeta de revisión, p. ej. R01_Borrador")
    ap.add_argument("--estado", default="BORRADOR_REFERENCIAL")
    ap.add_argument("--formato", choices=["s10", "presto"], default="s10")
    ap.add_argument("--sin-excel", action="store_true", help="Solo JSON y validación (sirve para PC sin el runtime de Excel)")
    ap.add_argument("--vigente", action="store_true", help="Declarar la revisión como vigente en proyecto.json y el índice")
    args = ap.parse_args(argv)

    p = Path(args.proyecto)
    project = p if p.is_dir() else ROOT / "Proyectos" / args.proyecto
    if not (project / "proyecto.json").is_file():
        print(json.dumps({"status": "FAIL", "error": f"Proyecto sin proyecto.json: {project}"}, ensure_ascii=False))
        return 2
    brain = project / "03_Cerebro" / "cerebro_digital"
    rev_dir = project / "04_Presupuesto" / args.revision
    if rev_dir.exists() and any(rev_dir.iterdir()):
        print(json.dumps({"status": "FAIL", "error": f"La revisión {args.revision} ya existe; usar otro nombre (no se sobrescribe)."}, ensure_ascii=False))
        return 2
    rev_short = args.revision.split("_")[0]
    steps = {}

    diag = env.diagnostico()
    steps["entorno"] = diag
    want_excel = not args.sin_excel and args.formato == "s10"
    if want_excel and diag["problemas"]:
        print(json.dumps({"status": "FAIL", "error": "Entorno incompleto para generar Excel", "entorno": diag}, ensure_ascii=False, indent=2))
        return 3

    if (project / "01_Entrada_Minima" / "00_MAPA_INGESTA.md").is_file():
        steps["ingesta"] = ingesta_mapa.run(project)
        dump(project / "05_Trazabilidad" / "inventario_ingesta.json", steps["ingesta"])

    entrada = project / "03_Cerebro" / "entrada_presupuesto.json"
    comp = run([env.find_python(), CONSTRUIR, "--proyecto", project, "--salida", entrada], allow_fail=True)
    if comp.returncode != 0:
        print(comp.stdout)
        return 1
    steps["construir_entrada"] = parse_json_output(comp)

    rev_dir.mkdir(parents=True, exist_ok=True)
    entrada_rev = rev_dir / f"presupuesto_s10_entrada_{rev_short}.json"
    entrada_rev.write_bytes(entrada.read_bytes())

    val = {}
    for mode in ("draft", "strict"):
        proc = engine("validate", "--input", entrada, "--mode", mode, allow_fail=True)
        val[mode] = parse_json_output(proc)
        val[mode]["exit_code"] = proc.returncode
    steps["validacion"] = {k: {"status": v.get("status"), "errores": v.get("errors", [])[:10]} for k, v in val.items()}
    if val["draft"].get("status") != "PASS":
        print(json.dumps({"status": "FAIL", "paso": "validate draft", "errores": val["draft"].get("errors")}, ensure_ascii=False, indent=2))
        return 1

    comp_dir = rev_dir / "compilado"
    build_args = ["build", "--input", entrada, "--output-dir", comp_dir, "--mode", "draft", "--format", args.formato]
    if not want_excel:
        build_args.append("--no-xlsx")
    engine(*build_args)
    result_path = comp_dir / "budget_result.json"
    result = load(result_path)

    supuestos = load(brain / "supuestos.json", [])
    informe = informe_supuestos.build(supuestos, result)
    sup_json = rev_dir / f"supuestos_{rev_short}.json"
    sup_md = rev_dir / f"supuestos_{rev_short}.md"
    dump(sup_json, informe)
    sup_md.write_text(informe_supuestos.to_markdown(informe, args.revision), encoding="utf-8")

    pendientes = load(brain / "pendientes.json", {"pendientes": []})
    pend_path = rev_dir / f"pendientes_{rev_short}.json"
    dump(pend_path, pendientes)
    proyecto_cerebro = load(brain / "proyecto.json", {})
    estado_txt = args.estado.replace("_", " ")
    strict_ok = val["strict"].get("status") == "PASS"
    n_sup = len(informe)
    meta = {
        "revision": rev_short, "estado_etiqueta": estado_txt, "estado_corto": estado_txt.split()[-1],
        "validacion_draft": "PASS", "validacion_strict": "PASS" if strict_ok else "FAIL",
        "nota_strict": (f"Pasa formalmente, pero hay {n_sup} supuestos abiertos: NO es emisión definitiva" if strict_ok and n_sup
                        else ("Cumple strict" if strict_ok else "Fuentes pendientes: ver observaciones")),
        "naturaleza_metrados": proyecto_cerebro.get("naturaleza_metrados", "SIN CLASIFICAR"),
        "utilidad_pendiente": bool(proyecto_cerebro.get("utilidad_pendiente", False)),
        "nota_gg": "Con supuestos: ver hoja SUPUESTOS" if any("GG " in e for r in informe for e in r["elementos_afectados"]) else "",
        "nota_gg_hoja": "GASTOS GENERALES CON SUPUESTOS DEL AGENTE — VER HOJA SUPUESTOS" if any("GG " in e for r in informe for e in r["elementos_afectados"]) else "",
        "nota_validacion": f"Draft: PASS. Strict: {'PASS formal' if strict_ok else 'FAIL'}. Supuestos abiertos: {n_sup}.",
    }
    meta_path = rev_dir / f"meta_{rev_short}.json"
    dump(meta_path, meta)

    excel = None
    if want_excel:
        excel = rev_dir / f"Presupuesto_S10_{args.revision}.xlsx"
        post = run([env.find_node(), POST, comp_dir / "budget_live.xlsx", entrada_rev, result_path, pend_path, meta_path,
                    sup_json if informe else "-", excel, rev_dir / "qa"])
        steps["postproceso"] = post.stdout.strip().splitlines()[-1] if post.stdout.strip() else ""
        ver = engine("verify", "--json", result_path, "--xlsx", excel, allow_fail=True)
        steps["verify"] = parse_json_output(ver)
        if steps["verify"].get("status") != "PASS":
            print(json.dumps({"status": "FAIL", "paso": "verify", "detalle": steps["verify"]}, ensure_ascii=False, indent=2))
            return 1

    # ---- Manifiesto ----
    prev = None
    prev_rev = load(project / "proyecto.json", {}).get("revision_vigente")
    prev_result = project / "04_Presupuesto" / prev_rev if prev_rev else None
    if prev_result:
        for cand in (prev_result / "compilado" / "budget_result.json", *prev_result.glob("presupuesto_s10_resultado_*.json")):
            if cand.is_file():
                prev = load(cand)["summary"]
                break
    files = [entrada_rev, result_path, sup_json, sup_md, pend_path, meta_path] + ([excel] if excel else [])
    manifest = {
        "proyecto": project.name, "revision": args.revision, "estado": args.estado, "revision_anterior": prev_rev,
        "resumen": result["summary"],
        "comparacion_anterior": ({k: {"anterior": round(prev[k], 2), "actual": round(result["summary"][k], 2),
                                      "delta": round(result["summary"][k] - prev[k], 2)} for k in result["summary"] if k in prev} if prev else None),
        "validacion": {"draft": "PASS", "strict": "PASS formal" if strict_ok else "FAIL",
                       "verify": steps.get("verify", {}).get("status", "NO_EJECUTADO")},
        "supuestos_abiertos": n_sup,
        "archivos": [{"ruta": str(f.relative_to(project)).replace("\\", "/"), "sha256": sha(f), "bytes": f.stat().st_size} for f in files],
        "limitacion": "Borrador con supuestos del agente: no es emisión definitiva ni archivo nativo S10." if n_sup else "Presentación Excel local; no es archivo nativo S10.",
    }
    dump(rev_dir / f"manifest_{rev_short}.json", manifest)

    if args.vigente:
        pm = load(project / "proyecto.json")
        pm["estado"] = args.estado
        pm["revision_vigente"] = args.revision
        pm["entradas"]["canonico"] = "03_Cerebro/entrada_presupuesto.json"
        pm.setdefault("entregables", {}).update({
            "revision": f"04_Presupuesto/{args.revision}",
            "entrada_json": f"04_Presupuesto/{args.revision}/{entrada_rev.name}",
            "resultado_json": f"04_Presupuesto/{args.revision}/compilado/budget_result.json",
            "manifest": f"04_Presupuesto/{args.revision}/manifest_{rev_short}.json",
            "hash_resultado_json": sha(result_path),
        })
        if excel:
            pm["entregables"]["excel_s10"] = f"04_Presupuesto/{args.revision}/{excel.name}"
            pm["entregables"]["hash_excel"] = sha(excel)
        dump(project / "proyecto.json", pm)
        idx_path = ROOT / "Proyectos" / "indice_proyectos.json"
        idx = load(idx_path, {"proyectos": []})
        for row in idx.get("proyectos", []):
            if row.get("codigo") == project.name:
                row["estado"] = args.estado
                row["revision_vigente"] = args.revision
        dump(idx_path, idx)

    print(json.dumps({"status": "PASS", "revision": args.revision, "resumen": result["summary"], "supuestos_abiertos": n_sup,
                      "excel": str(excel) if excel else None, "manifiesto": str(rev_dir / f"manifest_{rev_short}.json"),
                      "avisos": steps["construir_entrada"].get("avisos", [])}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
