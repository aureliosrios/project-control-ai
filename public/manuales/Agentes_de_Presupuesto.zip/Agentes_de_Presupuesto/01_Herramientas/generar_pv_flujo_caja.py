"""Plantilla Excel de PV semanal (HH y USD), curva S y flujo de caja con adelanto y cobranza diferida.

Toma las actividades, el metrado, el precio unitario y las horas-hombre del JSON integrado
presupuesto + cronograma (``integrar_presupuesto_cronograma.py``). Todo lo calculado es fórmula viva:

  ACTIVIDADES   metrado × precio unitario (PARTIDAS)  → costo USD;  metrado × HH por unidad → HH
  PV_SEMANAL    reparto uniforme de cada actividad en sus días, sumado por semana (SUMPRODUCT)
  PV_MENSUAL    el mismo reparto por período de valorización (días por mes editables)
  FLUJO_CAJA    adelanto, valorización mensual, amortización, cobranza diferida N meses y egresos
  CURVA_S       gráficos de curva S (% acumulado USD y HH) y de PV semanal

Los datos que el proyecto marca como pendientes del usuario (fecha de inicio, días por mes de valorización)
no se completan por defecto: se reciben por argumento y quedan como celdas editables en DATOS.

Uso:  python generar_pv_flujo_caja.py --integrado <json> --salida <carpeta nueva> --fecha-inicio AAAA-MM-DD
        [--dias-mes 30] [--adelanto 0.20] [--meses-cobranza 2] [--incluir-igv 0] [--velocidad 4] [--prueba-oculta]
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.datavalidation import DataValidation

AZUL = "1F3864"
FILL_H = PatternFill("solid", fgColor=AZUL)
FILL_IN = PatternFill("solid", fgColor="FFF2CC")
FILL_REF = PatternFill("solid", fgColor="EDEDED")
FILL_OK = PatternFill("solid", fgColor="C6EFCE")
FILL_BAD = PatternFill("solid", fgColor="FFC7CE")
F_H = Font(bold=True, color="FFFFFF")
F_IN = Font(color="0000FF")
F_T = Font(bold=True, size=14, color=AZUL)
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
USD, USD0, HH, PCT, FECHA = '#,##0.00', '#,##0', '#,##0.0', '0.0%', 'dd/mm/yyyy'


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def encabezado(ws, fila, titulos, ancho=None):
    for j, t in enumerate(titulos, 1):
        c = ws.cell(fila, j, t)
        c.fill, c.font, c.border = FILL_H, F_H, BORDER
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[fila].height = 42
    for j, w in enumerate(ancho or [], 1):
        ws.column_dimensions[L(j)].width = w


def construir(doc: dict, a, ruta: Path) -> dict:
    acts = doc["cronograma"]["actividades"]
    partidas = doc["partidas"]
    apus = {x["id"]: x for x in doc["apus"]}
    tot = doc["totales"]
    max_dia = max(x["programacion"]["fin_dia"] for x in acts)
    nsem = math.ceil(max_dia / 7)
    nper = math.ceil(max_dia / a.dias_mes)
    nflujo = nper + 4  # períodos 0..nper+3: admite hasta 3 meses de cobranza diferida sin perder ingresos
    hh_unit = {}
    for p in partidas:
        comp = apus[p["apu_id"]]["componentes"]
        hh_unit[p["id"]] = sum(c["cantidad_por_unidad"] * (1 + c["desperdicio"]) for c in comp if c["tipo"] == "LABOR" and c["unidad"] == "hh")

    wb = Workbook()
    # ------------------------------------------------------------------ DATOS
    d = wb.active
    d.title = "DATOS"
    d["B2"], d["B2"].font = "PV (HH y USD), CURVA S Y FLUJO DE CAJA", F_T
    d["B3"] = f'{doc["proyecto"]["nombre"]} · presupuesto {doc["proyecto"]["revision_presupuesto"]} · cronograma {doc["proyecto"]["revision_cronograma"]} · {doc["proyecto"]["estado"]}'
    d.column_dimensions["A"].width = 2
    d.column_dimensions["B"].width = 62
    d.column_dimensions["C"].width = 18
    d.column_dimensions["D"].width = 90
    filas = [
        (5, "Fecha de inicio del proyecto (día 1)", dt.datetime.combine(a.fecha_inicio, dt.time()), FECHA, True, "Entrada del usuario (misma fecha de la macro MS Project). Mueve todo el calendario."),
        (6, "Días por semana del cronograma (ventana del PV semanal)", 7, "0", True, "Calendario del proyecto: 7 días por semana, 08:00–16:00, sin refrigerio."),
        (7, "Jornada (horas por día)", 8, "0", True, "Calendario del proyecto."),
        (8, "Días por mes de valorización (período)", a.dias_mes, "0", True, "Entrada del usuario (la macro MS Project usa 30 días por mes). Define los cortes mensuales."),
        (9, "Adelanto directo (% del monto del contrato)", a.adelanto, PCT, True, "Solicitado: 20%. Se amortiza en proporción a cada valorización."),
        (10, "Plazo de aprobación y cobro de la valorización (meses desde su presentación)", a.meses_cobranza, "0", True, "Solicitado: 2 meses. La valorización se presenta al cierre del período y se cobra N períodos después."),
        (11, "Incluir IGV en valorizaciones y adelanto (1 = sí, 0 = no)", a.incluir_igv, "0", True, "0 = flujo sin IGV (el IGV es crédito fiscal y no se modela). 1 = ingresos con IGV, egresos sin IGV."),
        (12, "Tasa de IGV", doc["totales"]["igv"]["tasa"], PCT, True, "Del presupuesto R02."),
        (13, "Rezago de pago de egresos (meses)", 0, "0", True, "0 = los costos se pagan en el período en que se ejecutan."),
        (15, "Costo directo del presupuesto (USD)", tot["costo_directo"]["valor"], USD, False, "Referencia del JSON integrado (= PRESUPUESTO_S10!G102 del Excel R02)."),
        (16, "Gastos generales fijos (USD)", tot["gastos_generales_fijos"]["valor"], USD, False, "Referencia del JSON integrado (G103)."),
        (17, "Gastos generales variables (USD)", tot["gastos_generales_variables"]["valor"], USD, False, "Referencia del JSON integrado (G104)."),
        (18, "Utilidad (USD)", tot["utilidad"]["valor"], USD, False, "Referencia del JSON integrado (G105)."),
    ]
    for r, et, val, fmt, entrada, nota in filas:
        d.cell(r, 2, et)
        c = d.cell(r, 3, val)
        c.number_format = fmt
        c.border = BORDER
        if entrada:
            c.fill, c.font = FILL_IN, F_IN
        else:
            c.fill = FILL_REF
        d.cell(r, 4, nota).font = Font(italic=True, color="595959")
    calc = [
        (19, "Precio de venta sin IGV (CD + GG + utilidad)", "=C15+C16+C17+C18", USD, "Subtotal del presupuesto (G106)."),
        (20, "Factor de precio de venta sobre el costo directo", "=C19/C15", "0.0000", "Convierte el PV de costo directo en valorización."),
        (21, "Monto del contrato a valorizar (USD)", "=C19*(1+C11*C12)", USD, "Con o sin IGV según C11."),
        (22, "Adelanto directo (USD)", "=C9*C21", USD, "Se recibe en el período 0 (inicio)."),
        (23, "Duración del proyecto (días)", f"=MAX(ACTIVIDADES!$E$6:$E${5+len(acts)})", "0", "Último día de la programación."),
        (24, "Períodos de valorización del proyecto", "=ROUNDUP(C23/C8,0)", "0", f"Con {a.dias_mes} días por mes; la tabla PV_MENSUAL tiene {nper} filas."),
        (25, "Semanas del proyecto", "=ROUNDUP(C23/C6,0)", "0", f"La tabla PV_SEMANAL tiene {nsem} filas."),
    ]
    for r, et, f, fmt, nota in calc:
        d.cell(r, 2, et)
        c = d.cell(r, 3, f)
        c.number_format, c.border = fmt, BORDER
        d.cell(r, 4, nota).font = Font(italic=True, color="595959")
    d["B27"] = "Celdas amarillas con letra azul = entradas editables; todo lo demás se recalcula."
    d["B27"].font = Font(italic=True)
    d["B28"] = "Supuestos: el PV reparte el costo y las HH de cada actividad de forma uniforme entre sus días; no hay retención de garantía; los gastos generales se distribuyen uniformemente en los períodos del proyecto; la utilidad no es egreso."
    d["B28"].alignment = Alignment(wrap_text=True)
    d.row_dimensions[28].height = 48
    dv = DataValidation(type="list", formula1='"0,1"', allow_blank=False)
    d.add_data_validation(dv)
    dv.add("C11")

    # --------------------------------------------------------------- PARTIDAS
    p_ws = wb.create_sheet("PARTIDAS")
    p_ws["A2"], p_ws["A2"].font = "PARTIDAS · precio unitario (APU) y horas-hombre por unidad", F_T
    p_ws["A3"] = "Precio unitario y HH por unidad provienen de los APU del JSON integrado (APU-xx → componentes de mano de obra en hh)."
    encabezado(p_ws, 5, ["ID partida", "WBS", "Descripción", "Unidad", "Cantidad", "PU directo (USD)", "HH por unidad", "Costo directo (USD)", "HH totales"],
               [14, 8, 70, 8, 12, 16, 14, 18, 14])
    n_p = len(partidas)
    for i, p in enumerate(partidas):
        r = 6 + i
        vals = [p["id"], p["wbs"], p["descripcion"], p["unidad"], p["cantidad"], p["precio_unitario_usd"], hh_unit[p["id"]]]
        for j, v in enumerate(vals, 1):
            c = p_ws.cell(r, j, v)
            c.border = BORDER
        p_ws.cell(r, 8, f"=E{r}*F{r}")
        p_ws.cell(r, 9, f"=E{r}*G{r}")
        p_ws.cell(r, 5).number_format = '#,##0.00'
        p_ws.cell(r, 6).number_format = '#,##0.0000'
        p_ws.cell(r, 7).number_format = '0.0000'
        p_ws.cell(r, 8).number_format = USD
        p_ws.cell(r, 9).number_format = HH
        p_ws.cell(r, 8).border = p_ws.cell(r, 9).border = BORDER
    pf, pl = 6, 5 + n_p
    p_ws.cell(pl + 2, 3, "TOTAL").font = Font(bold=True)
    p_ws.cell(pl + 2, 8, f"=SUM(H{pf}:H{pl})").number_format = USD
    p_ws.cell(pl + 2, 9, f"=SUM(I{pf}:I{pl})").number_format = HH
    for c in (p_ws.cell(pl + 2, 8), p_ws.cell(pl + 2, 9)):
        c.font = Font(bold=True)

    # ------------------------------------------------------------ ACTIVIDADES
    a_ws = wb.create_sheet("ACTIVIDADES")
    a_ws["A2"], a_ws["A2"].font = "ACTIVIDADES del cronograma · costo y HH = metrado × valores de PARTIDAS", F_T
    encabezado(a_ws, 5, ["ID actividad", "ID partida", "Descripción", "Inicio (día)", "Fin (día)", "Duración (días)", "Metrado", "Costo directo (USD)",
                         "HH", "USD por día", "HH por día", "Crítica", "Tipo"], [26, 12, 62, 10, 10, 11, 12, 16, 12, 14, 12, 8, 18])
    f0, fN = 6, 5 + len(acts)
    rngP_id = f"PARTIDAS!$A${pf}:$A${pl}"
    for i, x in enumerate(acts):
        r = f0 + i
        a_ws.cell(r, 1, x["id"]); a_ws.cell(r, 2, x["partida_id"]); a_ws.cell(r, 3, x["descripcion"])
        a_ws.cell(r, 4, x["programacion"]["inicio_dia"]); a_ws.cell(r, 5, x["programacion"]["fin_dia"])
        a_ws.cell(r, 6, f"=E{r}-D{r}+1")
        a_ws.cell(r, 7, x["metrado"]).number_format = '#,##0.0000'
        a_ws.cell(r, 8, f"=G{r}*INDEX(PARTIDAS!$F${pf}:$F${pl},MATCH(B{r},{rngP_id},0))").number_format = USD
        a_ws.cell(r, 9, f"=G{r}*INDEX(PARTIDAS!$G${pf}:$G${pl},MATCH(B{r},{rngP_id},0))").number_format = HH
        a_ws.cell(r, 10, f"=H{r}/F{r}").number_format = USD
        a_ws.cell(r, 11, f"=I{r}/F{r}").number_format = '#,##0.000'
        a_ws.cell(r, 12, "SÍ" if x["programacion"]["critica"] else "NO")
        a_ws.cell(r, 13, x["tipo_actividad"])
        for j in range(1, 14):
            a_ws.cell(r, j).border = BORDER
    a_ws["G3"] = "TOTAL"; a_ws["G3"].font = Font(bold=True)
    a_ws["H3"] = f"=SUM(H{f0}:H{fN})"; a_ws["H3"].number_format = USD
    a_ws["I3"] = f"=SUM(I{f0}:I{fN})"; a_ws["I3"].number_format = HH
    a_ws["H3"].font = a_ws["I3"].font = Font(bold=True)
    AI, AF = f"ACTIVIDADES!$D${f0}:$D${fN}", f"ACTIVIDADES!$E${f0}:$E${fN}"
    A_USD, A_HH = f"ACTIVIDADES!$J${f0}:$J${fN}", f"ACTIVIDADES!$K${f0}:$K${fN}"

    def solape(a_ref, b_ref):
        """Días de cada actividad dentro de la ventana [a, b]: MIN(fin,b) − MAX(ini,a) + 1, solo si se cruzan."""
        return (f"(({AF}<{b_ref})*{AF}+({AF}>={b_ref})*{b_ref}-({AI}>{a_ref})*{AI}-({AI}<={a_ref})*{a_ref}+1)"
                f"*({AF}>={a_ref})*({AI}<={b_ref})")

    # ------------------------------------------------------------- PV_SEMANAL
    s = wb.create_sheet("PV_SEMANAL")
    s["A2"], s["A2"].font = "PV SEMANAL · valor planificado en HH y USD (fórmulas vivas)", F_T
    s["A3"] = "Cada fila suma, para sus 7 días, el costo y las HH diarias de todas las actividades que se cruzan con esa semana (SUMPRODUCT sobre ACTIVIDADES)."
    encabezado(s, 5, ["Semana", "Día inicial", "Día final", "Fecha inicial", "Fecha final", "PV (HH)", "PV (HH) acumulado", "% HH acumulado",
                      "PV (USD) costo directo", "PV (USD) acumulado", "% USD acumulado", "PV (USD) precio de venta"],
               [9, 10, 10, 13, 13, 14, 16, 12, 18, 18, 12, 18])
    s0, sN = 6, 5 + nsem
    for i in range(nsem):
        r = s0 + i
        s.cell(r, 1, i + 1)
        s.cell(r, 2, f"=(A{r}-1)*DATOS!$C$6+1")
        s.cell(r, 3, f"=A{r}*DATOS!$C$6")
        s.cell(r, 4, f"=DATOS!$C$5+B{r}-1").number_format = FECHA
        s.cell(r, 5, f"=DATOS!$C$5+C{r}-1").number_format = FECHA
        s.cell(r, 6, f"=SUMPRODUCT({A_HH},{solape(f'$B{r}', f'$C{r}')})").number_format = HH
        s.cell(r, 7, f"=SUM(F${s0}:F{r})").number_format = HH
        s.cell(r, 8, f"=G{r}/$G${sN}").number_format = PCT
        s.cell(r, 9, f"=SUMPRODUCT({A_USD},{solape(f'$B{r}', f'$C{r}')})").number_format = USD
        s.cell(r, 10, f"=SUM(I${s0}:I{r})").number_format = USD
        s.cell(r, 11, f"=J{r}/$J${sN}").number_format = PCT
        s.cell(r, 12, f"=I{r}*DATOS!$C$20").number_format = USD
        for j in range(1, 13):
            s.cell(r, j).border = BORDER
    s.cell(sN + 2, 5, "TOTAL").font = Font(bold=True)
    for col, fmt in ((6, HH), (9, USD), (12, USD)):
        c = s.cell(sN + 2, col, f"=SUM({L(col)}{s0}:{L(col)}{sN})")
        c.number_format, c.font = fmt, Font(bold=True)

    # ------------------------------------------------------------- PV_MENSUAL
    m = wb.create_sheet("PV_MENSUAL")
    m["A2"], m["A2"].font = "PV POR PERÍODO DE VALORIZACIÓN · mismo cálculo con ventana = días por mes (DATOS!C8)", F_T
    encabezado(m, 5, ["Período", "Día inicial", "Día final", "Fecha inicial", "Fecha final", "PV (HH)", "PV (USD) costo directo", "PV (USD) acumulado", "% USD acumulado"],
               [10, 10, 10, 13, 13, 14, 20, 20, 14])
    m0, mN = 6, 5 + nper
    for i in range(nper):
        r = m0 + i
        m.cell(r, 1, i + 1)
        m.cell(r, 2, f"=(A{r}-1)*DATOS!$C$8+1")
        m.cell(r, 3, f"=A{r}*DATOS!$C$8")
        m.cell(r, 4, f"=DATOS!$C$5+B{r}-1").number_format = FECHA
        m.cell(r, 5, f"=DATOS!$C$5+C{r}-1").number_format = FECHA
        m.cell(r, 6, f"=SUMPRODUCT({A_HH},{solape(f'$B{r}', f'$C{r}')})").number_format = HH
        m.cell(r, 7, f"=SUMPRODUCT({A_USD},{solape(f'$B{r}', f'$C{r}')})").number_format = USD
        m.cell(r, 8, f"=SUM(G${m0}:G{r})").number_format = USD
        m.cell(r, 9, f"=H{r}/$H${mN}").number_format = PCT
        for j in range(1, 10):
            m.cell(r, j).border = BORDER
    m.cell(mN + 2, 5, "TOTAL").font = Font(bold=True)
    for col, fmt in ((6, HH), (7, USD)):
        c = m.cell(mN + 2, col, f"=SUM({L(col)}{m0}:{L(col)}{mN})")
        c.number_format, c.font = fmt, Font(bold=True)

    # ------------------------------------------------------------ FLUJO_CAJA
    f = wb.create_sheet("FLUJO_CAJA")
    f["A2"], f["A2"].font = "FLUJO DE CAJA · adelanto, valorización mensual y cobranza diferida", F_T
    f["A3"] = ("La valorización del período p se presenta al cierre del período y se cobra en el período p + plazo (DATOS!C10). "
               "El adelanto se recibe en el período 0 y se amortiza en proporción a cada valorización.")
    encabezado(f, 5, ["Período", "Fecha de cierre", "Costo directo (PV)", "Gastos generales", "Egresos devengados", "Valorización presentada",
                      "Amortización adelanto", "Valorización neta", "Adelanto recibido", "Cobranza de valorizaciones", "Ingresos totales",
                      "Egresos pagados", "Flujo neto", "Flujo acumulado"], [9, 14, 16, 16, 16, 18, 16, 16, 16, 18, 16, 16, 16, 16])
    c0, cN = 6, 5 + nflujo
    for i in range(nflujo):
        r = c0 + i
        f.cell(r, 1, i)
        f.cell(r, 2, f"=IF(A{r}=0,DATOS!$C$5,DATOS!$C$5+A{r}*DATOS!$C$8-1)").number_format = FECHA
        f.cell(r, 3, f"=IF(AND(A{r}>=1,A{r}<=ROWS(PV_MENSUAL!$G${m0}:$G${mN})),INDEX(PV_MENSUAL!$G${m0}:$G${mN},A{r}),0)").number_format = USD
        f.cell(r, 4, f"=IF(AND(A{r}>=1,A{r}<=DATOS!$C$24),(DATOS!$C$16+DATOS!$C$17)/DATOS!$C$24,0)").number_format = USD
        f.cell(r, 5, f"=C{r}+D{r}").number_format = USD
        f.cell(r, 6, f"=C{r}*DATOS!$C$20*(1+DATOS!$C$11*DATOS!$C$12)").number_format = USD
        f.cell(r, 7, f"=F{r}*DATOS!$C$9").number_format = USD
        f.cell(r, 8, f"=F{r}-G{r}").number_format = USD
        f.cell(r, 9, f"=IF(A{r}=0,DATOS!$C$22,0)").number_format = USD
        f.cell(r, 10, f"=IF(A{r}-INT(DATOS!$C$10)>=0,INDEX($H${c0}:$H${cN},A{r}-INT(DATOS!$C$10)+1),0)").number_format = USD
        f.cell(r, 11, f"=I{r}+J{r}").number_format = USD
        f.cell(r, 12, f"=IF(A{r}-INT(DATOS!$C$13)>=0,INDEX($E${c0}:$E${cN},A{r}-INT(DATOS!$C$13)+1),0)").number_format = USD
        f.cell(r, 13, f"=K{r}-L{r}").number_format = USD
        f.cell(r, 14, f"=SUM(M${c0}:M{r})").number_format = USD
        for j in range(1, 15):
            f.cell(r, j).border = BORDER
    f.cell(cN + 2, 2, "TOTAL").font = Font(bold=True)
    for col in range(3, 14):
        c = f.cell(cN + 2, col, f"=SUM({L(col)}{c0}:{L(col)}{cN})")
        c.number_format, c.font = USD, Font(bold=True)
    f.conditional_formatting.add(f"M{c0}:N{cN}", CellIsRule(operator="lessThan", formula=["0"], font=Font(color="C00000")))

    # --------------------------------------------------------------- CURVA_S
    cs = wb.create_sheet("CURVA_S")
    cs["A2"], cs["A2"].font = "CURVA S · PV acumulado en USD y HH", F_T
    cs["A3"] = "Los gráficos leen PV_SEMANAL y FLUJO_CAJA; se mueven al cambiar cualquier dato de DATOS."
    ch = LineChart()
    ch.title, ch.height, ch.width = "Curva S: PV acumulado (% del total)", 11, 26
    ch.y_axis.number_format, ch.y_axis.scaling.min, ch.y_axis.scaling.max = "0%", 0, 1
    ch.y_axis.title, ch.x_axis.title = "% acumulado", "Semana"
    for col in (11, 8):
        ch.add_data(Reference(s, min_col=col, min_row=5, max_row=sN), titles_from_data=True)
    ch.set_categories(Reference(s, min_col=1, min_row=s0, max_row=sN))
    for ser in ch.series:
        ser.smooth = False
    ch.x_axis.delete = ch.y_axis.delete = False
    cs.add_chart(ch, "A5")
    b1 = BarChart()
    b1.title, b1.height, b1.width = "PV semanal (USD, costo directo)", 9, 26
    b1.add_data(Reference(s, min_col=9, min_row=5, max_row=sN), titles_from_data=True)
    b1.set_categories(Reference(s, min_col=1, min_row=s0, max_row=sN))
    b1.x_axis.delete = b1.y_axis.delete = False
    cs.add_chart(b1, "A29")
    b2 = BarChart()
    b2.title, b2.height, b2.width = "PV semanal (HH)", 9, 26
    b2.add_data(Reference(s, min_col=6, min_row=5, max_row=sN), titles_from_data=True)
    b2.set_categories(Reference(s, min_col=1, min_row=s0, max_row=sN))
    b2.x_axis.delete = b2.y_axis.delete = False
    cs.add_chart(b2, "A48")

    bar = BarChart()
    bar.title, bar.height, bar.width = "Flujo de caja mensual: ingresos, egresos y acumulado (USD)", 11, 26
    for col in (11, 12):
        bar.add_data(Reference(f, min_col=col, min_row=5, max_row=cN), titles_from_data=True)
    bar.set_categories(Reference(f, min_col=1, min_row=c0, max_row=cN))
    lin = LineChart()
    lin.add_data(Reference(f, min_col=14, min_row=5, max_row=cN), titles_from_data=True)
    bar.x_axis.delete = bar.y_axis.delete = False
    bar.x_axis.title, bar.y_axis.title = "Período", "USD"
    for ser in lin.series:
        ser.smooth = False
    bar.x_axis.tickLblPos = "low"
    bar += lin
    f.add_chart(bar, f"A{cN + 5}")

    # --------------------------------------------------------------- RESUMEN
    rs = wb.create_sheet("RESUMEN")
    rs["B2"], rs["B2"].font = "RESUMEN Y CONTROLES", F_T
    rs.column_dimensions["A"].width = 2
    rs.column_dimensions["B"].width = 70
    for c in "CDE":
        rs.column_dimensions[c].width = 22
    encabezado_cols = ["Indicador", "Valor", "Referencia JSON integrado", "Control"]
    for j, t in enumerate(encabezado_cols, 2):
        c = rs.cell(4, j, t)
        c.fill, c.font, c.border, c.alignment = FILL_H, F_H, BORDER, Alignment(horizontal="center")
    hh_ref = sum(r["cantidad_total"] for r in doc["recursos"] if r["tipo"] == "LABOR" and r["unidad"] == "hh")
    sn = sN + 2
    ctrl = [
        ("PV (USD) semanal total = costo directo del presupuesto", f"=PV_SEMANAL!I{sn}", tot["costo_directo"]["valor"], USD, 0.01),
        ("PV (USD) total en ACTIVIDADES = costo directo del presupuesto", "=ACTIVIDADES!H3", tot["costo_directo"]["valor"], USD, 0.01),
        ("PV (USD) por período de valorización = costo directo", f"=PV_MENSUAL!G{mN + 2}", tot["costo_directo"]["valor"], USD, 0.01),
        ("PV (HH) semanal total = HH de mano de obra de los APU", f"=PV_SEMANAL!F{sn}", hh_ref, HH, 0.01),
        ("PV (HH) en ACTIVIDADES = HH de mano de obra de los APU", "=ACTIVIDADES!I3", hh_ref, HH, 0.01),
        ("Valorizaciones presentadas = monto del contrato", f"=FLUJO_CAJA!F{cN + 2}", None, USD, 0.01),
        ("Adelanto amortizado completo = adelanto recibido", f"=FLUJO_CAJA!G{cN + 2}", None, USD, 0.01),
        ("Todo lo valorizado se cobra dentro de la tabla (plazo ≤ 3 meses)", f"=FLUJO_CAJA!J{cN + 2}+FLUJO_CAJA!I{cN + 2}", None, USD, 0.01),
    ]
    r = 5
    for et, fm, ref, fmt, tol in ctrl:
        rs.cell(r, 2, et)
        rs.cell(r, 3, fm).number_format = fmt
        if ref is not None:
            rs.cell(r, 4, ref).number_format = fmt
            rs.cell(r, 5, f'=IF(ABS(C{r}-D{r})<={tol},"OK","REVISAR")')
        r += 1
    rs.cell(10, 4, "=DATOS!C21"); rs.cell(10, 5, f'=IF(ABS(C10-D10)<=0.01,"OK","REVISAR")')
    rs.cell(11, 4, "=DATOS!C22"); rs.cell(11, 5, f'=IF(ABS(C11-D11)<=0.01,"OK","REVISAR")')
    rs.cell(12, 4, f"=FLUJO_CAJA!H{cN + 2}+FLUJO_CAJA!I{cN + 2}"); rs.cell(12, 5, f'=IF(ABS(C12-D12)<=0.01,"OK","REVISAR")')
    rs.cell(10, 4).number_format = rs.cell(11, 4).number_format = rs.cell(12, 4).number_format = USD
    for rr in range(5, 13):
        for cc in range(2, 6):
            rs.cell(rr, cc).border = BORDER
    kp = [
        (15, "Duración del proyecto (días)", "=DATOS!C23", "0"),
        (16, "Semana de mayor PV (USD)", f"=INDEX(PV_SEMANAL!A{s0}:A{sN},MATCH(MAX(PV_SEMANAL!I{s0}:I{sN}),PV_SEMANAL!I{s0}:I{sN},0))", "0"),
        (17, "PV (USD) de esa semana", f"=MAX(PV_SEMANAL!I{s0}:I{sN})", USD),
        (18, "Semana de mayor PV (HH)", f"=INDEX(PV_SEMANAL!A{s0}:A{sN},MATCH(MAX(PV_SEMANAL!F{s0}:F{sN}),PV_SEMANAL!F{s0}:F{sN},0))", "0"),
        (19, "PV (HH) de esa semana", f"=MAX(PV_SEMANAL!F{s0}:F{sN})", HH),
        (20, "Monto del contrato valorizado (USD)", "=DATOS!C21", USD),
        (21, "Adelanto recibido (USD)", "=DATOS!C22", USD),
        (22, "Mayor déficit de caja acumulado (USD)", f"=MIN(FLUJO_CAJA!N{c0}:N{cN})", USD),
        (23, "Período del mayor déficit", f"=INDEX(FLUJO_CAJA!A{c0}:A{cN},MATCH(MIN(FLUJO_CAJA!N{c0}:N{cN}),FLUJO_CAJA!N{c0}:N{cN},0))", "0"),
        (24, "Flujo neto final acumulado (USD)", f"=FLUJO_CAJA!N{cN}", USD),
    ]
    rs.cell(14, 2, "Indicadores").font = Font(bold=True, color=AZUL)
    for rr, et, fm, fmt in kp:
        rs.cell(rr, 2, et)
        c = rs.cell(rr, 3, fm)
        c.number_format = fmt
        rs.cell(rr, 2).border = c.border = BORDER
    rs.conditional_formatting.add("E5:E12", CellIsRule(operator="equal", formula=['"OK"'], fill=FILL_OK))
    rs.conditional_formatting.add("E5:E12", CellIsRule(operator="equal", formula=['"REVISAR"'], fill=FILL_BAD))
    rs["B26"] = ("Origen: JSON integrado " + doc["proyecto"]["revision_presupuesto"] + " / " + doc["proyecto"]["revision_cronograma"] +
                 ". Los datos de entrada (metrados, precios, HH, cronograma) son los del JSON; el reparto en el tiempo y el flujo son fórmulas.")
    rs["B26"].alignment = Alignment(wrap_text=True)
    rs.row_dimensions[26].height = 36

    for ws in wb.worksheets:
        ws.sheet_view.showGridLines = False
        ws.sheet_view.zoomScale = 90
    wb.active = 0
    ruta.parent.mkdir(parents=True, exist_ok=True)
    wb.save(ruta)
    return {"semanas": nsem, "periodos_valorizacion": nper, "periodos_flujo": nflujo, "actividades": len(acts), "partidas": n_p,
            "hh_referencia": hh_ref, "costo_directo_referencia": tot["costo_directo"]["valor"], "max_dia": max_dia}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--integrado", type=Path, required=True)
    ap.add_argument("--salida", type=Path, required=True, help="carpeta nueva; no se sobrescribe")
    ap.add_argument("--fecha-inicio", type=dt.date.fromisoformat, required=True)
    ap.add_argument("--dias-mes", type=int, default=30)
    ap.add_argument("--adelanto", type=float, default=0.20)
    ap.add_argument("--meses-cobranza", type=int, default=2)
    ap.add_argument("--incluir-igv", type=int, choices=[0, 1], default=0)
    ap.add_argument("--velocidad", type=float, default=4)
    ap.add_argument("--prueba-oculta", action="store_true")
    ap.add_argument("--cerrar-al-final", action="store_true", help="cierra Excel al terminar (por defecto queda abierto para ver el resultado)")
    ap.add_argument("--solo-plantilla", action="store_true", help="genera la plantilla sin abrir Excel")
    a = ap.parse_args()
    if a.salida.exists() and any(a.salida.iterdir()):
        sys.exit(f"La carpeta de salida no está vacía: {a.salida}")
    doc = json.loads(a.integrado.read_text(encoding="utf-8"))
    # La plantilla interna va a la carpeta temporal: Excel no abre rutas de más de ~218 caracteres.
    sop = Path(tempfile.mkdtemp(prefix="pv_")) / "Plantilla_Interna.xlsx"
    info = construir(doc, a, sop)
    print(f"Plantilla preparada: {info['semanas']} semanas, {info['periodos_valorizacion']} períodos, {info['actividades']} actividades.", flush=True)
    if a.solo_plantilla:
        return 0
    a.salida.mkdir(parents=True, exist_ok=True)
    final = a.salida / "PV_Flujo.xlsx"
    if len(str(final)) > 216:
        sys.exit(f"Ruta de salida demasiado larga para Excel ({len(str(final))} caracteres): {final}")
    ps1 = Path(__file__).with_name("excel_tiempo_real.ps1")
    orden = "DATOS,PARTIDAS,ACTIVIDADES,PV_SEMANAL,PV_MENSUAL,FLUJO_CAJA,CURVA_S,RESUMEN"
    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(ps1), "-Plantilla", str(sop), "-Salida", str(final),
           "-Orden", orden, "-Velocidad", str(a.velocidad), "-Adelanto", str(a.adelanto), "-MesesCobranza", str(a.meses_cobranza)]
    if a.prueba_oculta:
        cmd.append("-PruebaOculta")
    if a.cerrar_al_final:
        cmd.append("-CerrarAlFinal")
    res = subprocess.run(cmd)
    shutil.rmtree(sop.parent, ignore_errors=True)
    if res.returncode:
        return res.returncode
    rep_p = a.salida / "verificacion_tiempo_real.json"
    rep = json.loads(rep_p.read_text(encoding="utf-8-sig"))
    rep.update({"herramienta": "generar_pv_flujo_caja.py", "integrado": str(a.integrado), "sha256_integrado": sha(a.integrado),
                "sha256_salida": sha(final), "parametros": {"fecha_inicio": a.fecha_inicio.isoformat(), "dias_mes": a.dias_mes, "adelanto": a.adelanto,
                                                            "meses_cobranza": a.meses_cobranza, "incluir_igv": a.incluir_igv}, "plantilla": info})
    rep_p.write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Entregable verificado: {final}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
