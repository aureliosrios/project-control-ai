"""Construcción corrida visible seguida de inspección; maestro económico intacto."""
import argparse, datetime, json, subprocess
import contextlib, io
from pathlib import Path
from generar_presentacion import ROOT, build, digest, equivalent
import openpyxl

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--proyecto',required=True)
    parser.add_argument('--formato',choices=['s10','presto'],required=True)
    parser.add_argument('--velocidad',type=float,default=4)
    parser.add_argument('--inspeccionar',type=int,default=12,help='Fórmulas mostradas por hoja al terminar; 0 muestra todas. Todas se verifican.')
    parser.add_argument('--prueba-oculta',action='store_true')
    a=parser.parse_args()
    if a.velocidad<=0 or a.inspeccionar<0: parser.error('Velocidad >0 e inspeccionar >=0')
    project=ROOT/'Proyectos'/a.proyecto
    meta=json.loads((project/'proyecto.json').read_text(encoding='utf-8-sig'))
    active=project/meta['entregables']['excel']
    folder=project/'04_Presupuesto'/f'{meta["revision_vigente"]}_Vigente'/'Salidas'/('V_'+a.formato.upper()+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3])
    support=folder/'_soporte'/'Plantilla_Interna.xlsx'
    print('Preparando formato USD desde el maestro vigente; construcción visible antes de inspeccionar.',flush=True)
    with contextlib.redirect_stdout(io.StringIO()):
        build(a.proyecto,a.formato,str(support),recalc=False)
    output=folder/f'{meta["revision_vigente"]}_{a.formato.upper()}_EnVivo.xlsx'
    cmd=['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(Path(__file__).with_name('presentacion_tiempo_real.ps1')),'-Plantilla',str(support),'-Salida',str(output),'-Formato',a.formato,'-Velocidad',str(a.velocidad),'-Inspeccionar',str(a.inspeccionar)]
    if a.prueba_oculta:cmd.append('-PruebaOculta')
    result=subprocess.run(cmd)
    if result.returncode:return result.returncode
    verification=folder/'verificacion_tiempo_real.json'
    report=json.loads(verification.read_text(encoding='utf-8-sig'))
    source_book=openpyxl.load_workbook(support); final_book=openpyxl.load_workbook(output)
    for sheet in source_book:
        for row in sheet:
            for cell in row:
                if cell.value is not None and not equivalent(cell.value,final_book[sheet.title][cell.coordinate].value):
                    raise ValueError(f'Dato o formula alterado: {sheet.title}!{cell.coordinate}')
    cache=openpyxl.load_workbook(output,data_only=True)
    errors=[f'{s.title}!{c.coordinate}' for s in cache for row in s for c in row if c.data_type=='e']
    if errors:raise ValueError(f'Errores Excel: {errors[:10]}')
    expected=json.loads((support.parent/'verificacion.json').read_text(encoding='utf-8'))['total_original']
    if abs(report['total']-expected)>0.01:raise ValueError('Total animado no concilia con maestro')
    report.update(sha256_maestro=digest(active),sha256_salida=digest(output),dictamen='BORRADOR_OBSERVADO',maestro=str(active),preservacion_completa='PASS',errores_todas_hojas=errors)
    verification.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    manifest_path=project/'05_Trazabilidad/manifest_archivos.json'
    manifest=json.loads(manifest_path.read_text(encoding='utf-8-sig'))
    for f in (output,verification):manifest['archivos'].append({'ruta':f.relative_to(project).as_posix(),'sha256':digest(f),'bytes':f.stat().st_size})
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Entregable verificado: {output}',flush=True)
    return 0

if __name__=='__main__':raise SystemExit(main())
