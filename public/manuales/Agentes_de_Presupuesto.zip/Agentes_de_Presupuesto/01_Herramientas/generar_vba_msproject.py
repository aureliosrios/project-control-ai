"""Genera un módulo .bas autocontenido que construye el cronograma en MS Project.

Dos modos, uno por agente:
- ``tiempo_real``: el Gantt se pinta mientras se crean tareas y vínculos (demos, cursos).
- ``automatico``: sin animación, máxima velocidad (producción).

El calendario, la jornada, los feriados, la fecha de inicio y el nombre del proyecto no
los decide esta herramienta: se leen del ``calendario_proyecto.json`` que proporciona el
usuario, y deben ser los mismos con los que se calculó el cronograma JSON (se contrasta el
SHA-256). La verificación textual de este script no reemplaza la prueba en MS Project:
ejecutar ``verificar_bas_msproject.py`` antes de entregar.
"""
from __future__ import annotations

from datetime import date, datetime, time
from pathlib import Path
import argparse
import hashlib
import json
import math
import sys

from calendario_proyecto import CalendarioIncompleto, PJ_WEEKDAY, cargar as cargar_calendario

MODOS = {
    "tiempo_real": {"modulo": "CronogramaTiempoReal", "macro": "ConstruirCronogramaTiempoReal", "animado": True},
    "automatico": {"modulo": "CronogramaAutomatico", "macro": "ConstruirCronogramaAutomatico", "animado": False},
}


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha256(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def vba_string(value) -> str:
    text = "" if value is None else str(value)
    text = " ".join(text.replace("\r", " ").replace("\n", " ").split())
    return '"' + text.replace('"', '""') + '"'


def vba_number(value) -> str:
    number = float(value)
    if math.isfinite(number):
        return format(number, ".15g")
    raise ValueError(f"Número no finito: {value}")


def vba_date(value: date) -> str:
    return f"DateSerial({value.year}, {value.month}, {value.day})"


def vba_time(value: time) -> str:
    return f"TimeSerial({value.hour}, {value.minute}, 0)"


def chunked(values, size):
    for index in range(0, len(values), size):
        yield values[index:index + size]


def loader_procedures(name: str, items: list[str], chunk_size: int, tipo: str = "Collection") -> str:
    chunks = list(chunked(items, chunk_size))
    lines = [f"Private Sub Load{name}(ByRef items As {tipo})"]
    for index in range(1, len(chunks) + 1):
        lines.append(f"    Load{name}_{index:02d} items")
    lines.extend(["End Sub", ""])
    for index, chunk in enumerate(chunks, 1):
        lines.append(f"Private Sub Load{name}_{index:02d}(ByRef items As {tipo})")
        lines.extend(f"    items.Add {row}" for row in chunk)
        lines.extend(["End Sub", ""])
    return "\n".join(lines)


def calendar_procedure(cal) -> str:
    """Configura el calendario base con los datos del usuario (días, turnos y feriados)."""
    lines = [
        "Private Sub ConfigurarCalendarioBase(ByVal cal As Calendar)",
        "    Dim exceptionIndex As Long",
        "    For exceptionIndex = cal.Exceptions.Count To 1 Step -1",
        "        cal.Exceptions(exceptionIndex).Delete",
        "    Next exceptionIndex",
        "",
    ]
    for nombre, pj in sorted(PJ_WEEKDAY.items(), key=lambda kv: kv[1]):
        lines.append(f"    ' {nombre}")
        lines.append(f"    With cal.WeekDays({pj})")
        if nombre in cal.dias_laborables:
            lines.append("        .Working = True")
            lines.append("        LimpiarTurnosExtra cal.WeekDays(" + str(pj) + ")")
            for index, (inicio, fin) in enumerate(cal.turnos, 1):
                lines.append(f"        .Shift{index}.Start = {vba_time(inicio)}")
                lines.append(f"        .Shift{index}.Finish = {vba_time(fin)}")
        else:
            lines.append("        .Working = False")
        lines.append("    End With")
    for index, feriado in enumerate(sorted(cal.datos.get("feriados") or [], key=lambda f: str(f.get("fecha") if isinstance(f, dict) else f)), 1):
        fecha_txt = feriado.get("fecha") if isinstance(feriado, dict) else feriado
        motivo = feriado.get("motivo") if isinstance(feriado, dict) else None
        fecha = date.fromisoformat(str(fecha_txt))
        nombre = f"Feriado {index:02d}" + (f" - {motivo}" if motivo else "")
        lines.append(f"    cal.Exceptions.Add Type:=pjDaily, Start:={vba_date(fecha)}, Finish:={vba_date(fecha)}, Name:={vba_string(nombre[:60])}")
    lines.extend(["End Sub", ""])
    return "\n".join(lines)


VBA_TEMPLATE = r'''Attribute VB_Name = "__MODULE__"
Option Explicit

' Cronograma __PROJECT_CODE__ | Modo: __MODE_LABEL__
' Generado por Agentes_de_Presupuesto/01_Herramientas/generar_vba_msproject.py. No editar a mano:
' cambie el cronograma JSON o el calendario del usuario y vuelva a generar.
' Calendario proporcionado por: __CAL_PROVIDER__ (SHA-256 __CAL_SHA__)

Private Const PROJECT_TITLE As String = __PROJECT_TITLE__
Private Const PROJECT_CODE As String = __PROJECT_CODE_STR__
Private Const CALENDAR_NAME As String = __CALENDAR_NAME__
Private Const MINUTES_PER_DAY As Long = __MINUTES_PER_DAY__
Private Const HOURS_PER_WEEK As Double = __HOURS_PER_WEEK__
Private Const DAYS_PER_MONTH As Long = __DAYS_PER_MONTH__
Private Const JSON_DURATION_DAYS As Long = __JSON_DURATION_DAYS__
Private Const REAL_TIME_VIEW As Boolean = __REAL_TIME_VIEW__
Private Const TASK_REFRESH_EVERY As Long = __TASK_REFRESH__
Private Const LINK_REFRESH_EVERY As Long = __LINK_REFRESH__
Private Const STATUS_EVERY As Long = 25
Private Const SOURCE_REVISION As String = __SOURCE_REVISION__
Private Const SOURCE_SHA256 As String = "__SOURCE_SHA256__"
Private Const PARTIDA_LEVEL As Boolean = __PARTIDA_LEVEL__
Private Const HAS_TRACKING As Boolean = __HAS_TRACKING__
Private Const TRACKING_REPORTS As Long = __TRACKING_REPORTS__

Private mInteractive As Boolean

Public Sub __MACRO__()
    EjecutarConstruccion True
End Sub

' Igual que el anterior, sin cuadros de diálogo (lo usa verificar_bas_msproject.py).
Public Sub ConstruirCronogramaSilencioso()
    EjecutarConstruccion False
End Sub

Private Function InicioProyecto() As Date
    InicioProyecto = __START_DATE__ + __START_TIME__
End Function

Private Function FinEsperado() As Date
    FinEsperado = __FINISH_DATE__ + __FINISH_TIME__
End Function

Private Sub EjecutarConstruccion(ByVal interactive As Boolean)
    Dim oldCalculation As Long
    Dim oldScreenUpdating As Boolean
    Dim activities As Collection
    Dim links As Collection
    Dim chapters As Object
    Dim taskMap As Object
    Dim rec As Variant
    Dim rel As Variant
    Dim newTask As Task
    Dim capTask As Task
    Dim predecessor As Task
    Dim successor As Task
    Dim dependency As TaskDependency
    Dim lagMinutes As Long
    Dim taskCount As Long
    Dim linkCount As Long
    Dim currentCap As String
    Dim lastCap As String
    Dim msgFinal As String
    Dim msgError As String
    Dim startTimer As Single
    Dim summaryDays As Double
    Dim currentPar As String
    Dim lastPar As String
    Dim parTask As Task
    Dim actLevel As Long
    Dim tracking As Object
    Dim trackedCount As Long
    Dim notStartedCount As Long

    mInteractive = interactive
    startTimer = Timer

    On Error Resume Next
    If mInteractive Then AppActivate Application.Caption
    ViewApply Name:="Diagrama de Gantt"
    If Err.Number <> 0 Then
        Err.Clear
        ViewApply Name:="Gantt Chart"
    End If
    Err.Clear
    On Error GoTo ErrorHandler

    oldCalculation = Application.Calculation
    oldScreenUpdating = Application.ScreenUpdating

    If ActiveProject.Tasks.Count > 0 And mInteractive Then
        If MsgBox("El proyecto activo contiene tareas. El macro debe eliminarlas para crear el cronograma trazable." & vbCrLf & _
                  "¿Desea continuar?", vbQuestion + vbYesNo, "Crear cronograma") <> vbYes Then GoTo SafeExit
    End If

    ' Los nombres de campos personalizados requieren la pantalla activa (error 1100 si está congelada).
    ConfigurarCamposTrazables

    Application.Calculation = pjManual
    Application.ScreenUpdating = False

    Estado "Configurando nombre, calendario y fecha de inicio..."
    ConfigurarProyectoYCalendario
    LimpiarTareasExistentes
    Refrescar 0

    Set activities = New Collection
    Set links = New Collection
    Set chapters = CreateObject("Scripting.Dictionary")
    Set taskMap = CreateObject("Scripting.Dictionary")
    LoadChapters chapters
    LoadActivities activities
    LoadLinks links

    lastCap = ""
    For Each rec In activities
        currentCap = CStr(rec(2))
        If currentCap <> lastCap Then
            If chapters.Exists(currentCap) Then
                Set capTask = ActiveProject.Tasks.Add(currentCap & " " & CStr(chapters(currentCap)))
            Else
                Set capTask = ActiveProject.Tasks.Add(currentCap)
            End If
            capTask.OutlineLevel = 1
            capTask.Manual = False
            capTask.Text1 = currentCap
            capTask.Text2 = currentCap
            capTask.Text3 = currentCap
            lastCap = currentCap
            lastPar = ""
        End If

        actLevel = 2
        If PARTIDA_LEVEL Then
            currentPar = CStr(rec(1))
            If currentPar <> lastPar Then
                Set parTask = ActiveProject.Tasks.Add(currentPar & " " & CStr(rec(16)))
                parTask.OutlineLevel = 2
                parTask.Manual = False
                parTask.Text2 = currentPar
                parTask.Text3 = currentCap
                lastPar = currentPar
            End If
            actLevel = 3
        End If

        Set newTask = ActiveProject.Tasks.Add(NombreVisible(rec))
        newTask.OutlineLevel = actLevel
        ConfigurarActividad newTask, rec
        taskMap.Add CStr(rec(0)), newTask
        taskCount = taskCount + 1

        If taskCount Mod STATUS_EVERY = 0 Then Estado "Actividad " & taskCount & "/" & activities.Count & ": " & CStr(rec(0))
        If REAL_TIME_VIEW Then
            If taskCount Mod TASK_REFRESH_EVERY = 0 Or taskCount = activities.Count Then Refrescar newTask.ID
        End If
    Next rec

    For Each rel In links
        If Not taskMap.Exists(CStr(rel(0))) Then Err.Raise vbObjectError + 2101, , "Predecesora no encontrada: " & CStr(rel(0))
        If Not taskMap.Exists(CStr(rel(1))) Then Err.Raise vbObjectError + 2102, , "Sucesora no encontrada: " & CStr(rel(1))

        Set predecessor = taskMap(CStr(rel(0)))
        Set successor = taskMap(CStr(rel(1)))
        Set dependency = successor.TaskDependencies.Add(predecessor, RelationTypeFromCode(CStr(rel(2))))
        lagMinutes = CLng(CDbl(rel(3)) * MINUTES_PER_DAY)
        If lagMinutes <> 0 Then dependency.Lag = lagMinutes
        linkCount = linkCount + 1

        If linkCount Mod (STATUS_EVERY * 4) = 0 Then Estado "Vínculo CPM " & linkCount & "/" & links.Count
        If REAL_TIME_VIEW Then
            If linkCount Mod LINK_REFRESH_EVERY = 0 Or linkCount = links.Count Then Refrescar successor.ID
        End If
    Next rel

    Application.Calculation = pjAutomatic
    Application.CalculateProject

    If HAS_TRACKING Then
        Estado "Guardando línea base (plan)..."
        GuardarLineaBase
        Set tracking = CreateObject("Scripting.Dictionary")
        LoadTracking tracking
        Estado "Aplicando seguimiento real (reportes diarios)..."
        AplicarSeguimiento taskMap, tracking, trackedCount, notStartedCount
        Application.CalculateProject
        Estado "Seguimiento aplicado: " & trackedCount & " actividades con avance real."
    End If
    Application.ScreenUpdating = True

    On Error Resume Next
    If HAS_TRACKING Then
        ViewApply Name:="Gantt de seguimiento"
        If Err.Number <> 0 Then
            Err.Clear
            ViewApply Name:="Tracking Gantt"
        End If
    End If
    SelectRow Row:=1, RowRelative:=False
    GotoTaskDates
    Application.TimescaleEdit MajorUnits:=pjTimescaleMonths, MinorUnits:=pjTimescaleWeeks
    Application.ZoomTimescale Selection:=False, Entire:=True
    Err.Clear
    On Error GoTo ErrorHandler

    summaryDays = ActiveProject.ProjectSummaryTask.Duration / MINUTES_PER_DAY

    msgFinal = "Cronograma creado: " & PROJECT_TITLE & vbCrLf
    msgFinal = msgFinal & "Calendario: " & ActiveProject.Calendar.Name & " (__CAL_DESCRIPTION__)" & vbCrLf
    msgFinal = msgFinal & "Inicio: " & Format$(ActiveProject.ProjectStart, "dd/mm/yyyy hh:nn") & vbCrLf
    msgFinal = msgFinal & "Fin: " & Format$(ActiveProject.ProjectFinish, "dd/mm/yyyy hh:nn") & vbCrLf
    msgFinal = msgFinal & "Duración: " & Format$(summaryDays, "0.##") & " días laborables (JSON: " & JSON_DURATION_DAYS & ")" & vbCrLf
    msgFinal = msgFinal & "Actividades: " & taskCount & " | Vínculos: " & linkCount & vbCrLf
    If HAS_TRACKING Then
        msgFinal = msgFinal & "Seguimiento: " & trackedCount & " actividades con avance real de " & TRACKING_REPORTS & " reportes; fecha de estado " & Format$(ActiveProject.StatusDate, "dd/mm/yyyy") & vbCrLf
        msgFinal = msgFinal & "Línea base guardada con el plan; el fin actual es " & Format$(ActiveProject.ProjectFinish, "dd/mm/yyyy") & vbCrLf
    End If
    msgFinal = msgFinal & "Tiempo de ejecución: " & Format$(Timer - startTimer, "0") & " s"
    If Not HAS_TRACKING And (Abs(ActiveProject.ProjectFinish - FinEsperado()) > (1 / 1440) Or Abs(summaryDays - JSON_DURATION_DAYS) > 0.01) Then
        msgFinal = msgFinal & vbCrLf & vbCrLf & "ADVERTENCIA: según el JSON el fin es " & Format$(FinEsperado(), "dd/mm/yyyy hh:nn") & _
                   " y la duración " & JSON_DURATION_DAYS & " días."
    End If
    Estado ""
    If mInteractive Then
        MsgBox msgFinal, vbInformation, "Cronograma terminado"
    Else
        Debug.Print msgFinal
    End If

SafeExit:
    On Error Resume Next
    Application.StatusBar = ""
    Application.Calculation = oldCalculation
    Application.ScreenUpdating = oldScreenUpdating
    On Error GoTo 0
    Exit Sub

ErrorHandler:
    msgError = "No se pudo completar el cronograma." & vbCrLf
    msgError = msgError & "Error " & Err.Number & ": " & Err.Description
    If mInteractive Then
        MsgBox msgError, vbCritical, "Cronograma detenido"
    Else
        Debug.Print msgError
    End If
    Resume SafeExit
End Sub

Private Sub ConfigurarProyectoYCalendario()
    Dim cal As Calendar

    On Error Resume Next
    Set cal = ActiveProject.BaseCalendars(CALENDAR_NAME)
    On Error GoTo 0
    If cal Is Nothing Then
        BaseCalendarCreate Name:=CALENDAR_NAME, FromName:=ActiveProject.BaseCalendars(1).Name
        Set cal = ActiveProject.BaseCalendars(CALENDAR_NAME)
    End If
    ConfigurarCalendarioBase cal

    ' ActiveProject.Calendar es de solo lectura: el calendario del proyecto se asigna con ProjectSummaryInfo.
    ActiveProject.ScheduleFromStart = True
    ProjectSummaryInfo Title:=PROJECT_TITLE, Subject:=PROJECT_CODE, Calendar:=CALENDAR_NAME
    If ActiveProject.Calendar.Name <> CALENDAR_NAME Then
        Err.Raise vbObjectError + 2001, , "No se pudo asignar el calendario del proyecto " & CALENDAR_NAME & "."
    End If
    ActiveProject.ProjectSummaryTask.Name = PROJECT_TITLE

    ActiveProject.NewTasksCreatedAsManual = False
    ActiveProject.DefaultTaskType = pjFixedDuration
    ActiveProject.DefaultEffortDriven = False
    ActiveProject.MultipleCriticalPaths = False
    ActiveProject.DisplayProjectSummaryTask = True
    ActiveProject.HoursPerDay = MINUTES_PER_DAY / 60
    ActiveProject.HoursPerWeek = HOURS_PER_WEEK
    ActiveProject.DaysPerMonth = DAYS_PER_MONTH
    ActiveProject.DefaultStartTime = __START_TIME__
    ActiveProject.DefaultFinishTime = __FINISH_TIME__
    ActiveProject.ProjectStart = InicioProyecto()
End Sub

' Borra los turnos 2 a 5 antes de fijar los turnos del usuario, para que no se superpongan.
Private Sub LimpiarTurnosExtra(ByVal wd As WeekDay)
    On Error Resume Next
    wd.Shift5.Clear
    wd.Shift4.Clear
    wd.Shift3.Clear
    wd.Shift2.Clear
    On Error GoTo 0
End Sub

Private Sub LimpiarTareasExistentes()
    Dim index As Long
    Dim currentTask As Task
    For index = ActiveProject.Tasks.Count To 1 Step -1
        Set currentTask = ActiveProject.Tasks(index)
        If Not currentTask Is Nothing Then currentTask.Delete
    Next index
End Sub

Private Sub ConfigurarCamposTrazables()
    On Error Resume Next
    Application.CustomFieldRename FieldID:=pjCustomTaskText1, NewName:="ID JSON"
    Application.CustomFieldRename FieldID:=pjCustomTaskText2, NewName:="WBS presupuesto"
    Application.CustomFieldRename FieldID:=pjCustomTaskText3, NewName:="Capítulo"
    Application.CustomFieldRename FieldID:=pjCustomTaskText4, NewName:="Nivel"
    Application.CustomFieldRename FieldID:=pjCustomTaskText5, NewName:="Sector"
    Application.CustomFieldRename FieldID:=pjCustomTaskText6, NewName:="Unidad"
    Application.CustomFieldRename FieldID:=pjCustomTaskText7, NewName:="Elemento metrado"
    Application.CustomFieldRename FieldID:=pjCustomTaskText8, NewName:="Clasificación"
    Application.CustomFieldRename FieldID:=pjCustomTaskText9, NewName:="Tipo actividad"
    Application.CustomFieldRename FieldID:=pjCustomTaskNumber1, NewName:="Metrado"
    Application.CustomFieldRename FieldID:=pjCustomTaskNumber2, NewName:="Rendimiento APU"
    Application.CustomFieldRename FieldID:=pjCustomTaskNumber3, NewName:="Cuadrillas"
    Application.CustomFieldRename FieldID:=pjCustomTaskNumber4, NewName:="Duración exacta días"
    If HAS_TRACKING Then
        Application.CustomFieldRename FieldID:=pjCustomTaskNumber5, NewName:="Atraso inicio (días)"
        Application.CustomFieldRename FieldID:=pjCustomTaskText10, NewName:="Estado reporte"
    End If
    On Error GoTo 0
End Sub

Private Sub ConfigurarActividad(ByVal target As Task, ByVal rec As Variant)
    Dim noteText As String

    ' Las tareas heredan el calendario del proyecto; no se asigna uno por tarea.
    target.Manual = False
    target.Type = pjFixedDuration
    target.EffortDriven = False
    target.Duration = CLng(CDbl(rec(11)) * MINUTES_PER_DAY)
    target.Estimated = False

    target.Text1 = CStr(rec(0))
    target.Text2 = CStr(rec(1))
    target.Text3 = CStr(rec(2))
    target.Text4 = CStr(rec(4))
    target.Text5 = CStr(rec(5))
    target.Text6 = CStr(rec(6))
    target.Text7 = CStr(rec(12))
    target.Text8 = CStr(rec(13))
    target.Text9 = CStr(rec(14))
    target.Number1 = CDbl(rec(7))
    target.Number2 = CDbl(rec(8))
    target.Number3 = CDbl(rec(9))
    target.Number4 = CDbl(rec(10))
    noteText = "Fuente: " & SOURCE_REVISION & vbCrLf
    noteText = noteText & "SHA-256: " & SOURCE_SHA256 & vbCrLf
    noteText = noteText & "Duración = metrado / (rendimiento APU x cuadrillas)." & vbCrLf
    noteText = noteText & "Ajuste: " & CStr(rec(15))
    target.Notes = noteText
End Sub

Private Function NombreVisible(ByVal rec As Variant) As String
    NombreVisible = CStr(rec(1)) & " | " & CStr(rec(3)) & " | " & CStr(rec(4)) & " | " & CStr(rec(5))
End Function

Private Function RelationTypeFromCode(ByVal code As String) As Long
    Select Case UCase$(Trim$(code))
        Case "FS": RelationTypeFromCode = pjFinishToStart
        Case "SS": RelationTypeFromCode = pjStartToStart
        Case "FF": RelationTypeFromCode = pjFinishToFinish
        Case "SF": RelationTypeFromCode = pjStartToFinish
        Case Else: Err.Raise vbObjectError + 2201, , "Tipo de vínculo no soportado: " & code
    End Select
End Function

Private Sub Estado(ByVal message As String)
    On Error Resume Next
    Application.StatusBar = message
    On Error GoTo 0
End Sub

' Refresco por lotes: recalcula una vez, pinta el Gantt y vuelve a congelar la pantalla.
Private Sub Refrescar(ByVal rowId As Long)
    If Not REAL_TIME_VIEW Then Exit Sub
    On Error Resume Next
    Application.CalculateProject
    Application.ScreenUpdating = True
    If rowId > 0 Then
        SelectRow Row:=rowId, RowRelative:=False
        GotoTaskDates
    End If
    DoEvents
    Application.ScreenUpdating = False
    On Error GoTo 0
End Sub

' Guarda el plan (tareas, jerarquía y vínculos ya calculados) como Línea base 0.
Private Sub GuardarLineaBase()
    On Error Resume Next
    BaselineSave All:=True
    If Err.Number <> 0 Then
        Err.Clear
        BaselineSave All:=True, Copy:=pjBaseline, Into:=pjBaseline
    End If
    If Err.Number <> 0 Then
        Dim errNumber As Long
        Dim errText As String
        errNumber = Err.Number
        errText = Err.Description
        On Error GoTo 0
        Err.Raise vbObjectError + 2301, , "No se pudo guardar la línea base: " & errNumber & " " & errText
    End If
    On Error GoTo 0
End Sub

Private Function FechaISO(ByVal text As String, ByVal horaDia As Date) As Date
    FechaISO = DateSerial(CInt(Mid$(text, 1, 4)), CInt(Mid$(text, 6, 2)), CInt(Mid$(text, 9, 2))) + horaDia
End Function

' Aplica el avance real de los reportes diarios: inicio real, fin real y % completado.
Private Sub AplicarSeguimiento(ByVal taskMap As Object, ByVal tracking As Object, ByRef trackedCount As Long, ByRef notStartedCount As Long)
    Dim key As Variant
    Dim rec As Variant
    Dim target As Task
    Dim processed As Long

    ActiveProject.StatusDate = STATUS_DATE_VALUE()
    For Each key In tracking.Keys
        If Not taskMap.Exists(CStr(key)) Then Err.Raise vbObjectError + 2401, , "Actividad del seguimiento no encontrada en el cronograma: " & CStr(key)
        Set target = taskMap(CStr(key))
        rec = tracking(key)
        If CDbl(rec(3)) > -9000 Then target.Number5 = CDbl(rec(3))
        target.Text10 = CStr(rec(4))
        If Len(CStr(rec(0))) > 0 Then
            target.ActualStart = FechaISO(CStr(rec(0)), TimeSerial(__START_HOUR__, __START_MINUTE__, 0))
            If Len(CStr(rec(1))) > 0 Then
                target.ActualFinish = FechaISO(CStr(rec(1)), TimeSerial(__FINISH_HOUR__, __FINISH_MINUTE__, 0))
            ElseIf CLng(rec(2)) > 0 Then
                target.PercentComplete = CLng(rec(2))
            End If
            trackedCount = trackedCount + 1
        Else
            notStartedCount = notStartedCount + 1
        End If
        processed = processed + 1
        If processed Mod STATUS_EVERY = 0 Then Estado "Seguimiento real " & processed & "/" & tracking.Count
        If REAL_TIME_VIEW Then
            If processed Mod TASK_REFRESH_EVERY = 0 Then Refrescar target.ID
        End If
    Next key
End Sub

Private Function STATUS_DATE_VALUE() As Date
    STATUS_DATE_VALUE = __STATUS_DATE__
End Function

'''


def tracking_rows(tracking: dict) -> list[str]:
    """Filas ``items.Add id, Array(inicio_real, fin_real, pct, atraso, estado)`` del seguimiento real."""
    rows = []
    for act_id, rec in sorted(tracking["actividades"].items()):
        atraso = rec.get("atraso_inicio_dias")
        rows.append("{0}, Array({1}, {2}, {3}, {4}, {5})".format(
            vba_string(act_id), vba_string(rec.get("inicio_real") or ""), vba_string(rec.get("fin_real") or ""),
            int(rec.get("pct_msproject") or 0), vba_number(-9999 if atraso is None else atraso),
            vba_string(rec.get("estado") or "")))
    return rows


def build_module(schedule: dict, source_hash: str, cal, modo: str, chapters: dict[str, str],
                 task_refresh: int, link_refresh: int, partida_level: bool = False,
                 tracking: dict | None = None) -> str:
    conf = MODOS[modo]
    duration = int(schedule["resumen"]["fin"])
    finish_date = cal.fecha_de_dia(duration)
    descripcion_cal = (f"{len(cal.dias_laborables)} días/semana, {cal.hora_inicio:%H:%M}-{cal.hora_fin:%H:%M}"
                       + (f", refrigerio {cal.refrigerio[0]:%H:%M}-{cal.refrigerio[1]:%H:%M}" if cal.refrigerio else ", sin refrigerio")
                       + (f", {len(cal.feriados)} feriados" if cal.feriados else ", sin feriados"))
    replacements = {
        "__MODULE__": conf["modulo"],
        "__MACRO__": conf["macro"],
        "__MODE_LABEL__": "TIEMPO REAL (animado)" if conf["animado"] else "AUTOMATICO (sin animación)",
        "__PROJECT_CODE__": cal.codigo_proyecto,
        "__CAL_PROVIDER__": cal.proporcionado_por,
        "__CAL_SHA__": cal.sha256,
        "__PROJECT_TITLE__": vba_string(cal.nombre_proyecto),
        "__PROJECT_CODE_STR__": vba_string(cal.codigo_proyecto),
        "__CALENDAR_NAME__": vba_string(cal.nombre_calendario),
        "__MINUTES_PER_DAY__": str(cal.minutos_dia),
        "__HOURS_PER_WEEK__": vba_number(cal.horas_semana),
        "__DAYS_PER_MONTH__": str(int(round(cal.dias_laborables_por_mes))),
        "__JSON_DURATION_DAYS__": str(duration),
        "__REAL_TIME_VIEW__": "True" if conf["animado"] else "False",
        "__TASK_REFRESH__": str(task_refresh),
        "__LINK_REFRESH__": str(link_refresh),
        "__SOURCE_REVISION__": vba_string(schedule.get("revision")),
        "__SOURCE_SHA256__": source_hash,
        "__START_DATE__": vba_date(cal.fecha_inicio),
        "__START_TIME__": vba_time(cal.hora_inicio),
        "__FINISH_DATE__": vba_date(finish_date),
        "__FINISH_TIME__": vba_time(cal.hora_fin),
        "__CAL_DESCRIPTION__": descripcion_cal.replace('"', "'"),
        "__PARTIDA_LEVEL__": "True" if partida_level else "False",
        "__HAS_TRACKING__": "True" if tracking else "False",
        "__TRACKING_REPORTS__": str(int(tracking["reportes"]["cantidad"])) if tracking else "0",
        "__START_HOUR__": str(cal.hora_inicio.hour), "__START_MINUTE__": str(cal.hora_inicio.minute),
        "__FINISH_HOUR__": str(cal.hora_fin.hour), "__FINISH_MINUTE__": str(cal.hora_fin.minute),
        "__STATUS_DATE__": (vba_date(date.fromisoformat(tracking["fecha_estado"])) + " + " + vba_time(cal.hora_fin)) if tracking else "0",
    }
    module = VBA_TEMPLATE
    for key, value in replacements.items():
        module = module.replace(key, value)

    chapter_rows = [f"{vba_string(code)}, {vba_string(title)}" for code, title in sorted(chapters.items())]
    chapter_lines = ["Private Sub LoadChapters(ByRef items As Object)"]
    chapter_lines.extend(f"    items.Add {row}" for row in chapter_rows)
    chapter_lines.extend(["End Sub", ""])

    activity_rows = []
    for item in schedule["actividades"]:
        record = [
            vba_string(item["id"]), vba_string(item["wbs"]), vba_string(item["capitulo"]),
            vba_string(item["descripcion"]), vba_string(item["nivel"]), vba_string(item["sector"]),
            vba_string(item["unidad"]), vba_number(item["metrado"]), vba_number(item["rendimiento_apu_efectivo"]),
            vba_number(item["cuadrillas_asignadas_frente"]), vba_number(item["duracion_productiva_exacta_dias"]),
            vba_number(item["duracion_programada_dias"]), vba_string(item["fuente_metrado"]["id_elemento"]),
            vba_string(item["fuente_metrado"].get("clasificacion")), vba_string(item["tipo_actividad"]),
            vba_string(item.get("ajuste_calendario") or "Sin ajuste; redondeo superior a día completo."),
            vba_string(item.get("partida_descripcion") or item["descripcion"]),
        ]
        activity_rows.append("Array(" + ", ".join(record) + ")")

    link_rows = [
        "Array(" + ", ".join([vba_string(link["predecesora"]), vba_string(link["sucesora"]),
                              vba_string(link["tipo"]), vba_number(link["desfase_dias"])]) + ")"
        for link in schedule["relaciones"]
    ]
    if tracking:
        tracking_block = "\n" + loader_procedures("Tracking", tracking_rows(tracking), 35, "Object")
    else:
        tracking_block = "\nPrivate Sub LoadTracking(ByRef items As Object)\nEnd Sub\n"
    return (module + calendar_procedure(cal) + "\n".join(chapter_lines) + "\n"
            + loader_procedures("Activities", activity_rows, 35) + "\n" + loader_procedures("Links", link_rows, 90)
            + tracking_block)


def chapter_titles(wbs_path: Path | None) -> dict[str, str]:
    if not wbs_path:
        return {}
    wbs = load(wbs_path)
    return {c["capitulo"]: c["titulo"] for c in wbs.get("capitulos", []) if c.get("capitulo") and c.get("titulo")}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--cronograma", type=Path, required=True)
    parser.add_argument("--calendario", type=Path, required=True, help="calendario_proyecto.json proporcionado por el usuario")
    parser.add_argument("--modo", choices=sorted(MODOS), required=True)
    parser.add_argument("--wbs", type=Path, help="wbs.json del proyecto (títulos de capítulo)")
    parser.add_argument("--refresco-tareas", type=int, default=5, help="tiempo_real: pinta el Gantt cada N tareas")
    parser.add_argument("--refresco-vinculos", type=int, default=40, help="tiempo_real: pinta el Gantt cada N vínculos")
    parser.add_argument("--jerarquia", choices=["capitulo", "partida"], default="capitulo",
                        help="capitulo: capítulo > actividad; partida: capítulo > partida > actividad")
    parser.add_argument("--seguimiento", type=Path,
                        help="seguimiento_real.json (preparar_gantt_seguimiento.py): guarda la línea base y aplica el avance real")
    parser.add_argument("--salida-bas", type=Path, required=True)
    parser.add_argument("--salida-verificacion", type=Path, required=True)
    args = parser.parse_args()

    try:
        cal = cargar_calendario(args.calendario)
    except CalendarioIncompleto as exc:
        print(f"CALENDARIO_INCOMPLETO: {exc}", file=sys.stderr)
        raise SystemExit(2)

    schedule = load(args.cronograma)
    cal_cron = schedule.get("calendario", {})
    if cal_cron.get("fuente") != "USUARIO" or cal_cron.get("sha256") != cal.sha256:
        print("CALENDARIO_DISTINTO: el cronograma JSON no se calculó con este calendario del usuario "
              f"(JSON: {cal_cron.get('sha256') or cal_cron.get('tipo')}; calendario: {cal.sha256}). "
              "Regenere el JSON con generar_cronograma.py --calendario antes de crear el .bas.", file=sys.stderr)
        raise SystemExit(3)
    if args.refresco_tareas < 1 or args.refresco_vinculos < 1:
        parser.error("los intervalos de refresco deben ser >= 1")

    source_hash = sha256(args.cronograma)
    tracking = load(args.seguimiento) if args.seguimiento else None
    module = build_module(schedule, source_hash, cal, args.modo, chapter_titles(args.wbs),
                          args.refresco_tareas, args.refresco_vinculos,
                          partida_level=args.jerarquia == "partida", tracking=tracking)
    args.salida_bas.parent.mkdir(parents=True, exist_ok=True)
    args.salida_bas.write_text(module, encoding="cp1252", errors="replace", newline="\r\n")

    text = args.salida_bas.read_text(encoding="cp1252")
    activity_count = text.count("items.Add Array(") - len(schedule["relaciones"])
    duration = int(schedule["resumen"]["fin"])
    verification = {
        "schema": "verificacion_vba_msproject/2.0",
        "modo": args.modo,
        "modulo": MODOS[args.modo]["modulo"],
        "macro": MODOS[args.modo]["macro"],
        "archivo": str(args.salida_bas),
        "sha256_bas": sha256(args.salida_bas),
        "fuente_cronograma": str(args.cronograma),
        "sha256_fuente": source_hash,
        "calendario": cal.resumen(),
        "esperado": {
            "titulo": cal.nombre_proyecto,
            "inicio": datetime.combine(cal.fecha_inicio, cal.hora_inicio).isoformat(timespec="minutes"),
            "fin": datetime.combine(cal.fecha_de_dia(duration), cal.hora_fin).isoformat(timespec="minutes"),
            "duracion_dias_laborables": duration,
            "actividades": len(schedule["actividades"]),
            "relaciones": len(schedule["relaciones"]),
        },
        "seguimiento": None if not tracking else {
            "archivo": str(args.seguimiento), "sha256": sha256(args.seguimiento),
            "fecha_estado": tracking["fecha_estado"], "reportes": tracking["reportes"]["cantidad"],
            "actividades_con_inicio_real": sum(1 for r in tracking["actividades"].values() if r.get("inicio_real")),
            "actividades_con_fin_real": sum(1 for r in tracking["actividades"].values() if r.get("fin_real")),
        },
        "jerarquia": args.jerarquia,
        "controles_estaticos": {
            "actividades_embebidas": activity_count == len(schedule["actividades"]),
            "calendario_coincide_con_json": True,
            "option_explicit": "Option Explicit" in text,
            "calendario_por_projectsummaryinfo": "ProjectSummaryInfo Title:=PROJECT_TITLE" in text and "ActiveProject.Calendar =" not in text,
            "calculo_manual_durante_carga": "Application.Calculation = pjManual" in text,
            "sin_sleep": "Sleep" not in text,
        },
        "prueba_ms_project": None,
        "dictamen": None,
    }
    static_ok = all(verification["controles_estaticos"].values())
    verification["dictamen"] = "PENDIENTE_PRUEBA_MS_PROJECT" if static_ok else "NO_CONFORME"
    args.salida_verificacion.write_text(json.dumps(verification, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"bas": str(args.salida_bas), "modo": args.modo, "actividades": len(schedule["actividades"]),
                      "relaciones": len(schedule["relaciones"]), "fin_esperado": verification["esperado"]["fin"],
                      "dictamen": verification["dictamen"]}, ensure_ascii=True))
    if not static_ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
