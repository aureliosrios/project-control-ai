"""Calcula el impacto de cada supuesto abierto y genera el informe ordenado por impacto.

Impacto = importe de lo que depende del supuesto: recursos cuyo precio usa la fuente del supuesto,
líneas de gastos generales con esa fuente, partidas cuyo APU la cita y los elementos listados en 'afecta'
(ids de recurso, partida WBS o gasto general). Los impactos pueden solaparse y no son sumables.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def build(supuestos: list, result: dict) -> list:
    summary = result["summary"]
    sub = summary.get("pre_tax_total") or 1
    res_amount = {r["id"]: r["amount"] for r in result["resources"]}
    res_source = {r["id"]: r["price_source_id"] for r in result["resources"]}
    gg_amount = {g["id"]: g["amount"] for g in result["general_conditions"]}
    gg_source = {g["id"]: g["source_id"] for g in result["general_conditions"]}
    items = {i["wbs"]: i for i in result["items"]}
    apu_sources = {a["wbs"]: a["technical_source_ids"] for a in result["apus"]}
    out = []
    for sp in supuestos:
        if sp.get("estado", "ABIERTO") == "CERRADO":
            continue
        sid = "SRC-" + sp["id"]
        touched = {}
        for rid, src in res_source.items():
            if src == sid:
                touched["recurso " + rid] = res_amount[rid]
        for gid, src in gg_source.items():
            if src == sid:
                touched["GG " + gid] = gg_amount[gid]
        for wbs, srcs in apu_sources.items():
            if sid in srcs and wbs in items:
                touched["partida " + wbs] = items[wbs]["amount"]
        for ref in sp.get("afecta", []):
            if ref in res_amount:
                touched["recurso " + ref] = res_amount[ref]
            elif ref in gg_amount:
                touched["GG " + ref] = gg_amount[ref]
            elif ref in items:
                touched["partida " + ref] = items[ref]["amount"]
        impact = round(sum(touched.values()), 2)
        row = dict(sp)
        row["impacto_importe"] = impact
        row["impacto_pct_subtotal"] = round(impact / sub, 6)
        row["elementos_afectados"] = sorted(touched)
        out.append(row)
    out.sort(key=lambda r: r["impacto_importe"], reverse=True)
    return out


def to_markdown(rows: list, revision: str) -> str:
    lines = [f"# Supuestos del agente — {revision}", "",
             "Datos que no vinieron en la entrada y que el agente completó. Orden: mayor impacto primero. "
             "Los impactos pueden solaparse y no son sumables.", "",
             "| Nº | ID | Tema | Valor | Base | Confianza | Impacto (S/) | % subtotal |", "|---|---|---|---|---|---|---|---|"]
    for i, r in enumerate(rows, 1):
        lines.append(f"| {i} | {r['id']} | {r['tema']} | {r['valor']} {r.get('unidad','')} | {r['base']} | {r['confianza']} | "
                     f"{r['impacto_importe']:,.2f} | {r['impacto_pct_subtotal']*100:.2f}% |")
    lines += ["", "## Sustento", ""]
    for r in rows:
        lines.append(f"- **{r['id']}** — {r.get('sustento', 'sin sustento registrado')}")
    return "\n".join(lines) + "\n"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--supuestos", required=True)
    ap.add_argument("--resultado", required=True)
    ap.add_argument("--salida-json", required=True)
    ap.add_argument("--salida-md", required=True)
    ap.add_argument("--revision", default="")
    args = ap.parse_args(argv)
    sup = json.loads(Path(args.supuestos).read_text(encoding="utf-8-sig")) if Path(args.supuestos).is_file() else []
    result = json.loads(Path(args.resultado).read_text(encoding="utf-8-sig"))
    rows = build(sup, result)
    Path(args.salida_json).write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    Path(args.salida_md).write_text(to_markdown(rows, args.revision), encoding="utf-8")
    print(json.dumps({"supuestos_abiertos": len(rows)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
