"""Lee el mapa de ingesta del usuario y genera el inventario de la información de entrada.

El usuario declara en `00_MAPA_INGESTA.md` (tabla Markdown) qué carpetas de `01_Entrada_Minima`
contienen qué tipo de información. Verifica el mapa, inventaría los archivos (hash y estructura
básica) y detecta lo que falta o no está declarado. Los presupuestos Excel/JSON se normalizan
después con ``normalizar_ingesta_presupuesto.py``; este inventario no sustituye esa validación.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

ROLES = {
    "DATOS_GENERALES": "Nombre, ubicación, cliente, moneda, fecha base, plazo, impuestos, utilidad",
    "ALCANCE": "Alcance, exclusiones, restricciones, memoria descriptiva",
    "WBS": "Estructura de partidas",
    "METRADOS": "Mediciones y su evidencia",
    "EETT": "Especificaciones técnicas, procedimientos, calidad y seguridad",
    "PRECIOS": "Cotizaciones, listas de precios, jornales",
    "PROCEDIMIENTOS": "Estrategia constructiva, rendimientos, cuadrillas",
    "PLAZO_CALENDARIO": "Plazo, feriados, jornada, fecha de inicio",
    "GASTOS_GENERALES": "Organización de obra, plantel, seguros, garantías",
    "OTROS": "Cualquier otra información de apoyo",
}
# Roles sin los cuales el agente tendrá que suponer datos y registrarlos como supuestos.
ROLES_BASE = ["DATOS_GENERALES", "WBS", "METRADOS", "EETT", "PRECIOS"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_map(text: str):
    rows, warnings = [], []
    for line in text.splitlines():
        s = line.strip()
        if not s.startswith("|"):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if len(cells) < 2 or set("".join(cells)) <= set("-: "):
            continue
        if cells[0].lower() in {"carpeta", "carpeta o archivo"}:
            continue
        folder = cells[0].strip("`").replace("\\", "/").rstrip("/")
        roles = [r.strip().upper() for r in re.split(r"[,;/+]", cells[1]) if r.strip()]
        unknown = [r for r in roles if r not in ROLES]
        if unknown:
            warnings.append(f"Rol no reconocido {unknown} en '{folder}'; se trata como OTROS.")
            roles = [r if r in ROLES else "OTROS" for r in roles]
        rows.append({"carpeta": folder, "roles": roles, "descripcion": cells[2] if len(cells) > 2 else ""})
    return rows, warnings


def describe_md(path: Path) -> dict:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    heads = [m.group(0).strip() for m in re.finditer(r"^#{1,3} .+$", text, re.M)]
    tables = len(re.findall(r"^\|.*\|\s*\n\|[\s:|-]+\|", text, re.M))
    return {"lineas": text.count("\n") + 1, "encabezados": heads[:25], "tablas": tables}


def describe_json(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        return {"json_valido": False, "error_json": str(exc)}
    if isinstance(data, dict):
        return {"json_valido": True, "claves_raiz": list(data)[:50], "schema_version": data.get("schema_version")}
    return {"json_valido": True, "tipo_raiz": type(data).__name__, "elementos": len(data) if isinstance(data, list) else None}


def describe_excel(path: Path) -> dict:
    if path.suffix.lower() == ".xls":
        return {"excel_soportado": False, "motivo": "Convertir .xls a .xlsx conservando formulas."}
    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=False, data_only=False)
        sheets = wb.sheetnames
        required = {"PRESUPUESTO_S10", "ANALISIS_APU_S10", "INSUMOS_RECURSOS_S10"}
        subpart_sheets = {"SUBPARTIDAS_S10", "LISTADO_SUBPARTIDAS_S10"}
        return {
            "excel_soportado": True, "hojas": sheets,
            "presupuesto_s10_detectado": required.issubset(sheets),
            "hojas_subpartidas": sorted(subpart_sheets.intersection(sheets)),
            "estructura_subpartidas_completa": subpart_sheets.issubset(sheets),
        }
    except Exception as exc:
        return {"excel_soportado": False, "motivo": str(exc)}


def run(project_dir: Path, raiz: Path | None = None) -> dict:
    base = (raiz or project_dir / "01_Entrada_Minima").resolve()
    map_path = base / "00_MAPA_INGESTA.md"
    out = {"proyecto": project_dir.name, "raiz_ingesta": str(base), "errores": [], "avisos": []}
    if not map_path.is_file():
        out["errores"].append(
            f"Falta {map_path.name}. Crearlo desde 02_Plantillas/ingesta/00_MAPA_INGESTA.plantilla.md "
            "o pedir al usuario que indique qué contiene cada carpeta."
        )
        return out
    rows, warns = parse_map(map_path.read_text(encoding="utf-8-sig"))
    out["avisos"] += warns
    if not rows:
        out["errores"].append("El mapa no contiene filas de tabla (| Carpeta | Rol | Descripción |).")
        return out

    declared = set()
    carpetas = []
    for row in rows:
        target = (base / row["carpeta"]).resolve()
        declared.add(target)
        entry = {**row, "existe": target.exists(), "archivos": []}
        if not target.exists():
            out["errores"].append(f"Carpeta declarada que no existe: {row['carpeta']}")
        elif not target.is_relative_to(base):
            out["errores"].append(f"Carpeta fuera de la raíz de ingesta: {row['carpeta']}")
        else:
            files = [target] if target.is_file() else sorted(p for p in target.rglob("*") if p.is_file())
            for f in files:
                rec = {"ruta": str(f.relative_to(base)).replace("\\", "/"), "bytes": f.stat().st_size, "sha256": sha256(f)}
                suffix = f.suffix.lower()
                if suffix == ".md":
                    rec.update(describe_md(f))
                elif suffix == ".json":
                    rec.update(describe_json(f))
                elif suffix in {".xlsx", ".xlsm", ".xls"}:
                    rec.update(describe_excel(f))
                else:
                    rec["tipo"] = suffix or "sin_extension"
                    out["avisos"].append(f"Formato sin ingesta estructurada: {rec['ruta']}. Tratarlo como evidencia o convertirlo.")
                entry["archivos"].append(rec)
            if not files:
                out["avisos"].append(f"Carpeta declarada sin archivos: {row['carpeta']}")
        carpetas.append(entry)
    out["carpetas"] = carpetas

    for child in sorted(base.iterdir()):
        if child.name == map_path.name or child.name.startswith("."):
            continue
        if not any(child.resolve() == d or d.is_relative_to(child.resolve()) or child.resolve().is_relative_to(d) for d in declared):
            out["avisos"].append(f"Elemento no declarado en el mapa: {child.name}")

    present = {r for row in rows for r in row["roles"]}
    out["roles_presentes"] = sorted(present)
    out["roles_faltantes"] = [r for r in ROLES_BASE if r not in present]
    if out["roles_faltantes"]:
        out["avisos"].append(
            "Faltan roles base " + ", ".join(out["roles_faltantes"]) +
            ": el agente deberá completar esa información con supuestos registrados en supuestos.json."
        )
    out["mapa_sha256"] = sha256(map_path)
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--proyecto", required=True, help="Código del proyecto o ruta a su carpeta")
    ap.add_argument("--raiz", help="Raíz de ingesta si no es 01_Entrada_Minima")
    ap.add_argument("--salida", help="Archivo JSON de inventario (por defecto 05_Trazabilidad/inventario_ingesta.json)")
    args = ap.parse_args(argv)
    p = Path(args.proyecto)
    project = p if p.is_dir() else ROOT / "Proyectos" / args.proyecto
    if not project.is_dir():
        print(json.dumps({"errores": [f"Proyecto inexistente: {args.proyecto}"]}, ensure_ascii=False))
        return 2
    result = run(project, Path(args.raiz) if args.raiz else None)
    dest = Path(args.salida) if args.salida else project / "05_Trazabilidad" / "inventario_ingesta.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    resumen = {k: result.get(k) for k in ("proyecto", "errores", "avisos", "roles_presentes", "roles_faltantes")}
    resumen["inventario"] = str(dest)
    print(json.dumps(resumen, ensure_ascii=False, indent=2))
    return 1 if result["errores"] else 0


if __name__ == "__main__":
    sys.exit(main())
