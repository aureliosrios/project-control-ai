"""Integra presupuesto (APU, recursos, metrados, EETT) y cronograma (actividades, vínculos) en un solo JSON trazable.

No inventa datos: cada valor sale de un archivo del proyecto declarado en ``proyecto.json`` y cada enlace se
resuelve por ID. Todo lo calculado se contrasta con el Excel vigente (celdas y resultados) y con el propio
cronograma; las diferencias se informan, no se corrigen.

Cadena de trazabilidad (todas las flechas son IDs que resuelven en el mismo JSON):

    WBS/capítulo → partida → metrado (subtotal → elemento) → EETT
                           → APU → componente → recurso → fuente / celda Excel
                           → actividad (elemento de metrado) → vínculo (predecesora/sucesora)

Uso:
    python integrar_presupuesto_cronograma.py --proyecto <Proyectos/CODIGO> --salida <carpeta nueva> [--bas <archivo.bas> ...]
La carpeta de salida debe estar vacía o no existir (nunca se sobrescribe una revisión anterior).
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
import argparse
import hashlib
import json
import math
import re
import sys
from collections import Counter, defaultdict

SCHEMA = "presupuesto_cronograma_integrado/1.0"
TOL = 1e-6


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(a, b, tol=TOL) -> bool:
    return abs(float(a) - float(b)) <= tol * max(1.0, abs(float(a)), abs(float(b)))


def num(v, nd=None):
    return round(v, nd) if nd is not None else v


# ----------------------------------------------------------------------------------------------- Excel
class Hoja:
    """Hoja del libro volcada en R02_USD.json: celda -> {valor, resultado, es_formula}."""

    def __init__(self, nombre, celdas):
        self.nombre = nombre
        self.c = {x["celda"]: x for x in celdas}

    def v(self, ref):  # valor/fórmula tal cual
        return self.c.get(ref, {}).get("valor")

    def r(self, ref):  # resultado evaluado
        return self.c.get(ref, {}).get("resultado")

    def ref(self, ref):
        return f"{self.nombre}!{ref}"


def leer_apu_excel(hoja: Hoja):
    """Bloques 'Partida: dd.dd - …' de ANALISIS_APU_S10: filas de cabecera y de componentes."""
    filas = sorted({int(re.sub(r"\D", "", k)) for k in hoja.c})
    bloques, actual = {}, None
    seccion = None
    for fila in filas:
        b = hoja.v(f"B{fila}")
        if isinstance(b, str) and b.startswith("Partida:"):
            wbs = re.match(r"Partida:\s*([\d.]+)", b).group(1)
            actual = {"wbs": wbs, "fila_titulo": fila, "fila_costo": fila + 1, "componentes": []}
            bloques[wbs] = actual
            seccion = None
            continue
        if actual is None:
            continue
        c = hoja.v(f"C{fila}")
        if b in (None, "") and c in ("Mano de Obra", "Materiales", "Equipos"):
            seccion = c
            continue
        if isinstance(b, str) and b not in ("Código", "Rendimiento MO.") and hoja.v(f"G{fila}") not in (None, ""):
            actual["componentes"].append({"fila": fila, "codigo": b, "seccion": seccion})
    return bloques


def fila_insumo(formula_g) -> int | None:
    m = re.search(r"INSUMOS_RECURSOS_S10!\$?F\$?(\d+)", str(formula_g or ""))
    return int(m.group(1)) if m else None


# --------------------------------------------------------------------------------------------- integración
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--proyecto", type=Path, required=True, help="carpeta Proyectos/<codigo>")
    ap.add_argument("--salida", type=Path, required=True, help="carpeta nueva para el JSON integrado")
    ap.add_argument("--nombre", default="presupuesto_cronograma_integrado.json")
    ap.add_argument("--bas", type=Path, action="append", default=[], help="macro(s) .bas de MS Project derivadas del cronograma")
    args = ap.parse_args()

    raiz: Path = args.proyecto.resolve()
    if args.salida.exists() and any(args.salida.iterdir()):
        sys.exit(f"La carpeta de salida no está vacía: {args.salida}. Use una revisión nueva.")
    proy = load(raiz / "proyecto.json")
    ent, entr = proy["entradas"], proy["entregables"]

    rutas = {
        "canonico_usd": raiz / ent["canonico"],
        "canonico_pen": raiz / proy["fuente_economica_pen"]["canonico"],
        "libro_json": raiz / entr["json"],
        "libro_excel": raiz / entr["excel"],
        "cronograma": raiz / entr["cronograma_json"],
        "cronograma_verificacion": raiz / entr["cronograma_verificacion"],
        "wbs": raiz / ent["wbs"],
        "metrados": raiz / ent["metrados"],
        "eett_indice": raiz / ent["eett_indice"],
        "eett_md": raiz / ent["eett_md"],
        "cerebro": raiz / ent["cerebro"],
        "pendientes": raiz / ent["pendientes"],
        "parametros_hse_qa": raiz / "03_Cerebro" / "parametros_HSE_QA.json",
        "calendario_proyecto": raiz / "06_Cronograma" / "calendario_proyecto.json",
        "datos_proyecto": raiz / ent["datos"],
    }
    faltan = [k for k, p in rutas.items() if not p.exists()]
    if faltan:
        sys.exit(f"Faltan archivos declarados: {faltan}")
    D = {k: load(p) for k, p in rutas.items() if p.suffix == ".json"}
    usd, pen, cron = D["canonico_usd"], D["canonico_pen"], D["cronograma"]
    libro = {h["nombre"]: Hoja(h["nombre"], h["celdas"]) for h in D["libro_json"]["libro_excel"]["hojas"]}
    PRE, APU, INS, GG, DAT = (libro[n] for n in ("PRESUPUESTO_S10", "ANALISIS_APU_S10", "INSUMOS_RECURSOS_S10",
                                                 "GASTOS_GENERALES_S10", "DATOS_GENERALES_S10"))
    tc = float(D["libro_json"]["tipo_cambio_pen_por_usd"])
    ctl = []  # controles de verificación

    def control(nombre, ok, detalle):
        ctl.append({"control": nombre, "resultado": "CONFORME" if ok else "OBSERVADO", "detalle": detalle})

    # ---- archivos fuente con hash
    archivos = []
    for k, p in rutas.items():
        archivos.append({"id": f"ARCH-{k.upper()}", "rol": k, "ruta": str(p.relative_to(raiz)).replace("\\", "/"),
                         "sha256": sha256(p), "bytes": p.stat().st_size})
    for p in args.bas:
        archivos.append({"id": f"ARCH-BAS-{p.stem.upper()}", "rol": "macro_msproject", "ruta": str(p.resolve().relative_to(raiz)).replace("\\", "/")
                         if raiz in p.resolve().parents else str(p), "sha256": sha256(p), "bytes": p.stat().st_size})

    # ---- fuentes canónicas
    fuentes = [{**s, "id": s["id"]} for s in usd["sources"]]
    ids_fuente = {s["id"] for s in fuentes}

    # ---- Excel: bloques APU, filas de presupuesto, insumos
    bloques = leer_apu_excel(APU)
    filas_pre = {}
    for ref in PRE.c:
        m = re.fullmatch(r"B(\d+)", ref)
        v = PRE.v(ref)
        if m and isinstance(v, str) and re.fullmatch(r"\d\d\.\d\d", v):
            filas_pre[v] = int(m.group(1))
    filas_ins = {}
    for ref in INS.c:
        m = re.fullmatch(r"B(\d+)", ref)
        if m and isinstance(INS.v(ref), str):
            filas_ins.setdefault(INS.v(ref), int(m.group(1)))

    # ---- recursos
    pen_precio = {r["id"]: r["unit_price"] for r in pen["resources"]}
    recursos = {}
    for r in usd["resources"]:
        fila = int(r["id"].split("-")[-1]) if r["id"].startswith("REC-FILA-") else filas_ins.get(r["id"])
        recursos[r["id"]] = {
            "id": r["id"], "tipo": r["type"], "descripcion": r["description_es"], "unidad": r["unit"],
            "precio_unitario_usd": r["unit_price"], "precio_unitario_pen": pen_precio.get(r["id"]),
            "tipo_cambio_pen_por_usd": tc, "fuente_precio_id": r["price_source_id"], "fecha_precio": r["price_date"],
            "codigo_excel": INS.v(f"B{fila}") if fila else None,
            "excel": {"hoja": "INSUMOS_RECURSOS_S10", "fila": fila, "celda_precio": INS.ref(f"F{fila}") if fila else None,
                      "celda_cantidad_total": INS.ref(f"E{fila}") if fila else None,
                      "cantidad_total_excel": INS.r(f"E{fila}") if fila else None},
            "usado_en_apus": [], "cantidad_total": 0.0, "importe_total_usd": 0.0,
        }
        if r["price_source_id"] not in ids_fuente:
            control(f"Fuente de precio de {r['id']}", False, f"{r['price_source_id']} no existe en fuentes")
    fila_a_recurso = {}
    for rid, rec in recursos.items():
        f = rec["excel"]["fila"]
        if f and (f not in fila_a_recurso or rid.startswith("REC-FILA-")):
            fila_a_recurso[f] = rid
    control("Precio PEN/USD de recursos", all(
        close(rec["precio_unitario_pen"] / tc, rec["precio_unitario_usd"], 1e-9) for rec in recursos.values()
        if rec["precio_unitario_pen"] is not None),
        f"recursos con precio PEN comparable={sum(1 for r in recursos.values() if r['precio_unitario_pen'] is not None)}/{len(recursos)}, T.C. {tc}")

    # ---- HSE/QA
    hse = D["parametros_hse_qa"]
    param_hse = {p["wbs"]: p for p in hse["parameters"]}
    soporte = {(s["wbs"], s["resource_id"]): s for s in hse["support_components"]}

    # ---- metrados / EETT / WBS / pendientes
    metr = {p["codigo_partida"]: p for p in D["metrados"]["partidas"]}
    eett = {p["wbs"]: p for p in D["eett_indice"]["partidas"]}
    capitulos_wbs = {c["capitulo"]: c for c in D["wbs"]["capitulos"]}
    obs_por_wbs = defaultdict(list)
    observaciones = []
    for origen in ("heredadas_R01", "nuevas_R02"):
        for o in D["pendientes"].get(origen, []):
            reg = {"id": o["id"], "origen": origen, "partida_id": f"PAR-{o['partida']}" if o.get("partida") else None,
                   "tipo": o.get("tipo"), "severidad": o.get("severidad"), "detalle": o.get("detalle"),
                   "fuente": o.get("fuente"), "estado": o.get("estado")}
            observaciones.append(reg)
            if o.get("partida"):
                obs_por_wbs[o["partida"]].append(o["id"])

    # ---- APUs y partidas
    items = {i["wbs"]: i for i in usd["items"]}
    apus_in = {a["id"]: a for a in usd["apus"]}
    partidas, apus = [], []
    cd_total = 0.0
    sin_match = []
    for it in usd["items"]:
        wbs = it["wbs"]
        a = apus_in[it["apu_id"]]
        blk = bloques.get(wbs)
        fila_pre = filas_pre[wbs]
        # componentes del Excel, agrupados por el recurso (fila de INSUMOS) al que apuntan
        disp = defaultdict(list)
        for cx in (blk["componentes"] if blk else []):
            fi = fila_insumo(APU.v(f"G{cx['fila']}"))
            if fi is None and APU.v(f"D{cx['fila']}") == "%MO":
                rid = f"TOOLS-{wbs}"  # herramientas como % de la mano de obra: sin fila de INSUMOS
            else:
                rid = fila_a_recurso.get(fi)
            disp[rid].append(cx)
        comps = []
        pu = 0.0
        por_tipo = defaultdict(float)
        for n, c in enumerate(a["components"], 1):
            rec = recursos[c["resource_id"]]
            cant = c["quantity"]
            parcial = cant * (1 + c.get("waste_rate", 0)) * rec["precio_unitario_usd"]
            pu += parcial
            por_tipo[rec["tipo"]] += parcial
            cx = disp[c["resource_id"]].pop(0) if disp.get(c["resource_id"]) else None
            if cx is None:
                sin_match.append((wbs, c["resource_id"]))
            sp = soporte.get((wbs, c["resource_id"]))
            comp = {
                "id": f"CMP-{wbs}-{n:02d}", "recurso_id": c["resource_id"], "tipo": rec["tipo"], "unidad": rec["unidad"],
                "cantidad_por_unidad": cant, "desperdicio": c.get("waste_rate", 0),
                "precio_unitario_usd": rec["precio_unitario_usd"], "parcial_usd": parcial,
                "nota_origen": c.get("note"),
                "excel": None if cx is None else {
                    "hoja": "ANALISIS_APU_S10", "fila": cx["fila"], "seccion": cx["seccion"], "codigo": APU.v(f"B{cx['fila']}"),
                    "cuadrilla": {"celda": APU.ref(f"E{cx['fila']}"), "valor": APU.v(f"E{cx['fila']}")},
                    "cantidad": {"celda": APU.ref(f"F{cx['fila']}"), "formula": APU.v(f"F{cx['fila']}"), "resultado": APU.r(f"F{cx['fila']}")},
                    "precio": {"celda": APU.ref(f"G{cx['fila']}"), "formula": APU.v(f"G{cx['fila']}"), "resultado": APU.r(f"G{cx['fila']}")},
                    "parcial": {"celda": APU.ref(f"H{cx['fila']}"), "formula": APU.v(f"H{cx['fila']}"), "resultado": APU.r(f"H{cx['fila']}")},
                },
                "soporte_hse_qa": None if sp is None else {k: sp[k] for k in ("crew", "coverage", "role_basis", "continuous_during_hazard", "master_row", "factor_row") if k in sp},
            }
            if cx is not None and not close(comp["parcial_usd"], comp["excel"]["parcial"]["resultado"], 1e-9):
                comp["diferencia_excel_parcial"] = comp["parcial_usd"] - comp["excel"]["parcial"]["resultado"]
            comps.append(comp)
            rec["usado_en_apus"].append(a["id"]) if a["id"] not in rec["usado_en_apus"] else None
        cantidad = it["quantity"]
        parcial_part = pu * cantidad
        cd_total += parcial_part
        for cmp_ in comps:
            rec = recursos[cmp_["recurso_id"]]
            q = cmp_["cantidad_por_unidad"] * (1 + cmp_["desperdicio"]) * cantidad
            rec["cantidad_total"] += q
            rec["importe_total_usd"] += q * rec["precio_unitario_usd"]
        meta_e = eett[wbs]
        y = meta_e.get("metadatos_originales_yaml") or ""
        gid = lambda k: (re.search(rf'{k}:\s*"([^"]+)"', y) or [None, None])[1]
        apus.append({
            "id": a["id"], "partida_id": f"PAR-{wbs}", "wbs": wbs, "unidad_salida": a["output_unit"],
            "rendimiento_diario": a["daily_output"], "fuentes_tecnicas_ids": a["technical_source_ids"],
            "componentes": comps, "costo_unitario_directo_usd": pu,
            "costo_por_tipo_usd": dict(por_tipo),
            "excel": {"hoja": "ANALISIS_APU_S10", "fila_titulo": blk["fila_titulo"] if blk else None,
                      "celda_rendimiento": APU.ref(f"C{blk['fila_costo']}") if blk else None,
                      "celda_costo_unitario": APU.ref(f"H{blk['fila_costo']}") if blk else None,
                      "formula_costo_unitario": APU.v(f"H{blk['fila_costo']}") if blk else None,
                      "costo_unitario_excel": APU.r(f"H{blk['fila_costo']}") if blk else None},
        })
        cm = metr[wbs]
        partidas.append({
            "id": f"PAR-{wbs}", "wbs": wbs, "capitulo_id": f"CAP-{cm['codigo_wbs']}", "descripcion": it["description_es"],
            "unidad": it["unit"], "cantidad": cantidad, "apu_id": a["id"],
            "precio_unitario_usd": pu, "parcial_usd": parcial_part,
            "excel_presupuesto": {"hoja": "PRESUPUESTO_S10", "fila": fila_pre, "celda_cantidad": PRE.ref(f"E{fila_pre}"),
                                  "celda_precio": PRE.ref(f"F{fila_pre}"), "formula_precio": PRE.v(f"F{fila_pre}"),
                                  "celda_parcial": PRE.ref(f"G{fila_pre}"), "formula_parcial": PRE.v(f"G{fila_pre}"),
                                  "precio_excel": PRE.r(f"F{fila_pre}"), "parcial_excel": PRE.r(f"G{fila_pre}")},
            "metrado": {
                "fuente_ids": it["quantity_evidence_ids"], "regla_medicion_y_formula": cm.get("formula_metrado"),
                "especialidad": cm.get("especialidad"), "sistema": cm.get("sistema"), "clasificacion": cm.get("dimensiones_origen", {}).get("metodo"),
                "plano_o_fuente": cm.get("plano_o_fuente"), "version_fuente": cm.get("version_fuente"), "estado": cm.get("estado"),
                "inclusiones": cm.get("inclusiones"), "exclusiones": cm.get("exclusiones"),
                "subtotales": [{"id": s["id_subtotal"], "nivel": s["nivel"], "cota": s["cota"], "sector": s["sector"], "subtotal": s["subtotal"],
                                "unidad": s["unidad"], "elementos": [{
                                    "id": e["id_elemento"], "item": e["item"], "veces": e["veces"], "largo": e["largo"], "ancho": e["ancho"],
                                    "alto": e["alto"], "parcial": e["parcial"], "formula": e["formula_elemento"],
                                    "clasificacion": e["clasificacion_dato"], "actividad_ids": []} for e in s["elementos"]]}
                               for s in cm["desglose_detallado_por_piso"]],
            },
            "eett": {"id": gid("eett_id"), "requirement_id": gid("requirement_id"), "wbs_id": gid("wbs_id"), "ancla": meta_e["ancla"],
                     "archivo_consolidado": str(rutas["eett_md"].relative_to(raiz)).replace("\\", "/"),
                     "ruta_origen": meta_e["ruta_origen"], "sha256_origen": meta_e["sha256_origen"], "fuente_ids": it["eett_source_ids"]},
            "parametros_hse_qa": None if wbs not in param_hse else {k: v for k, v in param_hse[wbs].items() if k not in ("wbs", "description", "eett_source")},
            "observacion_ids": obs_por_wbs.get(wbs, []),
            "actividad_ids": [],
        })
    control("Componentes APU enlazados con su celda del Excel", not sin_match, f"sin celda={len(sin_match)} {sin_match[:5]}")

    # ---- reconciliación con el Excel (precio, parcial, cantidad)
    dif_pu = [p["wbs"] for p in partidas if not close(p["precio_unitario_usd"], p["excel_presupuesto"]["precio_excel"], 1e-9)]
    dif_q = [p["wbs"] for p in partidas if not close(p["cantidad"], PRE.r(f"E{p['excel_presupuesto']['fila']}"))]
    dif_par = [p["wbs"] for p in partidas if not close(p["parcial_usd"], p["excel_presupuesto"]["parcial_excel"], 1e-9)]
    dif_cmp = [c["id"] for a in apus for c in a["componentes"] if "diferencia_excel_parcial" in c]
    control("Precio unitario de las 78 partidas = Excel R02 (PRESUPUESTO_S10!F)", not dif_pu, f"diferencias={len(dif_pu)} {dif_pu[:5]}")
    control("Cantidad de partida = Excel R02 (PRESUPUESTO_S10!E)", not dif_q, f"diferencias={len(dif_q)}")
    control("Parcial de partida = Excel R02 (PRESUPUESTO_S10!G)", not dif_par, f"diferencias={len(dif_par)}")
    control("Parcial de cada componente APU = Excel (ANALISIS_APU_S10!H)", not dif_cmp, f"diferencias={len(dif_cmp)} {dif_cmp[:5]}")
    dif_ins = [r["id"] for r in recursos.values() if r["excel"]["cantidad_total_excel"] is not None and r["usado_en_apus"]
               and not close(r["cantidad_total"], r["excel"]["cantidad_total_excel"], 1e-6)]
    control("Cantidad total por recurso = INSUMOS_RECURSOS_S10!E", not dif_ins, f"diferencias={len(dif_ins)} {dif_ins[:8]}")
    dif_rend = [a["id"] for a in apus if a["excel"]["celda_rendimiento"] and
                not close(a["rendimiento_diario"], APU.r(a["excel"]["celda_rendimiento"].split("!")[1]), 1e-9)]
    control("Rendimiento del APU = celda de rendimiento del Excel (ANALISIS_APU_S10!C)", not dif_rend, f"diferencias={len(dif_rend)} {dif_rend[:5]}")

    # ---- capítulos
    capitulos = []
    for cod, cap in capitulos_wbs.items():
        pids = [p["id"] for p in partidas if p["capitulo_id"] == f"CAP-{cod}"]
        capitulos.append({"id": f"CAP-{cod}", "codigo": cod, "titulo": cap["titulo"], "descripcion": cap.get("descripcion"),
                          "partida_ids": pids, "costo_directo_usd": sum(p["parcial_usd"] for p in partidas if p["id"] in pids),
                          "actividad_ids": []})
    control("Partidas del WBS = partidas del presupuesto", {p["wbs"] for p in partidas} == {
        x["codigo"] for c in D["wbs"]["capitulos"] for x in c["partidas"]},
        f"wbs={sum(len(c['partidas']) for c in D['wbs']['capitulos'])}, presupuesto={len(partidas)}, metrados={len(metr)}, eett={len(eett)}")

    # ---- gastos generales y totales
    gg = []
    # Filas del Excel: GG-n ↔ fila n (gastos S10); las condiciones adicionales R02-* siguen en orden desde la fila 26 (códigos GG-01…).
    contador_r02 = 0
    for g in usd["general_conditions"]:
        if g["id"].startswith("GG-"):
            fila = int(g["id"].split("-")[-1])
        else:
            contador_r02 += 1
            fila = 25 + contador_r02
        imp = g["quantity"] * g["unit_price"]
        desc_excel = GG.v(f"C{fila}")
        gg.append({"id": g["id"], "clase": g["class"], "descripcion": desc_excel, "cantidad": g["quantity"],
                   "precio_unitario_usd": g["unit_price"], "importe_usd": imp, "fuente_id": g["source_id"],
                   "excel": {"fila": fila, "codigo": GG.v(f"B{fila}"), "celda_importe": GG.ref(f"I{fila}"), "formula": GG.v(f"I{fila}"),
                             "importe_excel": GG.r(f"I{fila}")}})
    dif_gg = [g["id"] for g in gg if g["excel"]["importe_excel"] is None or not close(g["importe_usd"], g["excel"]["importe_excel"], 1e-9)]
    control("Importe de gastos generales = Excel (GASTOS_GENERALES_S10!I)", not dif_gg, f"diferencias={len(dif_gg)} {dif_gg[:6]}")
    ggf = sum(g["importe_usd"] for g in gg if g["clase"] == "FIXED")
    ggv = sum(g["importe_usd"] for g in gg if g["clase"] == "VARIABLE")
    ut = usd["assumptions"]["profit_rate"]
    igv = usd["assumptions"]["tax_rate"]
    sub = cd_total + ggf + ggv + cd_total * ut
    total = sub * (1 + igv)
    totales = {
        "moneda": "USD",
        "costo_directo": {"valor": cd_total, "formula": "Σ partida.parcial_usd", "celda_excel": PRE.ref("G102"), "excel": PRE.r("G102")},
        "gastos_generales_fijos": {"valor": ggf, "formula": "Σ gastos_generales[clase=FIXED].importe_usd", "celda_excel": PRE.ref("G103"), "excel": PRE.r("G103")},
        "gastos_generales_variables": {"valor": ggv, "formula": "Σ gastos_generales[clase=VARIABLE].importe_usd", "celda_excel": PRE.ref("G104"), "excel": PRE.r("G104")},
        "utilidad": {"tasa": ut, "valor": cd_total * ut, "formula": "costo_directo × tasa", "celda_excel": PRE.ref("G105"), "excel": PRE.r("G105")},
        "subtotal": {"valor": sub, "formula": "CD + GGF + GGV + utilidad", "celda_excel": PRE.ref("G106"), "excel": PRE.r("G106")},
        "igv": {"tasa": igv, "valor": sub * igv, "formula": "subtotal × tasa", "celda_excel": PRE.ref("G107"), "excel": PRE.r("G107")},
        "total": {"valor": total, "formula": "subtotal + IGV", "celda_excel": PRE.ref("G108"), "excel": PRE.r("G108")},
        "total_en_pen": total * tc,
    }
    for k in ("costo_directo", "gastos_generales_fijos", "gastos_generales_variables", "utilidad", "subtotal", "igv", "total"):
        control(f"Total '{k}' = Excel ({totales[k]['celda_excel']})", close(totales[k]["valor"], totales[k]["excel"], 1e-9),
                f"integrado={totales[k]['valor']:.6f} excel={totales[k]['excel']:.6f}")
    control("Total del presupuesto = total declarado en proyecto.json", close(total, proy["total_provisional"], 1e-9),
            f"{total:.6f} vs {proy['total_provisional']:.6f}")

    # ---- cronograma: actividades y relaciones
    por_wbs = {p["wbs"]: p for p in partidas}
    apu_wbs = {a["wbs"]: a for a in apus}
    elem_idx = {e["id"]: (p, s, e) for p in partidas for s in p["metrado"]["subtotales"] for e in s["elementos"]}
    act_in = {a["id"]: a for a in cron["actividades"]}
    rel_in = cron["relaciones"]
    rel_ids = {}
    relaciones = []
    for n, r in enumerate(rel_in, 1):
        rid = f"REL-{n:04d}"
        rel_ids[(r["predecesora"], r["sucesora"], r["tipo"], r["desfase_dias"], r["motivo"])] = rid
        relaciones.append({"id": rid, "predecesora_id": r["predecesora"], "sucesora_id": r["sucesora"], "tipo": r["tipo"],
                           "desfase_dias": r["desfase_dias"], "motivo": r["motivo"]})
    pred_de, suc_de = defaultdict(list), defaultdict(list)
    for r in relaciones:
        suc_de[r["predecesora_id"]].append(r["id"])
        pred_de[r["sucesora_id"]].append(r["id"])
    rel_by_id = {r["id"]: r for r in relaciones}
    sin_ref = [r["id"] for r in relaciones if r["predecesora_id"] not in act_in or r["sucesora_id"] not in act_in]
    control("Relaciones apuntan a actividades existentes", not sin_ref, f"2278 esperadas={len(relaciones)}, sin referencia={len(sin_ref)}")
    # simetría con las listas embebidas en cada actividad
    asim = 0
    for a in cron["actividades"]:
        e1 = {(x["predecesora"], a["id"], x["tipo"], x["desfase_dias"], x["motivo"]) for x in a["predecesoras"]}
        e2 = {(r["predecesora_id"], r["sucesora_id"], r["tipo"], r["desfase_dias"], r["motivo"]) for rid in pred_de[a["id"]] for r in [rel_by_id[rid]]}
        asim += e1 != e2
    control("Predecesoras embebidas = relaciones globales", asim == 0, f"actividades con diferencia={asim}")

    actividades = []
    err_dur, err_rend, err_elem, err_ini = [], [], [], []
    elem_base_de = {}
    for a in cron["actividades"]:
        p = por_wbs[a["wbs"]]
        ap_ = apu_wbs[a["wbs"]]
        fm = a["fuente_metrado"]
        eid = fm["id_elemento"]
        hit = elem_idx.get(eid)
        derivado = False
        if hit is None and re.search(r"-[VH]$", eid):
            hit, derivado = elem_idx.get(re.sub(r"-[VH]$", "", eid)), True
        if hit is None or hit[0]["wbs"] != a["wbs"] or hit[1]["id"] != fm["id_subtotal"]:
            err_elem.append(a["id"])
        else:
            hit[2]["actividad_ids"].append(a["id"])
            elem_base_de[a["id"]] = (hit[2]["id"], derivado)
        if not close(ap_["rendimiento_diario"], a["rendimiento_apu_efectivo"]):
            err_rend.append(a["id"])
        exacta = a["metrado"] / (a["rendimiento_apu_efectivo"] * a["cuadrillas_asignadas_frente"])
        prog = max(1, math.ceil(exacta - 1e-9))
        if not close(exacta, a["duracion_productiva_exacta_dias"], 1e-6) or (prog != a["duracion_programada_dias"] and not a["ajuste_calendario"]):
            err_dur.append(a["id"])
        if a["tipo_actividad"] == "TAREA" and a["fin_dia_proyecto"] - a["inicio_dia_proyecto"] + 1 != a["duracion_programada_dias"]:
            err_ini.append(a["id"])
        pu = p["precio_unitario_usd"]
        consumos = [{"recurso_id": c["recurso_id"], "cantidad": a["metrado"] * c["cantidad_por_unidad"] * (1 + c["desperdicio"])}
                    for c in ap_["componentes"]]
        actividades.append({
            "id": a["id"], "partida_id": p["id"], "capitulo_id": p["capitulo_id"], "apu_id": ap_["id"], "descripcion": a["descripcion"],
            "nivel": a["nivel"], "cota": a["cota"], "sector": a["sector"], "unidad": a["unidad"], "metrado": a["metrado"],
            "metrado_fuente": {"subtotal_id": fm["id_subtotal"], "elemento_id": fm["id_elemento"], "clasificacion": fm["clasificacion"],
                               "elemento_base_id": elem_base_de.get(a["id"], (None, False))[0],
                               "derivado_por_division": elem_base_de.get(a["id"], (None, False))[1]},
            "rendimiento_apu_efectivo": a["rendimiento_apu_efectivo"], "cuadrillas_asignadas_frente": a["cuadrillas_asignadas_frente"],
            "duracion": {"formula": a["formula_duracion"], "exacta_dias": a["duracion_productiva_exacta_dias"],
                         "programada_dias": a["duracion_programada_dias"], "ajuste_calendario": a["ajuste_calendario"]},
            "tipo_actividad": a["tipo_actividad"],
            "programacion": {"inicio_dia": a["inicio_dia_proyecto"], "fin_dia": a["fin_dia_proyecto"],
                             "holgura_total_dias": a["holgura_total_dias"], "critica": a["critica"]},
            "predecesora_relacion_ids": pred_de[a["id"]], "sucesora_relacion_ids": suc_de[a["id"]],
            "costo_directo_usd": a["metrado"] * pu, "consumos_recursos": consumos,
        })
        p["actividad_ids"].append(a["id"])
    cob = [e["id"] for _, _, (_, _, e) in [(0, 0, v) for v in elem_idx.values()]
           if not close(sum(act_in[i]["metrado"] for i in e["actividad_ids"]), e["parcial"])]
    control("Cada elemento de metrado queda programado por completo (Σ metrado de sus actividades = parcial)", not cob,
            f"elementos={len(elem_idx)}, con diferencia={len(cob)} {cob[:5]}")
    control("Cada actividad resuelve a su elemento de metrado (ID, subtotal; V/H = división del elemento base)", not err_elem, f"errores={len(err_elem)} {err_elem[:5]}")
    control("Rendimiento de la actividad = rendimiento diario del APU", not err_rend, f"errores={len(err_rend)} {err_rend[:5]}")
    control("Duración = metrado / (rendimiento × cuadrillas), techo mín. 1 día (salvo ajustes declarados)", not err_dur, f"errores={len(err_dur)} {err_dur[:5]}")
    control("Fin = inicio + duración programada − 1 (tareas)", not err_ini, f"errores={len(err_ini)} {err_ini[:5]}")
    dif_met = [p["wbs"] for p in partidas if not close(sum(actividades[i]["metrado"] for i, x in enumerate(actividades) if x["partida_id"] == p["id"]), p["cantidad"])]
    control("Σ metrado de actividades = cantidad de la partida", not dif_met, f"partidas con diferencia={len(dif_met)} {dif_met[:5]}")
    dif_cos = [p["wbs"] for p in partidas if not close(sum(x["costo_directo_usd"] for x in actividades if x["partida_id"] == p["id"]), p["parcial_usd"])]
    control("Σ costo de actividades = parcial de la partida", not dif_cos, f"partidas con diferencia={len(dif_cos)} {dif_cos[:5]}")
    act_pos = {a["id"]: a for a in actividades}
    viol = []
    for r in relaciones:
        pa, sa = act_pos[r["predecesora_id"]]["programacion"], act_pos[r["sucesora_id"]]["programacion"]
        ok = sa["inicio_dia"] >= (pa["fin_dia"] + 1 + r["desfase_dias"] if r["tipo"] == "FS" else pa["inicio_dia"] + r["desfase_dias"])
        if not ok:
            viol.append(r["id"])
    control("Fechas respetan cada vínculo (FS: inicio ≥ fin+1+desfase; SS: inicio ≥ inicio+desfase)", not viol, f"violaciones={len(viol)} {viol[:5]}")
    fin = max(a["programacion"]["fin_dia"] for a in actividades)
    control("Duración del proyecto = resumen del cronograma", fin == cron["resumen"]["fin"], f"calculada={fin}, resumen={cron['resumen']['fin']}")
    # resumen por partida / capítulo
    plan_in = {p["wbs"]: p for p in cron["partidas"]}
    for p in partidas:
        acts = [act_pos[i] for i in p["actividad_ids"]]
        pl = plan_in[p["wbs"]]
        p["cronograma"] = {"actividades": len(acts), "inicio_dia": min(x["programacion"]["inicio_dia"] for x in acts),
                           "fin_dia": max(x["programacion"]["fin_dia"] for x in acts),
                           "critica": any(x["programacion"]["critica"] for x in acts),
                           "plan_cuadrillas": pl["plan_cuadrillas"], "trabajo_total_cuadrilla_dias": pl["trabajo_total_cuadrilla_dias"]}
    for c in capitulos:
        c["actividad_ids"] = [i for pid in c["partida_ids"] for i in next(p for p in partidas if p["id"] == pid)["actividad_ids"]]

    msp = {
        "descripcion": "Campos personalizados que las macros .bas escriben en MS Project: permiten volver de cada tarea a este JSON.",
        "campos": {"Text1": "actividad.id (ID JSON)", "Text2": "partida.wbs", "Text3": "capitulo.codigo", "Text4": "actividad.nivel",
                   "Text5": "actividad.sector", "Text6": "actividad.unidad", "Text7": "metrado_fuente.elemento_id",
                   "Text8": "metrado_fuente.clasificacion", "Text9": "actividad.tipo_actividad", "Number1": "actividad.metrado",
                   "Number2": "actividad.rendimiento_apu_efectivo", "Number3": "actividad.cuadrillas_asignadas_frente",
                   "Number4": "actividad.duracion.exacta_dias"},
        "macros": [a["id"] for a in archivos if a["rol"] == "macro_msproject"],
        "calendario": D["calendario_proyecto"],
    }

    resumen = {
        "partidas": len(partidas), "apus": len(apus), "componentes_apu": sum(len(a["componentes"]) for a in apus), "recursos": len(recursos),
        "capitulos": len(capitulos), "elementos_metrado": len(elem_idx), "actividades": len(actividades), "relaciones": len(relaciones),
        "tipos_relacion": dict(Counter(r["tipo"] for r in relaciones)), "relaciones_con_desfase": sum(1 for r in relaciones if r["desfase_dias"]),
        "observaciones": len(observaciones), "duracion_proyecto_dias": fin, "actividades_criticas": sum(1 for a in actividades if a["programacion"]["critica"]),
        "costo_directo_usd": cd_total, "total_presupuesto_usd": total,
    }
    conformes = sum(1 for c in ctl if c["resultado"] == "CONFORME")
    dictamen = "CONFORME_PARA_TRAZABILIDAD" if conformes == len(ctl) else "CON_OBSERVACIONES"
    doc = {
        "schema": SCHEMA, "generado": datetime.now().isoformat(timespec="seconds"),
        "herramienta": "Agentes_de_Presupuesto/01_Herramientas/integrar_presupuesto_cronograma.py",
        "proyecto": {"codigo": proy["codigo"], "nombre": proy["nombre"], "estado": proy["estado"], "revision_presupuesto": proy["revision_vigente"],
                     "revision_cronograma": cron["revision"], "estado_cronograma": cron["estado"], "moneda": "USD",
                     "tipo_cambio_pen_por_usd": tc, "datos": {k: usd["assumptions"][k] for k in usd["assumptions"]},
                     "advertencias": ["Metrados sintéticos: no acreditan medición de planos originales.",
                                      "Precios y perfiles HSE/QA provisionales; observaciones abiertas en 'observaciones'.",
                                      "Cronograma BORRADOR PARA CALIBRACIÓN: sin fecha de inicio aprobada ni calendario contractual (días relativos).",
                                      "La entrada canónica captura consumos evaluados; los factores vivos están en el Excel R02 (celdas referenciadas)."]},
        "cadena_de_trazabilidad": [
            "capitulo → partida (partida_ids)", "partida → metrado.subtotales[].elementos[] → actividad_ids",
            "partida → eett (id, ancla, ruta_origen, sha256_origen)", "partida → apu_id → componentes[] → recurso_id → fuente_precio_id",
            "partida/apu/componente/recurso → celdas del Excel R02 (campo 'excel')", "actividad → partida_id, apu_id, metrado_fuente.elemento_id",
            "actividad → predecesora_relacion_ids / sucesora_relacion_ids → relaciones[]", "recurso → usado_en_apus; actividad → consumos_recursos[]"],
        "convenciones_id": {"CAP-": "capítulo del WBS", "PAR-": "partida (WBS)", "APU-": "análisis de precios unitarios", "CMP-": "componente de APU",
                            "REC-/HSE-/QA-/TOOLS-": "recurso", "SUB-/ELM-": "subtotal y elemento de metrado", "ACT-": "actividad del cronograma",
                            "REL-": "relación lógica (vínculo)", "SRC-": "fuente", "OBS-": "observación abierta", "ARCH-": "archivo fuente con SHA-256"},
        "archivos_fuente": archivos, "fuentes": fuentes, "resumen": resumen, "totales": totales,
        "capitulos": capitulos, "partidas": partidas, "apus": apus, "recursos": list(recursos.values()),
        "gastos_generales": gg,
        "cronograma": {"metodologia": cron["metodologia"], "calendario_cronograma": cron["calendario"], "diagnostico_plazo": cron["diagnostico_plazo"],
                       "analisis_brecha_plazo": cron["analisis_brecha_plazo"], "observaciones": cron["observaciones"],
                       "actividades": actividades, "relaciones": relaciones},
        "observaciones": observaciones, "msproject": msp,
        "verificacion": {"dictamen": dictamen, "controles_conformes": conformes, "controles_total": len(ctl), "controles": ctl},
    }
    # ---- integridad referencial global
    ids = {"CAP": {c["id"] for c in capitulos}, "PAR": {p["id"] for p in partidas}, "APU": {a["id"] for a in apus}, "REC": set(recursos),
           "ACT": set(act_pos), "REL": set(rel_by_id), "SRC": ids_fuente}
    rotas = []
    for p in partidas:
        rotas += [("PAR→CAP", p["id"])] if p["capitulo_id"] not in ids["CAP"] else []
        rotas += [("PAR→APU", p["id"])] if p["apu_id"] not in ids["APU"] else []
        rotas += [("PAR→SRC", p["id"]) for s in p["metrado"]["fuente_ids"] + p["eett"]["fuente_ids"] if s not in ids["SRC"]]
    for a in apus:
        rotas += [("CMP→REC", c["id"]) for c in a["componentes"] if c["recurso_id"] not in ids["REC"]]
    for a in actividades:
        rotas += [("ACT→PAR", a["id"])] if a["partida_id"] not in ids["PAR"] else []
        rotas += [("ACT→REL", a["id"]) for r in a["predecesora_relacion_ids"] + a["sucesora_relacion_ids"] if r not in ids["REL"]]
    ids_todos = [x["id"] for x in doc["cronograma"]["actividades"]] + [x["id"] for x in partidas] + [x["id"] for x in apus] + \
                [c["id"] for a in apus for c in a["componentes"]] + [r["id"] for r in recursos.values()] + [r["id"] for r in relaciones]
    dup = [k for k, v in Counter(ids_todos).items() if v > 1]
    control("Integridad referencial (todo ID referenciado existe)", not rotas, f"referencias rotas={len(rotas)} {rotas[:5]}")
    control("IDs únicos en todo el documento", not dup, f"duplicados={len(dup)} {dup[:5]}")
    doc["verificacion"].update({"dictamen": "CONFORME_PARA_TRAZABILIDAD" if all(c["resultado"] == "CONFORME" for c in ctl) else "CON_OBSERVACIONES",
                                "controles_conformes": sum(1 for c in ctl if c["resultado"] == "CONFORME"), "controles_total": len(ctl), "controles": ctl})

    args.salida.mkdir(parents=True, exist_ok=True)
    out = args.salida / args.nombre
    out.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
    ver = {"schema": "verificacion_integrado/1.0", "archivo": out.name, "sha256": sha256(out), "bytes": out.stat().st_size,
           "generado": doc["generado"], "dictamen": doc["verificacion"]["dictamen"], "resumen": resumen, "controles": ctl,
           "archivos_fuente": archivos}
    (args.salida / "verificacion_integrado.json").write_text(json.dumps(ver, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({"salida": str(out), "dictamen": ver["dictamen"], "controles": f"{doc['verificacion']['controles_conformes']}/{len(ctl)}",
                      **{k: resumen[k] for k in ("partidas", "actividades", "relaciones", "componentes_apu", "recursos")}}, ensure_ascii=False))
    for c in ctl:
        if c["resultado"] != "CONFORME":
            print("OBSERVADO:", c["control"], "->", c["detalle"])
    sys.exit(0 if ver["dictamen"] == "CONFORME_PARA_TRAZABILIDAD" else 1)


if __name__ == "__main__":
    main()
