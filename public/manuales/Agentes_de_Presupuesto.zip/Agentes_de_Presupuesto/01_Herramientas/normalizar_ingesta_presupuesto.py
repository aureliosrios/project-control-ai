"""Normaliza un presupuesto Excel o JSON a un JSON relacional apto para staging SQL.

El resultado conserva tres clases de identificadores:

* el codigo funcional de la fuente (WBS/codigo de insumo);
* el numero de orden observado (partida, APU, componente e insumo);
* la ubicacion fisica de origen (hoja, fila, celda y formula, cuando viene de Excel).

No carga SQL Server. Produce y valida el contrato intermedio que puede consumir el flujo
``presupuesto-a-base-s10`` u otro cargador SQL. Se soportan:

* Excel S10 trazable con PRESUPUESTO_S10, ANALISIS_APU_S10 e
  INSUMOS_RECURSOS_S10.
* JSON ya normalizado con ``schema_version=ingesta_presupuesto_relacional/1.1``.
* JSON canonico del nucleo determinista (resources/apus/items).

Las subpartidas con desglose se conservan como analisis referenciables y pueden anidarse.
Los subcontratos permanecen como insumos ``SUBCONTRACT``; no se convierten en subpartidas.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path


SCHEMA = "ingesta_presupuesto_relacional/1.1"
REQUIRED_SHEETS = ("PRESUPUESTO_S10", "ANALISIS_APU_S10", "INSUMOS_RECURSOS_S10")
SECTION_MAP = {
    "MANO DE OBRA": "LABOR",
    "MATERIALES": "MATERIAL",
    "EQUIPOS": "EQUIPMENT",
    "SUBCONTRATOS": "SUBCONTRACT",
    "SUBPARTIDAS": "SUBPARTIDA",
    "HERRAMIENTAS": "TOOLS",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def scalar(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    return value


def as_number(value):
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else None


def norm_label(value) -> str:
    text = unicodedata.normalize("NFKD", str(value or ""))
    return re.sub(r"[^A-Z0-9]+", " ", "".join(c for c in text if not unicodedata.combining(c)).upper()).strip()


def find_header_map(ws, specifications: dict[str, tuple[str, ...]]) -> tuple[int, dict[str, int]]:
    """Localiza una fila de encabezados y devuelve columnas por nombre semantico."""
    for row in range(1, min(ws.max_row, 100) + 1):
        labels = {col: norm_label(ws.cell(row, col).value) for col in range(1, ws.max_column + 1)}
        mapping = {}
        for field, needles in specifications.items():
            col = next((c for c, label in labels.items() if any(n in label for n in needles)), None)
            if col:
                mapping[field] = col
        if all(field in mapping for field in specifications):
            return row, mapping
    raise ValueError(f"No se reconocieron encabezados en la hoja {ws.title}: {list(specifications)}")


def source_cell(sheet: str, row: int, column: str, formula=None, value=None) -> dict:
    out = {"sheet": sheet, "row": row, "cell": f"{column}{row}"}
    if formula not in (None, ""):
        out["formula"] = formula
    if value is not None:
        out["value"] = scalar(value)
    return out


def formula_reference(formula, expected_sheet: str):
    """Devuelve (celda, fila) de una referencia explicita a expected_sheet."""
    if not isinstance(formula, str) or not formula.startswith("="):
        return None
    pat = rf"(?:'([^']+)'|([A-Za-z0-9_ ]+))!\$?([A-Z]+)\$?(\d+)"
    for quoted, plain, col, row in re.findall(pat, formula):
        sheet = quoted or plain
        if sheet.strip().casefold() == expected_sheet.casefold():
            return f"{col}{row}", int(row)
    return None


def parse_apu_header(values):
    for value in values[:3]:
        if not isinstance(value, str):
            continue
        m = re.match(r"\s*PARTIDA\s*:?[ ]*([0-9]+(?:\.[0-9]+)+)\s*(?:[-:]\s*)?(.*)", value, re.I)
        if m:
            return m.group(1), m.group(2).strip()
    return None


def parse_subpartida_header(values):
    for value in values[:3]:
        if not isinstance(value, str):
            continue
        # El separador despues del codigo evita confundir una descripcion como
        # "Subpartida de concreto" con la cabecera de un bloque.
        m = re.match(r"\s*SUBPARTIDA\s*:?[ ]*([A-Z0-9_.%/-]+)\s*[-:]\s*(.*)", value, re.I)
        if m:
            return m.group(1), m.group(2).strip()
    return None


def parse_yield(values):
    for value in values[:4]:
        if not isinstance(value, str):
            continue
        m = re.search(r"Rendimiento(?:\s+MO\.)?\s*:?[ ]*([0-9]+(?:[.,][0-9]+)?)", value, re.I)
        if m:
            return float(m.group(1).replace(",", "."))
    return None


def discover_subpartidas(workbook) -> tuple[list[dict], set[str]]:
    """Descubre subpartidas con desglose y las meramente declaradas en el listado."""
    detailed = []
    if "SUBPARTIDAS_S10" in workbook.sheetnames:
        ws = workbook["SUBPARTIDAS_S10"]
        for row in range(1, ws.max_row + 1):
            values = [ws.cell(row, col).value for col in range(1, ws.max_column + 1)]
            header = parse_subpartida_header(values)
            if header:
                detailed.append({"code": header[0], "description": header[1], "source_row": row})
    declared = {x["code"] for x in detailed}
    if "LISTADO_SUBPARTIDAS_S10" in workbook.sheetnames:
        ws = workbook["LISTADO_SUBPARTIDAS_S10"]
        try:
            header_row, cols = find_header_map(ws, {"code": ("CODIGO",), "description": ("DESCRIPCION",)})
        except ValueError:
            header_row, cols = 0, {"code": 1, "description": 2}
        for row in range(header_row + 1, ws.max_row + 1):
            code = ws.cell(row, cols["code"]).value
            desc = ws.cell(row, cols["description"]).value
            if isinstance(code, str) and code.strip() and norm_label(code) not in {"N A", "CONTROL"} and desc:
                declared.add(code.strip())
    return detailed, declared


def parse_subpartida_blocks(formulas, values, resource_by_row, resources_by_code,
                             detailed_defs, declared_codes, warnings, errors):
    """Extrae APU de subpartidas, incluidos enlaces a otras subpartidas."""
    if not detailed_defs:
        return []
    if "SUBPARTIDAS_S10" not in formulas.sheetnames:
        errors.append("Se declararon subpartidas, pero falta la hoja SUBPARTIDAS_S10 con su desglose.")
        return []
    sf, sv = formulas["SUBPARTIDAS_S10"], values["SUBPARTIDAS_S10"]
    try:
        header_row, cols = find_header_map(sf, {
            "code": ("CODIGO",), "description": ("DESCRIPCION",), "unit": ("UNIDAD", "UND"),
            "quantity": ("CANTIDAD",), "price": ("PRECIO",), "partial": ("PARCIAL",),
        })
    except ValueError as exc:
        errors.append(str(exc))
        return []
    # CUADRILLA es opcional en algunas hojas de subpartidas.
    crew_col = next((col for col in range(1, sf.max_column + 1)
                     if "CUADRILLA" in norm_label(sf.cell(header_row, col).value)), None)
    id_by_code = {definition["code"]: f"SUB-{number:06d}" for number, definition in enumerate(detailed_defs, 1)}
    number_by_code = {definition["code"]: number for number, definition in enumerate(detailed_defs, 1)}
    subparts, current, section = [], None, None
    from openpyxl.utils import get_column_letter
    for row in range(1, sf.max_row + 1):
        rowf = [sf.cell(row, col).value for col in range(1, sf.max_column + 1)]
        header = parse_subpartida_header(rowf)
        if header:
            code, desc = header
            current = {
                "id": id_by_code[code], "subpartida_number": number_by_code[code], "source_code": code,
                "description": desc, "source_row": row, "daily_output": None, "output_unit": None,
                "unit_cost": None, "components": [],
                "source": {"sheet": sf.title, "row": row},
            }
            subparts.append(current)
            section = None
            continue
        if current is None:
            continue
        maybe_yield = parse_yield(rowf)
        if maybe_yield is not None:
            current["daily_output"] = maybe_yield
            text = " ".join(str(x) for x in rowf if isinstance(x, str))
            match = re.search(r"Rendimiento(?:\s+MO\.)?\s*:?[ ]*[0-9]+(?:[.,][0-9]+)?\s+([^/ ]+)\s*/", text, re.I)
            if match:
                current["output_unit"] = match.group(1)
            continue
        label = norm_label(sf.cell(row, cols["code"]).value)
        if label in SECTION_MAP:
            section = SECTION_MAP[label]
            continue
        code = sf.cell(row, cols["code"]).value
        if not isinstance(code, str) or not code.strip() or norm_label(code) == "CODIGO":
            continue
        desc = sf.cell(row, cols["description"]).value
        unit = sf.cell(row, cols["unit"]).value
        if desc in (None, "") or unit in (None, ""):
            if norm_label(code).startswith("COSTO DIRECTO"):
                current["unit_cost"] = as_number(sv.cell(row, cols["partial"]).value)
            continue
        code = code.strip()
        linked_resource = None
        linked_subpart_id = id_by_code.get(code)
        linked_subpart_number = number_by_code.get(code)
        ref, ref_formula, ref_cell = None, None, None
        if linked_subpart_id:
            for col in range(1, sf.max_column + 1):
                for expected in ("SUBPARTIDAS_S10", "LISTADO_SUBPARTIDAS_S10"):
                    found = formula_reference(rowf[col - 1], expected)
                    if found:
                        ref_formula, ref_cell = rowf[col - 1], found[0]
                        break
                if ref_formula:
                    break
            if linked_subpart_id == current["id"]:
                errors.append(f"Subpartida {current['source_code']} fila {row}: referencia a si misma.")
            component_kind = "SUBPARTIDA"
        elif code in declared_codes:
            errors.append(
                f"Subpartida {code!r} usada en {current['source_code']} no tiene desglose. "
                "Debe detallarse como APU o reclasificarse como insumo/subcontrato."
            )
            component_kind = "SUBPARTIDA"
        else:
            for col in range(1, sf.max_column + 1):
                found = formula_reference(rowf[col - 1], "INSUMOS_RECURSOS_S10")
                if found:
                    ref, ref_formula, ref_cell = found, rowf[col - 1], found[0]
                    break
            linked_resource = resource_by_row.get(ref[1]) if ref else None
            if linked_resource is None and len(resources_by_code.get(code, [])) == 1:
                linked_resource = resources_by_code[code][0]
                warnings.append(
                    f"Subpartida {current['source_code']} fila {row}: enlace a insumo resuelto por codigo."
                )
            if linked_resource is None:
                errors.append(f"Subpartida {current['source_code']} fila {row}: insumo {code!r} no resuelve.")
            elif linked_resource["source_code"] != code:
                errors.append(
                    f"Subpartida {current['source_code']} fila {row}: codigo {code!r} apunta a "
                    f"{linked_resource['source_code']!r}."
                )
            component_kind = "SUBCONTRACT" if linked_resource and linked_resource.get("type") == "SUBCONTRACT" else "RESOURCE"
        number = len(current["components"]) + 1
        current["components"].append({
            "id": f"{current['id']}-CMP-{number:04d}", "component_number": number,
            "component_kind": component_kind,
            "resource_id": linked_resource["id"] if linked_resource else None,
            "resource_number": linked_resource["resource_number"] if linked_resource else None,
            "subpartida_id": linked_subpart_id, "subpartida_number": linked_subpart_number,
            "source_code": code, "description": str(desc).strip(), "unit": str(unit).strip(),
            "type": "SUBPARTIDA" if linked_subpart_id else (linked_resource.get("type") if linked_resource else section),
            "crew": as_number(sv.cell(row, crew_col).value) if crew_col else None,
            "quantity": as_number(sv.cell(row, cols["quantity"]).value),
            "unit_price": as_number(sv.cell(row, cols["price"]).value),
            "partial": as_number(sv.cell(row, cols["partial"]).value),
            "source": {"sheet": sf.title, "row": row,
                       "code_cell": f"{get_column_letter(cols['code'])}{row}",
                       "reference_formula": ref_formula, "reference_cell": ref_cell},
        })
    return subparts


def excel_to_relational(path: Path) -> dict:
    try:
        import openpyxl
    except ImportError as exc:
        raise SystemExit("Se requiere openpyxl para leer Excel: " + str(exc))

    if path.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise ValueError("Excel admitido: .xlsx o .xlsm. Convertir .xls a .xlsx sin alterar formulas.")
    formulas = openpyxl.load_workbook(path, data_only=False, read_only=False)
    values = openpyxl.load_workbook(path, data_only=True, read_only=False)
    missing = [name for name in REQUIRED_SHEETS if name not in formulas.sheetnames]
    if missing:
        raise ValueError("Faltan hojas obligatorias: " + ", ".join(missing))

    warnings, errors = [], []
    # Recursos: la fila es una clave de enlace de primer nivel; el codigo es la clave funcional.
    sf = formulas["INSUMOS_RECURSOS_S10"]
    sv = values["INSUMOS_RECURSOS_S10"]
    _, resource_cols = find_header_map(sf, {
        "code": ("CODIGO",), "description": ("DESCRIPCION",), "unit": ("UND", "UNIDAD"),
        "quantity": ("CANTIDAD TOTAL", "CANTIDAD"), "price": ("PRECIO",),
    })
    resources, resource_by_row = [], {}
    current_type = None
    for row in range(1, sf.max_row + 1):
        cells = [sf.cell(row, col).value for col in range(1, min(sf.max_column, 8) + 1)]
        first = sf.cell(row, resource_cols["code"]).value
        if isinstance(first, str) and first.strip().upper() in SECTION_MAP:
            current_type = SECTION_MAP[first.strip().upper()]
            continue
        code = first
        desc = sf.cell(row, resource_cols["description"]).value
        unit = sf.cell(row, resource_cols["unit"]).value
        if not isinstance(code, str) or not code.strip() or desc in (None, "") or unit in (None, ""):
            continue
        if code.strip().upper() in {"CODIGO", "CÓDIGO", "ITEM", "ÍTEM"}:
            continue
        number = len(resources) + 1
        from openpyxl.utils import get_column_letter
        price_col = get_column_letter(resource_cols["price"])
        quantity_col = get_column_letter(resource_cols["quantity"])
        code_col = get_column_letter(resource_cols["code"])
        rec = {
            "id": f"REC-{number:06d}", "resource_number": number, "source_row": row,
            "source_code": code.strip(), "description": str(desc).strip(), "unit": str(unit).strip(),
            "type": current_type, "quantity_total": as_number(sv[f"{quantity_col}{row}"].value),
            "unit_price": as_number(sv[f"{price_col}{row}"].value),
            "source": {
                "code": source_cell(sf.title, row, code_col, value=code),
                "quantity_total": source_cell(sf.title, row, quantity_col, sf[f"{quantity_col}{row}"].value,
                                                sv[f"{quantity_col}{row}"].value),
                "unit_price": source_cell(sf.title, row, price_col, sf[f"{price_col}{row}"].value,
                                            sv[f"{price_col}{row}"].value),
            },
        }
        resources.append(rec)
        resource_by_row[row] = rec

    codes = defaultdict(list)
    for rec in resources:
        codes[rec["source_code"]].append(rec)

    detailed_subpart_defs, declared_subpart_codes = discover_subpartidas(formulas)
    subpartidas = parse_subpartida_blocks(
        formulas, values, resource_by_row, codes, detailed_subpart_defs, declared_subpart_codes,
        warnings, errors,
    )
    subpartida_by_code = {sub["source_code"]: sub for sub in subpartidas}

    # APU: se conserva el numero del bloque y el numero de linea dentro del bloque.
    af = formulas["ANALISIS_APU_S10"]
    av = values["ANALISIS_APU_S10"]
    _, apu_cols = find_header_map(af, {
        "code": ("CODIGO",), "description": ("DESCRIPCION",), "unit": ("UNIDAD", "UND"),
        "crew": ("CUADRILLA",), "quantity": ("CANTIDAD",), "price": ("PRECIO",),
        "partial": ("PARCIAL",),
    })
    apus, current, section = [], None, None
    for row in range(1, af.max_row + 1):
        rowf = [af.cell(row, col).value for col in range(1, af.max_column + 1)]
        rowv = [av.cell(row, col).value for col in range(1, av.max_column + 1)]
        header = parse_apu_header(rowf)
        if header:
            wbs, desc = header
            current = {
                "id": f"APU-{len(apus) + 1:06d}", "apu_number": len(apus) + 1, "wbs": wbs,
                "description": desc, "source_row": row, "daily_output": None,
                "output_unit": None, "unit_cost": None, "components": [],
                "source": {"header": source_cell(af.title, row, "A", value=next(v for v in rowf if v))},
            }
            apus.append(current)
            section = None
            continue
        if current is None:
            continue
        maybe_yield = parse_yield(rowf)
        if maybe_yield is not None:
            current["daily_output"] = maybe_yield
            text = " ".join(str(x) for x in rowf if isinstance(x, str))
            mu = re.search(r"Rendimiento(?:\s+MO\.)?\s*:?[ ]*[0-9]+(?:[.,][0-9]+)?\s+([^/ ]+)\s*/", text, re.I)
            if mu:
                current["output_unit"] = mu.group(1)
            continue
        label = norm_label(af.cell(row, apu_cols["code"]).value)
        if label in SECTION_MAP:
            section = SECTION_MAP[label]
            continue
        code = af.cell(row, apu_cols["code"]).value
        if not isinstance(code, str) or not code.strip() or code.strip().upper() in {"CODIGO", "CÓDIGO"}:
            continue
        desc = af.cell(row, apu_cols["description"]).value
        unit = af.cell(row, apu_cols["unit"]).value
        if desc in (None, "") or unit in (None, ""):
            # La fila total cierra el bloque y no es un componente.
            if code.upper().startswith("COSTO DIRECTO"):
                current["unit_cost"] = next((as_number(x) for x in reversed(rowv) if as_number(x) is not None), None)
            continue
        code = code.strip()
        ref = None
        price_col = None
        linked = None
        linked_subpartida = subpartida_by_code.get(code)
        reference_formula, reference_cell = None, None
        if linked_subpartida:
            for col in range(1, af.max_column + 1):
                for expected in ("SUBPARTIDAS_S10", "LISTADO_SUBPARTIDAS_S10"):
                    found = formula_reference(rowf[col - 1], expected)
                    if found:
                        reference_formula, reference_cell, price_col = rowf[col - 1], found[0], col
                        break
                if reference_formula:
                    break
            component_kind = "SUBPARTIDA"
        elif code in declared_subpart_codes:
            errors.append(
                f"APU {current['wbs']} fila {row}: subpartida {code!r} sin desglose. "
                "Debe detallarse o reclasificarse como insumo/subcontrato."
            )
            component_kind = "SUBPARTIDA"
        else:
            for col in range(1, af.max_column + 1):
                found = formula_reference(rowf[col - 1], "INSUMOS_RECURSOS_S10")
                if found:
                    ref, price_col = found, col
                    reference_formula, reference_cell = rowf[col - 1], found[0]
                    break
            linked = resource_by_row.get(ref[1]) if ref else None
            if linked is None and len(codes.get(code, [])) == 1:
                linked = codes[code][0]
                warnings.append(f"APU {current['wbs']} fila {row}: enlace a insumo resuelto por codigo, no por formula.")
            if linked is None:
                errors.append(f"APU {current['wbs']} fila {row}: no se pudo enlazar el insumo {code!r}.")
            elif linked["source_code"] != code:
                errors.append(
                    f"APU {current['wbs']} fila {row}: codigo {code!r} apunta por formula a "
                    f"{linked['source_code']!r} (fila {linked['source_row']})."
                )
            component_kind = "SUBCONTRACT" if linked and linked.get("type") == "SUBCONTRACT" else "RESOURCE"
        number = len(current["components"]) + 1
        price_col = price_col or apu_cols["price"]
        quantity_col = apu_cols["quantity"]
        partial_col = apu_cols["partial"]
        component = {
            "id": f"{current['id']}-CMP-{number:04d}", "component_number": number,
            "component_kind": component_kind,
            "resource_id": linked["id"] if linked else None,
            "resource_number": linked["resource_number"] if linked else None,
            "subpartida_id": linked_subpartida["id"] if linked_subpartida else None,
            "subpartida_number": linked_subpartida["subpartida_number"] if linked_subpartida else None,
            "source_code": code, "description": str(desc).strip(), "unit": str(unit).strip(),
            # El catalogo manda sobre la seccion visual: evita confundir subcontratos y equipos.
            "type": "SUBPARTIDA" if linked_subpartida else (linked.get("type") if linked else section),
            "crew": as_number(av.cell(row, apu_cols["crew"]).value),
            "quantity": as_number(rowv[quantity_col - 1]) if quantity_col else None,
            "unit_price": as_number(rowv[price_col - 1]) if price_col else (linked.get("unit_price") if linked else None),
            "partial": as_number(rowv[partial_col - 1]) if partial_col else None,
            "source": {
                "row": row, "code_cell": f"{get_column_letter(apu_cols['code'])}{row}",
                "reference_formula": reference_formula,
                "reference_cell": reference_cell,
                "resource_reference_formula": reference_formula if component_kind in {"RESOURCE", "SUBCONTRACT"} else None,
                "resource_reference_cell": reference_cell if component_kind in {"RESOURCE", "SUBCONTRACT"} else None,
                "subpartida_reference_formula": reference_formula if component_kind == "SUBPARTIDA" else None,
                "subpartida_reference_cell": reference_cell if component_kind == "SUBPARTIDA" else None,
            },
        }
        current["components"].append(component)

    # Partidas: la formula de PU es la relacion primaria con el bloque APU; WBS es control secundario.
    pf = formulas["PRESUPUESTO_S10"]
    pv = values["PRESUPUESTO_S10"]
    _, budget_cols = find_header_map(pf, {
        "item": ("ITEM",), "description": ("DESCRIPCION",), "unit": ("UNIDAD", "UND"),
        "quantity": ("METRADO", "CANTIDAD"), "price": ("PRECIO UNIT", "PRECIO"), "partial": ("IMPORTE", "PARCIAL"),
    })
    apu_by_wbs = defaultdict(list)
    apu_by_total_row = {}
    for apu in apus:
        apu_by_wbs[apu["wbs"]].append(apu)
        # Busca desde la cabecera hasta antes de la siguiente cabecera.
    for idx, apu in enumerate(apus):
        end = apus[idx + 1]["source_row"] - 1 if idx + 1 < len(apus) else af.max_row
        for row in range(apu["source_row"], end + 1):
            first = af.cell(row, apu_cols["code"]).value
            if isinstance(first, str) and first.upper().startswith("COSTO DIRECTO"):
                apu_by_total_row[row] = apu
                if apu["unit_cost"] is None:
                    apu["unit_cost"] = next(
                        (as_number(av.cell(row, col).value) for col in range(af.max_column, 0, -1)
                         if as_number(av.cell(row, col).value) is not None), None
                    )
                break

    items, chapters = [], []
    for row in range(1, pf.max_row + 1):
        code = pf.cell(row, budget_cols["item"]).value
        if not isinstance(code, str) or not re.fullmatch(r"\d+(?:\.\d+)+", code.strip()):
            continue
        desc, unit = pf.cell(row, budget_cols["description"]).value, pf.cell(row, budget_cols["unit"]).value
        if unit in (None, ""):
            chapters.append({"wbs": code.strip(), "description": scalar(desc), "source_row": row})
            continue
        formula_ref = None
        price_col = None
        for col in range(1, pf.max_column + 1):
            found = formula_reference(pf.cell(row, col).value, "ANALISIS_APU_S10")
            if found:
                formula_ref, price_col = found, col
                break
        linked = apu_by_total_row.get(formula_ref[1]) if formula_ref else None
        if linked is None and len(apu_by_wbs.get(code.strip(), [])) == 1:
            linked = apu_by_wbs[code.strip()][0]
            warnings.append(f"Partida {code} fila {row}: enlace al APU resuelto por WBS, no por formula.")
        if linked is None:
            errors.append(f"Partida {code} fila {row}: no se pudo enlazar un APU unico.")
        elif linked["wbs"] != code.strip():
            errors.append(f"Partida {code} fila {row}: la formula apunta al APU {linked['wbs']}.")
        number = len(items) + 1
        quantity_col = budget_cols["quantity"]
        price_col = price_col or budget_cols["price"]
        partial_col = budget_cols["partial"]
        items.append({
            "id": f"PAR-{number:06d}", "budget_line_number": number, "wbs": code.strip(),
            "description": scalar(desc), "unit": scalar(unit),
            "quantity": as_number(pv.cell(row, quantity_col).value),
            "unit_price": as_number(pv.cell(row, price_col).value) if price_col else None,
            "partial": as_number(pv.cell(row, partial_col).value) if partial_col else None,
            "apu_id": linked["id"] if linked else None,
            "apu_number": linked["apu_number"] if linked else None,
            "source": {
                "row": row, "item_cell": f"{get_column_letter(budget_cols['item'])}{row}",
                "apu_reference_formula": pf.cell(row, price_col).value if price_col else None,
                "apu_reference_cell": formula_ref[0] if formula_ref else None,
            },
        })

    relations_budget_apu = [{
        "budget_item_id": item["id"], "budget_line_number": item["budget_line_number"],
        "apu_id": item["apu_id"], "apu_number": item["apu_number"], "join_key": item["wbs"],
        "source_formula": item["source"]["apu_reference_formula"],
    } for item in items]
    component_relations = build_component_relations(apus, subpartidas)

    return {
        "schema_version": SCHEMA,
        "source": {"kind": "EXCEL", "path": str(path.resolve()), "sha256": sha256(path),
                   "required_sheets": list(REQUIRED_SHEETS)},
        "presupuesto": {"chapters": chapters, "items": items},
        "apus": apus,
        "subpartidas": subpartidas,
        "insumos": resources,
        "relaciones": {"presupuesto_apu": relations_budget_apu, **component_relations},
        "sql_staging": sql_staging(items, apus, resources, subpartidas),
        "validation": {"status": "FAIL" if errors else "PASS", "errors": errors, "warnings": warnings},
    }


def build_component_relations(apus, subpartidas):
    def source_formula(component):
        source = component.get("source") or {}
        return source.get("reference_formula") or source.get("resource_reference_formula") or source.get("subpartida_reference_formula")

    def resource_relation(owner, component, owner_kind):
        return {
            f"{owner_kind}_id": owner["id"], f"{owner_kind}_number": owner[f"{owner_kind}_number"],
            "component_id": component["id"], "component_number": component["component_number"],
            "component_kind": component.get("component_kind"), "resource_id": component.get("resource_id"),
            "resource_number": component.get("resource_number"), "source_code": component.get("source_code"),
            "source_formula": source_formula(component),
        }

    def subpart_relation(owner, component, owner_kind):
        return {
            f"{owner_kind}_id": owner["id"], f"{owner_kind}_number": owner[f"{owner_kind}_number"],
            "component_id": component["id"], "component_number": component["component_number"],
            "subpartida_id": component.get("subpartida_id"),
            "subpartida_number": component.get("subpartida_number"), "source_code": component.get("source_code"),
            "source_formula": source_formula(component),
        }

    return {
        "apu_insumo": [resource_relation(a, c, "apu") for a in apus for c in a.get("components", [])
                        if c.get("component_kind") in {"RESOURCE", "SUBCONTRACT"}],
        "apu_subpartida": [subpart_relation(a, c, "apu") for a in apus for c in a.get("components", [])
                            if c.get("component_kind") == "SUBPARTIDA"],
        "subpartida_insumo": [resource_relation(s, c, "subpartida") for s in subpartidas
                               for c in s.get("components", [])
                               if c.get("component_kind") in {"RESOURCE", "SUBCONTRACT"}],
        "subpartida_subpartida": [subpart_relation(s, c, "subpartida") for s in subpartidas
                                   for c in s.get("components", [])
                                   if c.get("component_kind") == "SUBPARTIDA"],
    }


def canonical_json_to_relational(path: Path, data: dict) -> dict:
    resources_in = data.get("resources") or []
    apus_in = data.get("apus") or []
    items_in = data.get("items") or []
    resource_by_id, resources = {}, []
    for number, rec in enumerate(resources_in, 1):
        out = {
            "id": f"REC-{number:06d}", "resource_number": number, "source_id": rec.get("id"),
            "source_code": rec.get("id"), "description": rec.get("description_es") or rec.get("description"),
            "unit": rec.get("unit"), "type": rec.get("type"), "quantity_total": None,
            "unit_price": rec.get("unit_price"), "source": {"json_pointer": f"/resources/{number - 1}"},
        }
        resources.append(out)
        resource_by_id[rec.get("id")] = out

    apu_lookup, apus, errors = {}, [], []
    workday = ((data.get("assumptions") or {}).get("workday_hours") or 8)
    for number, apu in enumerate(apus_in, 1):
        out = {
            "id": f"APU-{number:06d}", "apu_number": number, "source_id": apu.get("id"),
            "wbs": apu.get("wbs"), "description": None, "source_row": None,
            "daily_output": apu.get("daily_output"), "output_unit": apu.get("output_unit"),
            "components": [], "source": {"json_pointer": f"/apus/{number - 1}"},
        }
        total = 0.0
        for comp_number, comp in enumerate(apu.get("components") or [], 1):
            rec = resource_by_id.get(comp.get("resource_id"))
            if rec is None:
                errors.append(f"APU {apu.get('id')}: recurso inexistente {comp.get('resource_id')!r}.")
            base_q = comp.get("quantity")
            if base_q is None and comp.get("crew") is not None and apu.get("daily_output"):
                base_q = comp["crew"] * workday / apu["daily_output"]
            effective_q = None if base_q is None else base_q * (1 + (comp.get("waste_rate") or 0))
            price = rec.get("unit_price") if rec else None
            partial = effective_q * price if effective_q is not None and price is not None else None
            if partial is not None:
                total += partial
            out["components"].append({
                "id": f"{out['id']}-CMP-{comp_number:04d}", "component_number": comp_number,
                "component_kind": "SUBCONTRACT" if rec and rec.get("type") == "SUBCONTRACT" else "RESOURCE",
                "resource_id": rec["id"] if rec else None,
                "resource_number": rec["resource_number"] if rec else None,
                "subpartida_id": None, "subpartida_number": None,
                "source_code": comp.get("resource_id"), "description": rec.get("description") if rec else None,
                "unit": rec.get("unit") if rec else None, "type": rec.get("type") if rec else None,
                "crew": comp.get("crew"), "quantity": effective_q, "unit_price": price, "partial": partial,
                "source": {"json_pointer": f"/apus/{number - 1}/components/{comp_number - 1}"},
            })
        out["unit_cost"] = total
        apus.append(out)
        apu_lookup[apu.get("id")] = out

    items, chapters = [], []
    for number, item in enumerate(items_in, 1):
        apu = apu_lookup.get(item.get("apu_id"))
        if apu is None:
            errors.append(f"Partida {item.get('wbs')}: APU inexistente {item.get('apu_id')!r}.")
        quantity = item.get("quantity")
        unit_price = apu.get("unit_cost") if apu else None
        items.append({
            "id": f"PAR-{number:06d}", "budget_line_number": number, "wbs": item.get("wbs"),
            "description": item.get("description_es") or item.get("description"), "unit": item.get("unit"),
            "quantity": quantity, "unit_price": unit_price,
            "partial": quantity * unit_price if isinstance(quantity, (int, float)) and unit_price is not None else None,
            "apu_id": apu["id"] if apu else None, "apu_number": apu["apu_number"] if apu else None,
            "source": {"json_pointer": f"/items/{number - 1}"},
        })
    relations_budget_apu = [{
        "budget_item_id": x["id"], "budget_line_number": x["budget_line_number"],
        "apu_id": x["apu_id"], "apu_number": x["apu_number"], "join_key": x["wbs"],
        "source_formula": None,
    } for x in items]
    subpartidas = []
    component_relations = build_component_relations(apus, subpartidas)
    return {
        "schema_version": SCHEMA,
        "source": {"kind": "JSON_CANONICO", "path": str(path.resolve()), "sha256": sha256(path)},
        "presupuesto": {"chapters": chapters, "items": items}, "apus": apus,
        "subpartidas": subpartidas, "insumos": resources,
        "relaciones": {"presupuesto_apu": relations_budget_apu, **component_relations},
        "sql_staging": sql_staging(items, apus, resources, subpartidas),
        "validation": {"status": "FAIL" if errors else "PASS", "errors": errors, "warnings": []},
    }


def sql_staging(items, apus, resources, subpartidas):
    """Vistas planas; sus *_id son claves foraneas, no descripciones inferidas."""
    return {
        "tables": {
            "stg_presupuesto_partida": [
                {k: x.get(k) for k in ("id", "budget_line_number", "wbs", "description", "unit", "quantity",
                                        "unit_price", "partial", "apu_id", "apu_number")} for x in items
            ],
            "stg_apu": [
                {k: a.get(k) for k in ("id", "apu_number", "wbs", "description", "output_unit", "daily_output",
                                        "unit_cost")} for a in apus
            ],
            "stg_apu_componente": [
                {"id": c.get("id"), "apu_id": a.get("id"), "apu_number": a.get("apu_number"),
                 **{k: c.get(k) for k in ("component_number", "component_kind", "resource_id", "resource_number",
                                          "subpartida_id", "subpartida_number", "source_code", "type", "unit",
                                          "crew", "quantity", "unit_price", "partial")}}
                for a in apus for c in a.get("components", [])
            ],
            "stg_subpartida": [
                {k: s.get(k) for k in ("id", "subpartida_number", "source_code", "description", "output_unit",
                                        "daily_output", "unit_cost")} for s in subpartidas
            ],
            "stg_subpartida_componente": [
                {"id": c.get("id"), "subpartida_owner_id": s.get("id"),
                 "subpartida_owner_number": s.get("subpartida_number"),
                 **{k: c.get(k) for k in ("component_number", "component_kind", "resource_id", "resource_number",
                                          "subpartida_id", "subpartida_number", "source_code", "type", "unit",
                                          "crew", "quantity", "unit_price", "partial")}}
                for s in subpartidas for c in s.get("components", [])
            ],
            "stg_insumo": [
                {k: r.get(k) for k in ("id", "resource_number", "source_code", "description", "unit", "type",
                                        "quantity_total", "unit_price")} for r in resources
            ],
        },
        "foreign_keys": [
            {"from": "stg_presupuesto_partida.apu_id", "to": "stg_apu.id"},
            {"from": "stg_apu_componente.apu_id", "to": "stg_apu.id"},
            {"from": "stg_apu_componente.resource_id", "to": "stg_insumo.id"},
            {"from": "stg_apu_componente.subpartida_id", "to": "stg_subpartida.id"},
            {"from": "stg_subpartida_componente.subpartida_owner_id", "to": "stg_subpartida.id"},
            {"from": "stg_subpartida_componente.resource_id", "to": "stg_insumo.id"},
            {"from": "stg_subpartida_componente.subpartida_id", "to": "stg_subpartida.id"},
        ],
    }


def validate_relational(data: dict) -> list[str]:
    errors = []
    if data.get("schema_version") != SCHEMA:
        errors.append(f"schema_version debe ser {SCHEMA!r}.")
    items = (data.get("presupuesto") or {}).get("items") or []
    apus = data.get("apus") or []
    subpartidas = data.get("subpartidas") or []
    resources = data.get("insumos") or []
    apu_ids = [x.get("id") for x in apus]
    subpartida_ids = [x.get("id") for x in subpartidas]
    resource_ids = [x.get("id") for x in resources]
    for label, ids in (("APU", apu_ids), ("subpartida", subpartida_ids), ("insumo", resource_ids)):
        duplicates = [x for x, n in Counter(ids).items() if x is not None and n > 1]
        if duplicates:
            errors.append(f"IDs duplicados de {label}: {duplicates[:10]}")
    for item in items:
        if item.get("apu_id") not in set(apu_ids):
            errors.append(f"Partida {item.get('id')}: apu_id no resuelve ({item.get('apu_id')!r}).")
    resource_set, subpartida_set = set(resource_ids), set(subpartida_ids)
    resource_type = {x.get("id"): x.get("type") for x in resources}

    def validate_components(owner, owner_label):
        for comp in owner.get("components") or []:
            kind = comp.get("component_kind")
            resource_id, subpartida_id = comp.get("resource_id"), comp.get("subpartida_id")
            if kind in {"RESOURCE", "SUBCONTRACT"}:
                if resource_id not in resource_set:
                    errors.append(
                        f"Componente {comp.get('id')} de {owner_label}: resource_id no resuelve ({resource_id!r})."
                    )
                if subpartida_id is not None:
                    errors.append(f"Componente {comp.get('id')}: no puede enlazar insumo y subpartida a la vez.")
                if kind == "SUBCONTRACT" and resource_type.get(resource_id) != "SUBCONTRACT":
                    errors.append(f"Componente {comp.get('id')}: SUBCONTRACT apunta a un insumo de otro tipo.")
                if kind == "RESOURCE" and resource_type.get(resource_id) == "SUBCONTRACT":
                    errors.append(f"Componente {comp.get('id')}: el insumo SUBCONTRACT no fue clasificado como tal.")
            elif kind == "SUBPARTIDA":
                if subpartida_id not in subpartida_set:
                    errors.append(
                        f"Componente {comp.get('id')} de {owner_label}: subpartida_id no resuelve ({subpartida_id!r})."
                    )
                if resource_id is not None:
                    errors.append(f"Componente {comp.get('id')}: no puede enlazar subpartida e insumo a la vez.")
            else:
                errors.append(f"Componente {comp.get('id')} de {owner_label}: component_kind invalido ({kind!r}).")

    for apu in apus:
        validate_components(apu, f"APU {apu.get('id')}")
    for subpartida in subpartidas:
        if not subpartida.get("components"):
            errors.append(
                f"Subpartida {subpartida.get('source_code') or subpartida.get('id')} sin desglose: "
                "debe reclasificarse como insumo si solo tiene precio."
            )
        validate_components(subpartida, f"subpartida {subpartida.get('id')}")

    # Las subpartidas pueden anidarse, pero no formar ciclos.
    graph = {s.get("id"): [c.get("subpartida_id") for c in s.get("components") or []
                            if c.get("component_kind") == "SUBPARTIDA"] for s in subpartidas}
    visiting, visited = set(), set()

    def visit(node):
        if node in visiting:
            errors.append(f"Ciclo de subpartidas detectado en {node}.")
            return
        if node in visited or node not in graph:
            return
        visiting.add(node)
        for child in graph[node]:
            visit(child)
        visiting.remove(node)
        visited.add(node)

    for node in graph:
        visit(node)
    rel = data.get("relaciones") or {}
    if len(rel.get("presupuesto_apu") or []) != len(items):
        errors.append("relaciones.presupuesto_apu no tiene una fila por partida.")
    apu_resource_count = sum(1 for a in apus for c in a.get("components") or []
                             if c.get("component_kind") in {"RESOURCE", "SUBCONTRACT"})
    apu_subpart_count = sum(1 for a in apus for c in a.get("components") or []
                            if c.get("component_kind") == "SUBPARTIDA")
    sub_resource_count = sum(1 for s in subpartidas for c in s.get("components") or []
                             if c.get("component_kind") in {"RESOURCE", "SUBCONTRACT"})
    sub_subpart_count = sum(1 for s in subpartidas for c in s.get("components") or []
                            if c.get("component_kind") == "SUBPARTIDA")
    for key, expected in (("apu_insumo", apu_resource_count), ("apu_subpartida", apu_subpart_count),
                          ("subpartida_insumo", sub_resource_count),
                          ("subpartida_subpartida", sub_subpart_count)):
        if len(rel.get(key) or []) != expected:
            errors.append(f"relaciones.{key} tiene {len(rel.get(key) or [])} filas; se esperaban {expected}.")
    return errors


def upgrade_relational(data: dict) -> dict:
    """Actualiza el contrato 1.0 (sin subpartidas) al contrato 1.1."""
    if data.get("schema_version") == SCHEMA:
        return data
    if data.get("schema_version") != "ingesta_presupuesto_relacional/1.0":
        return data
    data["schema_version"] = SCHEMA
    subpartidas = data.setdefault("subpartidas", [])
    resource_type = {r.get("id"): r.get("type") for r in data.get("insumos") or []}
    for apu in data.get("apus") or []:
        for component in apu.get("components") or []:
            component.setdefault(
                "component_kind",
                "SUBCONTRACT" if resource_type.get(component.get("resource_id")) == "SUBCONTRACT" else "RESOURCE",
            )
            component.setdefault("subpartida_id", None)
            component.setdefault("subpartida_number", None)
    relations = data.setdefault("relaciones", {})
    budget_relations = relations.get("presupuesto_apu") or []
    data["relaciones"] = {
        "presupuesto_apu": budget_relations,
        **build_component_relations(data.get("apus") or [], subpartidas),
    }
    items = (data.get("presupuesto") or {}).get("items") or []
    data["sql_staging"] = sql_staging(items, data.get("apus") or [], data.get("insumos") or [], subpartidas)
    data.setdefault("validation", {}).setdefault("warnings", []).append(
        "Contrato ingesta_presupuesto_relacional/1.0 actualizado a 1.1; no contenia subpartidas."
    )
    return data


def normalize(path: Path) -> dict:
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xlsm", ".xls"}:
        result = excel_to_relational(path)
    elif suffix == ".json":
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if data.get("schema_version") in {SCHEMA, "ingesta_presupuesto_relacional/1.0"}:
            result = upgrade_relational(data)
            result.setdefault("source", {}).setdefault("path", str(path.resolve()))
            result["source"].setdefault("sha256", sha256(path))
        elif all(key in data for key in ("resources", "apus", "items")):
            result = canonical_json_to_relational(path, data)
        else:
            raise ValueError(
                "JSON no reconocido. Debe ser el JSON relacional de ingesta o el JSON canonico "
                "del nucleo (resources/apus/items)."
            )
    else:
        raise ValueError("Formato no soportado. Use .xlsx, .xlsm o .json.")
    errors = validate_relational(result)
    validation = result.setdefault("validation", {"errors": [], "warnings": []})
    validation.setdefault("errors", []).extend(x for x in errors if x not in validation.get("errors", []))
    validation.setdefault("warnings", [])
    validation["status"] = "FAIL" if validation["errors"] else "PASS"
    return result


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--entrada", required=True, type=Path)
    parser.add_argument("--salida", required=True, type=Path)
    parser.add_argument("--permitir-observado", action="store_true",
                        help="Escribe JSON con validation=FAIL; sin esta opcion, no deja salida invalida.")
    args = parser.parse_args(argv)
    if not args.entrada.is_file():
        parser.error(f"No existe la entrada: {args.entrada}")
    try:
        result = normalize(args.entrada)
    except (ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "FAIL", "errors": [str(exc)]}, ensure_ascii=False, indent=2))
        return 2
    if result["validation"]["status"] != "PASS" and not args.permitir_observado:
        print(json.dumps(result["validation"], ensure_ascii=False, indent=2))
        return 3
    args.salida.parent.mkdir(parents=True, exist_ok=True)
    args.salida.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=scalar) + "\n", encoding="utf-8")
    summary = {
        "status": result["validation"]["status"], "salida": str(args.salida),
        "partidas": len(result["presupuesto"]["items"]), "apus": len(result["apus"]),
        "componentes_apu": sum(len(a["components"]) for a in result["apus"]),
        "subpartidas": len(result.get("subpartidas") or []),
        "subpartidas_anidadas": len((result.get("relaciones") or {}).get("subpartida_subpartida") or []),
        "subcontratos": sum(1 for r in result["insumos"] if r.get("type") == "SUBCONTRACT"),
        "insumos": len(result["insumos"]), "warnings": result["validation"]["warnings"],
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if result["validation"]["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
