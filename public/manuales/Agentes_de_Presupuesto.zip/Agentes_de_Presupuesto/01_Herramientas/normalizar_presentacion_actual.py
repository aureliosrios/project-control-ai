"""Consolida valores vigentes; no vuelve a aplicar factores históricos."""
from pathlib import Path
import json,re,subprocess,collections,copy,datetime
import openpyxl
from openpyxl.formula import Tokenizer
from openpyxl.styles import Font,Alignment
from generar_presentacion import ROOT,digest

def consolidate(project):
    p=ROOT/'Proyectos'/project;meta=json.loads((p/'proyecto.json').read_text(encoding='utf-8-sig'))
    source=p/meta['entregables']['excel'];w=openpyxl.load_workbook(source);cached=openpyxl.load_workbook(source,data_only=True)
    folder=p/'04_Presupuesto/R02_Vigente/Salidas'/('Consolidado_'+datetime.datetime.now().strftime('%H%M%S'))
    folder.mkdir();out=folder/'R02_USD.xlsx'
    old=w['ANALISIS_APU_S10'];support=w['APOYO_HSE_QA'];sv=cached['APOYO_HSE_QA'];budget=w['PRESUPUESTO_S10']
    budget_rows={str(budget.cell(r,2).value):r for r in range(10,101) if budget.cell(r,4).value}
    starts=[r for r in range(1,old.max_row+1) if str(old.cell(r,2).value).startswith('Partida:')]
    grouped=collections.defaultdict(list)
    for r in range(5,support.max_row+1):
        if support.cell(r,1).value:grouped[str(support.cell(r,1).value)].append(r)
    new=w.create_sheet('_APU_NUEVO');new['B2']='ANÁLISIS DE PRECIOS UNITARIOS — USD'
    oldrows={};supprows={};pending=[];unit_checks=[];quantity_checks=[]
    sections=('Mano de Obra','Materiales','Equipos','Herramientas','Subcontratos','Subpartidas')
    for i,start in enumerate(starts):
        end=starts[i+1] if i+1<len(starts) else old.max_row+1
        code=re.search(r'Partida:\s*(\d+\.\d+)',str(old.cell(start,2).value))[1]
        header=new.max_row+3;perf=header+1
        new.cell(header,2,old.cell(start,2).value);oldrows[start]=header;oldrows[start+1]=perf;oldrows[start+2]=perf+1
        for col in range(2,9):new.cell(perf,col,cached[old.title].cell(start+1,col).value)
        new.cell(perf,2,'Rendimiento MO.');new.cell(perf,5,'EQ.')
        new.cell(perf+1,2,'Código');new.cell(perf+1,3,'Descripción');new.cell(perf+1,4,'Unidad');new.cell(perf+1,5,'Cuadrilla');new.cell(perf+1,6,'Cantidad');new.cell(perf+1,7,'Precio US$');new.cell(perf+1,8,'Parcial US$')
        categories=collections.defaultdict(list);category='Materiales'
        for r in range(start+3,end):
            desc=str(old.cell(r,3).value or '')
            if desc.casefold() in [s.casefold() for s in sections]:category=next(s for s in sections if s.casefold()==desc.casefold());continue
            if old.cell(r,2).value and old.cell(r,4).value:categories[category].append(('original',r))
        for r in grouped[code]:categories['Equipos' if sv.cell(r,4).value=='hm' else 'Mano de Obra'].append(('apoyo',r))
        lines=[]
        for category in sections:
            if not categories[category]:continue
            row=new.max_row+1;new.cell(row,3,category)
            for kind,r in categories[category]:
                row=new.max_row+1;lines.append(row)
                if kind=='original':
                    oldrows[r]=row
                    for col in range(2,9):
                        value=old.cell(r,col).value
                        if old.cell(r,col).data_type=='f':
                            if 'BASE_PRECIOS_PEN' in value:value=cached[old.title].cell(r,col).value
                            else:pending.append((row,col,value))
                        new.cell(row,col,value)
                    quantity_checks.append((row,cached[old.title].cell(r,6).value))
                else:
                    supprows[r]=(row,budget_rows[code])
                    for col,sourcecol in ((2,2),(3,3),(4,4)):new.cell(row,col,sv.cell(r,sourcecol).value)
                    crew=sv.cell(r,5).value*sv.cell(r,6).value
                    new.cell(row,5,crew)
                    # Coeficientes finales de cuadrilla/cobertura, sin motor de reajustes.
                    new.cell(row,6,f'=E{row}*DATOS_GENERALES_S10!$B$4/C{perf}')
                    new.cell(row,7,support.cell(r,10).value)
                    new.cell(row,8,f'=F{row}*G{row}')
                    quantity_checks.append((row,sv.cell(r,9).value))
        new.cell(perf,8,'='+ '+'.join(f'H{r}' for r in lines))
        unit_checks.append((code,perf,cached[old.title].cell(start+1,8).value))
    def transform(formula,local):
        tokens=Tokenizer(formula)
        for token in tokens.items:
            if token.type!='OPERAND' or token.subtype!='RANGE':continue
            value=token.value;parts=value.rsplit('!',1);sheet=parts[0].strip("'") if len(parts)==2 else local;address=parts[-1]
            if sheet=='ANALISIS_APU_S10':
                def rowref(m):
                    row=int(m[3]);return m[1]+m[2]+str(oldrows.get(row,row))
                address=re.sub(r'(\$?[A-Z]+)(\$?)(\d+)',rowref,address)
                token.value=(parts[0]+'!' if len(parts)==2 else '')+address
            elif sheet=='APOYO_HSE_QA':
                m=re.fullmatch(r'\$?([A-Z]+)\$?(\d+)',address)
                if not m:raise ValueError('Rango histórico no consolidable: '+value)
                r,br=supprows[int(m[2])]
                if m[1]=='I':token.value=f'ANALISIS_APU_S10!F{r}'
                elif m[1]=='L':token.value=f'PRESUPUESTO_S10!E{br}'
                else:raise ValueError('Referencia histórica no esperada: '+value)
        return '='+''.join(t.value for t in tokens.items)
    for row,col,formula in pending:new.cell(row,col,transform(formula,'ANALISIS_APU_S10'))
    w.remove(old);new.title='ANALISIS_APU_S10'
    allowed={'DATOS_GENERALES_S10','PRESUPUESTO_S10','ANALISIS_APU_S10','INSUMOS_RECURSOS_S10','GASTOS_GENERALES_S10'}
    for s in list(w):
        if s.title not in allowed:w.remove(s);continue
        if s==new:continue
        for row in s:
            for c in row:
                if c.data_type!='f':continue
                if any(t in c.value for t in ('BASE_PRECIOS_PEN','CONFIG_HSE_QA','FACTORES_HSE_QA','METRADOS_TRAZABLES')):
                    c.value=cached[s.title][c.coordinate].value
                else:c.value=transform(c.value,s.title)
    resources=w['INSUMOS_RECURSOS_S10'];resources.delete_cols(8,resources.max_column)
    resources['B2']='LISTADO DE INSUMOS — USD';resources['F5']='Precio unitario US$'
    gg=w['GASTOS_GENERALES_S10'];gg.delete_cols(11,gg.max_column)
    gg['B2']='GASTOS GENERALES — USD';gg['B24']=None;gg['C24']='GASTOS GENERALES';gg['J25']='Clase'
    for r in range(26,37):
        gg.cell(r,2,f'GG-{r-25:02d}')
        desc=str(gg.cell(r,3).value or '')
        gg.cell(r,3,re.sub(r'\s*\([^)]*adicional[^)]*\)|\s+(?:adicional|incremental)','',desc,flags=re.I))
    gen=w['DATOS_GENERALES_S10']
    for row in gen:
        for c in row:
            if c.column>=3:c.value=None
    gen['A1']='DATOS GENERALES';gen['C3']=None;gen['B11']='PROVISIONAL';gen['A12']='Fecha base';gen['A14']='Revisión';gen['B14']=meta['revision_vigente']
    for r in (13,15):
        for c in gen[r]:c.value=None
    gen['A20']='Tipo de cambio de referencia PEN/US$';gen['B20']=meta['tipo_cambio_pen_por_usd'];gen['A21']='Moneda';gen['B21']='USD'
    budget['C108']='TOTAL PRESUPUESTO (US$)'
    for s in w:
        s.freeze_panes=None;s.sheet_view.pane=None;s.sheet_view.showGridLines=False
        for row in s:
            for c in row:
                if c.value is not None:
                    bold=c.font.bold or (s==new and (str(new.cell(c.row,2).value).startswith('Partida:') or str(new.cell(c.row,3).value) in sections or str(new.cell(c.row,2).value)=='Código'))
                    c.font=Font(name='Arial',size=10,bold=bold);c.alignment=Alignment(wrap_text=True,vertical='center')
        for col,width in {'A':3,'B':18,'C':78,'D':10,'E':16,'F':18,'G':20,'H':20}.items():s.column_dimensions[col].width=width
    w._sheets=[gen,budget,new,resources,gg]
    w.defined_names.clear();w.save(out)
    subprocess.run(['powershell','-NoProfile','-File',str(Path(__file__).with_name('recalcular_presentacion.ps1')),str(out)],check=True,capture_output=True)
    result=openpyxl.load_workbook(out,data_only=True);final=openpyxl.load_workbook(out)
    errors=[f'{s.title}!{c.coordinate}' for s in result for row in s for c in row if c.data_type=='e']
    if errors:raise ValueError(errors[:10])
    for code,row,expected in unit_checks:
        assert abs(result[new.title].cell(row,8).value-expected)<1e-7,(code,result[new.title].cell(row,8).value,expected)
    for row,expected in quantity_checks:
        if isinstance(expected,(int,float)):assert abs(result[new.title].cell(row,6).value-expected)<1e-7,(row,expected)
    for row in range(7,resources.max_row+1):
        if isinstance(cached[resources.title].cell(row,5).value,(int,float)):
            assert abs(result[resources.title].cell(row,5).value-cached[resources.title].cell(row,5).value)<1e-6,(resources.title,row)
    total=result[budget.title]['G108'].value;assert abs(total-meta['total_provisional'])<.01
    sheets=[]
    for s in final:
        cells=[{'celda':c.coordinate,'valor':c.value,'resultado':result[s.title][c.coordinate].value,'formato_numero':c.number_format,'es_formula':c.data_type=='f'} for row in s for c in row if c.value is not None]
        sheets.append({'nombre':s.title,'moneda_importes':'USD','filas':s.max_row,'columnas':s.max_column,'celdas':cells})
    snap={'version':'R02-presentacion-actual','moneda':'USD','tipo_cambio_pen_por_usd':meta['tipo_cambio_pen_por_usd'],'dictamen':'BORRADOR_OBSERVADO','proyecto':meta['nombre'],'totales':{'total':{'despues':total,'moneda':'USD'}},'libro_excel':{'archivo':'04_Presupuesto/R02_Vigente/R02_USD.xlsx','sha256':digest(out),'hojas':sheets}}
    (folder/'R02_USD.json').write_text(json.dumps(snap,ensure_ascii=False,indent=2),encoding='utf-8')
    report={'estado':'PASS','origen':str(source),'sha256_origen':digest(source),'salida':str(out),'total_usd':total,'apus_conciliados':len(unit_checks),'coeficientes_conciliados':len(quantity_checks),'insumos_conciliados':True,'sin_motor_reajustes':True,'errores':errors}
    (folder/'verificacion_normalizacion.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))
    return folder

if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--proyecto',required=True);args=a.parse_args();consolidate(args.proyecto)
