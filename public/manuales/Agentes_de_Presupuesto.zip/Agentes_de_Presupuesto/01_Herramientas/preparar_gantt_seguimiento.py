"""Prepara los insumos del Gantt de seguimiento para ``generar_vba_msproject.py``.

Lee (sin modificarlos):
- ``presupuesto_cronograma_integrado.json``: plan (actividades, duraciones programadas, relaciones).
- ``01_REPORTES_JSON/Parte_Diario_*.json``: avance real diario.
- ``calendario_proyecto.json`` proporcionado por el usuario.

Escribe en la carpeta de salida:
- ``cronograma_plan.json``: plan en el esquema que consume el generador (fechas calculadas con el calendario del usuario).
- ``seguimiento_real.json``: inicio real, fin real y % completado por actividad (último reporte).
- ``wbs.json``: títulos de capítulo.

Reglas del seguimiento:
- ``id_tarea`` del reporte = ``id`` de la actividad del cronograma. Un id que no exista en el plan detiene el proceso.
- inicio_real: primer valor no nulo informado; fin_real: primer valor no nulo informado.
- avance: ``avance_acum_pct`` del último reporte donde aparece la actividad (se exige que no decrezca).
- % de MS Project (entero): redondeo al entero más cercano; 100 solo si hay fin_real; si no, tope 99.
- Actividades sin reporte no reciben avance real.
"""
from __future__ import annotations

from datetime import datetime, time
from pathlib import Path
import argparse
import hashlib
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from calendario_proyecto import CalendarioIncompleto, cargar as cargar_calendario  # noqa: E402


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def iso(dia, hora: time) -> str:
    return datetime.combine(dia, hora).isoformat(timespec="minutes")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--integrado", type=Path, required=True)
    parser.add_argument("--reportes", type=Path, required=True, help="carpeta con Parte_Diario_*.json")
    parser.add_argument("--calendario", type=Path, required=True)
    parser.add_argument("--salida", type=Path, required=True)
    args = parser.parse_args()

    try:
        cal = cargar_calendario(args.calendario)
    except CalendarioIncompleto as exc:
        print(f"CALENDARIO_INCOMPLETO: {exc}", file=sys.stderr)
        raise SystemExit(2)

    integrado = load(args.integrado)
    cron = integrado["cronograma"]
    partidas = {p["id"]: p for p in integrado["partidas"]}
    capitulos = {c["id"]: c for c in integrado["capitulos"]}
    actividades = []
    for a in cron["actividades"]:
        prog = a["programacion"]
        dur = a["duracion"]
        if prog["fin_dia"] - prog["inicio_dia"] + 1 != dur["programada_dias"]:
            raise SystemExit(f"Duración inconsistente en {a['id']}: inicio_dia/fin_dia no coinciden con duracion.programada_dias")
        partida = partidas[a["partida_id"]]
        capitulo = capitulos[a["capitulo_id"]]
        actividades.append({
            "id": a["id"], "wbs": partida["wbs"], "capitulo": capitulo["codigo"],
            "descripcion": a["descripcion"], "partida_descripcion": partida["descripcion"],
            "nivel": a["nivel"], "cota": a.get("cota"), "sector": a["sector"], "unidad": a["unidad"],
            "metrado": a["metrado"],
            "fuente_metrado": {"id_subtotal": a["metrado_fuente"].get("subtotal_id"),
                               "id_elemento": a["metrado_fuente"]["elemento_id"],
                               "clasificacion": a["metrado_fuente"].get("clasificacion")},
            "rendimiento_apu_efectivo": a["rendimiento_apu_efectivo"],
            "cuadrillas_asignadas_frente": a["cuadrillas_asignadas_frente"],
            "duracion_productiva_exacta_dias": dur["exacta_dias"],
            "duracion_programada_dias": dur["programada_dias"],
            "formula_duracion": dur.get("formula"),
            "tipo_actividad": a["tipo_actividad"], "ajuste_calendario": dur.get("ajuste_calendario"),
            "inicio_dia": prog["inicio_dia"], "fin_dia": prog["fin_dia"],
            "inicio_fecha": iso(cal.fecha_de_dia(prog["inicio_dia"]), cal.hora_inicio),
            "fin_fecha": iso(cal.fecha_de_dia(prog["fin_dia"]), cal.hora_fin),
        })
    # El generador agrupa por capítulo y partida consecutivos: se exige contigüidad.
    vistos_cap, vistos_par, ult_cap, ult_par = set(), set(), None, None
    for a in actividades:
        if a["capitulo"] != ult_cap:
            if a["capitulo"] in vistos_cap:
                raise SystemExit(f"Capítulo {a['capitulo']} no es contiguo en la lista de actividades")
            vistos_cap.add(a["capitulo"]); ult_cap = a["capitulo"]
        if a["wbs"] != ult_par:
            if a["wbs"] in vistos_par:
                raise SystemExit(f"Partida {a['wbs']} no es contigua en la lista de actividades")
            vistos_par.add(a["wbs"]); ult_par = a["wbs"]

    relaciones = [{"id": r["id"], "predecesora": r["predecesora_id"], "sucesora": r["sucesora_id"],
                   "tipo": r["tipo"], "desfase_dias": r["desfase_dias"], "motivo": r.get("motivo")}
                  for r in cron["relaciones"]]
    ids = {a["id"] for a in actividades}
    for r in relaciones:
        if r["predecesora"] not in ids or r["sucesora"] not in ids:
            raise SystemExit(f"Relación {r['id']} apunta a una actividad inexistente")
    fin = max(a["fin_dia"] for a in actividades)

    plan = {
        "schema": "cronograma_plan_seguimiento/1.0",
        "revision": integrado["proyecto"]["revision_cronograma"],
        "estado": "PLAN_LINEA_BASE_PARA_SEGUIMIENTO",
        "proyecto": integrado["proyecto"]["codigo"],
        "fuente": {"archivo": str(args.integrado), "sha256": sha256(args.integrado)},
        "calendario": {"fuente": "USUARIO", "sha256": cal.sha256, "ruta": str(args.calendario),
                       "nombre_calendario": cal.nombre_calendario},
        "resumen": {"inicio": 1, "fin": fin, "actividades": len(actividades), "partidas": len(vistos_par),
                    "capitulos": len(vistos_cap), "relaciones": len(relaciones)},
        "actividades": actividades,
        "relaciones": relaciones,
    }

    # --- Seguimiento real ---
    archivos = sorted(args.reportes.glob("Parte_Diario_Dia_*.json"))
    if not archivos:
        raise SystemExit(f"No hay reportes Parte_Diario_Dia_*.json en {args.reportes}")
    seg: dict[str, dict] = {}
    primera_fecha = ultima_fecha = None
    for archivo in archivos:
        rep = load(archivo)
        meta = rep["metadatos_jornada"]
        fecha = meta["fecha"]
        primera_fecha = primera_fecha or fecha
        if ultima_fecha and fecha <= ultima_fecha:
            raise SystemExit(f"Reportes fuera de orden o repetidos en {archivo.name}")
        ultima_fecha = fecha
        for p in rep["01_cuantificacion_produccion_y_metrados"]["partidas_ejecutadas"]:
            tid = p["id_tarea"]
            if tid not in ids:
                raise SystemExit(f"{archivo.name}: id_tarea {tid} no existe en el cronograma")
            s = seg.setdefault(tid, {"inicio_real": None, "fin_real": None, "avance_acum_pct": 0.0,
                                     "atraso_inicio_dias": None, "estado": None, "reportes": 0,
                                     "primer_reporte": fecha, "ultimo_reporte": fecha})
            if p.get("inicio_real") and not s["inicio_real"]:
                s["inicio_real"] = p["inicio_real"]
            if p.get("fin_real") and not s["fin_real"]:
                s["fin_real"] = p["fin_real"]
            pct = float(p["avance_acum_pct"])
            if pct + 1e-9 < s["avance_acum_pct"]:
                raise SystemExit(f"{archivo.name}: el avance de {tid} decrece ({s['avance_acum_pct']} -> {pct})")
            s["avance_acum_pct"] = pct
            s["atraso_inicio_dias"] = p.get("atraso_inicio_dias")
            s["estado"] = p.get("estado")
            s["reportes"] += 1
            s["ultimo_reporte"] = fecha
    for tid, s in seg.items():
        if s["fin_real"] and not s["inicio_real"]:
            raise SystemExit(f"{tid}: tiene fin_real sin inicio_real")
        if s["fin_real"]:
            s["pct_msproject"] = 100
        else:
            s["pct_msproject"] = min(99, int(s["avance_acum_pct"] + 0.5)) if s["inicio_real"] else 0
    fecha_estado = ultima_fecha
    seguimiento = {
        "schema": "seguimiento_real/1.0",
        "fecha_estado": fecha_estado,
        "dia_estado": len(archivos),
        "fuente": {"carpeta": str(args.reportes), "sha256_por_archivo": {a.name: sha256(a) for a in archivos}},
        "reportes": {"cantidad": len(archivos), "primer_fecha": primera_fecha, "ultima_fecha": ultima_fecha},
        "regla": "id_tarea = id de actividad; inicio_real/fin_real = primer valor informado; avance = último reporte; "
                 "pct_msproject entero (100 solo con fin_real, tope 99 sin fin_real). Sin reporte = sin avance real.",
        "actividades": dict(sorted(seg.items())),
    }

    args.salida.mkdir(parents=True, exist_ok=True)
    (args.salida / "cronograma_plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=1), encoding="utf-8")
    (args.salida / "seguimiento_real.json").write_text(json.dumps(seguimiento, ensure_ascii=False, indent=1), encoding="utf-8")
    wbs = {"capitulos": [{"capitulo": c["codigo"], "titulo": c["titulo"]} for c in integrado["capitulos"]]}
    (args.salida / "wbs.json").write_text(json.dumps(wbs, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({
        "actividades": len(actividades), "partidas": len(vistos_par), "capitulos": len(vistos_cap),
        "relaciones": len(relaciones), "fin_dia": fin, "fin_fecha": plan["actividades"][-1]["fin_fecha"],
        "reportes": len(archivos), "fecha_estado": fecha_estado,
        "con_inicio_real": sum(1 for s in seg.values() if s["inicio_real"]),
        "con_fin_real": sum(1 for s in seg.values() if s["fin_real"]),
        "en_reportes_sin_inicio": sum(1 for s in seg.values() if not s["inicio_real"]),
    }, ensure_ascii=True))


if __name__ == "__main__":
    main()
