param(
    [Parameter(Mandatory=$true)][string]$Plantilla,
    [Parameter(Mandatory=$true)][string]$Salida,
    [Parameter(Mandatory=$true)][ValidateSet('s10','presto')][string]$Formato,
    [double]$Velocidad=4,
    [int]$Inspeccionar=12,
    [switch]$PruebaOculta,
    [switch]$CerrarAlFinal
)
$ErrorActionPreference='Stop'
if($Velocidad -le 0){throw 'Velocidad debe ser mayor que cero'}
if(Test-Path -LiteralPath $Salida){throw 'La salida ya existe; no se sobrescribe'}
$excel=$null; $source=$null; $book=$null; $ok=$false
$budgetName=if($Formato -eq 's10'){'PRESUPUESTO_S10'}else{'PRESUPUESTO_Y_MEDICIONES'}
$apuName=if($Formato -eq 's10'){'ANALISIS_APU_S10'}else{'DESCOMPOSICION_APU'}
$resourceName=if($Formato -eq 's10'){'INSUMOS_RECURSOS_S10'}else{'LISTADO_DE_CONCEPTOS'}
try {
    $excel=New-Object -ComObject Excel.Application
    $excel.Visible=$false; $excel.DisplayAlerts=$false; $excel.AskToUpdateLinks=$false
    $source=$excel.Workbooks.Open($Plantilla,0,$true)
    $snapshots=@{}
    foreach($sheet in $source.Worksheets){
        $range=$sheet.UsedRange
        $data=$range.Formula
        if($range.Rows.Count -eq 1 -and $range.Columns.Count -eq 1 -and -not $range.HasFormula){$data=$range.Value2}
        $snapshots[$sheet.Name]=@{data=$data; values=$range.Value2; firstRow=$range.Row; firstCol=$range.Column; rows=$range.Rows.Count; cols=$range.Columns.Count}
    }
    # Copiar todas las hojas juntas conserva estilos y referencias internas.
    $source.Worksheets.Copy()
    $book=$excel.ActiveWorkbook
    $source.Close($false); $source=$null
    foreach($sheet in $book.Worksheets){[void]$sheet.UsedRange.ClearContents()}
    $excel.Calculation=-4135
    $excel.Visible=(-not $PruebaOculta)
    if(-not $PruebaOculta){$excel.WindowState=-4137}
    $excel.ScreenUpdating=(-not $PruebaOculta)
    Write-Host 'FASE 1: CONSTRUCCION CORRIDA DEL ENTREGABLE. La inspeccion comienza al terminar.'
    $names=@($book.Worksheets | ForEach-Object {$_.Name})
    $generalName=if($Formato -eq 's10'){'DATOS_GENERALES_S10'}else{'DATOS_GENERALES_PRESTO'}
    # Cargar el cambio y los precios base antes de sus fórmulas en dólares.
    $first=@($generalName,'BASE_PRECIOS_PEN') | Where-Object {$_ -in $names}
    $order=@($first)+@($names | Where-Object {$_ -notin $first -and $_ -ne $apuName -and $_ -ne $budgetName})+@($apuName,$budgetName)
    $written=0; $formulaCount=0; $visibleRows=0
    foreach($name in $order){
        $sheet=$book.Worksheets.Item($name);$sheet.Activate()
        $excel.ActiveWindow.FreezePanes=$false
        $excel.ActiveWindow.SplitRow=0;$excel.ActiveWindow.SplitColumn=0
        $sheet.Application.ActiveWindow.DisplayFormulas=$false
        $sheet.Application.ActiveWindow.Zoom=90
        $snapshot=$snapshots[$name];$data=$snapshot.data
        Write-Host "Construyendo $name ..."
        if(-not $PruebaOculta){
            $excel.ActiveWindow.ScrollRow=[Math]::Max(1,$snapshot.firstRow)
            $excel.ActiveWindow.ScrollColumn=[Math]::Max(1,$snapshot.firstCol)
        }
        for($r=0;$r -lt $snapshot.rows;$r++){
            $hasContent=$false
            $actualRow=$snapshot.firstRow+$r
            $rowRange=$sheet.Range($sheet.Cells.Item($actualRow,$snapshot.firstCol),$sheet.Cells.Item($actualRow,$snapshot.firstCol+$snapshot.cols-1))
            if(-not $PruebaOculta){
                $vis=$excel.ActiveWindow.VisibleRange
                $maxVisRow=$vis.Row+$vis.Rows.Count-2
                if($actualRow -lt $vis.Row -or $actualRow -gt $maxVisRow){
                    # La pantalla cambia de ubicación cuando se alcanza el final de la pantalla visible,
                    # ubicando la nueva fila en la cabecera para continuar el recorrido de arriba a abajo.
                    $excel.ActiveWindow.ScrollRow=[Math]::Max(1,$actualRow)
                    $excel.ActiveWindow.ScrollColumn=[Math]::Max(1,$snapshot.firstCol)
                    $vis=$excel.ActiveWindow.VisibleRange
                }
                $excel.Goto($sheet.Cells.Item($actualRow,$snapshot.firstCol),$false)
                $visible=$excel.ActiveWindow.VisibleRange
                if($actualRow -lt $visible.Row -or $actualRow -ge ($visible.Row+$visible.Rows.Count)){throw "Fila fuera de vista antes de escribir: $name $actualRow"}
                $visibleRows++
                $excel.StatusBar="CONSTRUYENDO $name - fila $actualRow"
            }
            $batch=($snapshot.cols -gt 1 -and $rowRange.MergeCells -eq $false)
            $rowData=[Array]::CreateInstance([object],[int[]]@(1,$snapshot.cols),[int[]]@(1,1))
            for($c=0;$c -lt $snapshot.cols;$c++){
                if($data -is [Array]){$value=$data.GetValue($r+$data.GetLowerBound(0),$c+$data.GetLowerBound(1))}else{$value=$data}
                if($value -isnot [string] -or -not $value.StartsWith('=')){
                    $values=$snapshot.values
                    if($values -is [Array]){$value=$values.GetValue($r+$values.GetLowerBound(0),$c+$values.GetLowerBound(1))}else{$value=$values}
                }
                if($null -eq $value -or ($value -is [string] -and $value.Length -eq 0)){continue}
                $isFormula=($value -is [string] -and $value.StartsWith('='))
                if($isFormula){$formulaCount++}
                if($batch){
                    if($value -is [string] -and -not $isFormula){$rowData.SetValue("'"+$value,1,$c+1)}else{$rowData.SetValue($value,1,$c+1)}
                } elseif($isFormula){$sheet.Cells.Item($actualRow,$snapshot.firstCol+$c).Formula=$value}
                elseif($value -is [string]){$sheet.Cells.Item($actualRow,$snapshot.firstCol+$c).Value2=[string]("'"+$value)}
                else{$sheet.Cells.Item($actualRow,$snapshot.firstCol+$c).Value2=[double]$value}
                $written++;$hasContent=$true
            }
            if($batch -and $hasContent){[void]$rowRange.GetType().InvokeMember('Formula',[Reflection.BindingFlags]::SetProperty,$null,$rowRange,[object[]]@(,$rowData))}
            if($hasContent -and -not $PruebaOculta){$rowRange.Calculate()}
            if($hasContent -and -not $PruebaOculta){
                Start-Sleep -Milliseconds ([int][Math]::Max(1,35/$Velocidad))
            }
        }
    }
    $excel.Calculation=-4105;$excel.CalculateFullRebuild()
    # El entregable se guarda completo antes del recorrido de formulas.
    $book.Worksheets.Item($budgetName).Activate()
    $book.SaveAs($Salida,51)
    Write-Host 'ENTREGABLE COMPLETO GUARDADO. FASE 2: INSPECCION DE FORMULAS VIVAS.'
    $errors=@();$checked=0;$shown=@{}
    foreach($name in @($budgetName,$apuName)){
        $sheet=$book.Worksheets.Item($name);$snapshot=$snapshots[$name];$data=$snapshot.data
        $sheet.Activate();$excel.ActiveWindow.Zoom=120;$shown[$name]=0
        if(-not $PruebaOculta){$excel.ActiveWindow.DisplayFormulas=$true}
        for($r=0;$r -lt $snapshot.rows;$r++){
            for($c=0;$c -lt $snapshot.cols;$c++){
                if($data -is [Array]){$value=$data.GetValue($r+$data.GetLowerBound(0),$c+$data.GetLowerBound(1))}else{$value=$data}
                if($value -isnot [string] -or -not $value.StartsWith('=')){continue}
                $cell=$sheet.Cells.Item($snapshot.firstRow+$r,$snapshot.firstCol+$c)
                if(-not $cell.HasFormula){throw "Formula convertida a valor en $name"}
                $checked++
                if($cell.Text -match '^#(REF!|DIV/0!|VALUE!|NAME\?|N/A|NUM!|NULL!)$'){$errors+=($name+'!'+$cell.Address())}
                if(-not $PruebaOculta -and ($Inspeccionar -eq 0 -or $shown[$name] -lt $Inspeccionar)){
                    $excel.Goto($cell,$true)
                    $excel.StatusBar="VERIFICACION $name $($cell.Address()): $($cell.Formula)"
                    try{$cell.ShowPrecedents()}catch{}
                    Start-Sleep -Milliseconds ([int][Math]::Max(1,1000/$Velocidad))
                    $sheet.ClearArrows();$shown[$name]++
                }
            }
        }
        $excel.ActiveWindow.DisplayFormulas=$false
    }
    if($errors.Count){throw "Errores Excel: $($errors -join ', ')"}
    # Prueba real: un precio debe afectar al presupuesto y restaurar el total.
    $budget=$book.Worksheets.Item($budgetName);$resources=$book.Worksheets.Item($resourceName)
    $before=[double]$budget.Range('G108').Value2;$price=[double]$resources.Range('F7').Value2
    $priceFormula=$resources.Range('F7').Formula
    try {
        $resources.Range('F7').Value2=[double]($price*1.1);$excel.CalculateFullRebuild();$changed=$budget.Range('G108').Value2
        if($changed -le $before){throw 'El precio no se propaga al total'}
    } finally {$resources.Range('F7').Formula=$priceFormula;$excel.CalculateFullRebuild()}
    $restored=$budget.Range('G108').Value2
    if([Math]::Abs($restored-$before) -gt 0.01){throw 'El total no se restituye'}
    $excel.ActiveWindow.Zoom=90;$budget.Activate();$excel.StatusBar=$false
    $book.Save()
    @{estado='PASS';formato=$Formato;orden=@('construccion_corrida','guardado_completo','inspeccion_formulas','prueba_precio','guardado_verificado');celdas_escritas=$written;formulas_escritas=$formulaCount;formulas_presupuesto_apu_verificadas=$checked;total=$restored;total_precio_mas_10_pct=$changed;errores=$errors;filas_visibles_antes_de_escribir=$visibleRows;velocidad=$Velocidad;paneles_inmovilizados=$false;inspeccion_visual_por_hoja=$Inspeccionar;prueba_oculta=[bool]$PruebaOculta} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path ([IO.Path]::GetDirectoryName($Salida)) 'verificacion_tiempo_real.json') -Encoding UTF8
    $ok=$true
    Write-Host "VERIFICACION COMPLETA. Total: $restored. Entregable: $Salida"
} catch {
    Write-Host $_.InvocationInfo.PositionMessage
    Write-Host $_.ScriptStackTrace
    throw
} finally {
    if($null -ne $source){$source.Close($false)}
    if($null -ne $excel -and ($PruebaOculta -or $CerrarAlFinal -or -not $ok)){
        if($null -ne $book){$book.Close($false)}
        $excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)
    }
}
