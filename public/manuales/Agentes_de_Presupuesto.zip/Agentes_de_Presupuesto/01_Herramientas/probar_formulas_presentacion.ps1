param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][ValidateSet('s10','presto')][string]$Formato)
$ErrorActionPreference='Stop'
$excel=$null; $book=$null
try {
    $excel=New-Object -ComObject Excel.Application
    $excel.Visible=$false; $excel.DisplayAlerts=$false
    # Sólo lectura: modificar en memoria y cerrar sin guardar.
    $book=$excel.Workbooks.Open($Path,0,$true)
    $budgetName=if($Formato -eq 's10'){'PRESUPUESTO_S10'}else{'PRESUPUESTO_Y_MEDICIONES'}
    $resourcesName=if($Formato -eq 's10'){'INSUMOS_RECURSOS_S10'}else{'LISTADO_DE_CONCEPTOS'}
    $budget=$book.Worksheets.Item($budgetName)
    $resources=$book.Worksheets.Item($resourcesName)
    $excel.CalculateFullRebuild()
    $before=$budget.Range('G108').Value2
    $price=$resources.Range('F7').Value2
    $priceFormula=$resources.Range('F7').Formula
    $resources.Range('F7').Value2=$price*1.1
    $excel.CalculateFullRebuild()
    $after=$budget.Range('G108').Value2
    if($after -le $before){throw 'El precio no se propaga al total'}
    $resources.Range('F7').Formula=$priceFormula
    $excel.CalculateFullRebuild()
    $restored=$budget.Range('G108').Value2
    if([Math]::Abs($restored-$before) -gt 0.01){throw 'No se restituye total'}
    $generalName=if($Formato -eq 's10'){'DATOS_GENERALES_S10'}else{'DATOS_GENERALES_PRESTO'}
    $general=$book.Worksheets.Item($generalName)
    $fx=$general.Range('B20').Value2
    $fxTest=$null
    if($fx -is [double] -and $fx -gt 0 -and $priceFormula -is [string] -and $priceFormula.Contains('B20')){
        try {
            $general.Range('B20').Value2=[double]($fx+0.1);$excel.CalculateFullRebuild()
            $fxTotal=$budget.Range('G108').Value2
            if([Math]::Abs($fxTotal-$before*$fx/($fx+0.1)) -gt 0.01){throw 'Cambio USD no se propaga correctamente'}
            $fxTest='PASS'
        } finally {$general.Range('B20').Value2=[double]$fx;$excel.CalculateFullRebuild()}
    }
    @{formato=$Formato;total_base=$before;total_precio_mas_10_pct=$after;total_restaurado=$restored;prueba='PASS';prueba_tipo_cambio=$fxTest;tipo_cambio=$fx;sin_guardar=$true}|ConvertTo-Json
} finally {
    if($null -ne $book){$book.Close($false)}
    if($null -ne $excel){$excel.Quit();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)}
}
