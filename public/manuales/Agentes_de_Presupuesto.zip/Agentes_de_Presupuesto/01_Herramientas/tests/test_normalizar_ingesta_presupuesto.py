from __future__ import annotations

import importlib.util
import tempfile
import unittest
from pathlib import Path

import openpyxl


SCRIPT = Path(__file__).resolve().parents[1] / "normalizar_ingesta_presupuesto.py"
SPEC = importlib.util.spec_from_file_location("normalizar_ingesta_presupuesto", SCRIPT)
MOD = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(MOD)


def build_workbook(path: Path, broken_resource_link=False):
    wb = openpyxl.Workbook()
    budget = wb.active
    budget.title = "PRESUPUESTO_S10"
    budget.append(["ÍTEM", "DESCRIPCIÓN DE PARTIDA", "UND.", "METRADO", "PRECIO UNIT. (S/)", "IMPORTE (S/)"])
    budget.append(["01.00", "CAPÍTULO", None, None, None, None])
    budget.append(["01.01", "Partida uno", "m2", 2, "='ANALISIS_APU_S10'!G7", "=D3*E3"])

    apu = wb.create_sheet("ANALISIS_APU_S10")
    apu.append(["PARTIDA 01.01: Partida uno"])
    apu.append(["Rendimiento: 10 m2/día"])
    apu.append(["CÓDIGO", "DESCRIPCIÓN", "UNIDAD", "CUADRILLA", "CANTIDAD", "PRECIO", "PARCIAL"])
    apu.append(["MANO DE OBRA"])
    resource_row = 3 if broken_resource_link else 2
    apu.append(["MO-01", "Operario", "h", 1, "=8*D5/10", f"='INSUMOS_RECURSOS_S10'!E{resource_row}", "=E5*F5"])
    apu.append([None])
    apu.append(["COSTO DIRECTO UNITARIO POR M2", None, None, None, None, None, "=SUM(G4:G6)"])

    resources = wb.create_sheet("INSUMOS_RECURSOS_S10")
    resources.append(["CÓDIGO", "DESCRIPCIÓN RECURSO / INSUMO", "UND.", "CANTIDAD TOTAL", "PRECIO UNIT. (S/)", "IMPORTE"])
    resources.append(["MO-01", "Operario", "h", 1.6, 20, "=D2*E2"])
    resources.append(["MO-02", "Capataz", "h", 0, 25, "=D3*E3"])
    wb.save(path)


def build_subpart_workbook(path: Path, *, no_breakdown=False, self_cycle=False, nested=False):
    wb = openpyxl.Workbook()
    budget = wb.active
    budget.title = "PRESUPUESTO_S10"
    budget.append(["ÍTEM", "DESCRIPCIÓN DE PARTIDA", "UND.", "METRADO", "PRECIO UNIT. (S/)", "IMPORTE (S/)"])
    budget.append(["01.01", "Partida con subpartida", "m2", 1, "='ANALISIS_APU_S10'!G8", "=D2*E2"])

    apu = wb.create_sheet("ANALISIS_APU_S10")
    apu.append(["PARTIDA 01.01: Partida con subpartida"])
    apu.append(["Rendimiento: 10 m2/día"])
    apu.append(["CÓDIGO", "DESCRIPCIÓN", "UNIDAD", "CUADRILLA", "CANTIDAD", "PRECIO", "PARCIAL"])
    apu.append(["SUBPARTIDAS"])
    apu.append(["SP-01", "Subpartida uno", "m2", None, 1, "='SUBPARTIDAS_S10'!F7", "=E5*F5"])
    apu.append(["SUBCONTRATOS"])
    apu.append(["SC-01", "Ensayo subcontratado", "glb", None, 1, "='INSUMOS_RECURSOS_S10'!E5", "=E7*F7"])
    apu.append(["COSTO DIRECTO UNITARIO POR M2", None, None, None, None, None, "=SUM(G4:G7)"])

    resources = wb.create_sheet("INSUMOS_RECURSOS_S10")
    resources.append(["CÓDIGO", "DESCRIPCIÓN RECURSO / INSUMO", "UND.", "CANTIDAD TOTAL", "PRECIO UNIT. (S/)", "IMPORTE"])
    resources.append(["MANO DE OBRA"])
    resources.append(["MO-01", "Operario", "h", 0.8, 20, "=D3*E3"])
    resources.append(["SUBCONTRATOS"])
    resources.append(["SC-01", "Ensayo subcontratado", "glb", 1, 50, "=D5*E5"])

    sub = wb.create_sheet("SUBPARTIDAS_S10")
    sub.append(["CÓDIGO", "DESCRIPCIÓN", "UND.", "CANTIDAD", "PRECIO UNIT.", "PARCIAL"])
    if not no_breakdown:
        sub.append(["SUBPARTIDA SP-01: Subpartida uno"])
        sub.append(["Rendimiento: 10 m2/día"])
        sub.append(["CÓDIGO", "DESCRIPCIÓN", "UND.", "CANTIDAD", "PRECIO UNIT.", "PARCIAL"])
        sub.append(["MANO DE OBRA"])
        if self_cycle:
            sub.append(["SP-01", "Subpartida uno", "m2", 1, "='SUBPARTIDAS_S10'!F7", "=D6*E6"])
        elif nested:
            sub.append(["SP-02", "Subpartida dos", "m2", 1, "='SUBPARTIDAS_S10'!F14", "=D6*E6"])
        else:
            sub.append(["MO-01", "Operario", "h", 0.8, "='INSUMOS_RECURSOS_S10'!E3", "=D6*E6"])
        sub.append(["COSTO DIRECTO UNITARIO", None, None, None, None, "=SUM(F5:F6)"])
        if nested:
            sub.append([None])
            sub.append(["SUBPARTIDA SP-02: Subpartida dos"])
            sub.append(["Rendimiento: 10 m2/día"])
            sub.append(["CÓDIGO", "DESCRIPCIÓN", "UND.", "CANTIDAD", "PRECIO UNIT.", "PARCIAL"])
            sub.append(["MANO DE OBRA"])
            sub.append(["MO-01", "Operario", "h", 0.8, "='INSUMOS_RECURSOS_S10'!E3", "=D13*E13"])
            sub.append(["COSTO DIRECTO UNITARIO", None, None, None, None, "=SUM(F12:F13)"])

    listing = wb.create_sheet("LISTADO_SUBPARTIDAS_S10")
    listing.append(["CÓDIGO", "DESCRIPCIÓN", "UND.", "PRECIO UNIT.", "ESTADO"])
    listing.append(["SP-01", "Subpartida uno", "m2", "='SUBPARTIDAS_S10'!F7", "ACTIVA"])
    if nested:
        listing.append(["SP-02", "Subpartida dos", "m2", "='SUBPARTIDAS_S10'!F14", "ACTIVA"])
    wb.save(path)


class NormalizeIngestTest(unittest.TestCase):
    def test_excel_preserves_budget_apu_resource_relationships(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "input.xlsx"
            build_workbook(path)
            result = MOD.normalize(path)
        self.assertEqual(result["validation"]["status"], "PASS")
        self.assertEqual(result["relaciones"]["presupuesto_apu"][0]["apu_number"], 1)
        self.assertEqual(result["relaciones"]["apu_insumo"][0]["resource_number"], 1)
        self.assertEqual(result["relaciones"]["apu_insumo"][0]["source_code"], "MO-01")

    def test_excel_rejects_formula_pointing_to_another_resource_code(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "broken.xlsx"
            build_workbook(path, broken_resource_link=True)
            result = MOD.normalize(path)
        self.assertEqual(result["validation"]["status"], "FAIL")
        self.assertTrue(any("apunta por formula" in message for message in result["validation"]["errors"]))

    def test_excel_distinguishes_subpartida_from_subcontract(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "subpartida.xlsx"
            build_subpart_workbook(path)
            result = MOD.normalize(path)
        self.assertEqual(result["validation"]["status"], "PASS")
        self.assertEqual(len(result["subpartidas"]), 1)
        components = result["apus"][0]["components"]
        self.assertEqual(components[0]["component_kind"], "SUBPARTIDA")
        self.assertEqual(components[1]["component_kind"], "SUBCONTRACT")
        self.assertEqual(len(result["relaciones"]["apu_subpartida"]), 1)
        self.assertEqual(len(result["relaciones"]["subpartida_insumo"]), 1)
        self.assertIn("stg_subpartida_componente", result["sql_staging"]["tables"])

    def test_excel_rejects_subpartida_without_breakdown(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "subpartida_sin_desglose.xlsx"
            build_subpart_workbook(path, no_breakdown=True)
            result = MOD.normalize(path)
        self.assertEqual(result["validation"]["status"], "FAIL")
        self.assertTrue(any("sin desglose" in message for message in result["validation"]["errors"]))

    def test_excel_rejects_subpartida_cycle(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "subpartida_circular.xlsx"
            build_subpart_workbook(path, self_cycle=True)
            result = MOD.normalize(path)
        self.assertEqual(result["validation"]["status"], "FAIL")
        self.assertTrue(any("Ciclo de subpartidas" in message for message in result["validation"]["errors"]))

    def test_excel_accepts_nested_subpartidas_without_cycle(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "subpartidas_anidadas.xlsx"
            build_subpart_workbook(path, nested=True)
            result = MOD.normalize(path)
        self.assertEqual(result["validation"]["status"], "PASS")
        self.assertEqual(len(result["subpartidas"]), 2)
        self.assertEqual(len(result["relaciones"]["subpartida_subpartida"]), 1)

    def test_relational_1_0_is_upgraded_to_1_1(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "input.xlsx"
            build_workbook(path)
            result = MOD.normalize(path)
        result["schema_version"] = "ingesta_presupuesto_relacional/1.0"
        result.pop("subpartidas", None)
        for component in result["apus"][0]["components"]:
            component.pop("component_kind", None)
            component.pop("subpartida_id", None)
            component.pop("subpartida_number", None)
        upgraded = MOD.upgrade_relational(result)
        self.assertEqual(upgraded["schema_version"], MOD.SCHEMA)
        self.assertEqual(upgraded["apus"][0]["components"][0]["component_kind"], "RESOURCE")
        self.assertEqual(MOD.validate_relational(upgraded), [])


if __name__ == "__main__":
    unittest.main()
