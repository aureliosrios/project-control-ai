"""Recorre la cadena de trazabilidad de un ID en el JSON integrado presupuesto + cronograma.

    python trazar_integrado.py <presupuesto_cronograma_integrado.json> <ID>

IDs admitidos: CAP-, PAR-, APU-, CMP-, REC-/HSE-/QA-/TOOLS-, SUB-, ELM-, ACT-, REL-, OBS-.
Muestra hacia atrás (de dónde sale) y hacia adelante (qué alimenta), con las celdas del Excel R02.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    d = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    ident = sys.argv[2].strip()
    par = {p["id"]: p for p in d["partidas"]}
    apu = {a["id"]: a for a in d["apus"]}
    rec = {r["id"]: r for r in d["recursos"]}
    act = {a["id"]: a for a in d["cronograma"]["actividades"]}
    rel = {r["id"]: r for r in d["cronograma"]["relaciones"]}
    cap = {c["id"]: c for c in d["capitulos"]}
    obs = {o["id"]: o for o in d["observaciones"]}
    elem = {e["id"]: (p, s, e) for p in d["partidas"] for s in p["metrado"]["subtotales"] for e in s["elementos"]}
    sub = {s["id"]: (p, s) for p in d["partidas"] for s in p["metrado"]["subtotales"]}
    cmp_ = {c["id"]: (a, c) for a in d["apus"] for c in a["componentes"]}

    def linea(t, v=""):
        print(f"{t:<24}{v}")

    def ver_partida(p):
        e = p["excel_presupuesto"]
        linea("PARTIDA", f'{p["id"]} · {p["descripcion"]} ({p["cantidad"]} {p["unidad"]})')
        linea("  capítulo", f'{p["capitulo_id"]} · {cap[p["capitulo_id"]]["titulo"]}')
        linea("  precio / parcial", f'US$ {p["precio_unitario_usd"]:,.4f} / US$ {p["parcial_usd"]:,.2f}')
        linea("  Excel", f'{e["celda_precio"]} {e["formula_precio"]} · {e["celda_parcial"]} {e["formula_parcial"]}')
        linea("  EETT", f'{p["eett"]["id"]} ({p["eett"]["ancla"]}) · {p["eett"]["ruta_origen"]}')
        linea("  APU", p["apu_id"])
        linea("  metrado", f'{sum(len(s["elementos"]) for s in p["metrado"]["subtotales"])} elementos en {len(p["metrado"]["subtotales"])} subtotales · {p["metrado"]["regla_medicion_y_formula"]}')
        linea("  actividades", f'{len(p["actividad_ids"])} · días {p["cronograma"]["inicio_dia"]}–{p["cronograma"]["fin_dia"]} · crítica={p["cronograma"]["critica"]}')
        if p["observacion_ids"]:
            linea("  observaciones", ", ".join(p["observacion_ids"]))

    def ver_apu(a):
        x = a["excel"]
        linea("APU", f'{a["id"]} · rendimiento {a["rendimiento_diario"]:.4f} {a["unidad_salida"]}/día · costo unitario US$ {a["costo_unitario_directo_usd"]:,.4f}')
        linea("  Excel", f'{x["celda_costo_unitario"]} {x["formula_costo_unitario"]}')
        for c in a["componentes"]:
            ex = c["excel"]["parcial"]["celda"] if c["excel"] else "—"
            linea(f'  {c["id"]}', f'{c["recurso_id"]:<14} {c["cantidad_por_unidad"]:>10.4f} {c["unidad"]:<4} × {c["precio_unitario_usd"]:>9.4f} = {c["parcial_usd"]:>10.4f}  [{ex}]')

    def ver_act(a):
        p = par[a["partida_id"]]
        linea("ACTIVIDAD", f'{a["id"]} · {a["descripcion"]}')
        linea("  partida / APU", f'{a["partida_id"]} / {a["apu_id"]}')
        linea("  metrado", f'{a["metrado"]} {a["unidad"]} ← {a["metrado_fuente"]["elemento_id"]} ({a["metrado_fuente"]["subtotal_id"]}) · base {a["metrado_fuente"]["elemento_base_id"]}')
        linea("  duración", f'{a["duracion"]["formula"]} = {a["duracion"]["exacta_dias"]:.3f} d → {a["duracion"]["programada_dias"]} d')
        linea("  programación", f'días {a["programacion"]["inicio_dia"]}–{a["programacion"]["fin_dia"]} · holgura {a["programacion"]["holgura_total_dias"]} · crítica={a["programacion"]["critica"]}')
        linea("  costo directo", f'US$ {a["costo_directo_usd"]:,.2f}')
        for k, ids in (("  predecesoras", a["predecesora_relacion_ids"]), ("  sucesoras", a["sucesora_relacion_ids"])):
            linea(k, f"{len(ids)}: " + ", ".join(f'{i}→{rel[i]["sucesora_id" if k.endswith("sucesoras") else "predecesora_id"]}[{rel[i]["tipo"]}{rel[i]["desfase_dias"]:+d}]' for i in ids[:6]) + (" …" if len(ids) > 6 else ""))
        print("-- origen en el presupuesto --")
        ver_partida(p)

    if ident in par:
        ver_partida(par[ident])
        print("-- APU --"); ver_apu(apu[par[ident]["apu_id"]])
    elif ident in apu:
        ver_apu(apu[ident]); print("-- partida --"); ver_partida(par[apu[ident]["partida_id"]])
    elif ident in cmp_:
        a, c = cmp_[ident]
        print(json.dumps(c, ensure_ascii=False, indent=1)); print("-- recurso --"); print(json.dumps(rec[c["recurso_id"]], ensure_ascii=False, indent=1))
    elif ident in rec:
        r = rec[ident]
        print(json.dumps(r, ensure_ascii=False, indent=1))
        for aid in r["usado_en_apus"]:
            linea("  usado en", f'{aid} → {apu[aid]["partida_id"]}')
    elif ident in act:
        ver_act(act[ident])
    elif ident in rel:
        r = rel[ident]
        linea("RELACIÓN", f'{r["id"]} · {r["tipo"]} desfase {r["desfase_dias"]} d · {r["motivo"]}')
        for k in ("predecesora_id", "sucesora_id"):
            a = act[r[k]]
            linea(f'  {k[:-3]}', f'{a["id"]} · días {a["programacion"]["inicio_dia"]}–{a["programacion"]["fin_dia"]} · {a["partida_id"]} · {a["descripcion"][:60]}')
    elif ident in elem:
        p, s, e = elem[ident]
        print(json.dumps(e, ensure_ascii=False, indent=1)); linea("  subtotal", s["id"]); ver_partida(p)
        for i in e["actividad_ids"]:
            linea("  actividad", f'{i} · {act[i]["metrado"]} {act[i]["unidad"]} · días {act[i]["programacion"]["inicio_dia"]}–{act[i]["programacion"]["fin_dia"]}')
    elif ident in sub:
        p, s = sub[ident]
        print(json.dumps(s, ensure_ascii=False, indent=1)[:3000]); ver_partida(p)
    elif ident in cap:
        c = cap[ident]
        linea("CAPÍTULO", f'{c["id"]} · {c["titulo"]} · US$ {c["costo_directo_usd"]:,.2f} · {len(c["partida_ids"])} partidas · {len(c["actividad_ids"])} actividades')
        for pid in c["partida_ids"]:
            linea("  " + pid, f'US$ {par[pid]["parcial_usd"]:>12,.2f}  {par[pid]["descripcion"][:70]}')
    elif ident in obs:
        print(json.dumps(obs[ident], ensure_ascii=False, indent=1))
        if obs[ident]["partida_id"]:
            ver_partida(par[obs[ident]["partida_id"]])
    else:
        sys.exit(f"ID no encontrado: {ident}")


if __name__ == "__main__":
    main()
