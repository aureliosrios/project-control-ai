"""Valida trazabilidad numérica, rendimientos y red CPM del cronograma JSON."""
from __future__ import annotations

from collections import defaultdict, deque
from pathlib import Path
import argparse
import hashlib
import json
import math


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha256(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(a, b, tol=1e-8):
    return math.isclose(float(a), float(b), rel_tol=tol, abs_tol=tol)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cronograma", type=Path, required=True)
    parser.add_argument("--metrados", type=Path, required=True)
    parser.add_argument("--presupuesto", type=Path, required=True)
    parser.add_argument("--calendario", type=Path, help="calendario_proyecto.json del usuario; obligatorio si el cronograma tiene fechas")
    parser.add_argument("--salida", type=Path, required=True)
    args = parser.parse_args()

    cron = load(args.cronograma)
    met = load(args.metrados)
    pre = load(args.presupuesto)
    activities = cron["actividades"]
    relations = cron["relaciones"]
    by_id = {a["id"]: a for a in activities}
    met_by = {p["codigo_partida"]: p for p in met["partidas"]}
    pre_by = {p["wbs"]: p for p in pre["partidas"]}
    sch_by = {p["wbs"]: p for p in cron["partidas"]}
    errors, warnings, checks = [], [], []

    def check(name, ok, detail=""):
        checks.append({"control": name, "resultado": "CONFORME" if ok else "NO_CONFORME", "detalle": detail})
        if not ok:
            errors.append(f"{name}: {detail}")

    check("WBS idéntica en metrados, presupuesto y cronograma", set(met_by) == set(pre_by) == set(sch_by),
          f"metrados={len(met_by)}, presupuesto={len(pre_by)}, cronograma={len(sch_by)}")
    check("Identificadores únicos de actividades", len(by_id) == len(activities),
          f"actividades={len(activities)}, ids_unicos={len(by_id)}")

    quantity_issues = []
    yield_issues = []
    summary_issues = []
    source_element_totals = defaultdict(float)
    source_elements = {}
    for wbs, mp in met_by.items():
        for sub in mp["desglose_detallado_por_piso"]:
            for element in sub.get("elementos", []):
                source_elements[(wbs, element["id_elemento"])] = float(element["parcial"])
    grouped = defaultdict(list)
    for a in activities:
        grouped[a["wbs"]].append(a)
        source_id = a["fuente_metrado"]["id_elemento"]
        if a["wbs"] == "13.01" and source_id.endswith(("-V", "-H")):
            source_id = source_id[:-2]
        source_element_totals[(a["wbs"], source_id)] += float(a["metrado"])
        expected_yield = float(pre_by[a["wbs"]]["apu"]["rendimiento_mo"])
        if not close(a["rendimiento_apu_efectivo"], expected_yield):
            yield_issues.append(a["id"])
        exact = float(a["metrado"]) / (expected_yield * int(a["cuadrillas_asignadas_frente"]))
        if not close(a["duracion_productiva_exacta_dias"], exact):
            yield_issues.append(a["id"] + ":duracion")
        if int(a["duracion_programada_dias"]) < 1 or int(a["cuadrillas_asignadas_frente"]) < 1:
            yield_issues.append(a["id"] + ":valor_no_positivo")
    for wbs in sorted(pre_by):
        total = sum(float(a["metrado"]) for a in grouped[wbs])
        expected = float(pre_by[wbs]["cantidad_actualizada"])
        if not close(total, expected):
            quantity_issues.append({"wbs": wbs, "cronograma": total, "presupuesto": expected})
        summary = sch_by[wbs]
        if not close(summary["metrado_total"], total) or not close(summary["rendimiento_apu_efectivo"], pre_by[wbs]["apu"]["rendimiento_mo"]):
            summary_issues.append(wbs)
    element_issues = []
    for key, expected in source_elements.items():
        actual = source_element_totals.get(key)
        if actual is None or not close(actual, expected):
            element_issues.append({"wbs": key[0], "elemento": key[1], "metrado": expected, "cronograma": actual})
    unknown_elements = [list(key) for key in source_element_totals if key not in source_elements]
    check("Metrados por WBS conciliados", not quantity_issues, f"diferencias={len(quantity_issues)}")
    check("Trazabilidad de cada elemento de metrado", not element_issues and not unknown_elements,
          f"diferencias={len(element_issues)}, elementos_desconocidos={len(unknown_elements)}")
    check("Rendimientos APU y fórmula de duración conservados", not yield_issues, f"incidencias={len(yield_issues)}")
    check("Resúmenes por partida conciliados", not summary_issues, f"incidencias={len(summary_issues)}")

    edge_keys = []
    invalid_edges = []
    incoming, outgoing = defaultdict(list), defaultdict(list)
    for edge in relations:
        key = (edge["predecesora"], edge["sucesora"], edge["tipo"], int(edge["desfase_dias"]))
        edge_keys.append(key)
        if edge["predecesora"] not in by_id or edge["sucesora"] not in by_id or edge["tipo"] not in {"FS", "SS"}:
            invalid_edges.append(key)
            continue
        incoming[edge["sucesora"]].append(edge)
        outgoing[edge["predecesora"]].append(edge)
    check("Relaciones válidas y no duplicadas", not invalid_edges and len(edge_keys) == len(set(edge_keys)),
          f"inválidas={len(invalid_edges)}, duplicadas={len(edge_keys)-len(set(edge_keys))}")

    indegree = {activity_id: 0 for activity_id in by_id}
    graph = defaultdict(list)
    for edge in relations:
        if edge["predecesora"] in by_id and edge["sucesora"] in by_id:
            indegree[edge["sucesora"]] += 1
            graph[edge["predecesora"]].append(edge["sucesora"])
    queue = deque(activity_id for activity_id, degree in indegree.items() if degree == 0)
    visited = 0
    while queue:
        node = queue.popleft(); visited += 1
        for successor in graph[node]:
            indegree[successor] -= 1
            if indegree[successor] == 0:
                queue.append(successor)
    check("Red de precedencias acíclica", visited == len(by_id), f"procesadas={visited}/{len(by_id)}")

    timing_issues = []
    for edge in relations:
        pred, succ = by_id[edge["predecesora"]], by_id[edge["sucesora"]]
        pred_start = int(pred["inicio_dia_proyecto"]) - 1
        succ_start = int(succ["inicio_dia_proyecto"]) - 1
        required = pred_start + (int(pred["duracion_programada_dias"]) if edge["tipo"] == "FS" else 0) + int(edge["desfase_dias"])
        if succ_start < required:
            timing_issues.append({"predecesora": pred["id"], "sucesora": succ["id"], "inicio_requerido": required + 1, "inicio": succ_start + 1})
    check("Fechas relativas cumplen todas las relaciones", not timing_issues, f"incidencias={len(timing_issues)}")

    mirror_issues = []
    for activity_id, activity in by_id.items():
        expected_pred = {(e["predecesora"], e["tipo"], int(e["desfase_dias"])) for e in incoming[activity_id]}
        actual_pred = {(e["predecesora"], e["tipo"], int(e["desfase_dias"])) for e in activity["predecesoras"]}
        expected_succ = {(e["sucesora"], e["tipo"], int(e["desfase_dias"])) for e in outgoing[activity_id]}
        actual_succ = {(e["sucesora"], e["tipo"], int(e["desfase_dias"])) for e in activity["sucesoras"]}
        if expected_pred != actual_pred or expected_succ != actual_succ:
            mirror_issues.append(activity_id)
    check("Predecesoras y sucesoras reflejan la tabla de relaciones", not mirror_issues, f"incidencias={len(mirror_issues)}")

    scheduled_finish = max(int(a["fin_dia_proyecto"]) for a in activities)
    check("Duración general conciliada", scheduled_finish == int(cron["resumen"]["fin"]) == int(cron["diagnostico_plazo"]["duracion_calculada_dias_laborables"]),
          f"fin_actividades={scheduled_finish}, fin_resumen={cron['resumen']['fin']}")
    source_hashes = {f["tipo"]: f["sha256"] for f in cron["fuentes"]}
    hashes_ok = source_hashes.get("METRADOS") == sha256(args.metrados) and source_hashes.get("PRESUPUESTO_R02") == sha256(args.presupuesto)
    check("Huellas SHA-256 de fuentes vigentes", hashes_ok, "metrados y presupuesto contrastados")

    if cron.get("calendario", {}).get("fuente") == "USUARIO":
        if not args.calendario:
            check("Calendario del usuario contrastado", False, "falta --calendario")
        else:
            from calendario_proyecto import cargar as cargar_calendario
            from datetime import datetime
            cal = cargar_calendario(args.calendario)
            date_issues = [a["id"] for a in activities
                           if a.get("inicio_fecha") != datetime.combine(cal.fecha_de_dia(int(a["inicio_dia_proyecto"])), cal.hora_inicio).isoformat(timespec="minutes")
                           or a.get("fin_fecha") != datetime.combine(cal.fecha_de_dia(int(a["fin_dia_proyecto"])), cal.hora_fin).isoformat(timespec="minutes")]
            check("Calendario del usuario contrastado", cron["calendario"].get("sha256") == cal.sha256 and not date_issues,
                  f"sha256_coincide={cron['calendario'].get('sha256') == cal.sha256}, fechas_incorrectas={len(date_issues)}")

    if cron["diagnostico_plazo"]["cumple_plazo_objetivo"] is False:
        warnings.append("La programación calculada excede el plazo referencial del presupuesto; requiere replanteo de estrategia, solapes o recursos antes de convertirse en línea base.")
    warnings.extend(cron.get("observaciones", []))
    result = {
        "schema": "verificacion_cronograma/1.0",
        "archivo_verificado": str(args.cronograma),
        "sha256_cronograma": sha256(args.cronograma),
        "dictamen": "CONFORME_PARA_CALIBRACION" if not errors else "NO_CONFORME",
        "controles": checks,
        "resumen": {"controles": len(checks), "conformes": sum(c["resultado"] == "CONFORME" for c in checks), "no_conformes": len(errors), "advertencias": len(warnings)},
        "errores": errors,
        "advertencias": warnings,
        "detalle_incidencias": {"cantidades": quantity_issues, "elementos": element_issues, "elementos_desconocidos": unknown_elements, "rendimientos_o_formulas": yield_issues, "resumenes": summary_issues, "relaciones_temporales": timing_issues, "espejos_relaciones": mirror_issues},
    }
    args.salida.parent.mkdir(parents=True, exist_ok=True)
    args.salida.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result["resumen"] | {"dictamen": result["dictamen"]}, ensure_ascii=True))
    raise SystemExit(0 if not errors else 1)


if __name__ == "__main__":
    main()
