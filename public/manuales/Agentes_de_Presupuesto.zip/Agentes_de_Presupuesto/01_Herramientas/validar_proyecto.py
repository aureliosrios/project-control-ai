"""Revisa rutas activas, cobertura WBS/metrado/EETT y archivos de evidencia."""
from pathlib import Path
import argparse,json,hashlib,zipfile,importlib.util
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def audit(p,archive=False):
 p=p.resolve();m=read(p/'proyecto.json');errors=[];warnings=[]
 for key,v in {**m['entradas'],**m.get('entregables',{})}.items():
  if key.startswith('hash'):continue
  target=(p/v).resolve()
  if not target.is_relative_to(p):errors.append('Ruta fuera de proyecto: '+key)
  elif not target.exists():errors.append('Falta archivo o carpeta: '+v)
 if errors:return {'errores':errors,'avisos':warnings}
 wbs=read(p/m['entradas']['wbs']);codes=[x['codigo'] for cap in wbs['capitulos'] for x in cap['partidas']]
 met=read(p/m['entradas']['metrados']);ms=[x['codigo_partida'] for x in met['partidas']]
 eett=read(p/m['entradas']['eett_indice']);es=[x.get('wbs') or x.get('codigo_partida') for x in eett['partidas']]
 if not codes:
  errors.append('Proyecto sin partidas; completar datos antes de calcular')
  return dict(proyecto=m['codigo'],errores=errors,avisos=warnings,partidas=0,strict_conforme=False)
 if len(set(codes))!=len(codes) or set(codes)!=set(ms) or set(codes)!=set(es):errors.append('Cobertura WBS/metrado/EETT inconsistente')
 metmap={x['codigo_partida']:x for x in met['partidas']}
 for cap in wbs['capitulos']:
  for item in cap['partidas']:
   row=metmap.get(item['codigo'])
   if row and (item['unidad']!=row['unidad'] or abs(float(item['cantidad'])-float(row['cantidad']))>.000001):errors.append('Cantidad/unidad WBS y metrado difieren: '+item['codigo'])
 if 'resolver' in m['entradas']:
  resolver=read(p/m['entradas']['resolver']);zips={}
  for source,ref in resolver['rutas'].items():
   if 'archivo_zip' in ref:
    z=p/ref['archivo_zip']
    if not z.is_file():errors.append('Falta ZIP '+str(z));continue
    if archive:
     if z not in zips:zips[z]=zipfile.ZipFile(z)
     content=zips[z].read(ref['entrada_zip'])
     if hashlib.sha256(content).hexdigest()!=ref['sha256_original']:errors.append('Hash de archivo original no coincide: '+source)
   if ref.get('archivo_activo') and not (p/ref['archivo_activo'].split('#')[0]).is_file():errors.append('Destino activo ausente: '+source)
  for z in zips.values():z.close()
 hashpath=p/'05_Trazabilidad/manifest_archivos.json'
 if hashpath.exists():
  for ref in read(hashpath)['archivos']:
   target=p/ref['ruta']
   if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=ref['sha256']:errors.append('Hash activo no coincide: '+ref['ruta'])
 core=Path(__file__).resolve().parents[1]/'00_NUCLEO_DETERMINISTA/scripts/budget_engine.py';spec=importlib.util.spec_from_file_location('budget_engine',core);eng=importlib.util.module_from_spec(spec);spec.loader.exec_module(eng)
 data=read(p/m['entradas']['canonico']);de,dw=eng.validate(data,'draft');se,sw=eng.validate(data,'strict');errors+=de;warnings+=dw
 total=eng.plain(eng.calculate(data))['summary']['grand_total'] if not de else None
 if m.get('total_provisional') is not None and total is not None and abs(total-m['total_provisional'])>.01:errors.append('Total del núcleo no coincide con proyecto.json')
 return dict(proyecto=m['codigo'],errores=errors,avisos=warnings,partidas=len(codes),total_calculado=total,strict_conforme=not se,strict_errores=len(se),nota='Integridad documental y cálculo; no acredita aprobación técnica ni validación de todos los precios.')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--proyecto',required=True);a.add_argument('--verificar-archivos',action='store_true');v=a.parse_args();r=audit(Path(v.proyecto),v.verificar_archivos);print(json.dumps(r,ensure_ascii=True,indent=2));raise SystemExit(bool(r['errores']))

