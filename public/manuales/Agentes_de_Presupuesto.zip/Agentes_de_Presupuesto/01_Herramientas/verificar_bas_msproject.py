"""Prueba un .bas generado en MS Project real y lo contrasta con el cronograma JSON.

Abre una instancia propia de MS Project (no toca los archivos del usuario), crea un
proyecto en blanco, importa el módulo, ejecuta ``ConstruirCronogramaSilencioso`` y compara
título, calendario, inicio, fin, duración y las fechas de cada actividad con el JSON.
Actualiza la verificación que emitió ``generar_vba_msproject.py``:

- CONFORME_PARA_IMPORTAR: MS Project reproduce exactamente el JSON.
- NO_CONFORME: hay diferencias (se listan).
- NO_VERIFICADO: no se pudo ejecutar MS Project o el acceso al proyecto VBA está bloqueado.
  Esa opción de seguridad ("Confiar en el acceso al modelo de objetos de proyectos de VBA")
  la decide y activa el usuario; esta herramienta no la cambia.

Modo seguimiento (la verificación registra ``seguimiento``, es decir el .bas se generó con
``--seguimiento``): la línea base debe reproducir el plan del JSON (fechas y duración de cada
actividad), y además se comprueban tipo de tarea (duración fija), no conducida por esfuerzo,
jerarquía capítulo/partida, vínculos (predecesora, sucesora, tipo y desfase), fecha de estado,
inicio real, fin real, % completado y atraso de inicio contra ``seguimiento_real.json``.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime
from pathlib import Path
import argparse
import json
import time

TIPOS_VINCULO = {0: "FF", 1: "FS", 2: "SF", 3: "SS"}


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def as_naive(value) -> datetime:
    return datetime(value.year, value.month, value.day, value.hour, value.minute)


def fecha_o_none(value):
    """Las fechas sin asignar de MS Project vuelven como texto ('NA') o None."""
    if value is None or isinstance(value, str):
        return None
    return as_naive(value).isoformat(timespec="minutes")


def comparar_plan_vs_json(task, activity, differences):
    start = as_naive(task.Start).isoformat(timespec="minutes")
    finish = as_naive(task.Finish).isoformat(timespec="minutes")
    if start != activity["inicio_fecha"] or finish != activity["fin_fecha"]:
        differences.append(f"{task.Text1}: MS Project {start} -> {finish}; JSON {activity['inicio_fecha']} -> {activity['fin_fecha']}")


def comparar_seguimiento(task, activity, tracking, cal, minutes_day, ok, differences):
    """Línea base = plan; tipo/esfuerzo; avance real = reportes."""
    b_start = fecha_o_none(task.BaselineStart)
    b_finish = fecha_o_none(task.BaselineFinish)
    if b_start != activity["inicio_fecha"] or b_finish != activity["fin_fecha"]:
        differences.append(f"{task.Text1}: línea base {b_start} -> {b_finish}; plan JSON {activity['inicio_fecha']} -> {activity['fin_fecha']}")
    else:
        ok["linea_base_fechas"] += 1
    if abs(task.BaselineDuration / minutes_day - activity["duracion_programada_dias"]) < 0.001:
        ok["linea_base_duracion"] += 1
    else:
        differences.append(f"{task.Text1}: duración base {task.BaselineDuration / minutes_day} != {activity['duracion_programada_dias']}")
    if task.Type == 1:  # pjFixedDuration
        ok["tipo_duracion_fija"] += 1
    else:
        differences.append(f"{task.Text1}: tipo de tarea {task.Type} (esperado 1 = duración fija)")
    if not task.EffortDriven:
        ok["no_conducida_por_esfuerzo"] += 1
    else:
        differences.append(f"{task.Text1}: conducida por esfuerzo")

    real = tracking["actividades"].get(task.Text1)
    if real is None:
        if fecha_o_none(task.ActualStart) is None and task.PercentComplete == 0:
            ok["sin_reporte_sin_avance"] += 1
        else:
            differences.append(f"{task.Text1}: sin reporte pero tiene avance real")
        return
    exp_start = f"{real['inicio_real']}T{cal['hora_inicio']}" if real.get("inicio_real") else None
    exp_fin = f"{real['fin_real']}T{cal['hora_fin']}" if real.get("fin_real") else None
    got_start, got_fin = fecha_o_none(task.ActualStart), fecha_o_none(task.ActualFinish)
    if got_start == exp_start:
        ok["inicio_real"] += 1
    else:
        differences.append(f"{task.Text1}: inicio real MS Project {got_start}; reportes {exp_start}")
    if got_fin == exp_fin:
        ok["fin_real"] += 1
    else:
        differences.append(f"{task.Text1}: fin real MS Project {got_fin}; reportes {exp_fin}")
    expected_pct = real["pct_msproject"] if real.get("inicio_real") else 0
    if task.PercentComplete == expected_pct:
        ok["porcentaje_completado"] += 1
    else:
        differences.append(f"{task.Text1}: % completado MS Project {task.PercentComplete}; reportes {expected_pct}")
    atraso = real.get("atraso_inicio_dias")
    if atraso is not None and abs(float(task.Number5 or 0) - atraso) < 1e-9:
        ok["atraso_inicio"] += 1
    else:
        differences.append(f"{task.Text1}: atraso de inicio {task.Number5}; reportes {atraso}")
    if (task.Text10 or "") == (real.get("estado") or ""):
        ok["estado_reporte"] += 1
    else:
        differences.append(f"{task.Text1}: estado {task.Text10!r}; reportes {real.get('estado')!r}")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--bas", type=Path, required=True)
    parser.add_argument("--cronograma", type=Path, required=True)
    parser.add_argument("--verificacion", type=Path, required=True, help="JSON emitido por generar_vba_msproject.py; se actualiza")
    parser.add_argument("--seguimiento", type=Path, help="seguimiento_real.json (por defecto, el que registra la verificación del .bas)")
    parser.add_argument("--guardar-mpp", type=Path, help="opcional: guarda el resultado de la prueba como .mpp")
    parser.add_argument("--visible", action="store_true", help="muestra la ventana de MS Project durante la prueba")
    args = parser.parse_args()

    verification = load(args.verificacion)
    schedule = load(args.cronograma)
    expected = verification["esperado"]
    cal = verification["calendario"]
    tracking = None
    if verification.get("seguimiento"):
        tracking = load(args.seguimiento or Path(verification["seguimiento"]["archivo"]))
    result = {"fecha": datetime.now().isoformat(timespec="seconds"), "macro": "ConstruirCronogramaSilencioso"}
    differences: list[str] = []
    app = None
    try:
        import win32com.client  # pywin32
        app = win32com.client.DispatchEx("MSProject.Application")
        app.DisplayAlerts = False
        app.Visible = bool(args.visible)
        app.FileNew()
        project = app.ActiveProject
        try:
            component = project.VBProject.VBComponents.Import(str(args.bas.resolve()))
        except Exception as exc:  # acceso al modelo de objetos VBA desactivado
            raise RuntimeError("Acceso al proyecto VBA bloqueado en MS Project (Centro de confianza > Configuración de macros > "
                               f"Confiar en el acceso al modelo de objetos de proyectos de VBA): {exc}") from exc
        started = time.time()
        app.Macro(f"{component.Name}.ConstruirCronogramaSilencioso")
        result["segundos"] = round(time.time() - started, 1)

        project = app.ActiveProject
        summary = project.ProjectSummaryTask
        minutes_day = project.HoursPerDay * 60
        result.update({
            "titulo": summary.Name,
            "calendario": project.Calendar.Name,
            "inicio": as_naive(project.ProjectStart).isoformat(timespec="minutes"),
            "fin": as_naive(project.ProjectFinish).isoformat(timespec="minutes"),
            "duracion_dias_laborables": round(summary.Duration / minutes_day, 2) if minutes_day else None,
            "horas_dia": project.HoursPerDay,
            "horas_semana": project.HoursPerWeek,
            "dias_por_mes": project.DaysPerMonth,
        })
        by_id = {a["id"]: a for a in schedule["actividades"]}
        seen = set()
        links = 0
        ok = Counter()
        summaries = Counter()
        tipos_tarea = Counter()
        for task in project.Tasks:
            if task is None:
                continue
            if task.Summary:
                summaries["capitulos" if task.OutlineLevel == 1 else "partidas"] += 1
                continue
            activity = by_id.get(task.Text1)
            if activity is None:
                differences.append(f"Tarea sin correspondencia en el JSON: {task.Name}")
                continue
            seen.add(task.Text1)
            links += task.PredecessorTasks.Count
            tipos_tarea[task.Type] += 1
            if tracking:
                comparar_seguimiento(task, activity, tracking, cal, minutes_day, ok, differences)
            else:
                comparar_plan_vs_json(task, activity, differences)

        result["actividades"] = len(seen)
        result["actividades_con_fecha_distinta"] = sum(1 for d in differences if "MS Project" in d)
        missing = set(by_id) - seen
        if missing:
            differences.append(f"Actividades del JSON que no se crearon: {len(missing)}")

        if tracking:
            found = set()
            for task in project.Tasks:
                if task is None or task.Summary:
                    continue
                for dep in task.TaskDependencies:
                    if dep.To.ID == task.ID:
                        found.add((dep.From.Text1, task.Text1, TIPOS_VINCULO[dep.Type], round(dep.Lag / minutes_day, 4)))
            expected_links = {(r["predecesora"], r["sucesora"], r["tipo"], round(float(r["desfase_dias"]), 4))
                              for r in schedule["relaciones"]}
            result["vinculos_msproject"] = len(found)
            result["vinculos_json"] = len(expected_links)
            result["vinculos_por_tipo"] = dict(Counter(l[2] for l in found))
            result["vinculos_con_desfase"] = sum(1 for l in found if l[3] != 0)
            if found != expected_links:
                differences.append(f"Vínculos: faltan {len(expected_links - found)}, sobran {len(found - expected_links)}")
            result["jerarquia"] = dict(summaries)
            if summaries["capitulos"] != schedule["resumen"]["capitulos"] or summaries["partidas"] != schedule["resumen"]["partidas"]:
                differences.append(f"Jerarquía {dict(summaries)}; JSON capítulos {schedule['resumen']['capitulos']} partidas {schedule['resumen']['partidas']}")
            result["tipo_tarea_actividades"] = {("duracion_fija" if k == 1 else str(k)): v for k, v in tipos_tarea.items()}
            result["comprobaciones_ok"] = dict(ok)
            esperadas = {"linea_base_fechas": len(by_id), "linea_base_duracion": len(by_id),
                         "tipo_duracion_fija": len(by_id), "no_conducida_por_esfuerzo": len(by_id)}
            for clave, valor in esperadas.items():
                if ok[clave] != valor:
                    differences.append(f"{clave}: {ok[clave]} de {valor}")
            result["linea_base_proyecto"] = {
                "inicio": as_naive(summary.BaselineStart).isoformat(timespec="minutes"),
                "fin": as_naive(summary.BaselineFinish).isoformat(timespec="minutes"),
                "duracion_dias": round(summary.BaselineDuration / minutes_day, 2)}
            result["fecha_estado"] = fecha_o_none(project.StatusDate)
            result["fin_con_avance_real"] = result["fin"]
            result["actividades_con_inicio_real"] = ok["inicio_real"] and sum(1 for r in tracking["actividades"].values() if r.get("inicio_real"))
            result["actividades_con_fin_real"] = sum(1 for r in tracking["actividades"].values() if r.get("fin_real"))
            if (result["fecha_estado"] or "")[:10] != tracking["fecha_estado"]:
                differences.append(f"fecha de estado {result['fecha_estado']}; reportes {tracking['fecha_estado']}")
            fin_ok = result["linea_base_proyecto"]["fin"] == expected["fin"]
            dur_ok = result["linea_base_proyecto"]["duracion_dias"] == expected["duracion_dias_laborables"]
        else:
            fin_ok = result["fin"] == expected["fin"]
            dur_ok = result["duracion_dias_laborables"] == expected["duracion_dias_laborables"]

        checks = {
            "titulo": result["titulo"] == expected["titulo"],
            "calendario": result["calendario"] == cal["nombre_calendario"],
            "inicio": result["inicio"] == expected["inicio"],
            "fin": fin_ok,
            "duracion": dur_ok,
            "horas_semana": abs(result["horas_semana"] - cal["jornada_horas"] * cal["dias_laborables_semana"]) < 0.01,
            "dias_por_mes": result["dias_por_mes"] == cal["dias_laborables_mes"],
        }
        for name, passed in checks.items():
            if not passed:
                differences.append(f"{name}: MS Project {result.get(name, result.get('duracion_dias_laborables'))!r}; esperado {expected.get(name, '(ver calendario)')!r}")
        if args.guardar_mpp:
            app.FileSaveAs(str(args.guardar_mpp.resolve()))
        app.FileCloseEx(0)
        dictamen = "CONFORME_PARA_IMPORTAR" if not differences else "NO_CONFORME"
    except Exception as exc:
        result["error"] = str(exc)
        dictamen = "NO_VERIFICADO"
    finally:
        if app is not None:
            try:
                app.Quit(0)
            except Exception:
                pass

    result["diferencias"] = differences[:50]
    result["total_diferencias"] = len(differences)
    verification["prueba_ms_project"] = result
    verification["dictamen"] = dictamen
    args.verificacion.write_text(json.dumps(verification, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"dictamen": dictamen, **{k: result.get(k) for k in ("segundos", "inicio", "fin", "duracion_dias_laborables", "total_diferencias", "error")}}, ensure_ascii=True))
    raise SystemExit(0 if dictamen == "CONFORME_PARA_IMPORTAR" else 1)


if __name__ == "__main__":
    main()
