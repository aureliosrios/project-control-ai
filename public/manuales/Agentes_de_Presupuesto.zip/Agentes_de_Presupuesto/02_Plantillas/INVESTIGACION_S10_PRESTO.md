# Presentaciones S10 y Presto — consulta 05/10/2026

## Evidencia y límites

[S10 Presupuestos](https://www.s10peru.com/presupuestos/) confirma títulos, partidas, recursos, APU, análisis de subpartidas, pie de presupuesto, gastos generales y fórmula polinómica. La página no publica un estándar de fuente, RGB o dimensiones Excel. El [manual oficial S10](https://documentacion.s10peru.com/manual-de-presupuestos/) exige iniciar sesión: no se obtuvo su contenido protegido.

El [manual oficial Presto](https://www.rib-software.es/pdf/Usar-Presto/Manual-de-Presto-completo.pdf), páginas 4, 21–22 y 27, indica colores personalizables, plantillas Excel, informes modificables e importación de archivos Excel S10. El [centro de recursos](https://www.rib-software.com/es/recursos-clientes/presto) distingue informes de presupuesto y mediciones, descompuestos y cuadro de precios 1. [Presto Presupuestos](https://www.rib-software.com/es/rib-presto/presupuestos) presenta Excel2Presto. Esto no prueba que los Excel de este generador sean importables sin configuración.

No existe evidencia pública consultada de una lista obligatoria universal de pestañas, tamaños o RGB. Los nombres de hojas son un contrato local que organiza reportes y conserva el cálculo. No se han copiado plantillas propietarias ni generado formatos nativos S10/.Presto.

## Decisiones reproducibles de diseño

S10: estilo de informe minimalista, blanco/negro, capítulos gris claro; Arial 10 pt, filas 30 pt. Presto: Arial 10 pt, secciones gris claro y cabeceras azul grisáceo. Estos parámetros son aproximaciones editables, no medidas oficiales verificadas. Anchos Excel del presupuesto A:G: 3, 13, 78, 9, 17, 18 y 20 unidades de carácter. Impresión A4 horizontal, una página de ancho y varias de alto; los informes extensos conservan su detalle.

## Contrato de hojas

S10: DATOS_GENERALES_S10, PRESUPUESTO_S10, ANALISIS_APU_S10, INSUMOS_RECURSOS_S10, GASTOS_GENERALES_S10, SUBPARTIDAS_S10 y LISTADO_SUBPARTIDAS_S10.

Presto: DATOS_GENERALES_PRESTO, PRESUPUESTO_Y_MEDICIONES, CUADRO_PRECIOS_1, DESCOMPOSICION_APU, LISTADO_DE_CONCEPTOS, COSTES_INDIRECTOS, DESCOMP_SUBPARTIDAS y LISTADO_SUBPARTIDAS.

Ambos conservan METRADOS_TRAZABLES, TRAZABILIDAD_REVISION, OBSERVACIONES, COMPARATIVO, CONFIG_HSE_QA, FACTORES_HSE_QA, APOYO_HSE_QA y COMPARATIVO_R02. Subpartidas no equivale a desgloses de metrado: sólo se presenta una descomposición identificada expresamente como subpartida. La R02 no declara esos bloques; sus hojas explican la ausencia.

## Código y ejecución

Contrato JSON común, generador Python, entrada JavaScript MJS y adaptador JS. MJS delega el cálculo al mismo Python para evitar divergencias; no es un segundo motor económico. `plantilla_microsoft_excel.ts` es un Office Script de formato para una copia en Excel web; requiere pegarlo en Automatizar y no reemplaza el generador completo ni ha sido ejecutado en Excel web.

BAT por formato en R02_Vigente; usa Python de dependencias y Microsoft Excel instalado para recalcular. `PRESUPUESTO_PYTHON` permite configurar otra instalación con openpyxl. Las salidas se guardan en directorios fechados, sin alterar el maestro. El recálculo es oculto, sin simulación de teclado.

La presentación redefine estilos y reglas extendidas de formato condicional originales pueden ser retiradas por openpyxl; se conservan valores y fórmulas verificadas. La R02 sigue observada y no se valida como presupuesto definitivo ni se reemplazan sus precios o metrados. Para proyecto nuevo: entrada canónica, validación draft/strict y controles del núcleo antes de crear el maestro.

## Excel S10 desde JSON (14/10/2026)

Generador: Agentes_de_Presupuesto/01_Herramientas/generar_excel_s10_desde_json.py --json-dir <03_BASE_DATOS_JSON> --salida <xlsx>. Layout alineado al lector s10_nativo (col. A separadora, contenido desde B; items 01/01.01/01.01.01; APU con 'Partida:', 'Rendimiento MO.', secciones y columnas Código-Descripción-Und-Cuadrilla-Cantidad-Precio-Parcial; pie CD/GG/Utilidad/Subtotal/IGV/Total/SON). Requiere jerarquia_wbs.json y datos_generales.json junto a los JSON. Recalcular con Excel antes de entregar.
