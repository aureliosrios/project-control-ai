// Adaptador JS puro. Las medidas son decisiones reproducibles, no especificaciones oficiales.
export function planFormato(config, tipo, moneda = 'USD') {
  if (!['s10', 'presto'].includes(tipo)) throw new Error('Formato desconocido');
  const p = config[tipo];
  return { ...p, currency: moneda, currencyFormat: moneda === 'USD' ? '"US$" #,##0.00' : '#,##0.00', freezePanes: false, paper: 'A4', orientation: 'landscape',
    state: 'BORRADOR_OBSERVADO', budget: tipo === 's10' ? 'PRESUPUESTO_S10' : 'PRESUPUESTO_Y_MEDICIONES' };
}
