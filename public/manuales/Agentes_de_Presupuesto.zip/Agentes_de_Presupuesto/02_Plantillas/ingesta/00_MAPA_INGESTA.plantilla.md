# Mapa de ingesta

Copiar este archivo a `Proyectos/<codigo>/01_Entrada_Minima/00_MAPA_INGESTA.md` y completarlo.
Toda la información de entrada va en archivos Markdown (`.md`). El usuario decide cuántas carpetas hay y cómo se llaman;
este mapa le dice al agente qué contiene cada una.

Roles válidos (una carpeta puede tener varios, separados por coma):
`DATOS_GENERALES`, `ALCANCE`, `WBS`, `METRADOS`, `EETT`, `PRECIOS`, `PROCEDIMIENTOS`, `PLAZO_CALENDARIO`, `GASTOS_GENERALES`, `OTROS`.

La ingesta puede ser mínima. Lo que falte lo completa el agente con supuestos y los informa al final
(hoja `SUPUESTOS` del Excel e informe `supuestos_<revision>.md`).

| Carpeta | Rol | Descripción |
|---|---|---|
| 01_ejemplo_datos | DATOS_GENERALES, ALCANCE | Datos del proyecto y alcance |
| 02_ejemplo_metrados | WBS, METRADOS | Partidas y mediciones |
| 03_ejemplo_eett | EETT | Especificaciones técnicas por partida |

## Datos del calendario (el agente los pregunta; no los supone)

- Fecha de inicio:
- Días laborables por semana:
- Jornada (horas) y refrigerio:
- Feriados o días no laborables:
- Días por mes:
