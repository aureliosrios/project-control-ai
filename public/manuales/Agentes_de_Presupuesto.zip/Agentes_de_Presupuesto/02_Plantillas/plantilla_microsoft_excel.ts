/** Office Script: ejecutar únicamente en una COPIA del maestro. Renombra fórmulas
 * explícitamente y aplica la presentación Microsoft Excel; no inventa datos.
 * El generador PY/MJS es el flujo completo con verificación y manifiesto.
 */
function main(workbook: ExcelScript.Workbook, formato: string = 's10') {
  if (formato !== 's10' && formato !== 'presto') throw new Error('Usar s10 o presto');
  const names: { [key: string]: string } = formato === 'presto' ? {
    DATOS_GENERALES_S10: 'DATOS_GENERALES_PRESTO', PRESUPUESTO_S10: 'PRESUPUESTO_Y_MEDICIONES',
    ANALISIS_APU_S10: 'DESCOMPOSICION_APU', INSUMOS_RECURSOS_S10: 'LISTADO_DE_CONCEPTOS',
    GASTOS_GENERALES_S10: 'COSTES_INDIRECTOS', SUBPARTIDAS_S10: 'DESCOMP_SUBPARTIDAS',
    LISTADO_SUBPARTIDAS_S10: 'LISTADO_SUBPARTIDAS'
  } : {
    DATOS_GENERALES_PRESTO: 'DATOS_GENERALES_S10', PRESUPUESTO_Y_MEDICIONES: 'PRESUPUESTO_S10',
    DESCOMPOSICION_APU: 'ANALISIS_APU_S10', LISTADO_DE_CONCEPTOS: 'INSUMOS_RECURSOS_S10',
    COSTES_INDIRECTOS: 'GASTOS_GENERALES_S10', DESCOMPOSICION_SUBPARTIDAS: 'SUBPARTIDAS_S10',
    LISTADO_DE_SUBPARTIDAS: 'LISTADO_SUBPARTIDAS_S10'
  };
  // Excel actualiza automáticamente referencias al renombrar las hojas.
  for (const old of Object.keys(names)) {
    const sheet = workbook.getWorksheet(old);
    if (sheet && !workbook.getWorksheet(names[old])) sheet.setName(names[old]);
  }
  if (formato === 's10') ensureGastosGeneralesS10(workbook);
  for (const sheet of workbook.getWorksheets()) {
    sheet.getFreezePanes().unfreeze();
    const range = sheet.getUsedRange();
    if (!range) continue;
    sheet.setShowGridlines(false);
    const style = range.getFormat();
    style.getFont().setName('Arial'); style.getFont().setSize(10);
    style.setRowHeight(30); style.setWrapText(true);
    const first = range.getRow(0);
    first.getFormat().getFont().setBold(true);
    first.getFormat().getFill().setColor(formato === 's10' ? '#FFFFFF' : '#E7EDF4');
    first.getFormat().getFont().setColor(formato === 's10' ? '#000000' : '#193B60');
  }
  const budget = workbook.getWorksheet(formato === 's10' ? 'PRESUPUESTO_S10' : 'PRESUPUESTO_Y_MEDICIONES');
  if (!budget) throw new Error('Falta presupuesto maestro');
  budget.getRange('A1').setValue('PRESUPUESTO ' + formato.toUpperCase() + ' — BORRADOR REFERENCIAL');
  const widths = [22, 91, 546, 63, 119, 126, 140];
  for (let i = 0; i < widths.length; i++) budget.getRangeByIndexes(0, i, 1, 1).getEntireColumn().getFormat().setColumnWidth(widths[i]);
  const firstSheet = workbook.getWorksheet(formato === 's10' ? 'DATOS_GENERALES_S10' : 'DATOS_GENERALES_PRESTO');
  if (firstSheet) firstSheet.setPosition(0);
  workbook.getApplication().calculate(ExcelScript.CalculationType.fullRebuild);
}

function ensureGastosGeneralesS10(workbook: ExcelScript.Workbook) {
  if (workbook.getWorksheet('GASTOS_GENERALES_S10')) return;
  const datos = workbook.getWorksheet('DATOS_GENERALES_S10');
  const presupuesto = workbook.getWorksheet('PRESUPUESTO_S10');
  if (!datos || !presupuesto) throw new Error('No se puede crear GASTOS_GENERALES_S10: faltan DATOS_GENERALES_S10 o PRESUPUESTO_S10');
  const gg = workbook.addWorksheet('GASTOS_GENERALES_S10');
  gg.getRange('A1:C1').merge();
  gg.getRange('A1').setValue('GASTOS GENERALES — S10 — BORRADOR REFERENCIAL');
  gg.getRange('A3:C3').setValues([['CONCEPTO', 'VALOR', 'BASE / FUENTE']]);
  gg.getRange('A4:C10').setValues([
    ['Costo directo', '', 'PRESUPUESTO_S10'],
    ['Tasa de gastos generales fijos (GGF)', '', 'DATOS_GENERALES_S10'],
    ['Monto de gastos generales fijos (GGF)', '', 'Costo directo × tasa GGF'],
    ['Tasa de gastos generales variables (GGV)', '', 'DATOS_GENERALES_S10'],
    ['Monto de gastos generales variables (GGV)', '', 'Costo directo × tasa GGV'],
    ['Total de gastos generales', '', 'GGF + GGV'],
    ['Estado del desglose analítico', 'PENDIENTE', 'La fuente sólo proporciona tasas globales; no se fabrican partidas de GG.']
  ]);
  gg.getRange('B4').setFormula('=PRESUPUESTO_S10!F654');
  gg.getRange('B5').setFormula('=DATOS_GENERALES_S10!B6');
  gg.getRange('B6').setFormula('=B4*B5');
  gg.getRange('B7').setFormula('=DATOS_GENERALES_S10!B7');
  gg.getRange('B8').setFormula('=B4*B7');
  gg.getRange('B9').setFormula('=B6+B8');
  gg.getRange('B4:B10').getFormat().setHorizontalAlignment(ExcelScript.HorizontalAlignment.right);
  gg.getRange('B4').setNumberFormatLocal('S/ #,##0.00');
  gg.getRange('B5').setNumberFormat('0.00%');
  gg.getRange('B6').setNumberFormatLocal('S/ #,##0.00');
  gg.getRange('B7').setNumberFormat('0.00%');
  gg.getRange('B8:B9').setNumberFormatLocal('S/ #,##0.00');
}
