param([ValidateSet('audit','validate','build','verify')][string]$Action='validate',[string]$Proyecto='',[Alias('Input')][string]$InputFile='',[string]$OutputDir='',[ValidateSet('draft','strict')][string]$Mode='strict',[string]$Json='',[string]$Xlsx='')
& (Join-Path $PSScriptRoot 'EJECUTAR_PRESUPUESTO_TRAZABLE.ps1') @PSBoundParameters -Format s10
exit $LASTEXITCODE
