param(
 [ValidateSet('audit','validate','build','verify')][string]$Action='validate',
 [string]$Proyecto='', [Alias('Input')][string]$InputFile='', [string]$OutputDir='',
 [ValidateSet('draft','strict')][string]$Mode='strict',
 [ValidateSet('s10','presto')][string]$Format='s10', [string]$Json='', [string]$Xlsx=''
)
$ErrorActionPreference='Stop'
$CorePath=Join-Path $PSScriptRoot '00_NUCLEO_DETERMINISTA'
$RuntimeRoot=Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies'
$CodexPython=Join-Path $RuntimeRoot 'python\python.exe'
$PythonPath=if($env:CODEX_BUDGET_PYTHON){$env:CODEX_BUDGET_PYTHON}elseif(Test-Path -LiteralPath $CodexPython){$CodexPython}else{(Get-Command python -ErrorAction SilentlyContinue).Source}
if(-not $PythonPath -or -not(Test-Path -LiteralPath $PythonPath)){throw 'Cargar dependencias o definir CODEX_BUDGET_PYTHON con un Python disponible.'}
if(-not $env:CODEX_BUDGET_NODE){$CodexNode=Join-Path $RuntimeRoot 'node\bin\node.exe';if(Test-Path -LiteralPath $CodexNode){$env:CODEX_BUDGET_NODE=$CodexNode}else{$n=Get-Command node -ErrorAction SilentlyContinue;if($n){$env:CODEX_BUDGET_NODE=$n.Source}}}
if($Proyecto){
 $ProjectRoot=(Resolve-Path -LiteralPath $Proyecto).Path
 $Manifest=Get-Content -LiteralPath (Join-Path $ProjectRoot 'proyecto.json') -Raw | ConvertFrom-Json
 if(-not $InputFile){$InputFile=Join-Path $ProjectRoot $Manifest.entradas.canonico}
}
if($Action -eq 'audit'){
 if(-not $Proyecto){throw 'audit requiere -Proyecto con la carpeta del proyecto.'}
 & $PythonPath (Join-Path $PSScriptRoot '01_Herramientas\validar_proyecto.py') --proyecto $ProjectRoot --verificar-archivos
 exit $LASTEXITCODE
}
if($Action -eq 'verify'){
 if(-not $Json -or -not $Xlsx){throw 'verify requiere -Json budget_result.json y -Xlsx budget_live.xlsx del mismo build. Para revisar la organización usar audit.'}
 & $PythonPath (Join-Path $CorePath 'scripts\budget_engine.py') verify --json $Json --xlsx $Xlsx
 exit $LASTEXITCODE
}
if(-not $InputFile -or -not(Test-Path -LiteralPath $InputFile)){throw 'Indicar -Proyecto o -Input existente. No se infieren entradas de carpetas históricas.'}
if($Action -eq 'validate'){
 & $PythonPath (Join-Path $CorePath 'scripts\budget_engine.py') validate --input $InputFile --mode $Mode
}else{
 if(-not $OutputDir){throw 'build requiere -OutputDir para una nueva revisión; no sobrescribir R02 vigente.'}
 if(Test-Path -LiteralPath $OutputDir){if(Get-ChildItem -LiteralPath $OutputDir -Force | Select-Object -First 1){throw 'La salida debe estar vacía para conservar las revisiones existentes.'}}
 if(-not(Test-Path -LiteralPath (Join-Path $CorePath 'node_modules\@oai\artifact-tool'))){& (Join-Path $CorePath 'setup_runtime.ps1')}
 & $PythonPath (Join-Path $CorePath 'scripts\budget_engine.py') build --input $InputFile --output-dir $OutputDir --mode $Mode --format $Format
}
exit $LASTEXITCODE
