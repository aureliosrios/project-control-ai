# Agente reutilizable de presupuestos

Las herramientas son independientes de la obra. Los datos están en ../Proyectos/<codigo>/ y se declaran en proyecto.json.

## Requisitos en una PC nueva

- Python 3.10 o superior (solo biblioteca estándar para el motor y las herramientas).
- Node.js (para generar el Excel).
- Paquete `@oai/artifact-tool` en una carpeta `node_modules`; enlazarla con `00_NUCLEO_DETERMINISTA/setup_runtime.ps1` (define `CODEX_BUDGET_NODE_MODULES` si no está en la ubicación habitual). Sin él se genera y valida el JSON con `--sin-excel`, pero no el Excel.
- Variables opcionales: `CODEX_BUDGET_PYTHON`, `CODEX_BUDGET_NODE`, `CODEX_BUDGET_NODE_MODULES`.
- Diagnóstico: `python 01_Herramientas/_entorno.py`.

## Flujo completo desde información en Markdown

1. Crear el proyecto vacío (incluye la plantilla del mapa de ingesta y el esqueleto del cerebro):

```bash
python Agentes_de_Presupuesto/01_Herramientas/crear_proyecto.py --codigo OBRA_002 --nombre "Nombre de la obra"
```

2. Colocar la información en MD dentro de `Proyectos/OBRA_002/01_Entrada_Minima/` (las carpetas las define el usuario) y completar `00_MAPA_INGESTA.md`, que indica qué contiene cada carpeta.
3. Pedir al agente `ingesta-cerebro-presupuesto`: analiza los MD, escribe el cerebro digital (`03_Cerebro/cerebro_digital/`), formula los APU y registra en `supuestos.json` todo lo que complete por falta de información.
4. Generar el presupuesto (compila el cerebro, valida, construye el Excel, verifica y calcula el impacto de los supuestos):

```bash
python Agentes_de_Presupuesto/01_Herramientas/generar_presupuesto.py --proyecto OBRA_002 --revision R01_Borrador --estado BORRADOR_REFERENCIAL --vigente
```

Salida en `04_Presupuesto/R01_Borrador/`: entrada canónica, resultado del motor, Excel S10 con hoja `SUPUESTOS`, `supuestos_R01.md` ordenado por impacto, pendientes y manifiesto con hashes. No sobrescribe revisiones existentes.

## Herramientas de 01_Herramientas

- `ingesta_mapa.py`: verifica el mapa de ingesta e inventaría los archivos.
- `construir_entrada.py`: cerebro digital → entrada canónica (determinista; valida referencias).
- `informe_supuestos.py`: impacto de cada supuesto abierto.
- `generar_presupuesto.py`: orquestador de todo el flujo.
- `exportar_cerebro_desde_entrada.py`: migra una entrada canónica existente a cerebro y sirve de prueba de ida y vuelta.
- `crear_proyecto.py`, `validar_proyecto.py`, `generar_presentacion.py`: creación, auditoría y presentación derivada.

## Proyecto existente

```powershell
.\Agentes_de_Presupuesto\EJECUTAR_PRESUPUESTO_TRAZABLE.ps1 -Action audit -Proyecto .\Proyectos\EDU_SURQUILLO_06P_02S
.\Agentes_de_Presupuesto\EJECUTAR_PRESUPUESTO_S10.ps1 -Action validate -Proyecto .\Proyectos\EDU_SURQUILLO_06P_02S -Mode draft
```

Audit comprueba rutas, cobertura, hashes, archivos ZIP y total del núcleo. Validate revisa la entrada del motor.

## Componentes

- 00_NUCLEO_DETERMINISTA: esquema, motor, exportador y postproceso del Excel, pruebas y plantilla vacía.
- 01_Herramientas: ingesta, compilación del cerebro, orquestación, creación y auditoría de proyectos.
- 02_Plantillas: mapa de ingesta, contrato de formatos S10/Presto y calendario.
- EJECUTAR_PRESUPUESTO_*.ps1: acceso explícito por proyecto.

Las capturas canónicas reproducen consumos evaluados; los parámetros HSE/QA vivos de revisiones con Excel editado están en ese Excel. Un build de la captura no reemplaza ese libro editable. Las propuestas y generadores antiguos están en el archivo histórico. Seguir ../AGENTS.md para trazabilidad, seguridad/calidad y emisión.
