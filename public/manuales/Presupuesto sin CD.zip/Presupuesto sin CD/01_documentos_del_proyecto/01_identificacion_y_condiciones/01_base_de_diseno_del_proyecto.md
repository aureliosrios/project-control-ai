# BASE DE DISEÑO DEL PROYECTO (CRITERIOS ESTRUCTURALES Y TECNOLÓGICOS)

> **Clasificación de datos:** `SINTETICO_APROXIMADO`. Documento de simulación técnica basado en la Memoria Descriptiva Rev. D; no acredita medición de planos originales.

Criterios generales de cálculo, parámetros normativos y especificaciones de resistencia para el Edificio Educativo de 6 pisos, 2 sótanos y azotea.

---

## 1. Parámetros Sísmicos y Geotécnicos de Diseño
- **Zona Sísmica:** Z = 0.45 (Zona 4) conforme a [[RNE-E030-2026-TEXTO|RNE E.030]].
- **Uso e Importancia:** U = 1.50 (Categoría A2 - Edificación Esencial Educativa) conforme a [[RNE-E030-2026-TEXTO|RNE E.030]].
- **Perfil de Suelo:** Grava Típica de Lima Tipo S1 (S = 1.00, Tp = 0.40s, Tl = 2.50s) conforme a [[RNE-E050|RNE E.050]].
- **Capacidad Portante Admisible:** $\sigma_{adm} = 4.00\text{ kg/cm}^2$ a cota de cimentación -5.80 m.

---

## 2. Parámetros de Resistencia de Materiales
1. **Concreto Estructural Premezclado (Norma E.060):**
   - Solados y Cimientos Ciclópeos: $f'c = 140\text{ kg/cm}^2$.
   - Zapatas, Vigas de Cimentación, Vigas Aéreas, Losas Aligeradas y Escaleras: $f'c = 210\text{ kg/cm}^2$.
   - Muros Pantalla, Sótanos, Columnas, Placas Estructurales y Cisterna Monolítica: $f'c = 280\text{ kg/cm}^2$.
2. **Acero de Refuerzo:** Corrugado Grado 60 ($f_y = 4,200\text{ kg/cm}^2$) conforme a [[INACAL-NTP|NTP 341.031]] y [[ASTM-CONSTRUCCION|ASTM A615]].

---

## 3. Sustento Dimensional y Planimetría
- Las cantidades y geometrías se sustentan formalmente en las Planillas Maestras de Metrados Detallados por Ejes y Niveles y en los Resúmenes Técnicos de Ingeniería (`PL-TOP-01` a `PL-EST-24`).
