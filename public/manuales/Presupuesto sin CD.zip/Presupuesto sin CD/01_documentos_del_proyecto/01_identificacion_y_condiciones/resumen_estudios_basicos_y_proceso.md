# RESUMEN EJECUTIVO DE ESTUDIOS BÁSICOS Y LÍNEA BASE DEL PROYECTO

> **Clasificación de datos:** `SINTETICO_APROXIMADO`. Documento de simulación técnica basado en la Memoria Descriptiva Rev. D; no acredita medición de planos originales.

## PROYECTO: "EDIFICIO EDUCATIVO DE 6 PISOS, 2 SÓTANOS Y AZOTEA"
### Línea Base de Diseño Aprobada para Formulación de descripción de actividades y metrados

| Campo | Descripción |
|---|---|
| **Proyecto** | Edificio Educativo de 6 pisos, 2 sótanos y azotea |
| **Ubicación** | Jr. Las Gardenias 480, Urb. La Calera de la Merced, Surquillo, Lima |
| **Zonificación** | RDM — Residencial de Densidad Media, compatible con Uso Educativo (Categoría A2) |
| **Configuración** | 2 sótanos + 6 pisos + azotea (9 niveles, 18 sectores, 4,500.00 m² techados) |
| **Documento** | Compendio de Estudios Básicos y Criterios Técnicos de Ingeniería |
| **Fecha de corte** | 26 de agosto de 2026 |
| **Estado** | BASE DE DISEÑO APROBADA INTERNAMENTE (Vigente para descripción de actividades y metrados sintéticos) |

---

## 1. Relación de Estudios Básicos Controlados
El proyecto cuenta con 6 informes técnicos independientes y detallados en la carpeta `02_estudios_basicos/`:

1. **TOP-01:** Levantamiento Topográfico y Red Geodésica de Control (Poligonal cerrada, BM oficial IGN Cota +108.450 msnm, lote de 500.00 m², perímetro 90.00 m).
2. **EMS-01:** Estudio de Mecánica de Suelos y Cimentaciones (Grava aluvial densa del Cono de Lima GP-GM, capacidad portante $\sigma_{adm} = 4.00 kg/cm^2$ a cota -5.80 m, asentamiento $< 0.95 cm$).
3. **SIS-01:** Peligro Sísmico y Parámetros de Sitio (NTE E.030, Zona 4 $Z=0.45$, Uso Educativo Esencial $U=1.50$, Suelo $S_1$, $R_x=7$, $R_y=6$, derivas $< 0.007$).
4. **COL-01:** Auscultación de Edificaciones Colindantes (Caracterización de predios en Eje 1, Eje 6 y Eje E, plan de apuntalamiento en 12 puntos y monitoreo de 8 hitos).
5. **MAT-01:** Fuentes de Materiales, Agregados y Agua (Homologación de canteras Rímac/Lurín, cemento Tipo I/GU, acero Grado 60 y ensayos de durabilidad).
6. **RES-01:** Resistividad del Suelo y Factibilidad de Servicios (Resistividad promedio $95 \Omega\cdot m$, malla Ufer ground $< 5 \Omega$, factibilidad de agua, desagüe, energía 185 kW y telecomunicaciones).

---

## 2. Memorias Descriptivas y de Diseño por Especialidad
Disponibles en la carpeta `03_memorias_descriptivas/`:
- **MEM-EST-01:** Memoria de Diseño Estructural y Casco (Cargas E.020, Concreto f'c=280 en columnas/placas/muros y f'c=210 en vigas/losas/zapatas).
- **MEM-ARQ-01:** Memoria de Arquitectura, Programa Educativo y Evacuación (Cuadro general de 4,500 m², aforo simultáneo de 662 personas, 2 escaleras de escape EA-1 y EA-2 presurizadas con capacidad para 800 personas).
- **MEM-MEP-01:** Memoria de Interfaces e Instalaciones Embebidas (Sleeves sanitarios en tercio central E.060, pasamuros estancos, conduits pesados, mallas de tierra y pases de ventilación).

---

## 3. Estructura WBS y Matriz Maestra de Metrados
- **WBS Maestra (`05_wbs_maestra_unica.json`):** 13 Capítulos estructurados y 78 partidas contractuales/unitarias con reglas de medición unificadas.
- **Metrados Maestros (`06_metrados_maestros.json`):** Matriz detallada con los 21 campos técnicos obligatorios por línea de metrado, desagregada por los 9 niveles y 18 sectores, con fórmulas reproducibles, dimensiones y asignación de planos fuente (24 láminas en `04_inventario_planos_y_detalles.json`).
- **Trazabilidad 100 % (`07_matriz_trazabilidad.json`):** Mapeo íntegro entre estudio básico, plano, elemento, WBS, metrado y habilitación técnica.
- **Secuencia Lógica (`08_bloques_constructivos.md`):** Organización constructiva en Bloques A–H e hitos de liberación de calidad.

---

## 4. Estado de Habilitación para la Siguiente Etapa
Habiéndose levantado todas las observaciones de la Auditoría 4 y cerrado los 13 requisitos técnicos (R-01 a R-13), el proyecto se encuentra formalmente **HABILITADO Y CONFORME** para iniciar la elaboración de las **Especificaciones Técnicas (EETT)** y, posteriormente, el **Presupuesto de Obra**.
