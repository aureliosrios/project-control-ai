# WBS MAESTRA ÚNICA: 13 CAPÍTULOS Y 78 PARTIDAS - REV. D

> **Clasificación de datos:** `SINTETICO_APROXIMADO`. Alcance tecnológico basado en la Memoria Descriptiva Rev. D; cantidades adoptadas para simulación y conciliadas con los metrados detallados.

**Fecha:** 2026-08-26  
**Alcance:** Descripción de actividades y metrados; se excluyen presupuesto, APU y costos.

## Capítulo 01.00: TRABAJOS PRELIMINARES

Actividades preparatorias, movilización, habilitación de servicios provisionales, trazo y protección de interferencias.

- **Partida `01.01`**: Movilización y desmovilización de equipo pesado en cama baja de 30 Tn | Unidad: `glb` | Metrado: `1.0`
- **Partida `01.02`**: Instalaciones provisionales de agua, energía y desagüe de faena con tablero general | Unidad: `glb` | Metrado: `1.0`
- **Partida `01.03`**: Cerramiento provisional perimetral con parantes tubulares de acero 2" y Malla Raschel 80% | Unidad: `m` | Metrado: `90.0`
- **Partida `01.04`**: Trazo, niveles y replanteo topográfico con Estación Total Láser Leica | Unidad: `m2` | Metrado: `500.0`
- **Partida `01.05`**: Protección y desvío de interferencias de redes de servicios públicos (SEDAPAL/ENEL) | Unidad: `glb` | Metrado: `1.0`
- **Partida `01.06`**: Limpieza, desbroce manual y acondicionamiento del terreno | Unidad: `m2` | Metrado: `450.0`

## Capítulo 02.00: OBRAS TEMPORALES, SOSTENIMIENTO Y MONITOREO GEOTÉCNICO

Protección de colindancias, muros de sostenimiento provisional y auscultación.

- **Partida `02.01`**: Sostenimiento perimetral con perforadora hidráulica, anclajes Dywidag 32mm L=9m e inyección de lechada | Unidad: `m2` | Metrado: `522.0`
- **Partida `02.02`**: Apuntalamiento provisional de estructuras colindantes con puntales telescópicos Multiprop y vigas HEB | Unidad: `und` | Metrado: `12.0`
- **Partida `02.03`**: Instrumentación geotécnica: inclinómetros biaxiales profundos (2 und) y piezómetro abierto PZ-1 | Unidad: `glb` | Metrado: `1.0`
- **Partida `02.04`**: Monitoreo topográfico continuo de hitos geodésicos en colindancias con estación total (8 hitos) | Unidad: `mes` | Metrado: `4.0`
- **Partida `02.05`**: Sistema provisional de bombeo y achique de aguas de escorrentía con electrobomba sumergible 5 HP | Unidad: `glb` | Metrado: `1.0`

## Capítulo 03.00: MOVIMIENTO DE TIERRAS

Excavaciones masivas y localizadas, relleno compactado y eliminación de excedentes.

- **Partida `03.01`**: Excavación masiva con excavadora sobre orugas 200 HP hasta cota -5.80 m | Unidad: `m3` | Metrado: `3200.0`
- **Partida `03.02`**: Excavación manual localizada para zapatas, vigas de cimentación, foso y cisterna | Unidad: `m3` | Metrado: `250.0`
- **Partida `03.03`**: Carguío con cargador frontal CAT 950 y eliminación con volquetes de 15 m3 (d=10 km) | Unidad: `m3` | Metrado: `4100.0`
- **Partida `03.04`**: Relleno compactado con afirmado seleccionado de cantera y plancha vibratoria al 95% PM | Unidad: `m3` | Metrado: `180.0`
- **Partida `03.05`**: Perfilado y compactación de fondo de excavación (subrasante) con equipo liviano | Unidad: `m2` | Metrado: `500.0`

## Capítulo 04.00: CONCRETO SIMPLE Y PREPARACIÓN DE FONDO

Solados de cimentación, cimientos corridos y sobrecimientos de concreto ciclópeo/simple.

- **Partida `04.01`**: Solado de concreto premezclado f'c=140 kg/cm2 e=4" para zapatas, cisterna y fosos | Unidad: `m2` | Metrado: `161.2`
- **Partida `04.02`**: Cimientos corridos de concreto premezclado f'c=140 kg/cm2 + 30% piedra grande | Unidad: `m3` | Metrado: `120.0`
- **Partida `04.03`**: Sobrecimientos de concreto premezclado f'c=175 kg/cm2 + 25% piedra mediana | Unidad: `m3` | Metrado: `45.0`
- **Partida `04.04`**: Encofrado y desencofrado modular metálico con tablero fenólico para sobrecimientos | Unidad: `m2` | Metrado: `180.0`

## Capítulo 05.00: CIMENTACIONES DE CONCRETO ARMADO

Zapatas aisladas y combinadas, vigas de cimentación y amarre.

- **Partida `05.01`**: Zapatas: Concreto premezclado f'c=210 kg/cm2 vaciado con bomba telescópica | Unidad: `m3` | Metrado: `83.76`
- **Partida `05.02`**: Zapatas: Encofrado y desencofrado modular metálico | Unidad: `m2` | Metrado: `137.44`
- **Partida `05.03`**: Zapatas: Acero de refuerzo corrugado fy=4200 kg/cm2 Grado 60 habilitado en banco CNC | Unidad: `kg` | Metrado: `7119.6`
- **Partida `05.04`**: Vigas de cimentación y amarre: Concreto premezclado f'c=210 kg/cm2 con bomba | Unidad: `m3` | Metrado: `58.52`
- **Partida `05.05`**: Vigas de cimentación y amarre: Encofrado y desencofrado modular fenólico 18mm | Unidad: `m2` | Metrado: `258.4`
- **Partida `05.06`**: Vigas de cimentación y amarre: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | Unidad: `kg` | Metrado: `6437.2`

## Capítulo 06.00: ESTRUCTURAS ESPECIALES DE SÓTANOS

Muros de contención perimetrales, losa de contacto, cisterna, foso de ascensor y rampa.

- **Partida `06.01`**: Muros de contención / pantalla: Concreto premezclado f'c=280 kg/cm2 con bomba | Unidad: `m3` | Metrado: `156.6`
- **Partida `06.02`**: Muros de contención / pantalla: Encofrado modular fenólico a dos caras con sistema de trepa | Unidad: `m2` | Metrado: `1044.0`
- **Partida `06.03`**: Muros de contención / pantalla: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | Unidad: `kg` | Metrado: `14094.0`
- **Partida `06.04`**: Losa de contacto de Sótano 2 e=15 cm concreto premezclado f'c=210 sobre lámina de polietileno HDPE 8 mils | Unidad: `m2` | Metrado: `500.0`
- **Partida `06.05`**: Cisterna y cuarto de bombas: Estructura monolítica de concreto premezclado f'c=280 con impermeabilizante y waterstop | Unidad: `m3` | Metrado: `42.5`
- **Partida `06.06`**: Cisterna y cuarto de bombas: Encofrado modular fenólico impermeable | Unidad: `m2` | Metrado: `168.0`
- **Partida `06.07`**: Rampa vehicular estructural: Losa inclinada e=18 cm concreto f'c=210 con acabado endurecido antideslizante | Unidad: `m2` | Metrado: `125.0`
- **Partida `06.08`**: Sellos hidroexpansivos SikaSwell y cinta waterstop de PVC 6" en juntas frías de sótanos | Unidad: `m` | Metrado: `180.0`

## Capítulo 07.00: SUPERESTRUCTURA DE CONCRETO ARMADO

Columnas, placas, vigas, losas aligeradas, ladrillos de techo y escaleras del Piso 1 al 6.

- **Partida `07.01`**: Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m | Unidad: `m3` | Metrado: `48.6`
- **Partida `07.02`**: Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos | Unidad: `m2` | Metrado: `324.0`
- **Partida `07.03`**: Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica | Unidad: `kg` | Metrado: `7290.0`
- **Partida `07.04`**: Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba | Unidad: `m3` | Metrado: `72.9`
- **Partida `07.05`**: Placas de concreto armado: Encofrado modular fenólico trepante | Unidad: `m2` | Metrado: `486.0`
- **Partida `07.06`**: Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | Unidad: `kg` | Metrado: `8748.0`
- **Partida `07.07`**: Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba | Unidad: `m3` | Metrado: `126.0`
- **Partida `07.08`**: Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos | Unidad: `m2` | Metrado: `560.0`
- **Partida `07.09`**: Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | Unidad: `kg` | Metrado: `15120.0`
- **Partida `07.10`**: Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 | Unidad: `m3` | Metrado: `210.0`
- **Partida `07.11`**: Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares | Unidad: `m2` | Metrado: `2400.0`
- **Partida `07.12`**: Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 | Unidad: `kg` | Metrado: `12600.0`
- **Partida `07.13`**: Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre | Unidad: `und` | Metrado: `20400.0`
- **Partida `07.14`**: Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 | Unidad: `m3` | Metrado: `18.9`
- **Partida `07.15`**: Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos | Unidad: `m2` | Metrado: `108.0`
- **Partida `07.16`**: Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | Unidad: `kg` | Metrado: `2457.0`

## Capítulo 08.00: AZOTEA Y ELEMENTOS TÉCNICOS

Losa de techo final, parapetos de concreto, cuarto de máquinas e impermeabilización.

- **Partida `08.01`**: Losa de techo de azotea e=20 cm concreto premezclado f'c=210 con membrana asfáltica e=3mm | Unidad: `m2` | Metrado: `500.0`
- **Partida `08.02`**: Parapeto perimetral de concreto armado f'c=210 h=1.10 m en azotea | Unidad: `m` | Metrado: `90.0`
- **Partida `08.03`**: Caseta de sala de máquinas de ascensor y cuarto técnico de bombas en concreto f'c=280 | Unidad: `m3` | Metrado: `12.5`
- **Partida `08.04`**: Juntas de dilatación sísmica perimetral con tecnopor de 1" y sellador elastomérico de poliuretano | Unidad: `m` | Metrado: `65.0`

## Capítulo 09.00: ALBAÑILERÍA Y ACABADOS BÁSICOS EN CASCO

Muros de ladrillo pandereta confinado, columnetas, dinteles y solaqueo primario.

- **Partida `09.01`**: Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga | Unidad: `m2` | Metrado: `1850.0`
- **Partida `09.02`**: Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) | Unidad: `m3` | Metrado: `28.5`
- **Partida `09.03`**: Encofrado y desencofrado modular para columnetas y vigas de amarre | Unidad: `m2` | Metrado: `195.0`
- **Partida `09.04`**: Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex | Unidad: `m` | Metrado: `420.0`

## Capítulo 10.00: INTERFACES E INSTALACIONES SANITARIAS EMBEBIDAS

Mangas, sleeves, pasamuros rompeaguas, montantes verticales y pruebas hidrostáticas.

- **Partida `10.01`**: Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) | Unidad: `und` | Metrado: `96.0`
- **Partida `10.02`**: Red colectora de desagüe colgada PVC SAL 4" y 2" en sótanos | Unidad: `m` | Metrado: `280.0`
- **Partida `10.03`**: Montantes de ventilación y desagüe vertical PVC SAL 4" | Unidad: `m` | Metrado: `195.0`
- **Partida `10.04`**: Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje | Unidad: `und` | Metrado: `24.0`
- **Partida `10.05`**: Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM | Unidad: `m` | Metrado: `350.0`

## Capítulo 11.00: INTERFACES E INSTALACIONES ELÉCTRICAS Y COMUNICACIONES EMBEBIDAS

Red equipotencial de puesta a tierra Ufer, conduits, cajas galvanizadas y shafts.

- **Partida `11.01`**: Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos | Unidad: `und` | Metrado: `120.0`
- **Partida `11.02`**: Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados | Unidad: `m` | Metrado: `1850.0`
- **Partida `11.03`**: Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) | Unidad: `m` | Metrado: `3200.0`
- **Partida `11.04`**: Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza | Unidad: `und` | Metrado: `210.0`
- **Partida `11.05`**: Sistema de puesta a tierra integral de baja resistencia (< 5 ohmios) en foso de sótanos | Unidad: `und` | Metrado: `4.0`

## Capítulo 12.00: INTERFACES MECÁNICAS, VENTILACIÓN Y CONTRA INCENDIOS EMBEBIDAS

Pases de presurización de escaleras, extracción de CO, montante ACI e insertos HVAC.

- **Partida `12.01`**: Pases estructurales coordinados BIM para ductos de presurización de escalera | Unidad: `und` | Metrado: `18.0`
- **Partida `12.02`**: Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) | Unidad: `m` | Metrado: `850.0`
- **Partida `12.03`**: Anclajes y soportes antivibratorios para equipos electromecánicos de bombeo | Unidad: `und` | Metrado: `8.0`
- **Partida `12.04`**: Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego | Unidad: `und` | Metrado: `64.0`

## Capítulo 13.00: ASEGURAMIENTO Y CONTROL DE CALIDAD (QA/QC)

Control topográfico, ensayos de compresión de concreto, acero, densidades y protocolos.

- **Partida `13.01`**: Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto | Unidad: `und` | Metrado: `144.0`
- **Partida `13.02`**: Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) | Unidad: `und` | Metrado: `65.0`
- **Partida `13.03`**: Ensayos de tracción y doblado de acero de refuerzo en laboratorio acreditado | Unidad: `und` | Metrado: `12.0`
- **Partida `13.04`**: Pruebas hidrostáticas y de estanqueidad presurizada en redes y cisterna (72 horas) | Unidad: `glb` | Metrado: `1.0`
- **Partida `13.05`**: Ensayos de densidad de campo (cono de arena) en rellenos y subrasante al 95% PM | Unidad: `und` | Metrado: `18.0`
- **Partida `13.06`**: Elaboración y entrega del Dossier Final de Calidad y Planos As-Built en formato BIM/CAD | Unidad: `glb` | Metrado: `1.0`
