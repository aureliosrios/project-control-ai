---
tipo: "wbs_capitulo"
codigo: "01.00"
titulo: "TRABAJOS PRELIMINARES"
partidas: 6
tags: ["wbs", "proyecto"]
---

# WBS-01.00 — TRABAJOS PRELIMINARES

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-01.01]] | Movilización y desmovilización de equipo pesado en cama baja de 30 Tn | glb | 1.0 | [[EETT-01.01]] | [[APU-01.01]] |
| [[WBS-01.02]] | Instalaciones provisionales de agua, energía y desagüe de faena con tablero general | glb | 1.0 | [[EETT-01.02]] | [[APU-01.02]] |
| [[WBS-01.03]] | Cerramiento provisional perimetral con parantes tubulares de acero 2" y Malla Raschel 80% | m | 90.0 | [[EETT-01.03]] | [[APU-01.03]] |
| [[WBS-01.04]] | Trazo, niveles y replanteo topográfico con Estación Total Láser Leica | m2 | 500.0 | [[EETT-01.04]] | [[APU-01.04]] |
| [[WBS-01.05]] | Protección y desvío de interferencias de redes de servicios públicos (SEDAPAL/ENEL) | glb | 1.0 | [[EETT-01.05]] | [[APU-01.05]] |
| [[WBS-01.06]] | Limpieza, desbroce manual y acondicionamiento del terreno | m2 | 450.0 | [[EETT-01.06]] | [[APU-01.06]] |

**Costo directo del capítulo (R01):** S/ 30,573.85 — ver [[PRESUPUESTO_R01]].
