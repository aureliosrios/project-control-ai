---
tipo: "wbs_capitulo"
codigo: "02.00"
titulo: "OBRAS TEMPORALES, SOSTENIMIENTO Y MONITOREO GEOTÉCNICO"
partidas: 5
tags: ["wbs", "proyecto"]
---

# WBS-02.00 — OBRAS TEMPORALES, SOSTENIMIENTO Y MONITOREO GEOTÉCNICO

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-02.01]] | Sostenimiento perimetral con perforadora hidráulica, anclajes Dywidag 32mm L=9m e inyección de lechada | m2 | 522.0 | [[EETT-02.01]] | [[APU-02.01]] |
| [[WBS-02.02]] | Apuntalamiento provisional de estructuras colindantes con puntales telescópicos Multiprop y vigas HEB | und | 12.0 | [[EETT-02.02]] | [[APU-02.02]] |
| [[WBS-02.03]] | Instrumentación geotécnica: inclinómetros biaxiales profundos (2 und) y piezómetro abierto PZ-1 | glb | 1.0 | [[EETT-02.03]] | [[APU-02.03]] |
| [[WBS-02.04]] | Monitoreo topográfico continuo de hitos geodésicos en colindancias con estación total (8 hitos) | mes | 4.0 | [[EETT-02.04]] | [[APU-02.04]] |
| [[WBS-02.05]] | Sistema provisional de bombeo y achique de aguas de escorrentía con electrobomba sumergible 5 HP | glb | 1.0 | [[EETT-02.05]] | [[APU-02.05]] |

**Costo directo del capítulo (R01):** S/ 310,658.60 — ver [[PRESUPUESTO_R01]].
