---
tipo: "wbs_capitulo"
codigo: "03.00"
titulo: "MOVIMIENTO DE TIERRAS"
partidas: 5
tags: ["wbs", "proyecto"]
---

# WBS-03.00 — MOVIMIENTO DE TIERRAS

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-03.01]] | Excavación masiva con excavadora sobre orugas 200 HP hasta cota -5.80 m | m3 | 3,200.0 | [[EETT-03.01]] | [[APU-03.01]] |
| [[WBS-03.02]] | Excavación manual localizada para zapatas, vigas de cimentación, foso y cisterna | m3 | 250.0 | [[EETT-03.02]] | [[APU-03.02]] |
| [[WBS-03.03]] | Carguío con cargador frontal CAT 950 y eliminación con volquetes de 15 m3 (d=10 km) | m3 | 4,100.0 | [[EETT-03.03]] | [[APU-03.03]] |
| [[WBS-03.04]] | Relleno compactado con afirmado seleccionado de cantera y plancha vibratoria al 95% PM | m3 | 180.0 | [[EETT-03.04]] | [[APU-03.04]] |
| [[WBS-03.05]] | Perfilado y compactación de fondo de excavación (subrasante) con equipo liviano | m2 | 500.0 | [[EETT-03.05]] | [[APU-03.05]] |

**Costo directo del capítulo (R01):** S/ 236,846.75 — ver [[PRESUPUESTO_R01]].
