---
tipo: "wbs_capitulo"
codigo: "04.00"
titulo: "CONCRETO SIMPLE Y PREPARACIÓN DE FONDO"
partidas: 4
tags: ["wbs", "proyecto"]
---

# WBS-04.00 — CONCRETO SIMPLE Y PREPARACIÓN DE FONDO

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-04.01]] | Solado de concreto premezclado f'c=140 kg/cm2 e=4" para zapatas, cisterna y fosos | m2 | 161.2 | [[EETT-04.01]] | [[APU-04.01]] |
| [[WBS-04.02]] | Cimientos corridos de concreto premezclado f'c=140 kg/cm2 + 30% piedra grande | m3 | 120.0 | [[EETT-04.02]] | [[APU-04.02]] |
| [[WBS-04.03]] | Sobrecimientos de concreto premezclado f'c=175 kg/cm2 + 25% piedra mediana | m3 | 45.0 | [[EETT-04.03]] | [[APU-04.03]] |
| [[WBS-04.04]] | Encofrado y desencofrado modular metálico con tablero fenólico para sobrecimientos | m2 | 180.0 | [[EETT-04.04]] | [[APU-04.04]] |

**Costo directo del capítulo (R01):** S/ 67,607.90 — ver [[PRESUPUESTO_R01]].
