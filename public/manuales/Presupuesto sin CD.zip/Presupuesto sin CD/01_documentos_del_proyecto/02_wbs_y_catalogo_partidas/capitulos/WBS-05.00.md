---
tipo: "wbs_capitulo"
codigo: "05.00"
titulo: "CIMENTACIONES DE CONCRETO ARMADO"
partidas: 6
tags: ["wbs", "proyecto"]
---

# WBS-05.00 — CIMENTACIONES DE CONCRETO ARMADO

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-05.01]] | Zapatas: Concreto premezclado f'c=210 kg/cm2 vaciado con bomba telescópica | m3 | 83.76 | [[EETT-05.01]] | [[APU-05.01]] |
| [[WBS-05.02]] | Zapatas: Encofrado y desencofrado modular metálico | m2 | 137.44 | [[EETT-05.02]] | [[APU-05.02]] |
| [[WBS-05.03]] | Zapatas: Acero de refuerzo corrugado fy=4200 kg/cm2 Grado 60 habilitado en banco CNC | kg | 7,119.6 | [[EETT-05.03]] | [[APU-05.03]] |
| [[WBS-05.04]] | Vigas de cimentación y amarre: Concreto premezclado f'c=210 kg/cm2 con bomba | m3 | 58.52 | [[EETT-05.04]] | [[APU-05.04]] |
| [[WBS-05.05]] | Vigas de cimentación y amarre: Encofrado y desencofrado modular fenólico 18mm | m2 | 258.4 | [[EETT-05.05]] | [[APU-05.05]] |
| [[WBS-05.06]] | Vigas de cimentación y amarre: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 6,437.2 | [[EETT-05.06]] | [[APU-05.06]] |

**Costo directo del capítulo (R01):** S/ 177,967.57 — ver [[PRESUPUESTO_R01]].
