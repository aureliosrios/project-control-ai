---
tipo: "wbs_capitulo"
codigo: "06.00"
titulo: "ESTRUCTURAS ESPECIALES DE SÓTANOS"
partidas: 8
tags: ["wbs", "proyecto"]
---

# WBS-06.00 — ESTRUCTURAS ESPECIALES DE SÓTANOS

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-06.01]] | Muros de contención / pantalla: Concreto premezclado f'c=280 kg/cm2 con bomba | m3 | 156.6 | [[EETT-06.01]] | [[APU-06.01]] |
| [[WBS-06.02]] | Muros de contención / pantalla: Encofrado modular fenólico a dos caras con sistema de trepa | m2 | 1,044.0 | [[EETT-06.02]] | [[APU-06.02]] |
| [[WBS-06.03]] | Muros de contención / pantalla: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 14,094.0 | [[EETT-06.03]] | [[APU-06.03]] |
| [[WBS-06.04]] | Losa de contacto de Sótano 2 e=15 cm concreto premezclado f'c=210 sobre lámina de polietileno HDPE 8 mils | m2 | 500.0 | [[EETT-06.04]] | [[APU-06.04]] |
| [[WBS-06.05]] | Cisterna y cuarto de bombas: Estructura monolítica de concreto premezclado f'c=280 con impermeabilizante y waterstop | m3 | 42.5 | [[EETT-06.05]] | [[APU-06.05]] |
| [[WBS-06.06]] | Cisterna y cuarto de bombas: Encofrado modular fenólico impermeable | m2 | 168.0 | [[EETT-06.06]] | [[APU-06.06]] |
| [[WBS-06.07]] | Rampa vehicular estructural: Losa inclinada e=18 cm concreto f'c=210 con acabado endurecido antideslizante | m2 | 125.0 | [[EETT-06.07]] | [[APU-06.07]] |
| [[WBS-06.08]] | Sellos hidroexpansivos SikaSwell y cinta waterstop de PVC 6" en juntas frías de sótanos | m | 180.0 | [[EETT-06.08]] | [[APU-06.08]] |

**Costo directo del capítulo (R01):** S/ 336,178.61 — ver [[PRESUPUESTO_R01]].
