---
tipo: "wbs_capitulo"
codigo: "07.00"
titulo: "SUPERESTRUCTURA DE CONCRETO ARMADO"
partidas: 16
tags: ["wbs", "proyecto"]
---

# WBS-07.00 — SUPERESTRUCTURA DE CONCRETO ARMADO

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-07.01]] | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m | m3 | 48.6 | [[EETT-07.01]] | [[APU-07.01]] |
| [[WBS-07.02]] | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos | m2 | 324.0 | [[EETT-07.02]] | [[APU-07.02]] |
| [[WBS-07.03]] | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica | kg | 7,290.0 | [[EETT-07.03]] | [[APU-07.03]] |
| [[WBS-07.04]] | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba | m3 | 72.9 | [[EETT-07.04]] | [[APU-07.04]] |
| [[WBS-07.05]] | Placas de concreto armado: Encofrado modular fenólico trepante | m2 | 486.0 | [[EETT-07.05]] | [[APU-07.05]] |
| [[WBS-07.06]] | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 8,748.0 | [[EETT-07.06]] | [[APU-07.06]] |
| [[WBS-07.07]] | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba | m3 | 126.0 | [[EETT-07.07]] | [[APU-07.07]] |
| [[WBS-07.08]] | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos | m2 | 560.0 | [[EETT-07.08]] | [[APU-07.08]] |
| [[WBS-07.09]] | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 15,120.0 | [[EETT-07.09]] | [[APU-07.09]] |
| [[WBS-07.10]] | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 | m3 | 210.0 | [[EETT-07.10]] | [[APU-07.10]] |
| [[WBS-07.11]] | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares | m2 | 2,400.0 | [[EETT-07.11]] | [[APU-07.11]] |
| [[WBS-07.12]] | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 | kg | 12,600.0 | [[EETT-07.12]] | [[APU-07.12]] |
| [[WBS-07.13]] | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre | und | 20,400.0 | [[EETT-07.13]] | [[APU-07.13]] |
| [[WBS-07.14]] | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 | m3 | 18.9 | [[EETT-07.14]] | [[APU-07.14]] |
| [[WBS-07.15]] | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos | m2 | 108.0 | [[EETT-07.15]] | [[APU-07.15]] |
| [[WBS-07.16]] | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 | kg | 2,457.0 | [[EETT-07.16]] | [[APU-07.16]] |

**Costo directo del capítulo (R01):** S/ 922,840.92 — ver [[PRESUPUESTO_R01]].
