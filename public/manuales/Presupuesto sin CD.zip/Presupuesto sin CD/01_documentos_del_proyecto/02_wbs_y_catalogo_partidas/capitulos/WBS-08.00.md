---
tipo: "wbs_capitulo"
codigo: "08.00"
titulo: "AZOTEA Y ELEMENTOS TÉCNICOS"
partidas: 4
tags: ["wbs", "proyecto"]
---

# WBS-08.00 — AZOTEA Y ELEMENTOS TÉCNICOS

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-08.01]] | Losa de techo de azotea e=20 cm concreto premezclado f'c=210 con membrana asfáltica e=3mm | m2 | 500.0 | [[EETT-08.01]] | [[APU-08.01]] |
| [[WBS-08.02]] | Parapeto perimetral de concreto armado f'c=210 h=1.10 m en azotea | m | 90.0 | [[EETT-08.02]] | [[APU-08.02]] |
| [[WBS-08.03]] | Caseta de sala de máquinas de ascensor y cuarto técnico de bombas en concreto f'c=280 | m3 | 12.5 | [[EETT-08.03]] | [[APU-08.03]] |
| [[WBS-08.04]] | Juntas de dilatación sísmica perimetral con tecnopor de 1" y sellador elastomérico de poliuretano | m | 65.0 | [[EETT-08.04]] | [[APU-08.04]] |

**Costo directo del capítulo (R01):** S/ 107,852.42 — ver [[PRESUPUESTO_R01]].
