---
tipo: "wbs_capitulo"
codigo: "09.00"
titulo: "ALBAÑILERÍA Y ACABADOS BÁSICOS EN CASCO"
partidas: 4
tags: ["wbs", "proyecto"]
---

# WBS-09.00 — ALBAÑILERÍA Y ACABADOS BÁSICOS EN CASCO

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-09.01]] | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga | m2 | 1,850.0 | [[EETT-09.01]] | [[APU-09.01]] |
| [[WBS-09.02]] | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) | m3 | 28.5 | [[EETT-09.02]] | [[APU-09.02]] |
| [[WBS-09.03]] | Encofrado y desencofrado modular para columnetas y vigas de amarre | m2 | 195.0 | [[EETT-09.03]] | [[APU-09.03]] |
| [[WBS-09.04]] | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex | m | 420.0 | [[EETT-09.04]] | [[APU-09.04]] |

**Costo directo del capítulo (R01):** S/ 268,443.33 — ver [[PRESUPUESTO_R01]].
