---
tipo: "wbs_capitulo"
codigo: "10.00"
titulo: "INTERFACES E INSTALACIONES SANITARIAS EMBEBIDAS"
partidas: 5
tags: ["wbs", "proyecto"]
---

# WBS-10.00 — INTERFACES E INSTALACIONES SANITARIAS EMBEBIDAS

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-10.01]] | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) | und | 96.0 | [[EETT-10.01]] | [[APU-10.01]] |
| [[WBS-10.02]] | Red colectora de desagüe colgada PVC SAL 4" y 2" en sótanos | m | 280.0 | [[EETT-10.02]] | [[APU-10.02]] |
| [[WBS-10.03]] | Montantes de ventilación y desagüe vertical PVC SAL 4" | m | 195.0 | [[EETT-10.03]] | [[APU-10.03]] |
| [[WBS-10.04]] | Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje | und | 24.0 | [[EETT-10.04]] | [[APU-10.04]] |
| [[WBS-10.05]] | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM | m | 350.0 | [[EETT-10.05]] | [[APU-10.05]] |

**Costo directo del capítulo (R01):** S/ 94,516.33 — ver [[PRESUPUESTO_R01]].
