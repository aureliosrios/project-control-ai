---
tipo: "wbs_capitulo"
codigo: "11.00"
titulo: "INTERFACES E INSTALACIONES ELÉCTRICAS Y COMUNICACIONES EMBEBIDAS"
partidas: 5
tags: ["wbs", "proyecto"]
---

# WBS-11.00 — INTERFACES E INSTALACIONES ELÉCTRICAS Y COMUNICACIONES EMBEBIDAS

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-11.01]] | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos | und | 120.0 | [[EETT-11.01]] | [[APU-11.01]] |
| [[WBS-11.02]] | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados | m | 1,850.0 | [[EETT-11.02]] | [[APU-11.02]] |
| [[WBS-11.03]] | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) | m | 3,200.0 | [[EETT-11.03]] | [[APU-11.03]] |
| [[WBS-11.04]] | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza | und | 210.0 | [[EETT-11.04]] | [[APU-11.04]] |
| [[WBS-11.05]] | Sistema de puesta a tierra integral de baja resistencia (< 5 ohmios) en foso de sótanos | und | 4.0 | [[EETT-11.05]] | [[APU-11.05]] |

**Costo directo del capítulo (R01):** S/ 94,752.28 — ver [[PRESUPUESTO_R01]].
