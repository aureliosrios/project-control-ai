---
tipo: "wbs_capitulo"
codigo: "12.00"
titulo: "INTERFACES MECÁNICAS, VENTILACIÓN Y CONTRA INCENDIOS EMBEBIDAS"
partidas: 4
tags: ["wbs", "proyecto"]
---

# WBS-12.00 — INTERFACES MECÁNICAS, VENTILACIÓN Y CONTRA INCENDIOS EMBEBIDAS

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-12.01]] | Pases estructurales coordinados BIM para ductos de presurización de escalera | und | 18.0 | [[EETT-12.01]] | [[APU-12.01]] |
| [[WBS-12.02]] | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) | m | 850.0 | [[EETT-12.02]] | [[APU-12.02]] |
| [[WBS-12.03]] | Anclajes y soportes antivibratorios para equipos electromecánicos de bombeo | und | 8.0 | [[EETT-12.03]] | [[APU-12.03]] |
| [[WBS-12.04]] | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego | und | 64.0 | [[EETT-12.04]] | [[APU-12.04]] |

**Costo directo del capítulo (R01):** S/ 35,356.03 — ver [[PRESUPUESTO_R01]].
