---
tipo: "wbs_capitulo"
codigo: "13.00"
titulo: "ASEGURAMIENTO Y CONTROL DE CALIDAD (QA/QC)"
partidas: 6
tags: ["wbs", "proyecto"]
---

# WBS-13.00 — ASEGURAMIENTO Y CONTROL DE CALIDAD (QA/QC)

Parte de [[MOC_WBS]] · Proyecto: [[MOC_PROYECTO]]

| Partida | Descripción | Und | Metrado | EETT | APU |
|---|---|---|---:|---|---|
| [[WBS-13.01]] | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto | und | 144.0 | [[EETT-13.01]] | [[APU-13.01]] |
| [[WBS-13.02]] | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) | und | 65.0 | [[EETT-13.02]] | [[APU-13.02]] |
| [[WBS-13.03]] | Ensayos de tracción y doblado de acero de refuerzo en laboratorio acreditado | und | 12.0 | [[EETT-13.03]] | [[APU-13.03]] |
| [[WBS-13.04]] | Pruebas hidrostáticas y de estanqueidad presurizada en redes y cisterna (72 horas) | glb | 1.0 | [[EETT-13.04]] | [[APU-13.04]] |
| [[WBS-13.05]] | Ensayos de densidad de campo (cono de arena) en rellenos y subrasante al 95% PM | und | 18.0 | [[EETT-13.05]] | [[APU-13.05]] |
| [[WBS-13.06]] | Elaboración y entrega del Dossier Final de Calidad y Planos As-Built en formato BIM/CAD | glb | 1.0 | [[EETT-13.06]] | [[APU-13.06]] |

**Costo directo del capítulo (R01):** S/ 42,409.23 — ver [[PRESUPUESTO_R01]].
