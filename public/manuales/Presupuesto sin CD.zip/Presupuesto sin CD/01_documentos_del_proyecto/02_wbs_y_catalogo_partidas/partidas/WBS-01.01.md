---
tipo: "wbs_partida"
codigo: "01.01"
capitulo: "01.00"
unidad: "glb"
metrado: 1.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-01.01 — Movilización y desmovilización de equipo pesado en cama baja de 30 Tn

Capítulo: [[WBS-01.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** glb / 1.0
- **Regla de medición:** Suma global por traslado total de equipos a obra y retiro al finalizar casco.
- **Ubicación (planilla maestra):** Nivel Terreno (±0.00) · General de Obra · Área de lote y frentes de trabajo
- **Especificación técnica:** [[EETT-01.01]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-01.01]] · costo unitario S/ 9,601.60 · parcial S/ 9,601.60 (ver [[PRESUPUESTO_R01]])
