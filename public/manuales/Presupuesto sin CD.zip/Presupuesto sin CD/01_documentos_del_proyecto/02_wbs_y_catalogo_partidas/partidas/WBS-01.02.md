---
tipo: "wbs_partida"
codigo: "01.02"
capitulo: "01.00"
unidad: "glb"
metrado: 1.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-01.02 — Instalaciones provisionales de agua, energía y desagüe de faena con tablero general

Capítulo: [[WBS-01.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** glb / 1.0
- **Regla de medición:** Suma global que incluye acometidas provisionales y tableros de faena.
- **Ubicación (planilla maestra):** Nivel Terreno (±0.00) · General de Obra · Frente Jr. Las Gardenias
- **Especificación técnica:** [[EETT-01.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-01.02]] · costo unitario S/ 5,422.60 · parcial S/ 5,422.60 (ver [[PRESUPUESTO_R01]])
