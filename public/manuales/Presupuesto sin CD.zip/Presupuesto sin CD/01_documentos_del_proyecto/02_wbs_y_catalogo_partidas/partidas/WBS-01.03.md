---
tipo: "wbs_partida"
codigo: "01.03"
capitulo: "01.00"
unidad: "m"
metrado: 90.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-01.03 — Cerramiento provisional perimetral con parantes tubulares de acero 2" y Malla Raschel 80%

Capítulo: [[WBS-01.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 90.0
- **Regla de medición:** Metro lineal de cerco perimetral de triplay/planchas metálicas h=2.40m.
- **Ubicación (planilla maestra):** Nivel Terreno (±0.00) · Perímetro del Lote · Linderos Frontal, Posterior, Izquierdo y Derecho
- **Especificación técnica:** [[EETT-01.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-01.03]] · costo unitario S/ 62.29 · parcial S/ 5,605.65 (ver [[PRESUPUESTO_R01]])
