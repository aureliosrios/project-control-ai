---
tipo: "wbs_partida"
codigo: "01.04"
capitulo: "01.00"
unidad: "m2"
metrado: 500.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-01.04 — Trazo, niveles y replanteo topográfico con Estación Total Láser Leica

Capítulo: [[WBS-01.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 500.0
- **Regla de medición:** Área en proyección horizontal del lote replanteado.
- **Ubicación (planilla maestra):** Nivel Terreno (±0.00) · Área Total · Ejes A-E, 1-6 (Lote completo)
- **Especificación técnica:** [[EETT-01.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-01.04]] · costo unitario S/ 1.90 · parcial S/ 952.00 (ver [[PRESUPUESTO_R01]])
