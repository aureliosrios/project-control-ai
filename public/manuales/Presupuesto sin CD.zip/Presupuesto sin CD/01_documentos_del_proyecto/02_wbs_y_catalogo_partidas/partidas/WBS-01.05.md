---
tipo: "wbs_partida"
codigo: "01.05"
capitulo: "01.00"
unidad: "glb"
metrado: 1.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-01.05 — Protección y desvío de interferencias de redes de servicios públicos (SEDAPAL/ENEL)

Capítulo: [[WBS-01.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** glb / 1.0
- **Regla de medición:** Suma global por apuntalamiento y protección de redes aéreas y matrices.
- **Ubicación (planilla maestra):** Nivel Terreno (±0.00) · Frente de Calle · Eje A / Jr. Las Gardenias
- **Especificación técnica:** [[EETT-01.05]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-01.05]] · costo unitario S/ 6,865.60 · parcial S/ 6,865.60 (ver [[PRESUPUESTO_R01]])
