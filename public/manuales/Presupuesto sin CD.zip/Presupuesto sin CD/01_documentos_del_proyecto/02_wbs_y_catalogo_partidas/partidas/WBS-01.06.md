---
tipo: "wbs_partida"
codigo: "01.06"
capitulo: "01.00"
unidad: "m2"
metrado: 450.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-01.06 — Limpieza, desbroce manual y acondicionamiento del terreno

Capítulo: [[WBS-01.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 450.0
- **Regla de medición:** Área neta de terreno desbrozado y limpio de basura superficial.
- **Ubicación (planilla maestra):** Nivel Terreno (±0.00) · Área Total · Superficie total del lote
- **Especificación técnica:** [[EETT-01.06]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-01.06]] · costo unitario S/ 4.73 · parcial S/ 2,126.40 (ver [[PRESUPUESTO_R01]])
