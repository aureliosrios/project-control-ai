---
tipo: "wbs_partida"
codigo: "02.01"
capitulo: "02.00"
unidad: "m2"
metrado: 522.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-02.01 — Sostenimiento perimetral con perforadora hidráulica, anclajes Dywidag 32mm L=9m e inyección de lechada

Capítulo: [[WBS-02.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 522.0
- **Regla de medición:** Área de cara expuesta de taludes y muros sostenidos perimetralmente.
- **Ubicación (planilla maestra):** Sótanos 1 y 2 (0.00 a -5.80 m) · Perímetro Excavación · Linderos Eje 1, Eje 6, Eje E
- **Especificación técnica:** [[EETT-02.01]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-02.01]]
- **Resultado:** [[APU-02.01]] · costo unitario S/ 519.03 · parcial S/ 270,935.40 (ver [[PRESUPUESTO_R01]])
