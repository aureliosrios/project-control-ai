---
tipo: "wbs_partida"
codigo: "02.02"
capitulo: "02.00"
unidad: "und"
metrado: 12.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-02.02 — Apuntalamiento provisional de estructuras colindantes con puntales telescópicos Multiprop y vigas HEB

Capítulo: [[WBS-02.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 12.0
- **Regla de medición:** Unidad de puntal telescópico o pie de amigo colocado y arriostrado.
- **Ubicación (planilla maestra):** Sótanos 1 y 2 · Linderos Vecinos · Eje 1 (Jr. Las Gardenias 472) y Eje E (Jr. Los Sauces 475)
- **Especificación técnica:** [[EETT-02.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-02.02]] · costo unitario S/ 453.60 · parcial S/ 5,443.20 (ver [[PRESUPUESTO_R01]])
