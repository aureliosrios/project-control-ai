---
tipo: "wbs_partida"
codigo: "02.03"
capitulo: "02.00"
unidad: "glb"
metrado: 1.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-02.03 — Instrumentación geotécnica: inclinómetros biaxiales profundos (2 und) y piezómetro abierto PZ-1

Capítulo: [[WBS-02.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** glb / 1.0
- **Regla de medición:** Suma global por suministro, perforación, instalación y calibración de instrumentos.
- **Ubicación (planilla maestra):** Subsuelo (0.00 a -12.00 m) · Linderos Críticos · INC-1 (Eje 1-B), INC-2 (Eje E-3), PZ-1 (Eje 6-D)
- **Especificación técnica:** [[EETT-02.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-02.03]] · costo unitario S/ 22,624.00 · parcial S/ 22,624.00 (ver [[PRESUPUESTO_R01]])
