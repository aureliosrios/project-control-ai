---
tipo: "wbs_partida"
codigo: "02.04"
capitulo: "02.00"
unidad: "mes"
metrado: 4.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-02.04 — Monitoreo topográfico continuo de hitos geodésicos en colindancias con estación total (8 hitos)

Capítulo: [[WBS-02.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** mes / 4.0
- **Regla de medición:** Meses de servicio continuo de lecturas topográficas semanales de 8 hitos.
- **Ubicación (planilla maestra):** Sótanos y Medianeras · Colindancias · 4 hitos Eje 1, 4 hitos Eje E
- **Especificación técnica:** [[EETT-02.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-02.04]] · costo unitario S/ 952.00 · parcial S/ 3,808.00 (ver [[PRESUPUESTO_R01]])
