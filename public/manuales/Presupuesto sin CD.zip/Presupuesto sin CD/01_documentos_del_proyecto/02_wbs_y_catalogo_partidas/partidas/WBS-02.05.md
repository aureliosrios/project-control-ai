---
tipo: "wbs_partida"
codigo: "02.05"
capitulo: "02.00"
unidad: "glb"
metrado: 1.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-02.05 — Sistema provisional de bombeo y achique de aguas de escorrentía con electrobomba sumergible 5 HP

Capítulo: [[WBS-02.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** glb / 1.0
- **Regla de medición:** Suma global por motobombas, mangueras y pozo sumidero de drenaje pluvial.
- **Ubicación (planilla maestra):** Fondo Sótano 2 (-5.80 m) · Fondo de Poza · Eje D-2 / Punto bajo provisional
- **Especificación técnica:** [[EETT-02.05]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-02.05]] · costo unitario S/ 7,848.00 · parcial S/ 7,848.00 (ver [[PRESUPUESTO_R01]])
