---
tipo: "wbs_partida"
codigo: "03.01"
capitulo: "03.00"
unidad: "m3"
metrado: 3200.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-03.01 — Excavación masiva con excavadora sobre orugas 200 HP hasta cota -5.80 m

Capítulo: [[WBS-03.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 3,200.0
- **Regla de medición:** Volumen geométrico en banco de excavación a máquina.
- **Ubicación (planilla maestra):** Sótanos 1 y 2 (0.00 a -5.80 m) · Sectores S2-1 y S2-2 · Ejes A-E, 1-6
- **Especificación técnica:** [[EETT-03.01]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-03.01]]
- **Resultado:** [[APU-03.01]] · costo unitario S/ 4.48 · parcial S/ 14,343.20 (ver [[PRESUPUESTO_R01]])
