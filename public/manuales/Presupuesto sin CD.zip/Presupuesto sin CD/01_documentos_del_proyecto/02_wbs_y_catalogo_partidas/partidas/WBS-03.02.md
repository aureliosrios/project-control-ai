---
tipo: "wbs_partida"
codigo: "03.02"
capitulo: "03.00"
unidad: "m3"
metrado: 250.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-03.02 — Excavación manual localizada para zapatas, vigas de cimentación, foso y cisterna

Capítulo: [[WBS-03.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 250.0
- **Regla de medición:** Volumen geométrico de zanjas y pozos excavados a pulso.
- **Ubicación (planilla maestra):** Fondo Cimentación (-5.80 a -7.50 m) · Sectores S2-1 y S2-2 · Zapatas Z-1 a Z-16, Cisterna y Foso Ascensor
- **Especificación técnica:** [[EETT-03.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-03.02]] · costo unitario S/ 53.69 · parcial S/ 13,422.22 (ver [[PRESUPUESTO_R01]])
