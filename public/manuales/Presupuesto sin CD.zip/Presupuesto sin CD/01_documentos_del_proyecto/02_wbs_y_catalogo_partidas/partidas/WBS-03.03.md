---
tipo: "wbs_partida"
codigo: "03.03"
capitulo: "03.00"
unidad: "m3"
metrado: 4100.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-03.03 — Carguío con cargador frontal CAT 950 y eliminación con volquetes de 15 m3 (d=10 km)

Capítulo: [[WBS-03.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 4,100.0
- **Regla de medición:** Volumen esponjado (factor 1.20) de material transportado a botadero oficial.
- **Ubicación (planilla maestra):** Sótanos y Cimentación · General de Obra · Ruta Surquillo a Botadero Autorizado Huaycoloro / Lurín
- **Especificación técnica:** [[EETT-03.03]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-03.03]]
- **Resultado:** [[APU-03.03]] · costo unitario S/ 46.74 · parcial S/ 191,624.89 (ver [[PRESUPUESTO_R01]])
