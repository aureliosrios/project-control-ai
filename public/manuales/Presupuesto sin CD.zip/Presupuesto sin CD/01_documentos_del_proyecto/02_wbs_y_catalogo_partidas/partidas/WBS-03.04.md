---
tipo: "wbs_partida"
codigo: "03.04"
capitulo: "03.00"
unidad: "m3"
metrado: 180.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-03.04 — Relleno compactado con afirmado seleccionado de cantera y plancha vibratoria al 95% PM

Capítulo: [[WBS-03.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 180.0
- **Regla de medición:** Volumen compactado en capas de 20 cm medido en sitio.
- **Ubicación (planilla maestra):** Fondo Cimentación (-5.80 a -5.60 m) · Sectores S2-1 y S2-2 · Costados de zapatas y bajo losa de sótano 2
- **Especificación técnica:** [[EETT-03.04]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-03.04]]
- **Resultado:** [[APU-03.04]] · costo unitario S/ 82.41 · parcial S/ 14,834.62 (ver [[PRESUPUESTO_R01]])
