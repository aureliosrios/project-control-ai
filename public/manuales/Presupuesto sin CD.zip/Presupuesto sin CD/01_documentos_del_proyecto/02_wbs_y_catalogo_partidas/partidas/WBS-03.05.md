---
tipo: "wbs_partida"
codigo: "03.05"
capitulo: "03.00"
unidad: "m2"
metrado: 500.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-03.05 — Perfilado y compactación de fondo de excavación (subrasante) con equipo liviano

Capítulo: [[WBS-03.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 500.0
- **Regla de medición:** Área de fondo de excavación perfilada y compactada con plancha vibratoria.
- **Ubicación (planilla maestra):** Cota Fondo Cimentación (-5.80 m) · Sectores S2-1 y S2-2 · Área completa de fondo de excavación
- **Especificación técnica:** [[EETT-03.05]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-03.05]] · costo unitario S/ 5.24 · parcial S/ 2,621.82 (ver [[PRESUPUESTO_R01]])
