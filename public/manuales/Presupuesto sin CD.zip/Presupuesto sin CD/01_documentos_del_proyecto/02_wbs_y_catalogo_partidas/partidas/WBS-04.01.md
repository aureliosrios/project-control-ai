---
tipo: "wbs_partida"
codigo: "04.01"
capitulo: "04.00"
unidad: "m2"
metrado: 161.2
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-04.01 — Solado de concreto premezclado f'c=140 kg/cm2 e=4" para zapatas, cisterna y fosos

Capítulo: [[WBS-04.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 161.2
- **Regla de medición:** Área efectiva de solado vaciado bajo elementos de cimentación.
- **Ubicación (planilla maestra):** Fondo Cimentación (-5.80 m) · Sectores S2-1 y S2-2 · Bajo Z-1 a Z-16, Cisterna y Foso Ascensor
- **Especificación técnica:** [[EETT-04.01]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-04.01]] · costo unitario S/ 41.47 · parcial S/ 6,684.96 (ver [[PRESUPUESTO_R01]])
