---
tipo: "wbs_partida"
codigo: "04.02"
capitulo: "04.00"
unidad: "m3"
metrado: 120.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-04.02 — Cimientos corridos de concreto premezclado f'c=140 kg/cm2 + 30% piedra grande

Capítulo: [[WBS-04.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 120.0
- **Regla de medición:** Volumen geométrico de zanjas vaciadas con concreto ciclópeo.
- **Ubicación (planilla maestra):** Fondo Cimentación y Piso 1 · Sectores S2-1, S2-2, P1-1 · Bajo muros de albañilería no portante
- **Especificación técnica:** [[EETT-04.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-04.02]] · costo unitario S/ 302.01 · parcial S/ 36,240.86 (ver [[PRESUPUESTO_R01]])
