---
tipo: "wbs_partida"
codigo: "04.03"
capitulo: "04.00"
unidad: "m3"
metrado: 45.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-04.03 — Sobrecimientos de concreto premezclado f'c=175 kg/cm2 + 25% piedra mediana

Capítulo: [[WBS-04.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 45.0
- **Regla de medición:** Volumen geométrico de sobrecimientos vaciados.
- **Ubicación (planilla maestra):** Piso 1 a Piso 6 · Todos los sectores · Sobre cimientos y vigas en ejes de tabiquería
- **Especificación técnica:** [[EETT-04.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-04.03]] · costo unitario S/ 338.22 · parcial S/ 15,220.08 (ver [[PRESUPUESTO_R01]])
