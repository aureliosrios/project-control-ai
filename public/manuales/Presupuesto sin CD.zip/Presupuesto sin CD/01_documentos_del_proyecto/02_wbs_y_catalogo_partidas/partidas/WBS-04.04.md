---
tipo: "wbs_partida"
codigo: "04.04"
capitulo: "04.00"
unidad: "m2"
metrado: 180.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-04.04 — Encofrado y desencofrado modular metálico con tablero fenólico para sobrecimientos

Capítulo: [[WBS-04.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 180.0
- **Regla de medición:** Área de contacto de madera con el concreto en ambas caras.
- **Ubicación (planilla maestra):** Piso 1 a Piso 6 · Todos los sectores · Ejes de tabiquería
- **Especificación técnica:** [[EETT-04.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-04.04]] · costo unitario S/ 52.57 · parcial S/ 9,462.00 (ver [[PRESUPUESTO_R01]])
