---
tipo: "wbs_partida"
codigo: "05.01"
capitulo: "05.00"
unidad: "m3"
metrado: 83.76
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-05.01 — Zapatas: Concreto premezclado f'c=210 kg/cm2 vaciado con bomba telescópica

Capítulo: [[WBS-05.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 83.76
- **Regla de medición:** Volumen geométrico de zapatas según planos estructurales.
- **Ubicación (planilla maestra):** Fondo Cimentación (-5.80 m) · Sectores S2-1 y S2-2 · Zapatas aisladas y combinadas en ejes A-E, 1-6
- **Especificación técnica:** [[EETT-05.01]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-05.01]] · costo unitario S/ 493.30 · parcial S/ 41,318.57 (ver [[PRESUPUESTO_R01]])
