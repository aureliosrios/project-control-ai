---
tipo: "wbs_partida"
codigo: "05.02"
capitulo: "05.00"
unidad: "m2"
metrado: 137.44
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-05.02 — Zapatas: Encofrado y desencofrado modular metálico

Capítulo: [[WBS-05.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 137.44
- **Regla de medición:** Área lateral de contacto de zapatas encofradas.
- **Ubicación (planilla maestra):** Fondo Cimentación (-5.80 m) · Sectores S2-1 y S2-2 · Perímetro exterior de Z-1 a Z-16
- **Especificación técnica:** [[EETT-05.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-05.02]] · costo unitario S/ 52.57 · parcial S/ 7,224.76 (ver [[PRESUPUESTO_R01]])
