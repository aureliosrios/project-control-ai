---
tipo: "wbs_partida"
codigo: "05.03"
capitulo: "05.00"
unidad: "kg"
metrado: 7119.6
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-05.03 — Zapatas: Acero de refuerzo corrugado fy=4200 kg/cm2 Grado 60 habilitado en banco CNC

Capítulo: [[WBS-05.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** kg / 7,119.6
- **Regla de medición:** Peso nominal en kilogramos según planilla de doblado y despiece.
- **Ubicación (planilla maestra):** Fondo Cimentación (-5.80 m) · Sectores S2-1 y S2-2 · Zapatas Z-1 a Z-16
- **Especificación técnica:** [[EETT-05.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-05.03]] · costo unitario S/ 6.14 · parcial S/ 43,721.46 (ver [[PRESUPUESTO_R01]])
