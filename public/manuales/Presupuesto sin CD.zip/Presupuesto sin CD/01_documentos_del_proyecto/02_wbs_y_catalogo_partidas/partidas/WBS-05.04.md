---
tipo: "wbs_partida"
codigo: "05.04"
capitulo: "05.00"
unidad: "m3"
metrado: 58.52
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-05.04 — Vigas de cimentación y amarre: Concreto premezclado f'c=210 kg/cm2 con bomba

Capítulo: [[WBS-05.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 58.52
- **Regla de medición:** Volumen geométrico de vigas de cimentación vaciadas.
- **Ubicación (planilla maestra):** Fondo Cimentación (-5.80 m) · Sectores S2-1 y S2-2 · Ejes 1-6 y A-E
- **Especificación técnica:** [[EETT-05.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-05.04]] · costo unitario S/ 493.30 · parcial S/ 28,867.75 (ver [[PRESUPUESTO_R01]])
