---
tipo: "wbs_partida"
codigo: "05.05"
capitulo: "05.00"
unidad: "m2"
metrado: 258.4
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-05.05 — Vigas de cimentación y amarre: Encofrado y desencofrado modular fenólico 18mm

Capítulo: [[WBS-05.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 258.4
- **Regla de medición:** Área de contacto lateral de encofrado.
- **Ubicación (planilla maestra):** Fondo Cimentación (-5.80 m) · Sectores S2-1 y S2-2 · Ejes 1-6 y A-E
- **Especificación técnica:** [[EETT-05.05]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-05.05]] · costo unitario S/ 66.97 · parcial S/ 17,304.18 (ver [[PRESUPUESTO_R01]])
