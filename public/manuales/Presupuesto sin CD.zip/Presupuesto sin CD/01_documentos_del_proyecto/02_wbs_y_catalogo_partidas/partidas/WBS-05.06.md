---
tipo: "wbs_partida"
codigo: "05.06"
capitulo: "05.00"
unidad: "kg"
metrado: 6437.2
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-05.06 — Vigas de cimentación y amarre: Acero de refuerzo fy=4200 kg/cm2 Grado 60

Capítulo: [[WBS-05.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** kg / 6,437.2
- **Regla de medición:** Peso nominal de varillas longitudinales y estribos colocados.
- **Ubicación (planilla maestra):** Fondo Cimentación (-5.80 m) · Sectores S2-1 y S2-2 · Ejes 1-6 y A-E
- **Especificación técnica:** [[EETT-05.06]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-05.06]] · costo unitario S/ 6.14 · parcial S/ 39,530.85 (ver [[PRESUPUESTO_R01]])
