---
tipo: "wbs_partida"
codigo: "06.01"
capitulo: "06.00"
unidad: "m3"
metrado: 156.6
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-06.01 — Muros de contención / pantalla: Concreto premezclado f'c=280 kg/cm2 con bomba

Capítulo: [[WBS-06.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 156.6
- **Regla de medición:** Volumen geométrico de muros perimetrales vaciados.
- **Ubicación (planilla maestra):** Sótanos 1 y 2 (-5.80 a ±0.00 m) · Sectores S2-1, S2-2, S1-1, S1-2 · Perímetro Ejes 1, 6, E y A
- **Especificación técnica:** [[EETT-06.01]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-06.01]]
- **Resultado:** [[APU-06.01]] · costo unitario S/ 539.65 · parcial S/ 84,508.74 (ver [[PRESUPUESTO_R01]])
