---
tipo: "wbs_partida"
codigo: "06.02"
capitulo: "06.00"
unidad: "m2"
metrado: 1044.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-06.02 — Muros de contención / pantalla: Encofrado modular fenólico a dos caras con sistema de trepa

Capítulo: [[WBS-06.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 1,044.0
- **Regla de medición:** Área de contacto de encofrado metálico/fenólico en ambas caras.
- **Ubicación (planilla maestra):** Sótanos 1 y 2 · Sectores S2-1 a S1-2 · Perímetro completo
- **Especificación técnica:** [[EETT-06.02]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-06.02]]
- **Resultado:** [[APU-06.02]] · costo unitario S/ 52.57 · parcial S/ 54,879.60 (ver [[PRESUPUESTO_R01]])
