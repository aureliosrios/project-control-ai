---
tipo: "wbs_partida"
codigo: "06.03"
capitulo: "06.00"
unidad: "kg"
metrado: 14094.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-06.03 — Muros de contención / pantalla: Acero de refuerzo fy=4200 kg/cm2 Grado 60

Capítulo: [[WBS-06.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** kg / 14,094.0
- **Regla de medición:** Peso nominal de malla doble de refuerzo y bastones.
- **Ubicación (planilla maestra):** Sótanos 1 y 2 · Sectores S2-1 a S1-2 · Muros perimetrales MC-1 a MC-4
- **Especificación técnica:** [[EETT-06.03]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-06.03]]
- **Resultado:** [[APU-06.03]] · costo unitario S/ 6.14 · parcial S/ 86,551.25 (ver [[PRESUPUESTO_R01]])
