---
tipo: "wbs_partida"
codigo: "06.04"
capitulo: "06.00"
unidad: "m2"
metrado: 500.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-06.04 — Losa de contacto de Sótano 2 e=15 cm concreto premezclado f'c=210 sobre lámina de polietileno HDPE 8 mils

Capítulo: [[WBS-06.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 500.0
- **Regla de medición:** Área superficial de losa de fondo de sótano con frotachado mecánico.
- **Ubicación (planilla maestra):** Sótano 2 (-5.60 m) · Sectores S2-1 y S2-2 · Área de estacionamientos y circulación
- **Especificación técnica:** [[EETT-06.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-06.04]] · costo unitario S/ 85.77 · parcial S/ 42,885.01 (ver [[PRESUPUESTO_R01]])
