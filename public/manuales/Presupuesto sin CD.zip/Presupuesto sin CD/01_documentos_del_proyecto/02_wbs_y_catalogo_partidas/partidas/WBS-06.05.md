---
tipo: "wbs_partida"
codigo: "06.05"
capitulo: "06.00"
unidad: "m3"
metrado: 42.5
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-06.05 — Cisterna y cuarto de bombas: Estructura monolítica de concreto premezclado f'c=280 con impermeabilizante y waterstop

Capítulo: [[WBS-06.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 42.5
- **Regla de medición:** Suma global por concreto, encofrado y acero de cuba de cisterna 45 m3.
- **Ubicación (planilla maestra):** Bajo Sótano 2 (-7.50 a -5.60 m) · Sector S2-1 · Ejes D-E, 1-2 (Capacidad 45 m³)
- **Especificación técnica:** [[EETT-06.05]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-06.05]]
- **Resultado:** [[APU-06.05]] · costo unitario S/ 588.11 · parcial S/ 24,994.51 (ver [[PRESUPUESTO_R01]])
