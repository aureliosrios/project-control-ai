---
tipo: "wbs_partida"
codigo: "06.06"
capitulo: "06.00"
unidad: "m2"
metrado: 168.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-06.06 — Cisterna y cuarto de bombas: Encofrado modular fenólico impermeable

Capítulo: [[WBS-06.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 168.0
- **Regla de medición:** Suma global por foso y sobre-recorrido de ascensor con sello estanco.
- **Ubicación (planilla maestra):** Fondo Foso (-7.00 a -5.60 m) · Sector S2-2 · Ejes B-C, 3-4
- **Especificación técnica:** [[EETT-06.06]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-06.06]] · costo unitario S/ 52.57 · parcial S/ 8,831.20 (ver [[PRESUPUESTO_R01]])
