---
tipo: "wbs_partida"
codigo: "06.07"
capitulo: "06.00"
unidad: "m2"
metrado: 125.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-06.07 — Rampa vehicular estructural: Losa inclinada e=18 cm concreto f'c=210 con acabado endurecido antideslizante

Capítulo: [[WBS-06.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 125.0
- **Regla de medición:** Área en planta desarrollada de rampa con acabado peinado.
- **Ubicación (planilla maestra):** Sótanos 1 y 2 · Sectores S2-1 y S1-1 · Ejes A-B, 5-6
- **Especificación técnica:** [[EETT-06.07]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-06.07]] · costo unitario S/ 118.86 · parcial S/ 14,857.50 (ver [[PRESUPUESTO_R01]])
