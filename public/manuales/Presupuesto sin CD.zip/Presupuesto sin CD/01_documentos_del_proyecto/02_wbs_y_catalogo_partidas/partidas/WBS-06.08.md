---
tipo: "wbs_partida"
codigo: "06.08"
capitulo: "06.00"
unidad: "m"
metrado: 180.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-06.08 — Sellos hidroexpansivos SikaSwell y cinta waterstop de PVC 6" en juntas frías de sótanos

Capítulo: [[WBS-06.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 180.0
- **Regla de medición:** Metro lineal de junta sellada estancamente.
- **Ubicación (planilla maestra):** Sótanos 1 y 2 · Sectores S2-1 a S1-2 · Juntas de cimentación con muros y pases
- **Especificación técnica:** [[EETT-06.08]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-06.08]] · costo unitario S/ 103.73 · parcial S/ 18,670.80 (ver [[PRESUPUESTO_R01]])
