---
tipo: "wbs_partida"
codigo: "07.01"
capitulo: "07.00"
unidad: "m3"
metrado: 48.6
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-07.01 — Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 48.6
- **Regla de medición:** Volumen geométrico de columnas del Piso 1 al Piso 6.
- **Ubicación (planilla maestra):** Pisos 1 al 6 · Sectores P1-1 a P6-2 (12 sectores) · Ejes A-E, 1-6
- **Especificación técnica:** [[EETT-07.01]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-07.01]] · costo unitario S/ 539.65 · parcial S/ 26,226.85 (ver [[PRESUPUESTO_R01]])
