---
tipo: "wbs_partida"
codigo: "07.02"
capitulo: "07.00"
unidad: "m2"
metrado: 324.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-07.02 — Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 324.0
- **Regla de medición:** Área de cara de contacto de columnas.
- **Ubicación (planilla maestra):** Pisos 1 al 6 · Sectores P1-1 a P6-2 · Ejes A-E, 1-6
- **Especificación técnica:** [[EETT-07.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-07.02]] · costo unitario S/ 52.57 · parcial S/ 17,031.60 (ver [[PRESUPUESTO_R01]])
