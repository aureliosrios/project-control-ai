---
tipo: "wbs_partida"
codigo: "07.03"
capitulo: "07.00"
unidad: "kg"
metrado: 7290.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-07.03 — Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** kg / 7,290.0
- **Regla de medición:** Peso nominal de barras longitudinales y estribos.
- **Ubicación (planilla maestra):** Pisos 1 al 6 · Sectores P1-1 a P6-2 · Ejes A-E, 1-6
- **Especificación técnica:** [[EETT-07.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-07.03]] · costo unitario S/ 6.14 · parcial S/ 44,767.89 (ver [[PRESUPUESTO_R01]])
