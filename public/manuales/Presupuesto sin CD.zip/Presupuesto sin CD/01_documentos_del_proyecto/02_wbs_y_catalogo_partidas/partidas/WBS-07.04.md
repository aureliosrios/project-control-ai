---
tipo: "wbs_partida"
codigo: "07.04"
capitulo: "07.00"
unidad: "m3"
metrado: 72.9
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-07.04 — Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 72.9
- **Regla de medición:** Volumen de concreto premezclado vaciado en muros de corte.
- **Ubicación (planilla maestra):** Pisos 1 al 6 · Sectores P1-1 a P6-2 · Ejes 1, 6, C, D
- **Especificación técnica:** [[EETT-07.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-07.04]] · costo unitario S/ 539.65 · parcial S/ 39,340.28 (ver [[PRESUPUESTO_R01]])
