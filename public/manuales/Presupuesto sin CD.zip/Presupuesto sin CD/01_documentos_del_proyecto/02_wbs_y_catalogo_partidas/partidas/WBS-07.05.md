---
tipo: "wbs_partida"
codigo: "07.05"
capitulo: "07.00"
unidad: "m2"
metrado: 486.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-07.05 — Placas de concreto armado: Encofrado modular fenólico trepante

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 486.0
- **Regla de medición:** Área de contacto a dos caras de placas.
- **Ubicación (planilla maestra):** Pisos 1 al 6 · Sectores P1-1 a P6-2 · Ejes 1, 6, C, D
- **Especificación técnica:** [[EETT-07.05]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-07.05]] · costo unitario S/ 52.57 · parcial S/ 25,547.40 (ver [[PRESUPUESTO_R01]])
