---
tipo: "wbs_partida"
codigo: "07.06"
capitulo: "07.00"
unidad: "kg"
metrado: 8748.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-07.06 — Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** kg / 8,748.0
- **Regla de medición:** Peso nominal de acero corrugado colocado.
- **Ubicación (planilla maestra):** Pisos 1 al 6 · Sectores P1-1 a P6-2 · Ejes 1, 6, C, D
- **Especificación técnica:** [[EETT-07.06]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-07.06]]
- **Resultado:** [[APU-07.06]] · costo unitario S/ 6.14 · parcial S/ 53,721.47 (ver [[PRESUPUESTO_R01]])
