---
tipo: "wbs_partida"
codigo: "07.07"
capitulo: "07.00"
unidad: "m3"
metrado: 126.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-07.07 — Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 126.0
- **Regla de medición:** Volumen geométrico de vigas principales y de amarre.
- **Ubicación (planilla maestra):** Pisos 1 al 6 y Techos Sótanos · Todos los sectores (16 sectores) · Ejes A-E, 1-6 en todos los techos
- **Especificación técnica:** [[EETT-07.07]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-07.07]]
- **Resultado:** [[APU-07.07]] · costo unitario S/ 493.30 · parcial S/ 62,155.44 (ver [[PRESUPUESTO_R01]])
