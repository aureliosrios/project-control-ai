---
tipo: "wbs_partida"
codigo: "07.08"
capitulo: "07.00"
unidad: "m2"
metrado: 560.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-07.08 — Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 560.0
- **Regla de medición:** Área de fondo y laterales de vigas.
- **Ubicación (planilla maestra):** Pisos 1 al 6 y Sótanos · Todos los sectores · Ejes A-E, 1-6
- **Especificación técnica:** [[EETT-07.08]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-07.08]] · costo unitario S/ 66.97 · parcial S/ 37,501.33 (ver [[PRESUPUESTO_R01]])
