---
tipo: "wbs_partida"
codigo: "07.09"
capitulo: "07.00"
unidad: "kg"
metrado: 15120.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-07.09 — Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** kg / 15,120.0
- **Regla de medición:** Peso nominal de acero colocado en vigas.
- **Ubicación (planilla maestra):** Pisos 1 al 6 y Sótanos · Todos los sectores · Ejes A-E, 1-6
- **Especificación técnica:** [[EETT-07.09]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-07.09]]
- **Resultado:** [[APU-07.09]] · costo unitario S/ 6.14 · parcial S/ 92,851.92 (ver [[PRESUPUESTO_R01]])
