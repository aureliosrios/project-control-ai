---
tipo: "wbs_partida"
codigo: "07.10"
capitulo: "07.00"
unidad: "m3"
metrado: 210.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-07.10 — Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 210.0
- **Regla de medición:** Volumen de concreto en viguetas y loseta superior de 5 cm.
- **Ubicación (planilla maestra):** Pisos 1 al 6 y Sótanos · Todos los sectores · Paños de losa entre vigas
- **Especificación técnica:** [[EETT-07.10]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-07.10]]
- **Resultado:** [[APU-07.10]] · costo unitario S/ 493.30 · parcial S/ 103,592.40 (ver [[PRESUPUESTO_R01]])
