---
tipo: "wbs_partida"
codigo: "07.11"
capitulo: "07.00"
unidad: "m2"
metrado: 2400.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-07.11 — Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 2,400.0
- **Regla de medición:** Área en planta de fondo de losas aligeradas encofradas.
- **Ubicación (planilla maestra):** Pisos 1 al 6 y Sótanos · Todos los sectores · Área de techo
- **Especificación técnica:** [[EETT-07.11]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-07.11]]
- **Resultado:** [[APU-07.11]] · costo unitario S/ 66.97 · parcial S/ 160,720.00 (ver [[PRESUPUESTO_R01]])
