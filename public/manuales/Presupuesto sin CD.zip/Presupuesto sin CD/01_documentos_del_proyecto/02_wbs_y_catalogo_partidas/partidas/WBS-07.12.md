---
tipo: "wbs_partida"
codigo: "07.12"
capitulo: "07.00"
unidad: "kg"
metrado: 12600.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-07.12 — Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** kg / 12,600.0
- **Regla de medición:** Peso nominal de acero positivo, negativo y temperatura.
- **Ubicación (planilla maestra):** Pisos 1 al 6 y Sótanos · Todos los sectores · Viguetas y loseta superior
- **Especificación técnica:** [[EETT-07.12]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-07.12]]
- **Resultado:** [[APU-07.12]] · costo unitario S/ 6.14 · parcial S/ 77,376.60 (ver [[PRESUPUESTO_R01]])
