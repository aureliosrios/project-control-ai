---
tipo: "wbs_partida"
codigo: "07.13"
capitulo: "07.00"
unidad: "und"
metrado: 20400.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-07.13 — Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 20,400.0
- **Regla de medición:** Conteo total de unidades de ladrillo hueco colocadas (8.33 und/m2).
- **Ubicación (planilla maestra):** Pisos 1 al 6 y Sótanos · Todos los sectores · Entre viguetas de losa e=20cm
- **Especificación técnica:** [[EETT-07.13]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-07.13]]
- **Resultado:** [[APU-07.13]] · costo unitario S/ 7.45 · parcial S/ 151,918.80 (ver [[PRESUPUESTO_R01]])
