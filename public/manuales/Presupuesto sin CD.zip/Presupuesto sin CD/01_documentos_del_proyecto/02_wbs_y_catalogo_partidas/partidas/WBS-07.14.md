---
tipo: "wbs_partida"
codigo: "07.14"
capitulo: "07.00"
unidad: "m3"
metrado: 18.9
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-07.14 — Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 18.9
- **Regla de medición:** Volumen geométrico de rampas y descansos de escaleras.
- **Ubicación (planilla maestra):** Sótanos a Azotea (9 niveles) · Sectores S2-1 a AZ-2 · Núcleos EA-1 (Ejes B-C, 1-2) y EA-2 (Ejes D-E, 5-6)
- **Especificación técnica:** [[EETT-07.14]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-07.14]] · costo unitario S/ 493.30 · parcial S/ 9,323.32 (ver [[PRESUPUESTO_R01]])
