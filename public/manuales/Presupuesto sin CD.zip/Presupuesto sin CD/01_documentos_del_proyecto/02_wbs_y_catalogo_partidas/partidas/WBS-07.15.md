---
tipo: "wbs_partida"
codigo: "07.15"
capitulo: "07.00"
unidad: "m2"
metrado: 108.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-07.15 — Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 108.0
- **Regla de medición:** Área de fondos, contrapasos y costados de escaleras.
- **Ubicación (planilla maestra):** Sótanos a Azotea · Sectores EA-1 y EA-2 · Núcleos de escape
- **Especificación técnica:** [[EETT-07.15]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-07.15]] · costo unitario S/ 52.57 · parcial S/ 5,677.20 (ver [[PRESUPUESTO_R01]])
