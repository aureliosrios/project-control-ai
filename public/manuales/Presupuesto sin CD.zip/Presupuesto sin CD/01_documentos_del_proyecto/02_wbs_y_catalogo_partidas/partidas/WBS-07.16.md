---
tipo: "wbs_partida"
codigo: "07.16"
capitulo: "07.00"
unidad: "kg"
metrado: 2457.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-07.16 — Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60

Capítulo: [[WBS-07.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** kg / 2,457.0
- **Regla de medición:** Peso nominal de acero longitudinal y transversal de escaleras.
- **Ubicación (planilla maestra):** Sótanos a Azotea · Sectores EA-1 y EA-2 · Núcleos de escape
- **Especificación técnica:** [[EETT-07.16]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-07.16]] · costo unitario S/ 6.14 · parcial S/ 15,088.44 (ver [[PRESUPUESTO_R01]])
