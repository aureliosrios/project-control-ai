---
tipo: "wbs_partida"
codigo: "08.01"
capitulo: "08.00"
unidad: "m2"
metrado: 500.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-08.01 — Losa de techo de azotea e=20 cm concreto premezclado f'c=210 con membrana asfáltica e=3mm

Capítulo: [[WBS-08.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 500.0
- **Regla de medición:** Área superficial de losa de azotea acabada.
- **Ubicación (planilla maestra):** Azotea (+19.50 m) · Sectores AZ-1 y AZ-2 · Ejes A-E, 1-6
- **Especificación técnica:** [[EETT-08.01]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-08.01]]
- **Resultado:** [[APU-08.01]] · costo unitario S/ 138.19 · parcial S/ 69,095.26 (ver [[PRESUPUESTO_R01]])
