---
tipo: "wbs_partida"
codigo: "08.02"
capitulo: "08.00"
unidad: "m"
metrado: 90.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-08.02 — Parapeto perimetral de concreto armado f'c=210 h=1.10 m en azotea

Capítulo: [[WBS-08.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 90.0
- **Regla de medición:** Metro lineal de parapeto vaciado y desencofrado.
- **Ubicación (planilla maestra):** Azotea (+19.50 a +20.70 m) · Sectores AZ-1 y AZ-2 · Perímetro completo de azotea
- **Especificación técnica:** [[EETT-08.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-08.02]] · costo unitario S/ 246.56 · parcial S/ 22,190.00 (ver [[PRESUPUESTO_R01]])
