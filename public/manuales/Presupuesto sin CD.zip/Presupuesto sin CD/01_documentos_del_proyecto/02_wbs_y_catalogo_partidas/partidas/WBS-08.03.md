---
tipo: "wbs_partida"
codigo: "08.03"
capitulo: "08.00"
unidad: "m3"
metrado: 12.5
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-08.03 — Caseta de sala de máquinas de ascensor y cuarto técnico de bombas en concreto f'c=280

Capítulo: [[WBS-08.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 12.5
- **Regla de medición:** Suma global por estructura elevada en azotea para equipos técnicos.
- **Ubicación (planilla maestra):** Sobre Azotea (+22.40 m) · Sector AZ-2 · Ejes B-C, 3-4
- **Especificación técnica:** [[EETT-08.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-08.03]] · costo unitario S/ 1,190.45 · parcial S/ 14,880.62 (ver [[PRESUPUESTO_R01]])
