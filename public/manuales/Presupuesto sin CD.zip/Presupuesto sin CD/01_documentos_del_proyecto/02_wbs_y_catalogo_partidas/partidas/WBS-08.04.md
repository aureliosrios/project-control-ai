---
tipo: "wbs_partida"
codigo: "08.04"
capitulo: "08.00"
unidad: "m"
metrado: 65.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-08.04 — Juntas de dilatación sísmica perimetral con tecnopor de 1" y sellador elastomérico de poliuretano

Capítulo: [[WBS-08.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 65.0
- **Regla de medición:** Área neta tratada con imprimante y manto termosellado 4 mm.
- **Ubicación (planilla maestra):** Azotea y Caseta · Sectores AZ-1 y AZ-2 · Áreas críticas de azotea y cuartos técnicos
- **Especificación técnica:** [[EETT-08.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-08.04]] · costo unitario S/ 25.95 · parcial S/ 1,686.53 (ver [[PRESUPUESTO_R01]])
