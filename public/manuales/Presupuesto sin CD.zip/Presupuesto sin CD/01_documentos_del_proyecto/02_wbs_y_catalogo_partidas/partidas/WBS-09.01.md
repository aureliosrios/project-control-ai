---
tipo: "wbs_partida"
codigo: "09.01"
capitulo: "09.00"
unidad: "m2"
metrado: 1850.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-09.01 — Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga

Capítulo: [[WBS-09.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 1,850.0
- **Regla de medición:** Área de tabiques levantados con mortero 1:4 e=1.5 cm.
- **Ubicación (planilla maestra):** Pisos 1 al 6 y Sótanos · Todos los sectores (16 sectores) · Distribución interna de ambientes educativos
- **Especificación técnica:** [[EETT-09.01]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-09.01]]
- **Resultado:** [[APU-09.01]] · costo unitario S/ 117.34 · parcial S/ 217,084.29 (ver [[PRESUPUESTO_R01]])
