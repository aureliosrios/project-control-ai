---
tipo: "wbs_partida"
codigo: "09.02"
capitulo: "09.00"
unidad: "m3"
metrado: 28.5
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-09.02 — Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070)

Capítulo: [[WBS-09.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m3 / 28.5
- **Regla de medición:** Volumen de concreto f'c=175 vaciado en confinamientos.
- **Ubicación (planilla maestra):** Pisos 1 al 6 · Sectores P1-1 a P6-2 · Extremos libres de tabiquería y sobre vanos
- **Especificación técnica:** [[EETT-09.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-09.02]] · costo unitario S/ 961.51 · parcial S/ 27,402.94 (ver [[PRESUPUESTO_R01]])
