---
tipo: "wbs_partida"
codigo: "09.03"
capitulo: "09.00"
unidad: "m2"
metrado: 195.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-09.03 — Encofrado y desencofrado modular para columnetas y vigas de amarre

Capítulo: [[WBS-09.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m2 / 195.0
- **Regla de medición:** Metro lineal de dintel vaciado con apoyo mínimo 20 cm.
- **Ubicación (planilla maestra):** Pisos 1 al 6 · Sectores P1-1 a P6-2 · Sobre vanos de puertas y ventanas
- **Especificación técnica:** [[EETT-09.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-09.03]] · costo unitario S/ 66.97 · parcial S/ 13,058.50 (ver [[PRESUPUESTO_R01]])
