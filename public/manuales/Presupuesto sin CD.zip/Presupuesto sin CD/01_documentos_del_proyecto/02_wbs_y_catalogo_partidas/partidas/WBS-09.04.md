---
tipo: "wbs_partida"
codigo: "09.04"
capitulo: "09.00"
unidad: "m"
metrado: 420.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-09.04 — Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex

Capítulo: [[WBS-09.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 420.0
- **Regla de medición:** Área superficial perfilada y resanada con mortero fino.
- **Ubicación (planilla maestra):** Sótanos a Azotea · Todos los sectores · Columnas, placas, vigas y muros de contención
- **Especificación técnica:** [[EETT-09.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-09.04]] · costo unitario S/ 25.95 · parcial S/ 10,897.61 (ver [[PRESUPUESTO_R01]])
