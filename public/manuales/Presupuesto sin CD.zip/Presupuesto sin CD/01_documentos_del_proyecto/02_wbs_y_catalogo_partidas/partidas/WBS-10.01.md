---
tipo: "wbs_partida"
codigo: "10.01"
capitulo: "10.00"
unidad: "und"
metrado: 96.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-10.01 — Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado)

Capítulo: [[WBS-10.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 96.0
- **Regla de medición:** Conteo de sleeves de PVC instalados rígidamente antes de vaciar.
- **Ubicación (planilla maestra):** Sótanos a Piso 6 · Todos los sectores · Tercio central de vigas peraltadas y losas aligeradas
- **Especificación técnica:** [[EETT-10.01]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-10.01]] · costo unitario S/ 69.52 · parcial S/ 6,674.13 (ver [[PRESUPUESTO_R01]])
