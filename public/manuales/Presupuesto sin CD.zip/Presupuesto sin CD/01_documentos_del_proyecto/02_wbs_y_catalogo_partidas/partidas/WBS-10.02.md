---
tipo: "wbs_partida"
codigo: "10.02"
capitulo: "10.00"
unidad: "m"
metrado: 280.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-10.02 — Red colectora de desagüe colgada PVC SAL 4" y 2" en sótanos

Capítulo: [[WBS-10.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 280.0
- **Regla de medición:** Conteo de bridas metálicas/PVC fijadas con waterstop.
- **Ubicación (planilla maestra):** Sótanos 1 y 2 y Cisterna · Sectores S2-1, S2-2, S1-1 · Muros de contención y paredes de cisterna
- **Especificación técnica:** [[EETT-10.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-10.02]] · costo unitario S/ 52.95 · parcial S/ 14,825.06 (ver [[PRESUPUESTO_R01]])
