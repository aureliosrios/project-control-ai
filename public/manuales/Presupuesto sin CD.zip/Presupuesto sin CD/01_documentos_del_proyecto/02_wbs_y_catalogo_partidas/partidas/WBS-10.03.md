---
tipo: "wbs_partida"
codigo: "10.03"
capitulo: "10.00"
unidad: "m"
metrado: 195.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-10.03 — Montantes de ventilación y desagüe vertical PVC SAL 4"

Capítulo: [[WBS-10.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 195.0
- **Regla de medición:** Metro lineal de tubería montante vertical colocada.
- **Ubicación (planilla maestra):** Sótanos a Azotea (9 niveles) · Ductos Sanitarios · Ductos en SSHH Ejes B-2 y D-5
- **Especificación técnica:** [[EETT-10.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-10.03]] · costo unitario S/ 52.95 · parcial S/ 10,324.60 (ver [[PRESUPUESTO_R01]])
