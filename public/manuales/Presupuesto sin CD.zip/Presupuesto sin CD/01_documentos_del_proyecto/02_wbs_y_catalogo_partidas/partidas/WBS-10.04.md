---
tipo: "wbs_partida"
codigo: "10.04"
capitulo: "10.00"
unidad: "und"
metrado: 24.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-10.04 — Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje

Capítulo: [[WBS-10.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 24.0
- **Regla de medición:** Conteo de puntos de captación embebidos en losas.
- **Ubicación (planilla maestra):** Sótanos y Azotea · Sectores S2-1, S2-2, AZ-1, AZ-2 · Fondo de rampa, estacionamientos y azotea
- **Especificación técnica:** [[EETT-10.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-10.04]] · costo unitario S/ 413.80 · parcial S/ 9,931.20 (ver [[PRESUPUESTO_R01]])
