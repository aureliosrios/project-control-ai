---
tipo: "wbs_partida"
codigo: "10.05"
capitulo: "10.00"
unidad: "m"
metrado: 350.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-10.05 — Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM

Capítulo: [[WBS-10.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 350.0
- **Regla de medición:** Suma global por pruebas de presión manométrica a 100 psi en faena.
- **Ubicación (planilla maestra):** Todos los niveles · Todos los sectores · Redes embebidas en losas y placas
- **Especificación técnica:** [[EETT-10.05]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-10.05]]
- **Resultado:** [[APU-10.05]] · costo unitario S/ 150.75 · parcial S/ 52,761.33 (ver [[PRESUPUESTO_R01]])
