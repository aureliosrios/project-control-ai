---
tipo: "wbs_partida"
codigo: "11.01"
capitulo: "11.00"
unidad: "und"
metrado: 120.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-11.01 — Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos

Capítulo: [[WBS-11.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 120.0
- **Regla de medición:** Metro lineal de cable de cobre desnudo soldado a zapatas.
- **Ubicación (planilla maestra):** Cimentación (-5.80 m) · Sectores S2-1 y S2-2 · Zapatas y vigas de cimentación perimetrales
- **Especificación técnica:** [[EETT-11.01]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-11.01]] · costo unitario S/ 69.52 · parcial S/ 8,342.66 (ver [[PRESUPUESTO_R01]])
