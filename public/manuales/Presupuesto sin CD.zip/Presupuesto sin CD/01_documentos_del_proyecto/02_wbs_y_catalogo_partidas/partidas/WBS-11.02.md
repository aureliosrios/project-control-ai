---
tipo: "wbs_partida"
codigo: "11.02"
capitulo: "11.00"
unidad: "m"
metrado: 1850.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-11.02 — Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados

Capítulo: [[WBS-11.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 1,850.0
- **Regla de medición:** Metro lineal de tubería conduit asegurada a armadura de acero.
- **Ubicación (planilla maestra):** Sótanos a Azotea (9 niveles) · Todos los sectores (18 sectores) · Embebidos en losas aligeradas y placas
- **Especificación técnica:** [[EETT-11.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-11.02]] · costo unitario S/ 18.47 · parcial S/ 34,174.87 (ver [[PRESUPUESTO_R01]])
