---
tipo: "wbs_partida"
codigo: "11.03"
capitulo: "11.00"
unidad: "m"
metrado: 3200.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-11.03 — Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco)

Capítulo: [[WBS-11.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 3,200.0
- **Regla de medición:** Conteo de cajas fijadas y selladas contra ingreso de lechada.
- **Ubicación (planilla maestra):** Sótanos a Azotea · Todos los sectores · Techos y muros
- **Especificación técnica:** [[EETT-11.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-11.03]] · costo unitario S/ 8.76 · parcial S/ 28,025.15 (ver [[PRESUPUESTO_R01]])
