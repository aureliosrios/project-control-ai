---
tipo: "wbs_partida"
codigo: "11.04"
capitulo: "11.00"
unidad: "und"
metrado: 210.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-11.04 — Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza

Capítulo: [[WBS-11.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 210.0
- **Regla de medición:** Conteo de pases verticales para ductería de alta y baja tensión.
- **Ubicación (planilla maestra):** Sótanos a Azotea · Ductos Técnicos · Shaft eléctrico Eje C-2
- **Especificación técnica:** [[EETT-11.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-11.04]] · costo unitario S/ 47.04 · parcial S/ 9,878.40 (ver [[PRESUPUESTO_R01]])
