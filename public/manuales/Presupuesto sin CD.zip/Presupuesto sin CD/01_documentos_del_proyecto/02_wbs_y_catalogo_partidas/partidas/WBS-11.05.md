---
tipo: "wbs_partida"
codigo: "11.05"
capitulo: "11.00"
unidad: "und"
metrado: 4.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-11.05 — Sistema de puesta a tierra integral de baja resistencia (< 5 ohmios) en foso de sótanos

Capítulo: [[WBS-11.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 4.0
- **Regla de medición:** Metro lineal de conduit exclusivo para corrientes débiles.
- **Ubicación (planilla maestra):** Sótanos a Azotea · Todos los sectores · Losas y tabiques hacia sala de servidores (MDF)
- **Especificación técnica:** [[EETT-11.05]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-11.05]]
- **Resultado:** [[APU-11.05]] · costo unitario S/ 3,582.80 · parcial S/ 14,331.20 (ver [[PRESUPUESTO_R01]])
