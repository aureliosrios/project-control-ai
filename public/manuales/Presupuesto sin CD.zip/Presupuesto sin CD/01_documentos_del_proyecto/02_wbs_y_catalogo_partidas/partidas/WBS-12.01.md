---
tipo: "wbs_partida"
codigo: "12.01"
capitulo: "12.00"
unidad: "und"
metrado: 18.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-12.01 — Pases estructurales coordinados BIM para ductos de presurización de escalera

Capítulo: [[WBS-12.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 18.0
- **Regla de medición:** Conteo de aberturas circulares/rectangulares con marco metálico.
- **Ubicación (planilla maestra):** Pisos 1 al 6 y Sótanos · Sectores EA-1 y EA-2 · Placas de núcleos de escalera EA-1 y EA-2
- **Especificación técnica:** [[EETT-12.01]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-12.01]] · costo unitario S/ 71.74 · parcial S/ 1,291.40 (ver [[PRESUPUESTO_R01]])
