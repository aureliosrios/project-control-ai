---
tipo: "wbs_partida"
codigo: "12.02"
capitulo: "12.00"
unidad: "m"
metrado: 850.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-12.02 — Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72)

Capítulo: [[WBS-12.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** m / 850.0
- **Regla de medición:** Conteo de mangas rectangulares fijadas en encofrados.
- **Ubicación (planilla maestra):** Sótanos 1 y 2 · Sectores S2-1 a S1-2 · Techo de sótanos hacia chimenea de extracción
- **Especificación técnica:** [[EETT-12.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-12.02]] · costo unitario S/ 18.47 · parcial S/ 15,701.97 (ver [[PRESUPUESTO_R01]])
