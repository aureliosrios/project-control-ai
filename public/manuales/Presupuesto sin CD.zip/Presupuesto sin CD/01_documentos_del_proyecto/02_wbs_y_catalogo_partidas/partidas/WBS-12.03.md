---
tipo: "wbs_partida"
codigo: "12.03"
capitulo: "12.00"
unidad: "und"
metrado: 8.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-12.03 — Anclajes y soportes antivibratorios para equipos electromecánicos de bombeo

Capítulo: [[WBS-12.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 8.0
- **Regla de medición:** Conteo de anclajes de acero estructural e insertos empotrados.
- **Ubicación (planilla maestra):** Sótanos a Azotea (9 niveles) · Ductos de Escaleras · Núcleo de escaleras EA-1 y EA-2
- **Especificación técnica:** [[EETT-12.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-12.03]] · costo unitario S/ 810.00 · parcial S/ 6,480.00 (ver [[PRESUPUESTO_R01]])
