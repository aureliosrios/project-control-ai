---
tipo: "wbs_partida"
codigo: "12.04"
capitulo: "12.00"
unidad: "und"
metrado: 64.0
cobertura_02: "DOCUMENTADA"
tags: ["wbs", "proyecto"]
---

# WBS-12.04 — Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego

Capítulo: [[WBS-12.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 64.0
- **Regla de medición:** Conteo de pases encamisados para refrigeración.
- **Ubicación (planilla maestra):** Pisos 1 al 6 · Sectores P1-1 a P6-2 · Aulas teóricas y laboratorios de cómputo
- **Especificación técnica:** [[EETT-12.04]]
- **Proceso y rendimiento (carpeta 02):** [[PROC-12.04]]
- **Resultado:** [[APU-12.04]] · costo unitario S/ 185.67 · parcial S/ 11,882.67 (ver [[PRESUPUESTO_R01]])
