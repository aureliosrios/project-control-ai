---
tipo: "wbs_partida"
codigo: "13.01"
capitulo: "13.00"
unidad: "und"
metrado: 144.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-13.01 — Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto

Capítulo: [[WBS-13.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 144.0
- **Regla de medición:** Meses de control topográfico continuo y calibración de instrumentos.
- **Ubicación (planilla maestra):** Todos los niveles · General de Obra · BM oficial y red de control en todos los frentes
- **Especificación técnica:** [[EETT-13.01]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-13.01]] · costo unitario S/ 33.43 · parcial S/ 4,814.40 (ver [[PRESUPUESTO_R01]])
