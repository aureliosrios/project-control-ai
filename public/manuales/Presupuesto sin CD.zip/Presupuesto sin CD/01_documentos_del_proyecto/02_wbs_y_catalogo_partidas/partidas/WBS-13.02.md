---
tipo: "wbs_partida"
codigo: "13.02"
capitulo: "13.00"
unidad: "und"
metrado: 65.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-13.02 — Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL)

Capítulo: [[WBS-13.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 65.0
- **Regla de medición:** Grupos de 4 probetas cilíndricas ensayadas a compresión axial.
- **Ubicación (planilla maestra):** Todos los niveles · Todos los sectores · Concretos f'c=210 y f'c=280 en zapatas, muros, columnas y losas
- **Especificación técnica:** [[EETT-13.02]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-13.02]] · costo unitario S/ 217.27 · parcial S/ 14,122.33 (ver [[PRESUPUESTO_R01]])
