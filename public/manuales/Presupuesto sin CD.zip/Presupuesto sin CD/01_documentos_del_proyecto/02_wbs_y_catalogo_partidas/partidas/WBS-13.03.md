---
tipo: "wbs_partida"
codigo: "13.03"
capitulo: "13.00"
unidad: "und"
metrado: 12.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-13.03 — Ensayos de tracción y doblado de acero de refuerzo en laboratorio acreditado

Capítulo: [[WBS-13.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 12.0
- **Regla de medición:** Ensayos de caracterización mecánica de barras corrugadas.
- **Ubicación (planilla maestra):** Todos los niveles · General de Obra · Varillas fi 3/8 pulg a 1 pulg
- **Especificación técnica:** [[EETT-13.03]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-13.03]] · costo unitario S/ 6.14 · parcial S/ 73.69 (ver [[PRESUPUESTO_R01]])
