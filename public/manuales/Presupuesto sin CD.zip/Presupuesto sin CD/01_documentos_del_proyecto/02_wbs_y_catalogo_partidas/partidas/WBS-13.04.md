---
tipo: "wbs_partida"
codigo: "13.04"
capitulo: "13.00"
unidad: "glb"
metrado: 1.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-13.04 — Pruebas hidrostáticas y de estanqueidad presurizada en redes y cisterna (72 horas)

Capítulo: [[WBS-13.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** glb / 1.0
- **Regla de medición:** Determinación in situ de porcentaje de compactación Proctor.
- **Ubicación (planilla maestra):** Cimentación (-5.80 m) · Sectores S2-1 y S2-2 · Bajo solados y zapatas
- **Especificación técnica:** [[EETT-13.04]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-13.04]] · costo unitario S/ 5,312.00 · parcial S/ 5,312.00 (ver [[PRESUPUESTO_R01]])
