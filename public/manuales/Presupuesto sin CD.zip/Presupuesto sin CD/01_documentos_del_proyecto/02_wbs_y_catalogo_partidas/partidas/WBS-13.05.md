---
tipo: "wbs_partida"
codigo: "13.05"
capitulo: "13.00"
unidad: "und"
metrado: 18.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-13.05 — Ensayos de densidad de campo (cono de arena) en rellenos y subrasante al 95% PM

Capítulo: [[WBS-13.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** und / 18.0
- **Regla de medición:** Actas firmadas de liberación previa a cada vaciado de elemento.
- **Ubicación (planilla maestra):** Todos los niveles · Todos los sectores (18 sectores) · Todos los elementos estructurales previo a vaciar
- **Especificación técnica:** [[EETT-13.05]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-13.05]] · costo unitario S/ 196.40 · parcial S/ 3,535.20 (ver [[PRESUPUESTO_R01]])
