---
tipo: "wbs_partida"
codigo: "13.06"
capitulo: "13.00"
unidad: "glb"
metrado: 1.0
cobertura_02: "POR_DERIVAR_CON_IA"
tags: ["wbs", "proyecto"]
---

# WBS-13.06 — Elaboración y entrega del Dossier Final de Calidad y Planos As-Built en formato BIM/CAD

Capítulo: [[WBS-13.00]] · Hub: [[MOC_WBS]]

- **Unidad / metrado:** glb / 1.0
- **Regla de medición:** Suma global por compilación completa del dossier de calidad final.
- **Ubicación (planilla maestra):** Todos los niveles · General de Obra · Expediente de Cierre de Casco
- **Especificación técnica:** [[EETT-13.06]]
- **Proceso / rendimiento:** derivados por IA según [[REGLAS_DERIVACION_IA]] (ver el APU).
- **Resultado:** [[APU-13.06]] · costo unitario S/ 14,551.60 · parcial S/ 14,551.60 (ver [[PRESUPUESTO_R01]])
