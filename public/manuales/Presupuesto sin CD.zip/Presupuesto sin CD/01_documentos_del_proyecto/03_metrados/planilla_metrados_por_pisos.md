# PLANILLA MAESTRA DE METRADOS SINTÉTICOS DETALLADOS POR NIVEL Y SECTOR

> **Clasificación de datos:** `SINTETICO_APROXIMADO`. Las cantidades son aproximaciones plausibles para simulación y cierran matemáticamente con la WBS Rev. D.

**Fecha de conciliación:** 2026-08-26  
**Autoridad técnica:** Memoria Descriptiva General de Casco Estructural Rev. D.  
**Exclusión:** Este documento no contiene precios, APUs ni presupuesto.

## 01.00 Obras Provisionales

### Partida 01.01: Movilización y desmovilización de equipo pesado en cama baja de 30 Tn
- **Unidad Oficial:** `glb` | **Cantidad Total Conciliada:** `1.0 glb`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| General de obra | 0.0 | General | Movilización y desmovilización de equipo pesado en cama baja de 30 Tn - General de obra - General | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | glb |
| **Subtotal General de obra** |  |  |  |  |  |  |  | **1.0000** | **glb** |

> **Total verificado 01.01:** `1.0 glb`. Diferencia = `0.0000`.

### Partida 01.02: Instalaciones provisionales de agua, energía y desagüe de faena con tablero general
- **Unidad Oficial:** `glb` | **Cantidad Total Conciliada:** `1.0 glb`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| General de obra | 0.0 | General | Instalaciones provisionales de agua, energía y desagüe de faena con tablero general - General de obra - General | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | glb |
| **Subtotal General de obra** |  |  |  |  |  |  |  | **1.0000** | **glb** |

> **Total verificado 01.02:** `1.0 glb`. Diferencia = `0.0000`.

### Partida 01.03: Cerramiento provisional perimetral con parantes tubulares de acero 2" y Malla Raschel 80%
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `90.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| General de obra | 0.0 | General | Cerramiento provisional perimetral con parantes tubulares de acero 2" y Malla Raschel 80% - General de obra - General | 1.0000 | 90.0000 | 1.0000 | 1.0000 | 90.0000 | m |
| **Subtotal General de obra** |  |  |  |  |  |  |  | **90.0000** | **m** |

> **Total verificado 01.03:** `90.0 m`. Diferencia = `0.0000`.

### Partida 01.04: Trazo, niveles y replanteo topográfico con Estación Total Láser Leica
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `500.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| General de obra | 0.0 | General | Trazo, niveles y replanteo topográfico con Estación Total Láser Leica - General de obra - General | 1.0000 | 22.3607 | 22.3607 | 1.0000 | 500.0000 | m2 |
| **Subtotal General de obra** |  |  |  |  |  |  |  | **500.0000** | **m2** |

> **Total verificado 01.04:** `500.0 m2`. Diferencia = `0.0000`.

### Partida 01.05: Protección y desvío de interferencias de redes de servicios públicos (SEDAPAL/ENEL)
- **Unidad Oficial:** `glb` | **Cantidad Total Conciliada:** `1.0 glb`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| General de obra | 0.0 | General | Protección y desvío de interferencias de redes de servicios públicos (SEDAPAL/ENEL) - General de obra - General | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | glb |
| **Subtotal General de obra** |  |  |  |  |  |  |  | **1.0000** | **glb** |

> **Total verificado 01.05:** `1.0 glb`. Diferencia = `0.0000`.

### Partida 01.06: Limpieza, desbroce manual y acondicionamiento del terreno
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `450.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| General de obra | 0.0 | General | Limpieza, desbroce manual y acondicionamiento del terreno - General de obra - General | 1.0000 | 21.2132 | 21.2132 | 1.0000 | 450.0000 | m2 |
| **Subtotal General de obra** |  |  |  |  |  |  |  | **450.0000** | **m2** |

> **Total verificado 01.06:** `450.0 m2`. Diferencia = `0.0000`.

## 02.00 Geotecnia y Estructuras

### Partida 02.01: Sostenimiento perimetral con perforadora hidráulica, anclajes Dywidag 32mm L=9m e inyección de lechada
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `522.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Sostenimiento perimetral con perforadora hidráulica, anclajes Dywidag 32mm L=9m e inyección de lechada - Sótano 2 - Sector 1 | 1.0000 | 11.4237 | 11.4237 | 1.0000 | 130.5000 | m2 |
|  |  |  | Sostenimiento perimetral con perforadora hidráulica, anclajes Dywidag 32mm L=9m e inyección de lechada - Sótano 2 - Sector 2 | 1.0000 | 11.4237 | 11.4237 | 1.0000 | 130.5000 | m2 |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **261.0000** | **m2** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Sostenimiento perimetral con perforadora hidráulica, anclajes Dywidag 32mm L=9m e inyección de lechada - Sótano 1 - Sector 1 | 1.0000 | 11.4237 | 11.4237 | 1.0000 | 130.5000 | m2 |
|  |  |  | Sostenimiento perimetral con perforadora hidráulica, anclajes Dywidag 32mm L=9m e inyección de lechada - Sótano 1 - Sector 2 | 1.0000 | 11.4237 | 11.4237 | 1.0000 | 130.5000 | m2 |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **261.0000** | **m2** |

> **Total verificado 02.01:** `522.0 m2`. Diferencia = `0.0000`.

### Partida 02.02: Apuntalamiento provisional de estructuras colindantes con puntales telescópicos Multiprop y vigas HEB
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `12.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Apuntalamiento provisional de estructuras colindantes con puntales telescópicos Multiprop y vigas HEB - Sótano 2 - Sector 1 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
|  |  |  | Apuntalamiento provisional de estructuras colindantes con puntales telescópicos Multiprop y vigas HEB - Sótano 2 - Sector 2 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **6.0000** | **und** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Apuntalamiento provisional de estructuras colindantes con puntales telescópicos Multiprop y vigas HEB - Sótano 1 - Sector 1 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
|  |  |  | Apuntalamiento provisional de estructuras colindantes con puntales telescópicos Multiprop y vigas HEB - Sótano 1 - Sector 2 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **6.0000** | **und** |

> **Total verificado 02.02:** `12.0 und`. Diferencia = `0.0000`.

### Partida 02.03: Instrumentación geotécnica: inclinómetros biaxiales profundos (2 und) y piezómetro abierto PZ-1
- **Unidad Oficial:** `glb` | **Cantidad Total Conciliada:** `1.0 glb`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| General de obra | 0.0 | General | Instrumentación geotécnica: inclinómetros biaxiales profundos (2 und) y piezómetro abierto PZ-1 - General de obra - General | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | glb |
| **Subtotal General de obra** |  |  |  |  |  |  |  | **1.0000** | **glb** |

> **Total verificado 02.03:** `1.0 glb`. Diferencia = `0.0000`.

### Partida 02.04: Monitoreo topográfico continuo de hitos geodésicos en colindancias con estación total (8 hitos)
- **Unidad Oficial:** `mes` | **Cantidad Total Conciliada:** `4.0 mes`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | General | Monitoreo topográfico continuo de hitos geodésicos en colindancias con estación total (8 hitos) - Sótano 2 - General | 2.0000 | 1.0000 | 1.0000 | 1.0000 | 2.0000 | mes |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **2.0000** | **mes** |
| Sótano 1 | -2.8 | General | Monitoreo topográfico continuo de hitos geodésicos en colindancias con estación total (8 hitos) - Sótano 1 - General | 2.0000 | 1.0000 | 1.0000 | 1.0000 | 2.0000 | mes |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **2.0000** | **mes** |

> **Total verificado 02.04:** `4.0 mes`. Diferencia = `0.0000`.

### Partida 02.05: Sistema provisional de bombeo y achique de aguas de escorrentía con electrobomba sumergible 5 HP
- **Unidad Oficial:** `glb` | **Cantidad Total Conciliada:** `1.0 glb`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| General de obra | 0.0 | General | Sistema provisional de bombeo y achique de aguas de escorrentía con electrobomba sumergible 5 HP - General de obra - General | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | glb |
| **Subtotal General de obra** |  |  |  |  |  |  |  | **1.0000** | **glb** |

> **Total verificado 02.05:** `1.0 glb`. Diferencia = `0.0000`.

## 03.00 Movimiento de Tierras

### Partida 03.01: Excavación masiva con excavadora sobre orugas 200 HP hasta cota -5.80 m
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `3200.0 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Excavación masiva con excavadora sobre orugas 200 HP hasta cota -5.80 m - Cimentación - Sector 1 | 1.0000 | 11.6961 | 11.6961 | 11.6961 | 1600.0000 | m3 |
|  |  |  | Excavación masiva con excavadora sobre orugas 200 HP hasta cota -5.80 m - Cimentación - Sector 2 | 1.0000 | 11.6961 | 11.6961 | 11.6961 | 1600.0000 | m3 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **3200.0000** | **m3** |

> **Total verificado 03.01:** `3200.0 m3`. Diferencia = `0.0000`.

### Partida 03.02: Excavación manual localizada para zapatas, vigas de cimentación, foso y cisterna
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `250.0 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Excavación manual localizada para zapatas, vigas de cimentación, foso y cisterna - Cimentación - Sector 1 | 1.0000 | 5.0000 | 5.0000 | 5.0000 | 125.0000 | m3 |
|  |  |  | Excavación manual localizada para zapatas, vigas de cimentación, foso y cisterna - Cimentación - Sector 2 | 1.0000 | 5.0000 | 5.0000 | 5.0000 | 125.0000 | m3 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **250.0000** | **m3** |

> **Total verificado 03.02:** `250.0 m3`. Diferencia = `0.0000`.

### Partida 03.03: Carguío con cargador frontal CAT 950 y eliminación con volquetes de 15 m3 (d=10 km)
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `4100.0 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Carguío con cargador frontal CAT 950 y eliminación con volquetes de 15 m3 (d=10 km) - Cimentación - Sector 1 | 1.0000 | 12.7033 | 12.7033 | 12.7033 | 2050.0000 | m3 |
|  |  |  | Carguío con cargador frontal CAT 950 y eliminación con volquetes de 15 m3 (d=10 km) - Cimentación - Sector 2 | 1.0000 | 12.7033 | 12.7033 | 12.7033 | 2050.0000 | m3 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **4100.0000** | **m3** |

> **Total verificado 03.03:** `4100.0 m3`. Diferencia = `0.0000`.

### Partida 03.04: Relleno compactado con afirmado seleccionado de cantera y plancha vibratoria al 95% PM
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `180.0 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Relleno compactado con afirmado seleccionado de cantera y plancha vibratoria al 95% PM - Cimentación - Sector 1 | 1.0000 | 4.4814 | 4.4814 | 4.4814 | 90.0000 | m3 |
|  |  |  | Relleno compactado con afirmado seleccionado de cantera y plancha vibratoria al 95% PM - Cimentación - Sector 2 | 1.0000 | 4.4814 | 4.4814 | 4.4814 | 90.0000 | m3 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **180.0000** | **m3** |

> **Total verificado 03.04:** `180.0 m3`. Diferencia = `0.0000`.

### Partida 03.05: Perfilado y compactación de fondo de excavación (subrasante) con equipo liviano
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `500.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Perfilado y compactación de fondo de excavación (subrasante) con equipo liviano - Cimentación - Sector 1 | 1.0000 | 15.8114 | 15.8114 | 1.0000 | 250.0000 | m2 |
|  |  |  | Perfilado y compactación de fondo de excavación (subrasante) con equipo liviano - Cimentación - Sector 2 | 1.0000 | 15.8114 | 15.8114 | 1.0000 | 250.0000 | m2 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **500.0000** | **m2** |

> **Total verificado 03.05:** `500.0 m2`. Diferencia = `0.0000`.

## 04.00 Estructuras

### Partida 04.01: Solado de concreto premezclado f'c=140 kg/cm2 e=4" para zapatas, cisterna y fosos
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `161.2 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Solado de concreto premezclado f'c=140 kg/cm2 e=4" para zapatas, cisterna y fosos - Cimentación - Sector 1 | 1.0000 | 8.9778 | 8.9778 | 1.0000 | 80.6000 | m2 |
|  |  |  | Solado de concreto premezclado f'c=140 kg/cm2 e=4" para zapatas, cisterna y fosos - Cimentación - Sector 2 | 1.0000 | 8.9778 | 8.9778 | 1.0000 | 80.6000 | m2 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **161.2000** | **m2** |

> **Total verificado 04.01:** `161.2 m2`. Diferencia = `0.0000`.

### Partida 04.02: Cimientos corridos de concreto premezclado f'c=140 kg/cm2 + 30% piedra grande
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `120.0 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Cimientos corridos de concreto premezclado f'c=140 kg/cm2 + 30% piedra grande - Cimentación - Sector 1 | 1.0000 | 3.9149 | 3.9149 | 3.9149 | 60.0000 | m3 |
|  |  |  | Cimientos corridos de concreto premezclado f'c=140 kg/cm2 + 30% piedra grande - Cimentación - Sector 2 | 1.0000 | 3.9149 | 3.9149 | 3.9149 | 60.0000 | m3 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **120.0000** | **m3** |

> **Total verificado 04.02:** `120.0 m3`. Diferencia = `0.0000`.

### Partida 04.03: Sobrecimientos de concreto premezclado f'c=175 kg/cm2 + 25% piedra mediana
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `45.0 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Sobrecimientos de concreto premezclado f'c=175 kg/cm2 + 25% piedra mediana - Cimentación - Sector 1 | 1.0000 | 2.8231 | 2.8231 | 2.8231 | 22.5000 | m3 |
|  |  |  | Sobrecimientos de concreto premezclado f'c=175 kg/cm2 + 25% piedra mediana - Cimentación - Sector 2 | 1.0000 | 2.8231 | 2.8231 | 2.8231 | 22.5000 | m3 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **45.0000** | **m3** |

> **Total verificado 04.03:** `45.0 m3`. Diferencia = `0.0000`.

### Partida 04.04: Encofrado y desencofrado modular metálico con tablero fenólico para sobrecimientos
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `180.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Encofrado y desencofrado modular metálico con tablero fenólico para sobrecimientos - Cimentación - Sector 1 | 1.0000 | 9.4868 | 9.4868 | 1.0000 | 90.0000 | m2 |
|  |  |  | Encofrado y desencofrado modular metálico con tablero fenólico para sobrecimientos - Cimentación - Sector 2 | 1.0000 | 9.4868 | 9.4868 | 1.0000 | 90.0000 | m2 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **180.0000** | **m2** |

> **Total verificado 04.04:** `180.0 m2`. Diferencia = `0.0000`.

## 05.00 Estructuras

### Partida 05.01: Zapatas: Concreto premezclado f'c=210 kg/cm2 vaciado con bomba telescópica
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `83.76 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Zapatas: Concreto premezclado f'c=210 kg/cm2 vaciado con bomba telescópica - Cimentación - Sector 1 | 1.0000 | 3.4727 | 3.4727 | 3.4727 | 41.8800 | m3 |
|  |  |  | Zapatas: Concreto premezclado f'c=210 kg/cm2 vaciado con bomba telescópica - Cimentación - Sector 2 | 1.0000 | 3.4727 | 3.4727 | 3.4727 | 41.8800 | m3 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **83.7600** | **m3** |

> **Total verificado 05.01:** `83.76 m3`. Diferencia = `0.0000`.

### Partida 05.02: Zapatas: Encofrado y desencofrado modular metálico
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `137.44 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Zapatas: Encofrado y desencofrado modular metálico - Cimentación - Sector 1 | 1.0000 | 8.2898 | 8.2898 | 1.0000 | 68.7200 | m2 |
|  |  |  | Zapatas: Encofrado y desencofrado modular metálico - Cimentación - Sector 2 | 1.0000 | 8.2898 | 8.2898 | 1.0000 | 68.7200 | m2 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **137.4400** | **m2** |

> **Total verificado 05.02:** `137.44 m2`. Diferencia = `0.0000`.

### Partida 05.03: Zapatas: Acero de refuerzo corrugado fy=4200 kg/cm2 Grado 60 habilitado en banco CNC
- **Unidad Oficial:** `kg` | **Cantidad Total Conciliada:** `7119.6 kg`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Zapatas: Acero de refuerzo corrugado fy=4200 kg/cm2 Grado 60 habilitado en banco CNC - Cimentación - Sector 1 | 1.0000 | 3559.8000 | 1.0000 | 1.0000 | 3559.8000 | kg |
|  |  |  | Zapatas: Acero de refuerzo corrugado fy=4200 kg/cm2 Grado 60 habilitado en banco CNC - Cimentación - Sector 2 | 1.0000 | 3559.8000 | 1.0000 | 1.0000 | 3559.8000 | kg |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **7119.6000** | **kg** |

> **Total verificado 05.03:** `7119.6 kg`. Diferencia = `0.0000`.

### Partida 05.04: Vigas de cimentación y amarre: Concreto premezclado f'c=210 kg/cm2 con bomba
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `58.52 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Vigas de cimentación y amarre: Concreto premezclado f'c=210 kg/cm2 con bomba - Cimentación - Sector 1 | 1.0000 | 3.0815 | 3.0815 | 3.0815 | 29.2600 | m3 |
|  |  |  | Vigas de cimentación y amarre: Concreto premezclado f'c=210 kg/cm2 con bomba - Cimentación - Sector 2 | 1.0000 | 3.0815 | 3.0815 | 3.0815 | 29.2600 | m3 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **58.5200** | **m3** |

> **Total verificado 05.04:** `58.52 m3`. Diferencia = `0.0000`.

### Partida 05.05: Vigas de cimentación y amarre: Encofrado y desencofrado modular fenólico 18mm
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `258.4 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Vigas de cimentación y amarre: Encofrado y desencofrado modular fenólico 18mm - Cimentación - Sector 1 | 1.0000 | 11.3666 | 11.3666 | 1.0000 | 129.2000 | m2 |
|  |  |  | Vigas de cimentación y amarre: Encofrado y desencofrado modular fenólico 18mm - Cimentación - Sector 2 | 1.0000 | 11.3666 | 11.3666 | 1.0000 | 129.2000 | m2 |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **258.4000** | **m2** |

> **Total verificado 05.05:** `258.4 m2`. Diferencia = `0.0000`.

### Partida 05.06: Vigas de cimentación y amarre: Acero de refuerzo fy=4200 kg/cm2 Grado 60
- **Unidad Oficial:** `kg` | **Cantidad Total Conciliada:** `6437.2 kg`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Cimentación | -5.8 | Sectores 1 y 2 | Vigas de cimentación y amarre: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Cimentación - Sector 1 | 1.0000 | 3218.6000 | 1.0000 | 1.0000 | 3218.6000 | kg |
|  |  |  | Vigas de cimentación y amarre: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Cimentación - Sector 2 | 1.0000 | 3218.6000 | 1.0000 | 1.0000 | 3218.6000 | kg |
| **Subtotal Cimentación** |  |  |  |  |  |  |  | **6437.2000** | **kg** |

> **Total verificado 05.06:** `6437.2 kg`. Diferencia = `0.0000`.

## 06.00 Estructuras

### Partida 06.01: Muros de contención / pantalla: Concreto premezclado f'c=280 kg/cm2 con bomba
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `156.6 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Muros de contención / pantalla: Concreto premezclado f'c=280 kg/cm2 con bomba - Sótano 2 - Sector 1 | 1.0000 | 3.3956 | 3.3956 | 3.3956 | 39.1500 | m3 |
|  |  |  | Muros de contención / pantalla: Concreto premezclado f'c=280 kg/cm2 con bomba - Sótano 2 - Sector 2 | 1.0000 | 3.3956 | 3.3956 | 3.3956 | 39.1500 | m3 |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **78.3000** | **m3** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Muros de contención / pantalla: Concreto premezclado f'c=280 kg/cm2 con bomba - Sótano 1 - Sector 1 | 1.0000 | 3.3956 | 3.3956 | 3.3956 | 39.1500 | m3 |
|  |  |  | Muros de contención / pantalla: Concreto premezclado f'c=280 kg/cm2 con bomba - Sótano 1 - Sector 2 | 1.0000 | 3.3956 | 3.3956 | 3.3956 | 39.1500 | m3 |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **78.3000** | **m3** |

> **Total verificado 06.01:** `156.6 m3`. Diferencia = `0.0000`.

### Partida 06.02: Muros de contención / pantalla: Encofrado modular fenólico a dos caras con sistema de trepa
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `1044.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Muros de contención / pantalla: Encofrado modular fenólico a dos caras con sistema de trepa - Sótano 2 - Sector 1 | 1.0000 | 16.1555 | 16.1555 | 1.0000 | 261.0000 | m2 |
|  |  |  | Muros de contención / pantalla: Encofrado modular fenólico a dos caras con sistema de trepa - Sótano 2 - Sector 2 | 1.0000 | 16.1555 | 16.1555 | 1.0000 | 261.0000 | m2 |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **522.0000** | **m2** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Muros de contención / pantalla: Encofrado modular fenólico a dos caras con sistema de trepa - Sótano 1 - Sector 1 | 1.0000 | 16.1555 | 16.1555 | 1.0000 | 261.0000 | m2 |
|  |  |  | Muros de contención / pantalla: Encofrado modular fenólico a dos caras con sistema de trepa - Sótano 1 - Sector 2 | 1.0000 | 16.1555 | 16.1555 | 1.0000 | 261.0000 | m2 |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **522.0000** | **m2** |

> **Total verificado 06.02:** `1044.0 m2`. Diferencia = `0.0000`.

### Partida 06.03: Muros de contención / pantalla: Acero de refuerzo fy=4200 kg/cm2 Grado 60
- **Unidad Oficial:** `kg` | **Cantidad Total Conciliada:** `14094.0 kg`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Muros de contención / pantalla: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Sótano 2 - Sector 1 | 1.0000 | 3523.5000 | 1.0000 | 1.0000 | 3523.5000 | kg |
|  |  |  | Muros de contención / pantalla: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Sótano 2 - Sector 2 | 1.0000 | 3523.5000 | 1.0000 | 1.0000 | 3523.5000 | kg |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **7047.0000** | **kg** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Muros de contención / pantalla: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Sótano 1 - Sector 1 | 1.0000 | 3523.5000 | 1.0000 | 1.0000 | 3523.5000 | kg |
|  |  |  | Muros de contención / pantalla: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Sótano 1 - Sector 2 | 1.0000 | 3523.5000 | 1.0000 | 1.0000 | 3523.5000 | kg |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **7047.0000** | **kg** |

> **Total verificado 06.03:** `14094.0 kg`. Diferencia = `0.0000`.

### Partida 06.04: Losa de contacto de Sótano 2 e=15 cm concreto premezclado f'c=210 sobre lámina de polietileno HDPE 8 mils
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `500.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Losa de contacto de Sótano 2 e=15 cm concreto premezclado f'c=210 sobre lámina de polietileno HDPE 8 mils - Sótano 2 - Sector 1 | 1.0000 | 15.8114 | 15.8114 | 1.0000 | 250.0000 | m2 |
|  |  |  | Losa de contacto de Sótano 2 e=15 cm concreto premezclado f'c=210 sobre lámina de polietileno HDPE 8 mils - Sótano 2 - Sector 2 | 1.0000 | 15.8114 | 15.8114 | 1.0000 | 250.0000 | m2 |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **500.0000** | **m2** |

> **Total verificado 06.04:** `500.0 m2`. Diferencia = `0.0000`.

### Partida 06.05: Cisterna y cuarto de bombas: Estructura monolítica de concreto premezclado f'c=280 con impermeabilizante y waterstop
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `42.5 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Cisterna y cuarto de bombas: Estructura monolítica de concreto premezclado f'c=280 con impermeabilizante y waterstop - Sótano 2 - Sector 1 | 1.0000 | 2.7698 | 2.7698 | 2.7698 | 21.2500 | m3 |
|  |  |  | Cisterna y cuarto de bombas: Estructura monolítica de concreto premezclado f'c=280 con impermeabilizante y waterstop - Sótano 2 - Sector 2 | 1.0000 | 2.7698 | 2.7698 | 2.7698 | 21.2500 | m3 |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **42.5000** | **m3** |

> **Total verificado 06.05:** `42.5 m3`. Diferencia = `0.0000`.

### Partida 06.06: Cisterna y cuarto de bombas: Encofrado modular fenólico impermeable
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `168.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Cisterna y cuarto de bombas: Encofrado modular fenólico impermeable - Sótano 2 - Sector 1 | 1.0000 | 9.1652 | 9.1652 | 1.0000 | 84.0000 | m2 |
|  |  |  | Cisterna y cuarto de bombas: Encofrado modular fenólico impermeable - Sótano 2 - Sector 2 | 1.0000 | 9.1652 | 9.1652 | 1.0000 | 84.0000 | m2 |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **168.0000** | **m2** |

> **Total verificado 06.06:** `168.0 m2`. Diferencia = `0.0000`.

### Partida 06.07: Rampa vehicular estructural: Losa inclinada e=18 cm concreto f'c=210 con acabado endurecido antideslizante
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `125.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Rampa vehicular estructural: Losa inclinada e=18 cm concreto f'c=210 con acabado endurecido antideslizante - Sótano 2 - Sector 1 | 1.0000 | 7.9057 | 7.9057 | 1.0000 | 62.5000 | m2 |
|  |  |  | Rampa vehicular estructural: Losa inclinada e=18 cm concreto f'c=210 con acabado endurecido antideslizante - Sótano 2 - Sector 2 | 1.0000 | 7.9057 | 7.9057 | 1.0000 | 62.5000 | m2 |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **125.0000** | **m2** |

> **Total verificado 06.07:** `125.0 m2`. Diferencia = `0.0000`.

### Partida 06.08: Sellos hidroexpansivos SikaSwell y cinta waterstop de PVC 6" en juntas frías de sótanos
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `180.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Sellos hidroexpansivos SikaSwell y cinta waterstop de PVC 6" en juntas frías de sótanos - Sótano 2 - Sector 1 | 1.0000 | 45.0000 | 1.0000 | 1.0000 | 45.0000 | m |
|  |  |  | Sellos hidroexpansivos SikaSwell y cinta waterstop de PVC 6" en juntas frías de sótanos - Sótano 2 - Sector 2 | 1.0000 | 45.0000 | 1.0000 | 1.0000 | 45.0000 | m |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **90.0000** | **m** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Sellos hidroexpansivos SikaSwell y cinta waterstop de PVC 6" en juntas frías de sótanos - Sótano 1 - Sector 1 | 1.0000 | 45.0000 | 1.0000 | 1.0000 | 45.0000 | m |
|  |  |  | Sellos hidroexpansivos SikaSwell y cinta waterstop de PVC 6" en juntas frías de sótanos - Sótano 1 - Sector 2 | 1.0000 | 45.0000 | 1.0000 | 1.0000 | 45.0000 | m |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **90.0000** | **m** |

> **Total verificado 06.08:** `180.0 m`. Diferencia = `0.0000`.

## 07.00 Estructuras

### Partida 07.01: Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `48.6 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 1 - Sector 1 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
|  |  |  | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 1 - Sector 2 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **8.1000** | **m3** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 2 - Sector 1 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
|  |  |  | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 2 - Sector 2 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **8.1000** | **m3** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 3 - Sector 1 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
|  |  |  | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 3 - Sector 2 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **8.1000** | **m3** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 4 - Sector 1 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
|  |  |  | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 4 - Sector 2 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **8.1000** | **m3** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 5 - Sector 1 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
|  |  |  | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 5 - Sector 2 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **8.1000** | **m3** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 6 - Sector 1 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
|  |  |  | Columnas: Concreto premezclado f'c=280 kg/cm2 con bomba telescópica 36m - Piso 6 - Sector 2 | 1.0000 | 1.5940 | 1.5940 | 1.5940 | 4.0500 | m3 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **8.1000** | **m3** |

> **Total verificado 07.01:** `48.6 m3`. Diferencia = `0.0000`.

### Partida 07.02: Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `324.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 1 - Sector 1 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
|  |  |  | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 1 - Sector 2 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **54.0000** | **m2** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 2 - Sector 1 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
|  |  |  | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 2 - Sector 2 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **54.0000** | **m2** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 3 - Sector 1 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
|  |  |  | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 3 - Sector 2 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **54.0000** | **m2** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 4 - Sector 1 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
|  |  |  | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 4 - Sector 2 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **54.0000** | **m2** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 5 - Sector 1 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
|  |  |  | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 5 - Sector 2 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **54.0000** | **m2** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 6 - Sector 1 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
|  |  |  | Columnas: Encofrado y desencofrado modular fenólico 18mm con alineadores metálicos - Piso 6 - Sector 2 | 1.0000 | 5.1962 | 5.1962 | 1.0000 | 27.0000 | m2 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **54.0000** | **m2** |

> **Total verificado 07.02:** `324.0 m2`. Diferencia = `0.0000`.

### Partida 07.03: Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica
- **Unidad Oficial:** `kg` | **Cantidad Total Conciliada:** `7290.0 kg`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 1 - Sector 1 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
|  |  |  | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 1 - Sector 2 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **1215.0000** | **kg** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 2 - Sector 1 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
|  |  |  | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 2 - Sector 2 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **1215.0000** | **kg** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 3 - Sector 1 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
|  |  |  | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 3 - Sector 2 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **1215.0000** | **kg** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 4 - Sector 1 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
|  |  |  | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 4 - Sector 2 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **1215.0000** | **kg** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 5 - Sector 1 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
|  |  |  | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 5 - Sector 2 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **1215.0000** | **kg** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 6 - Sector 1 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
|  |  |  | Columnas: Acero de refuerzo fy=4200 kg/cm2 Grado 60 habilitado con dobladora eléctrica - Piso 6 - Sector 2 | 1.0000 | 607.5000 | 1.0000 | 1.0000 | 607.5000 | kg |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **1215.0000** | **kg** |

> **Total verificado 07.03:** `7290.0 kg`. Diferencia = `0.0000`.

### Partida 07.04: Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `72.9 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 1 - Sector 1 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
|  |  |  | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 1 - Sector 2 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **12.1500** | **m3** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 2 - Sector 1 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
|  |  |  | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 2 - Sector 2 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **12.1500** | **m3** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 3 - Sector 1 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
|  |  |  | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 3 - Sector 2 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **12.1500** | **m3** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 4 - Sector 1 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
|  |  |  | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 4 - Sector 2 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **12.1500** | **m3** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 5 - Sector 1 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
|  |  |  | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 5 - Sector 2 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **12.1500** | **m3** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 6 - Sector 1 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
|  |  |  | Placas de concreto armado: Concreto premezclado f'c=280 kg/cm2 con bomba - Piso 6 - Sector 2 | 1.0000 | 1.8247 | 1.8247 | 1.8247 | 6.0750 | m3 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **12.1500** | **m3** |

> **Total verificado 07.04:** `72.9 m3`. Diferencia = `0.0000`.

### Partida 07.05: Placas de concreto armado: Encofrado modular fenólico trepante
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `486.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 1 - Sector 1 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
|  |  |  | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 1 - Sector 2 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **81.0000** | **m2** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 2 - Sector 1 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
|  |  |  | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 2 - Sector 2 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **81.0000** | **m2** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 3 - Sector 1 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
|  |  |  | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 3 - Sector 2 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **81.0000** | **m2** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 4 - Sector 1 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
|  |  |  | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 4 - Sector 2 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **81.0000** | **m2** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 5 - Sector 1 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
|  |  |  | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 5 - Sector 2 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **81.0000** | **m2** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 6 - Sector 1 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
|  |  |  | Placas de concreto armado: Encofrado modular fenólico trepante - Piso 6 - Sector 2 | 1.0000 | 6.3640 | 6.3640 | 1.0000 | 40.5000 | m2 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **81.0000** | **m2** |

> **Total verificado 07.05:** `486.0 m2`. Diferencia = `0.0000`.

### Partida 07.06: Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60
- **Unidad Oficial:** `kg` | **Cantidad Total Conciliada:** `8748.0 kg`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 1 - Sector 1 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
|  |  |  | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 1 - Sector 2 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **1458.0000** | **kg** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 2 - Sector 1 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
|  |  |  | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 2 - Sector 2 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **1458.0000** | **kg** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 3 - Sector 1 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
|  |  |  | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 3 - Sector 2 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **1458.0000** | **kg** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 4 - Sector 1 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
|  |  |  | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 4 - Sector 2 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **1458.0000** | **kg** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 5 - Sector 1 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
|  |  |  | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 5 - Sector 2 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **1458.0000** | **kg** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 6 - Sector 1 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
|  |  |  | Placas de concreto armado: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 6 - Sector 2 | 1.0000 | 729.0000 | 1.0000 | 1.0000 | 729.0000 | kg |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **1458.0000** | **kg** |

> **Total verificado 07.06:** `8748.0 kg`. Diferencia = `0.0000`.

### Partida 07.07: Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `126.0 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 1 - Sector 1 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
|  |  |  | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 1 - Sector 2 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **21.0000** | **m3** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 2 - Sector 1 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
|  |  |  | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 2 - Sector 2 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **21.0000** | **m3** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 3 - Sector 1 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
|  |  |  | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 3 - Sector 2 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **21.0000** | **m3** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 4 - Sector 1 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
|  |  |  | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 4 - Sector 2 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **21.0000** | **m3** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 5 - Sector 1 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
|  |  |  | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 5 - Sector 2 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **21.0000** | **m3** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 6 - Sector 1 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
|  |  |  | Vigas principales y secundarias: Concreto premezclado f'c=210 kg/cm2 con bomba - Piso 6 - Sector 2 | 1.0000 | 2.1898 | 2.1898 | 2.1898 | 10.5000 | m3 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **21.0000** | **m3** |

> **Total verificado 07.07:** `126.0 m3`. Diferencia = `0.0000`.

### Partida 07.08: Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `560.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 1 - Sector 1 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
|  |  |  | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 1 - Sector 2 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **93.3334** | **m2** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 2 - Sector 1 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
|  |  |  | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 2 - Sector 2 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **93.3334** | **m2** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 3 - Sector 1 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
|  |  |  | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 3 - Sector 2 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **93.3334** | **m2** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 4 - Sector 1 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
|  |  |  | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 4 - Sector 2 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **93.3334** | **m2** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 5 - Sector 1 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
|  |  |  | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 5 - Sector 2 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **93.3334** | **m2** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 6 - Sector 1 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6667 | m2 |
|  |  |  | Vigas principales y secundarias: Encofrado y desencofrado modular con puntales telescópicos - Piso 6 - Sector 2 | 1.0000 | 6.8313 | 6.8313 | 1.0000 | 46.6663 | m2 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **93.3330** | **m2** |

> **Total verificado 07.08:** `560.0 m2`. Diferencia = `0.0000`.

### Partida 07.09: Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60
- **Unidad Oficial:** `kg` | **Cantidad Total Conciliada:** `15120.0 kg`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 1 - Sector 1 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
|  |  |  | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 1 - Sector 2 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **2520.0000** | **kg** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 2 - Sector 1 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
|  |  |  | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 2 - Sector 2 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **2520.0000** | **kg** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 3 - Sector 1 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
|  |  |  | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 3 - Sector 2 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **2520.0000** | **kg** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 4 - Sector 1 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
|  |  |  | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 4 - Sector 2 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **2520.0000** | **kg** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 5 - Sector 1 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
|  |  |  | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 5 - Sector 2 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **2520.0000** | **kg** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 6 - Sector 1 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
|  |  |  | Vigas principales y secundarias: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 6 - Sector 2 | 1.0000 | 1260.0000 | 1.0000 | 1.0000 | 1260.0000 | kg |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **2520.0000** | **kg** |

> **Total verificado 07.09:** `15120.0 kg`. Diferencia = `0.0000`.

### Partida 07.10: Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `210.0 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 1 - Sector 1 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
|  |  |  | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 1 - Sector 2 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **35.0000** | **m3** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 2 - Sector 1 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
|  |  |  | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 2 - Sector 2 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **35.0000** | **m3** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 3 - Sector 1 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
|  |  |  | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 3 - Sector 2 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **35.0000** | **m3** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 4 - Sector 1 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
|  |  |  | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 4 - Sector 2 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **35.0000** | **m3** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 5 - Sector 1 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
|  |  |  | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 5 - Sector 2 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **35.0000** | **m3** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 6 - Sector 1 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
|  |  |  | Losas aligeradas unidireccionales e=20 cm: Concreto premezclado f'c=210 kg/cm2 - Piso 6 - Sector 2 | 1.0000 | 2.5962 | 2.5962 | 2.5962 | 17.5000 | m3 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **35.0000** | **m3** |

> **Total verificado 07.10:** `210.0 m3`. Diferencia = `0.0000`.

### Partida 07.11: Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `2400.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 1 - Sector 1 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
|  |  |  | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 1 - Sector 2 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **400.0000** | **m2** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 2 - Sector 1 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
|  |  |  | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 2 - Sector 2 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **400.0000** | **m2** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 3 - Sector 1 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
|  |  |  | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 3 - Sector 2 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **400.0000** | **m2** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 4 - Sector 1 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
|  |  |  | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 4 - Sector 2 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **400.0000** | **m2** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 5 - Sector 1 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
|  |  |  | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 5 - Sector 2 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **400.0000** | **m2** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 6 - Sector 1 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
|  |  |  | Losas aligeradas: Encofrado y desencofrado con vigas de aluminio y puntales modulares - Piso 6 - Sector 2 | 1.0000 | 14.1421 | 14.1421 | 1.0000 | 200.0000 | m2 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **400.0000** | **m2** |

> **Total verificado 07.11:** `2400.0 m2`. Diferencia = `0.0000`.

### Partida 07.12: Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2
- **Unidad Oficial:** `kg` | **Cantidad Total Conciliada:** `12600.0 kg`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 1 - Sector 1 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
|  |  |  | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 1 - Sector 2 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **2100.0000** | **kg** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 2 - Sector 1 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
|  |  |  | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 2 - Sector 2 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **2100.0000** | **kg** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 3 - Sector 1 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
|  |  |  | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 3 - Sector 2 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **2100.0000** | **kg** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 4 - Sector 1 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
|  |  |  | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 4 - Sector 2 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **2100.0000** | **kg** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 5 - Sector 1 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
|  |  |  | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 5 - Sector 2 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **2100.0000** | **kg** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 6 - Sector 1 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
|  |  |  | Losas aligeradas: Acero de refuerzo en viguetas y temperatura fy=4200 kg/cm2 - Piso 6 - Sector 2 | 1.0000 | 1050.0000 | 1.0000 | 1.0000 | 1050.0000 | kg |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **2100.0000** | **kg** |

> **Total verificado 07.12:** `12600.0 kg`. Diferencia = `0.0000`.

### Partida 07.13: Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `20400.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 1 - Sector 1 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
|  |  |  | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 1 - Sector 2 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **3400.0000** | **und** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 2 - Sector 1 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
|  |  |  | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 2 - Sector 2 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **3400.0000** | **und** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 3 - Sector 1 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
|  |  |  | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 3 - Sector 2 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **3400.0000** | **und** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 4 - Sector 1 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
|  |  |  | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 4 - Sector 2 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **3400.0000** | **und** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 5 - Sector 1 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
|  |  |  | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 5 - Sector 2 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **3400.0000** | **und** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 6 - Sector 1 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
|  |  |  | Losas aligeradas: Ladrillo hueco de arcilla 15x30x30 cm para techo izado con grúa torre - Piso 6 - Sector 2 | 1700.0000 | 1.0000 | 1.0000 | 1.0000 | 1700.0000 | und |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **3400.0000** | **und** |

> **Total verificado 07.13:** `20400.0 und`. Diferencia = `0.0000`.

### Partida 07.14: Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `18.9 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 1 - Sector 1 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
|  |  |  | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 1 - Sector 2 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **3.1500** | **m3** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 2 - Sector 1 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
|  |  |  | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 2 - Sector 2 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **3.1500** | **m3** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 3 - Sector 1 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
|  |  |  | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 3 - Sector 2 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **3.1500** | **m3** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 4 - Sector 1 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
|  |  |  | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 4 - Sector 2 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **3.1500** | **m3** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 5 - Sector 1 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
|  |  |  | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 5 - Sector 2 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **3.1500** | **m3** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 6 - Sector 1 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
|  |  |  | Escalera de evacuación presurizada: Concreto premezclado f'c=210 kg/cm2 - Piso 6 - Sector 2 | 1.0000 | 1.1635 | 1.1635 | 1.1635 | 1.5750 | m3 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **3.1500** | **m3** |

> **Total verificado 07.14:** `18.9 m3`. Diferencia = `0.0000`.

### Partida 07.15: Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `108.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 1 - Sector 1 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
|  |  |  | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 1 - Sector 2 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **18.0000** | **m2** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 2 - Sector 1 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
|  |  |  | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 2 - Sector 2 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **18.0000** | **m2** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 3 - Sector 1 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
|  |  |  | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 3 - Sector 2 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **18.0000** | **m2** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 4 - Sector 1 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
|  |  |  | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 4 - Sector 2 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **18.0000** | **m2** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 5 - Sector 1 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
|  |  |  | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 5 - Sector 2 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **18.0000** | **m2** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 6 - Sector 1 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
|  |  |  | Escalera de evacuación: Encofrado modular y pasos con moldes fenólicos - Piso 6 - Sector 2 | 1.0000 | 3.0000 | 3.0000 | 1.0000 | 9.0000 | m2 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **18.0000** | **m2** |

> **Total verificado 07.15:** `108.0 m2`. Diferencia = `0.0000`.

### Partida 07.16: Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60
- **Unidad Oficial:** `kg` | **Cantidad Total Conciliada:** `2457.0 kg`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 1 - Sector 1 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
|  |  |  | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 1 - Sector 2 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **409.5000** | **kg** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 2 - Sector 1 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
|  |  |  | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 2 - Sector 2 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **409.5000** | **kg** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 3 - Sector 1 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
|  |  |  | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 3 - Sector 2 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **409.5000** | **kg** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 4 - Sector 1 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
|  |  |  | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 4 - Sector 2 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **409.5000** | **kg** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 5 - Sector 1 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
|  |  |  | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 5 - Sector 2 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **409.5000** | **kg** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 6 - Sector 1 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
|  |  |  | Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60 - Piso 6 - Sector 2 | 1.0000 | 204.7500 | 1.0000 | 1.0000 | 204.7500 | kg |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **409.5000** | **kg** |

> **Total verificado 07.16:** `2457.0 kg`. Diferencia = `0.0000`.

## 08.00 Estructuras

### Partida 08.01: Losa de techo de azotea e=20 cm concreto premezclado f'c=210 con membrana asfáltica e=3mm
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `500.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Azotea | 19.5 | Sectores 1 y 2 | Losa de techo de azotea e=20 cm concreto premezclado f'c=210 con membrana asfáltica e=3mm - Azotea - Sector 1 | 1.0000 | 15.8114 | 15.8114 | 1.0000 | 250.0000 | m2 |
|  |  |  | Losa de techo de azotea e=20 cm concreto premezclado f'c=210 con membrana asfáltica e=3mm - Azotea - Sector 2 | 1.0000 | 15.8114 | 15.8114 | 1.0000 | 250.0000 | m2 |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **500.0000** | **m2** |

> **Total verificado 08.01:** `500.0 m2`. Diferencia = `0.0000`.

### Partida 08.02: Parapeto perimetral de concreto armado f'c=210 h=1.10 m en azotea
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `90.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Azotea | 19.5 | Sectores 1 y 2 | Parapeto perimetral de concreto armado f'c=210 h=1.10 m en azotea - Azotea - Sector 1 | 1.0000 | 45.0000 | 1.0000 | 1.0000 | 45.0000 | m |
|  |  |  | Parapeto perimetral de concreto armado f'c=210 h=1.10 m en azotea - Azotea - Sector 2 | 1.0000 | 45.0000 | 1.0000 | 1.0000 | 45.0000 | m |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **90.0000** | **m** |

> **Total verificado 08.02:** `90.0 m`. Diferencia = `0.0000`.

### Partida 08.03: Caseta de sala de máquinas de ascensor y cuarto técnico de bombas en concreto f'c=280
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `12.5 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Azotea | 19.5 | Sectores 1 y 2 | Caseta de sala de máquinas de ascensor y cuarto técnico de bombas en concreto f'c=280 - Azotea - Sector 1 | 1.0000 | 1.8420 | 1.8420 | 1.8420 | 6.2500 | m3 |
|  |  |  | Caseta de sala de máquinas de ascensor y cuarto técnico de bombas en concreto f'c=280 - Azotea - Sector 2 | 1.0000 | 1.8420 | 1.8420 | 1.8420 | 6.2500 | m3 |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **12.5000** | **m3** |

> **Total verificado 08.03:** `12.5 m3`. Diferencia = `0.0000`.

### Partida 08.04: Juntas de dilatación sísmica perimetral con tecnopor de 1" y sellador elastomérico de poliuretano
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `65.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Azotea | 19.5 | Sectores 1 y 2 | Juntas de dilatación sísmica perimetral con tecnopor de 1" y sellador elastomérico de poliuretano - Azotea - Sector 1 | 1.0000 | 32.5000 | 1.0000 | 1.0000 | 32.5000 | m |
|  |  |  | Juntas de dilatación sísmica perimetral con tecnopor de 1" y sellador elastomérico de poliuretano - Azotea - Sector 2 | 1.0000 | 32.5000 | 1.0000 | 1.0000 | 32.5000 | m |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **65.0000** | **m** |

> **Total verificado 08.04:** `65.0 m`. Diferencia = `0.0000`.

## 09.00 Arquitectura y Estructuras

### Partida 09.01: Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `1850.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Sótano 2 - Sector 1 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
|  |  |  | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Sótano 2 - Sector 2 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **231.2500** | **m2** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Sótano 1 - Sector 1 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
|  |  |  | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Sótano 1 - Sector 2 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **231.2500** | **m2** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 1 - Sector 1 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
|  |  |  | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 1 - Sector 2 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **231.2500** | **m2** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 2 - Sector 1 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
|  |  |  | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 2 - Sector 2 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **231.2500** | **m2** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 3 - Sector 1 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
|  |  |  | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 3 - Sector 2 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **231.2500** | **m2** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 4 - Sector 1 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
|  |  |  | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 4 - Sector 2 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **231.2500** | **m2** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 5 - Sector 1 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
|  |  |  | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 5 - Sector 2 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **231.2500** | **m2** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 6 - Sector 1 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
|  |  |  | Muro de ladrillo KK 18 huecos de arcilla asentado con mortero 1:4 e=15 cm tipo soga - Piso 6 - Sector 2 | 1.0000 | 10.7529 | 10.7529 | 1.0000 | 115.6250 | m2 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **231.2500** | **m2** |

> **Total verificado 09.01:** `1850.0 m2`. Diferencia = `0.0000`.

### Partida 09.02: Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070)
- **Unidad Oficial:** `m3` | **Cantidad Total Conciliada:** `28.5 m3`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Sótano 2 - Sector 1 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
|  |  |  | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Sótano 2 - Sector 2 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **3.5626** | **m3** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Sótano 1 - Sector 1 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
|  |  |  | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Sótano 1 - Sector 2 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **3.5626** | **m3** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 1 - Sector 1 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
|  |  |  | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 1 - Sector 2 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **3.5626** | **m3** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 2 - Sector 1 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
|  |  |  | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 2 - Sector 2 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **3.5626** | **m3** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 3 - Sector 1 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
|  |  |  | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 3 - Sector 2 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **3.5626** | **m3** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 4 - Sector 1 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
|  |  |  | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 4 - Sector 2 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **3.5626** | **m3** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 5 - Sector 1 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
|  |  |  | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 5 - Sector 2 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **3.5626** | **m3** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 6 - Sector 1 | 1.0000 | 1.2122 | 1.2122 | 1.2122 | 1.7813 | m3 |
|  |  |  | Columnetas y vigas de amarre de concreto f'c=210 para confinamiento de tabiques (E.070) - Piso 6 - Sector 2 | 1.0000 | 1.2120 | 1.2120 | 1.2120 | 1.7805 | m3 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **3.5618** | **m3** |

> **Total verificado 09.02:** `28.5 m3`. Diferencia = `0.0000`.

### Partida 09.03: Encofrado y desencofrado modular para columnetas y vigas de amarre
- **Unidad Oficial:** `m2` | **Cantidad Total Conciliada:** `195.0 m2`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Encofrado y desencofrado modular para columnetas y vigas de amarre - Sótano 2 - Sector 1 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
|  |  |  | Encofrado y desencofrado modular para columnetas y vigas de amarre - Sótano 2 - Sector 2 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **24.3750** | **m2** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Encofrado y desencofrado modular para columnetas y vigas de amarre - Sótano 1 - Sector 1 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
|  |  |  | Encofrado y desencofrado modular para columnetas y vigas de amarre - Sótano 1 - Sector 2 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **24.3750** | **m2** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 1 - Sector 1 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
|  |  |  | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 1 - Sector 2 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **24.3750** | **m2** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 2 - Sector 1 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
|  |  |  | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 2 - Sector 2 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **24.3750** | **m2** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 3 - Sector 1 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
|  |  |  | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 3 - Sector 2 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **24.3750** | **m2** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 4 - Sector 1 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
|  |  |  | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 4 - Sector 2 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **24.3750** | **m2** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 5 - Sector 1 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
|  |  |  | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 5 - Sector 2 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **24.3750** | **m2** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 6 - Sector 1 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
|  |  |  | Encofrado y desencofrado modular para columnetas y vigas de amarre - Piso 6 - Sector 2 | 1.0000 | 3.4911 | 3.4911 | 1.0000 | 12.1875 | m2 |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **24.3750** | **m2** |

> **Total verificado 09.03:** `195.0 m2`. Diferencia = `0.0000`.

### Partida 09.04: Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `420.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Sótano 2 - Sector 1 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
|  |  |  | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Sótano 2 - Sector 2 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **52.5000** | **m** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Sótano 1 - Sector 1 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
|  |  |  | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Sótano 1 - Sector 2 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **52.5000** | **m** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 1 - Sector 1 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
|  |  |  | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 1 - Sector 2 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **52.5000** | **m** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 2 - Sector 1 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
|  |  |  | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 2 - Sector 2 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **52.5000** | **m** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 3 - Sector 1 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
|  |  |  | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 3 - Sector 2 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **52.5000** | **m** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 4 - Sector 1 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
|  |  |  | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 4 - Sector 2 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **52.5000** | **m** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 5 - Sector 1 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
|  |  |  | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 5 - Sector 2 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **52.5000** | **m** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 6 - Sector 1 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
|  |  |  | Junta de aislamiento sísmico de 1" entre tabique y estructura de pórtico con poliestireno y sikaflex - Piso 6 - Sector 2 | 1.0000 | 26.2500 | 1.0000 | 1.0000 | 26.2500 | m |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **52.5000** | **m** |

> **Total verificado 09.04:** `420.0 m`. Diferencia = `0.0000`.

## 10.00 Instalaciones Sanitarias

### Partida 10.01: Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado)
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `96.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Sótano 2 - Sector 1 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
|  |  |  | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Sótano 2 - Sector 2 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **12.0000** | **und** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Sótano 1 - Sector 1 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
|  |  |  | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Sótano 1 - Sector 2 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **12.0000** | **und** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 1 - Sector 1 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
|  |  |  | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 1 - Sector 2 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **12.0000** | **und** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 2 - Sector 1 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
|  |  |  | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 2 - Sector 2 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **10.0000** | **und** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 3 - Sector 1 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
|  |  |  | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 3 - Sector 2 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **10.0000** | **und** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 4 - Sector 1 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
|  |  |  | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 4 - Sector 2 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **10.0000** | **und** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 5 - Sector 1 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
|  |  |  | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 5 - Sector 2 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **10.0000** | **und** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 6 - Sector 1 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
|  |  |  | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Piso 6 - Sector 2 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **10.0000** | **und** |
| Azotea | 19.5 | Sectores 1 y 2 | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Azotea - Sector 1 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
|  |  |  | Pases y mangas herméticas en vigas y losas para montantes sanitarias (BIM coordinado) - Azotea - Sector 2 | 5.0000 | 1.0000 | 1.0000 | 1.0000 | 5.0000 | und |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **10.0000** | **und** |

> **Total verificado 10.01:** `96.0 und`. Diferencia = `0.0000`.

### Partida 10.02: Red colectora de desagüe colgada PVC SAL 4" y 2" en sótanos
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `280.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Red colectora de desagüe colgada PVC SAL 4" y 2" en sótanos - Sótano 2 - Sector 1 | 1.0000 | 70.0000 | 1.0000 | 1.0000 | 70.0000 | m |
|  |  |  | Red colectora de desagüe colgada PVC SAL 4" y 2" en sótanos - Sótano 2 - Sector 2 | 1.0000 | 70.0000 | 1.0000 | 1.0000 | 70.0000 | m |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **140.0000** | **m** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Red colectora de desagüe colgada PVC SAL 4" y 2" en sótanos - Sótano 1 - Sector 1 | 1.0000 | 70.0000 | 1.0000 | 1.0000 | 70.0000 | m |
|  |  |  | Red colectora de desagüe colgada PVC SAL 4" y 2" en sótanos - Sótano 1 - Sector 2 | 1.0000 | 70.0000 | 1.0000 | 1.0000 | 70.0000 | m |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **140.0000** | **m** |

> **Total verificado 10.02:** `280.0 m`. Diferencia = `0.0000`.

### Partida 10.03: Montantes de ventilación y desagüe vertical PVC SAL 4"
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `195.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Montantes de ventilación y desagüe vertical PVC SAL 4" - Sótano 2 - Sector 1 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
|  |  |  | Montantes de ventilación y desagüe vertical PVC SAL 4" - Sótano 2 - Sector 2 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **21.6666** | **m** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Montantes de ventilación y desagüe vertical PVC SAL 4" - Sótano 1 - Sector 1 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
|  |  |  | Montantes de ventilación y desagüe vertical PVC SAL 4" - Sótano 1 - Sector 2 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **21.6666** | **m** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 1 - Sector 1 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
|  |  |  | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 1 - Sector 2 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **21.6666** | **m** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 2 - Sector 1 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
|  |  |  | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 2 - Sector 2 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **21.6666** | **m** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 3 - Sector 1 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
|  |  |  | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 3 - Sector 2 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **21.6666** | **m** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 4 - Sector 1 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
|  |  |  | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 4 - Sector 2 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **21.6666** | **m** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 5 - Sector 1 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
|  |  |  | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 5 - Sector 2 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **21.6666** | **m** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 6 - Sector 1 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
|  |  |  | Montantes de ventilación y desagüe vertical PVC SAL 4" - Piso 6 - Sector 2 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **21.6666** | **m** |
| Azotea | 19.5 | Sectores 1 y 2 | Montantes de ventilación y desagüe vertical PVC SAL 4" - Azotea - Sector 1 | 1.0000 | 10.8333 | 1.0000 | 1.0000 | 10.8333 | m |
|  |  |  | Montantes de ventilación y desagüe vertical PVC SAL 4" - Azotea - Sector 2 | 1.0000 | 10.8339 | 1.0000 | 1.0000 | 10.8339 | m |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **21.6672** | **m** |

> **Total verificado 10.03:** `195.0 m`. Diferencia = `0.0000`.

### Partida 10.04: Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `24.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje - Sótano 2 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje - Sótano 2 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje - Sótano 1 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje - Sótano 1 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Azotea | 19.5 | Sectores 1 y 2 | Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje - Azotea - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Sumideros con trampa P, cajas de registro prefabricadas de concreto y rejillas de drenaje - Azotea - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **8.0000** | **und** |

> **Total verificado 10.04:** `24.0 und`. Diferencia = `0.0000`.

### Partida 10.05: Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `350.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Sótano 2 - Sector 1 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
|  |  |  | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Sótano 2 - Sector 2 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **38.8888** | **m** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Sótano 1 - Sector 1 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
|  |  |  | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Sótano 1 - Sector 2 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **38.8888** | **m** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 1 - Sector 1 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
|  |  |  | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 1 - Sector 2 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **38.8888** | **m** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 2 - Sector 1 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
|  |  |  | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 2 - Sector 2 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **38.8888** | **m** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 3 - Sector 1 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
|  |  |  | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 3 - Sector 2 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **38.8888** | **m** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 4 - Sector 1 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
|  |  |  | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 4 - Sector 2 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **38.8888** | **m** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 5 - Sector 1 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
|  |  |  | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 5 - Sector 2 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **38.8888** | **m** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 6 - Sector 1 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
|  |  |  | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Piso 6 - Sector 2 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **38.8888** | **m** |
| Azotea | 19.5 | Sectores 1 y 2 | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Azotea - Sector 1 | 1.0000 | 19.4444 | 1.0000 | 1.0000 | 19.4444 | m |
|  |  |  | Red de agua contra incendio (ACI): Tubería de acero ranurado Sch 40 2" y rociadores automáticos UL/FM - Azotea - Sector 2 | 1.0000 | 19.4452 | 1.0000 | 1.0000 | 19.4452 | m |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **38.8896** | **m** |

> **Total verificado 10.05:** `350.0 m`. Diferencia = `0.0000`.

## 11.00 Instalaciones Eléctricas

### Partida 11.01: Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `120.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Sótano 2 - Sector 1 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
|  |  |  | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Sótano 2 - Sector 2 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **14.0000** | **und** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Sótano 1 - Sector 1 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
|  |  |  | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Sótano 1 - Sector 2 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **14.0000** | **und** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 1 - Sector 1 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
|  |  |  | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 1 - Sector 2 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **14.0000** | **und** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 2 - Sector 1 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
|  |  |  | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 2 - Sector 2 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **14.0000** | **und** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 3 - Sector 1 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
|  |  |  | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 3 - Sector 2 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **14.0000** | **und** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 4 - Sector 1 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
|  |  |  | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 4 - Sector 2 | 7.0000 | 1.0000 | 1.0000 | 1.0000 | 7.0000 | und |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **14.0000** | **und** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 5 - Sector 1 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
|  |  |  | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 5 - Sector 2 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **12.0000** | **und** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 6 - Sector 1 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
|  |  |  | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Piso 6 - Sector 2 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **12.0000** | **und** |
| Azotea | 19.5 | Sectores 1 y 2 | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Azotea - Sector 1 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
|  |  |  | Pases y canalizaciones embebidas en losas y placas para alimentadores eléctricos - Azotea - Sector 2 | 6.0000 | 1.0000 | 1.0000 | 1.0000 | 6.0000 | und |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **12.0000** | **und** |

> **Total verificado 11.01:** `120.0 und`. Diferencia = `0.0000`.

### Partida 11.02: Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `1850.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Sótano 2 - Sector 1 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
|  |  |  | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Sótano 2 - Sector 2 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **205.5556** | **m** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Sótano 1 - Sector 1 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
|  |  |  | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Sótano 1 - Sector 2 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **205.5556** | **m** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 1 - Sector 1 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
|  |  |  | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 1 - Sector 2 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **205.5556** | **m** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 2 - Sector 1 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
|  |  |  | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 2 - Sector 2 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **205.5556** | **m** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 3 - Sector 1 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
|  |  |  | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 3 - Sector 2 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **205.5556** | **m** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 4 - Sector 1 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
|  |  |  | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 4 - Sector 2 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **205.5556** | **m** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 5 - Sector 1 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
|  |  |  | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 5 - Sector 2 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **205.5556** | **m** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 6 - Sector 1 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
|  |  |  | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Piso 6 - Sector 2 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **205.5556** | **m** |
| Azotea | 19.5 | Sectores 1 y 2 | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Azotea - Sector 1 | 1.0000 | 102.7778 | 1.0000 | 1.0000 | 102.7778 | m |
|  |  |  | Tubería conduit PVC SAP 3/4" y 1" embebida para circuitos derivados - Azotea - Sector 2 | 1.0000 | 102.7774 | 1.0000 | 1.0000 | 102.7774 | m |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **205.5552** | **m** |

> **Total verificado 11.02:** `1850.0 m`. Diferencia = `0.0000`.

### Partida 11.03: Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco)
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `3200.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Sótano 2 - Sector 1 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
|  |  |  | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Sótano 2 - Sector 2 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **355.5556** | **m** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Sótano 1 - Sector 1 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
|  |  |  | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Sótano 1 - Sector 2 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **355.5556** | **m** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 1 - Sector 1 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
|  |  |  | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 1 - Sector 2 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **355.5556** | **m** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 2 - Sector 1 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
|  |  |  | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 2 - Sector 2 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **355.5556** | **m** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 3 - Sector 1 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
|  |  |  | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 3 - Sector 2 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **355.5556** | **m** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 4 - Sector 1 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
|  |  |  | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 4 - Sector 2 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **355.5556** | **m** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 5 - Sector 1 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
|  |  |  | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 5 - Sector 2 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **355.5556** | **m** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 6 - Sector 1 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
|  |  |  | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Piso 6 - Sector 2 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **355.5556** | **m** |
| Azotea | 19.5 | Sectores 1 y 2 | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Azotea - Sector 1 | 1.0000 | 177.7778 | 1.0000 | 1.0000 | 177.7778 | m |
|  |  |  | Conductor de cobre libre de halógenos LSOH 2.5 mm2 (Freetox Indeco) - Azotea - Sector 2 | 1.0000 | 177.7774 | 1.0000 | 1.0000 | 177.7774 | m |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **355.5552** | **m** |

> **Total verificado 11.03:** `3200.0 m`. Diferencia = `0.0000`.

### Partida 11.04: Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `210.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Sótano 2 - Sector 1 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
|  |  |  | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Sótano 2 - Sector 2 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **24.0000** | **und** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Sótano 1 - Sector 1 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
|  |  |  | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Sótano 1 - Sector 2 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **24.0000** | **und** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 1 - Sector 1 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
|  |  |  | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 1 - Sector 2 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **24.0000** | **und** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 2 - Sector 1 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
|  |  |  | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 2 - Sector 2 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **24.0000** | **und** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 3 - Sector 1 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
|  |  |  | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 3 - Sector 2 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **24.0000** | **und** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 4 - Sector 1 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
|  |  |  | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 4 - Sector 2 | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **24.0000** | **und** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 5 - Sector 1 | 11.0000 | 1.0000 | 1.0000 | 1.0000 | 11.0000 | und |
|  |  |  | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 5 - Sector 2 | 11.0000 | 1.0000 | 1.0000 | 1.0000 | 11.0000 | und |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **22.0000** | **und** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 6 - Sector 1 | 11.0000 | 1.0000 | 1.0000 | 1.0000 | 11.0000 | und |
|  |  |  | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Piso 6 - Sector 2 | 11.0000 | 1.0000 | 1.0000 | 1.0000 | 11.0000 | und |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **22.0000** | **und** |
| Azotea | 19.5 | Sectores 1 y 2 | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Azotea - Sector 1 | 11.0000 | 1.0000 | 1.0000 | 1.0000 | 11.0000 | und |
|  |  |  | Cajas de pase modulares de F°G° pesadas para sistemas de iluminación y fuerza - Azotea - Sector 2 | 11.0000 | 1.0000 | 1.0000 | 1.0000 | 11.0000 | und |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **22.0000** | **und** |

> **Total verificado 11.04:** `210.0 und`. Diferencia = `0.0000`.

### Partida 11.05: Sistema de puesta a tierra integral de baja resistencia (< 5 ohmios) en foso de sótanos
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `4.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Sistema de puesta a tierra integral de baja resistencia (< 5 ohmios) en foso de sótanos - Sótano 2 - Sector 1 | 2.0000 | 1.0000 | 1.0000 | 1.0000 | 2.0000 | und |
|  |  |  | Sistema de puesta a tierra integral de baja resistencia (< 5 ohmios) en foso de sótanos - Sótano 2 - Sector 2 | 2.0000 | 1.0000 | 1.0000 | 1.0000 | 2.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **4.0000** | **und** |

> **Total verificado 11.05:** `4.0 und`. Diferencia = `0.0000`.

## 12.00 Instalaciones Mecánicas

### Partida 12.01: Pases estructurales coordinados BIM para ductos de presurización de escalera
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `18.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Piso 1 | 0.0 | Sectores 1 y 2 | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 1 - Sector 1 | 2.0000 | 1.0000 | 1.0000 | 1.0000 | 2.0000 | und |
|  |  |  | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 1 - Sector 2 | 2.0000 | 1.0000 | 1.0000 | 1.0000 | 2.0000 | und |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **4.0000** | **und** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 2 - Sector 1 | 2.0000 | 1.0000 | 1.0000 | 1.0000 | 2.0000 | und |
|  |  |  | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 2 - Sector 2 | 2.0000 | 1.0000 | 1.0000 | 1.0000 | 2.0000 | und |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **4.0000** | **und** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 3 - Sector 1 | 2.0000 | 1.0000 | 1.0000 | 1.0000 | 2.0000 | und |
|  |  |  | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 3 - Sector 2 | 2.0000 | 1.0000 | 1.0000 | 1.0000 | 2.0000 | und |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **4.0000** | **und** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 4 - Sector 1 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | und |
|  |  |  | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 4 - Sector 2 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | und |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **2.0000** | **und** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 5 - Sector 1 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | und |
|  |  |  | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 5 - Sector 2 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | und |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **2.0000** | **und** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 6 - Sector 1 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | und |
|  |  |  | Pases estructurales coordinados BIM para ductos de presurización de escalera - Piso 6 - Sector 2 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | und |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **2.0000** | **und** |

> **Total verificado 12.01:** `18.0 und`. Diferencia = `0.0000`.

### Partida 12.02: Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72)
- **Unidad Oficial:** `m` | **Cantidad Total Conciliada:** `850.0 m`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Sótano 2 - Sector 1 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
|  |  |  | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Sótano 2 - Sector 2 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **94.4444** | **m** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Sótano 1 - Sector 1 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
|  |  |  | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Sótano 1 - Sector 2 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **94.4444** | **m** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 1 - Sector 1 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
|  |  |  | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 1 - Sector 2 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **94.4444** | **m** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 2 - Sector 1 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
|  |  |  | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 2 - Sector 2 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **94.4444** | **m** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 3 - Sector 1 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
|  |  |  | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 3 - Sector 2 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **94.4444** | **m** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 4 - Sector 1 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
|  |  |  | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 4 - Sector 2 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **94.4444** | **m** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 5 - Sector 1 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
|  |  |  | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 5 - Sector 2 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **94.4444** | **m** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 6 - Sector 1 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
|  |  |  | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Piso 6 - Sector 2 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **94.4444** | **m** |
| Azotea | 19.5 | Sectores 1 y 2 | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Azotea - Sector 1 | 1.0000 | 47.2222 | 1.0000 | 1.0000 | 47.2222 | m |
|  |  |  | Canalizaciones embebidas para sistema de detección y alarma de incendios (NFPA 72) - Azotea - Sector 2 | 1.0000 | 47.2226 | 1.0000 | 1.0000 | 47.2226 | m |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **94.4448** | **m** |

> **Total verificado 12.02:** `850.0 m`. Diferencia = `0.0000`.

### Partida 12.03: Anclajes y soportes antivibratorios para equipos electromecánicos de bombeo
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `8.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Anclajes y soportes antivibratorios para equipos electromecánicos de bombeo - Sótano 2 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Anclajes y soportes antivibratorios para equipos electromecánicos de bombeo - Sótano 2 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **8.0000** | **und** |

> **Total verificado 12.03:** `8.0 und`. Diferencia = `0.0000`.

### Partida 12.04: Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `64.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Sótano 2 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Sótano 2 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Sótano 1 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Sótano 1 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 1 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 1 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 2 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 2 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 3 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 3 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 4 - Sector 1 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
|  |  |  | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 4 - Sector 2 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **6.0000** | **und** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 5 - Sector 1 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
|  |  |  | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 5 - Sector 2 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **6.0000** | **und** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 6 - Sector 1 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
|  |  |  | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Piso 6 - Sector 2 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **6.0000** | **und** |
| Azotea | 19.5 | Sectores 1 y 2 | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Azotea - Sector 1 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
|  |  |  | Sellado cortafuego Firestop (RF-120) en todos los pases de losas y muros cortafuego - Azotea - Sector 2 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **6.0000** | **und** |

> **Total verificado 12.04:** `64.0 und`. Diferencia = `0.0000`.

## 13.00 Control de Calidad

### Partida 13.01: Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `144.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Sótano 2 - Sector 1 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
|  |  |  | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Sótano 2 - Sector 2 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **16.0000** | **und** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Sótano 1 - Sector 1 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
|  |  |  | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Sótano 1 - Sector 2 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **16.0000** | **und** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 1 - Sector 1 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
|  |  |  | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 1 - Sector 2 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **16.0000** | **und** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 2 - Sector 1 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
|  |  |  | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 2 - Sector 2 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **16.0000** | **und** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 3 - Sector 1 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
|  |  |  | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 3 - Sector 2 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **16.0000** | **und** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 4 - Sector 1 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
|  |  |  | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 4 - Sector 2 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **16.0000** | **und** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 5 - Sector 1 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
|  |  |  | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 5 - Sector 2 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **16.0000** | **und** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 6 - Sector 1 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
|  |  |  | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Piso 6 - Sector 2 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **16.0000** | **und** |
| Azotea | 19.5 | Sectores 1 y 2 | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Azotea - Sector 1 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
|  |  |  | Protocolos tripartitos de liberación de pases y armaduras previo a vaciados de concreto - Azotea - Sector 2 | 8.0000 | 1.0000 | 1.0000 | 1.0000 | 8.0000 | und |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **16.0000** | **und** |

> **Total verificado 13.01:** `144.0 und`. Diferencia = `0.0000`.

### Partida 13.02: Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL)
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `65.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Sótano 2 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Sótano 2 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Sótano 1 | -2.8 | Sectores 1 y 2 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Sótano 1 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Sótano 1 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Sótano 1** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Piso 1 | 0.0 | Sectores 1 y 2 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 1 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 1 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Piso 1** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Piso 2 | 3.5 | Sectores 1 y 2 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 2 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 2 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Piso 2** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Piso 3 | 6.7 | Sectores 1 y 2 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 3 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 3 - Sector 2 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
| **Subtotal Piso 3** |  |  |  |  |  |  |  | **8.0000** | **und** |
| Piso 4 | 9.9 | Sectores 1 y 2 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 4 - Sector 1 | 4.0000 | 1.0000 | 1.0000 | 1.0000 | 4.0000 | und |
|  |  |  | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 4 - Sector 2 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
| **Subtotal Piso 4** |  |  |  |  |  |  |  | **7.0000** | **und** |
| Piso 5 | 13.1 | Sectores 1 y 2 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 5 - Sector 1 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
|  |  |  | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 5 - Sector 2 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
| **Subtotal Piso 5** |  |  |  |  |  |  |  | **6.0000** | **und** |
| Piso 6 | 16.3 | Sectores 1 y 2 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 6 - Sector 1 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
|  |  |  | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Piso 6 - Sector 2 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
| **Subtotal Piso 6** |  |  |  |  |  |  |  | **6.0000** | **und** |
| Azotea | 19.5 | Sectores 1 y 2 | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Azotea - Sector 1 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
|  |  |  | Ensayos de resistencia a compresión de probetas de concreto a 7, 14 y 28 días (INACAL) - Azotea - Sector 2 | 3.0000 | 1.0000 | 1.0000 | 1.0000 | 3.0000 | und |
| **Subtotal Azotea** |  |  |  |  |  |  |  | **6.0000** | **und** |

> **Total verificado 13.02:** `65.0 und`. Diferencia = `0.0000`.

### Partida 13.03: Ensayos de tracción y doblado de acero de refuerzo en laboratorio acreditado
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `12.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| General de obra | 0.0 | General | Ensayos de tracción y doblado de acero de refuerzo en laboratorio acreditado - General de obra - General | 12.0000 | 1.0000 | 1.0000 | 1.0000 | 12.0000 | und |
| **Subtotal General de obra** |  |  |  |  |  |  |  | **12.0000** | **und** |

> **Total verificado 13.03:** `12.0 und`. Diferencia = `0.0000`.

### Partida 13.04: Pruebas hidrostáticas y de estanqueidad presurizada en redes y cisterna (72 horas)
- **Unidad Oficial:** `glb` | **Cantidad Total Conciliada:** `1.0 glb`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | General | Pruebas hidrostáticas y de estanqueidad presurizada en redes y cisterna (72 horas) - Sótano 2 - General | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | glb |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **1.0000** | **glb** |

> **Total verificado 13.04:** `1.0 glb`. Diferencia = `0.0000`.

### Partida 13.05: Ensayos de densidad de campo (cono de arena) en rellenos y subrasante al 95% PM
- **Unidad Oficial:** `und` | **Cantidad Total Conciliada:** `18.0 und`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| Sótano 2 | -5.6 | Sectores 1 y 2 | Ensayos de densidad de campo (cono de arena) en rellenos y subrasante al 95% PM - Sótano 2 - Sector 1 | 9.0000 | 1.0000 | 1.0000 | 1.0000 | 9.0000 | und |
|  |  |  | Ensayos de densidad de campo (cono de arena) en rellenos y subrasante al 95% PM - Sótano 2 - Sector 2 | 9.0000 | 1.0000 | 1.0000 | 1.0000 | 9.0000 | und |
| **Subtotal Sótano 2** |  |  |  |  |  |  |  | **18.0000** | **und** |

> **Total verificado 13.05:** `18.0 und`. Diferencia = `0.0000`.

### Partida 13.06: Elaboración y entrega del Dossier Final de Calidad y Planos As-Built en formato BIM/CAD
- **Unidad Oficial:** `glb` | **Cantidad Total Conciliada:** `1.0 glb`
- **Método:** `SUMA_DE_SUBTOTALES_SINTETICOS_REPRODUCIBLES`
- **Estado:** `CONFORME_SINTETICO`

| Nivel | Cota | Sector | Elemento sintético | Veces | Largo | Ancho | Alto | Parcial | Unidad |
|---|---:|---|---|---:|---:|---:|---:|---:|---|
| General de obra | 0.0 | General | Elaboración y entrega del Dossier Final de Calidad y Planos As-Built en formato BIM/CAD - General de obra - General | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | glb |
| **Subtotal General de obra** |  |  |  |  |  |  |  | **1.0000** | **glb** |

> **Total verificado 13.06:** `1.0 glb`. Diferencia = `0.0000`.
