---
id: "EETT-03.01"
tipo: "especificacion_tecnica_generada"
estado: "BORRADOR_TRAZABLE"
wbs: "WBS-03.01"
requisito: "REQ-WBS-03.01"
capitulo: "03.00"
unidad: "m3"
cantidad: 3200.0
estado_gate: "LISTO"
naturaleza_datos: "SINTETICO_APROXIMADO"
clasificacion_epistemica: "DATO_EXPRESO_DEL_PROYECTO+TEXTO_NORMATIVO+INFERENCIA"
tags: ["cerebro_digital", "eett_generada", "prompt_02"]
---

# EETT-03.01 — Excavación Masiva Con Excavadora Sobre Orugas 200 Hp Hasta Cota -5.80 M

> Partida [[WBS-03.01]] · Requisito [[REQ-WBS-03.01]] · Capítulo [[WBS-03.00]]  
> **Estado:** `BORRADOR_TRAZABLE` · **Naturaleza de datos:** `SINTETICO_APROXIMADO` · **Gate:** **LISTO**  
> Ver directivas marco en [[GENERALIDADES_EETT]].

---

## 1. Identificación y Metadatos de la Partida

| Parámetro | Valor Declarado | Fuente de Información |
|---|---|---|
| **Código EETT / WBS** | `EETT-03.01` / `[[WBS-03.01]]` | WBS Maestra del Proyecto |
| **Requisito Técnico** | `[[REQ-WBS-03.01]]` | Cerebro Digital Carpeta 02 |
| **Capítulo WBS** | `[[WBS-03.00]]` | Catálogo de Capítulos WBS |
| **Unidad de Medida** | `m3` | Norma Técnica Metrados MVCS RD-073-2010 |
| **Metrado Oficial** | **3200.0** | Planilla Maestra de Metrados |
| **Nivel de Criticidad** | Nivel 1 | Matriz de Criticidad de Obra |
| **Estado Gate de Madurez** | **LISTO** | Auditoría Automatizada Gate 02 |

---

## 2. Objeto y Alcance de la Especificación

Esta especificación técnica establece las condiciones técnicas, constructivas, normativas y de control de calidad para la ejecución de la partida Excavación masiva con excavadora sobre orugas 200 HP hasta cota -5.80 m, correspondiente a la especialidad de Estructuras / Movimiento de Tierras, en el marco del proyecto de construcción del Edificio Educativo de 6 pisos, 2 sótanos y azotea ubicado en Jr. Las Gardenias 480, Surquillo.

Descripción Integral de la Actividad:

Excavación masiva a cielo abierto con excavadora sobre orugas de 22 Tn en material de grava aluvial densa de Lima (GP), con carguío directo sobre camiones volquete de 15 m3 para el desalojo de los volúmenes correspondientes a los sótanos 1 y 2 hasta niveles de falso piso.

Delimitación Espacial y Frentes Operativos:

* Ubicación en el Edificio: Sótanos 1 y 2 (0.00 a -5.80 m), conforme a la sectorización de obra y las indicaciones de los planos de ingeniería PL-TOP-01.
* Alcance Operativo Conciliado: Volumen geométrico de 2,800.00 m3 medidos en banco entre la cota ±0.00 y la cota -5.60 m, respetando las líneas de calzadura y taludes perimetrales. Inclusiones Explícitas en el Alcance Contractual:

1. Suministro, transporte, almacenamiento y custodia técnica de la totalidad de materiales e insumos normados puestos al pie de obra.

2. Disposición de equipos mecánicos, herramientas especializadas y personal calificado con homologación técnica vigente.

3. Ejecución sistemática conforme a las tolerancias dimensionales, alineamiento, niveles y acabados estipulados en planos.

4. Implementación integral de medidas preventivas de Seguridad y Salud en el Trabajo (SST) y protocolos de control ambiental.

5. Ejecución obligatoria de los ensayos de control de calidad en laboratorio acreditado ante INACAL y emisión de protocolos liberados.

Exclusiones Explícitas:

* No se incluyen actividades correspondientes a partidas predecesoras o sucesoras cuantificadas independientemente en el catálogo WBS del presupuesto oficial.
* Quedan excluidas reparaciones por negligencia constructiva o sobrecostos derivados de trabajos ejecutados sin la debida liberación previa de la Supervisión.
---

---

## 3. Condiciones Previas y Prerrequisitos de Ejecución

1. **Liberación del Frente de Trabajo:** Antes de iniciar cualquier labor, el Contratista deberá verificar que las actividades predecesoras se encuentren formalmente concluidas y liberadas por la Supervisión.
2. **Permisos y Seguridad:** Cumplimiento imperativo del Análisis de Trabajo Seguro (ATS) y emisión de PETAR si la tarea involucra trabajos de alto riesgo.
3. **Condiciones Generales:** Rigen de manera estricta todas las disposiciones estipuladas en [[GENERALIDADES_EETT]] sobre orden de prelación, tolerancias y obligaciones generales.

---

## 4. Recursos y Requisitos Técnicos (Materiales, Equipos y Personal)

### 4.1. Materiales e Insumos Normados
Todos los materiales requeridos para la ejecución de la partida deberán ser de primer uso, libres de defectos y cumplir estrictamente con las especificaciones técnicas estipuladas en el RNE-E050 y estándares internacionales homologados (ASTM D1556 (Cono de Arena) / ASTM D1557 (Proctor)).

Insumos y Materiales Principales:

No incorpora insumos; consumo de combustible diésel y lubricantes.

Criterio Técnico y Respaldo Geotécnico/Estructural:

* Memoria de Cálculo (MEM-CASCO-2026-REV-D): Movimiento de Tierras - Vaciado de Sótanos.
* Estudio Básico (EMS-01): q_adm=3.50 kg/cm², asentamiento tolerable < 2.5 cm, módulo de balasto Ks=7.0 kg/cm³. * Exigencia Normativa Concreta: Compactación de fondo de zapatas y rellenos al 95% de la Máxima Densidad Seca. Certificaciones Exigibles por Lote:

* Certificados de calidad de fábrica originales o copias legalizadas emitidas por el fabricante para cada lote que ingrese a obra.
* Guías de remisión con indicación expresa de fecha de despacho, hora de preparación, dosificación de diseño y características técnicas.
* Fichas técnicas del fabricante y hojas de datos de seguridad (MSDS) para productos químicos o aditivos industriales.
---

### 4.2. Equipos, Maquinarias y Herramientas Asignadas
El Contratista dispondrá en obra del equipamiento mecánico idóneo y herramientas en perfecto estado de operatividad:

Relación de Equipos y Herramientas Asignadas:

Excavadora hidráulica sobre orugas de 22 Tn (cucharón 1.2 m3), camiones volquete de 15 m3, cuadrilla de desquinche, señalero/vigía.

Requisitos de Calibración y Mantenimiento Técnico:

* Todo equipo de medición, nivelación topográfica, control presurizado o ensayo deberá contar con Certificado de Calibración Técnica vigente, con antigüedad no mayor a seis (6) meses, emitido por laboratorio acreditado.
* Mantenimiento preventivo periódico de maquinaria pesada y equipos motorizados para evitar emanaciones excesivas de gases o fugas de fluidos hidráulicos.
* Disponibilidad obligatoria de equipos de respaldo o retén en obra para faenas críticas que demanden continuidad operativa ininterrumpida.
---

---

## 5. Procedimiento y Método de Ejecución Constructiva

La ejecución en campo se desarrollará bajo una secuencia técnica rigurosa y ordenada:

Secuencia Operativa de Ejecución:

1. Marcado de cotas de corte con nivel láser. 2. Ataque frontal con excavadora sobre orugas mediante capas horizontales de 1.50 m. 3. Carguío ordenado de camiones volquete dentro del predio. 4. Peinado de taludes y desquinche manual de bolonería suelta.

Protocolo de Ejecución en Cuatro Fases:

**Fase 1:**   Verificación Previa y Liberación del Frente: Limpieza profunda de la zona de trabajo, trazo topográfico milimétrico, inspección de armaduras o soportes y firma obligatoria del protocolo de inicio suscrito por la Supervisión.

**Fase 2:**   Colocación, Montaje o Procesamiento: Ejecución de la tarea aplicando las técnicas normadas, controlando espesores de capa, temperaturas, presiones o tiempos de fraguado según corresponda.

**Fase 3:**   Acabado, Curado y Protección: Protección inmediata del elemento frente a la intemperie, radiación solar o tránsito indebido; aplicación de curado húmedo continuo o químico durante el plazo reglamentario.

**Fase 4:**   Retiro de Protecciones y Limpieza Final: Desmovilización de encofrados o andamios previa verificación de resistencia alcanzada, retiro ordenado de residuos y entrega formal del frente liberado.

---

---

## 6. Control de Calidad, Ensayos y Criterios de Aceptación

### 6.1. Plan de Inspección y Ensayos (ITP)
| Control / Actividad | Criterio de Aceptación | Frecuencia / Registro Mínimo |
|---|---|---|
| Control de cotas y subrasante | Tolerancia de nivelación ± 10 mm respecto a cota -5.80 m | Por cada batache o sector / Libreta topográfica liberada |
| Densidad de campo en rellenos | ≥ 95% de la Máxima Densidad Seca (Proctor Modificado ASTM D1557) | 1 ensayo por cada 250 m² o capa compactada / Certificado de Laboratorio |
| Control de humedad de afirmado | Humedad óptima ± 2% de la humedad del Proctor | Por lote de material colocado / Reporte geotécnico |


### 6.2. Tolerancias Dimensionales y Criterios de Aceptación / Rechazo
El aseguramiento de la calidad se regirá por el Plan de Control de Calidad del proyecto y las directrices vinculantes del RNE-E050 (Capítulo 5 - Movimiento de Tierras y Rellenos):

Ensayos Obligatorios de Laboratorio y Campo:

Ensayos de densidad de campo in-situ cada 100 m² de capa compactada e=0.20m.

Tolerancias Dimensionales Admisibles:

Nivelación de fondo de corte: tolerancia +0.0 cm / -5.0 cm respecto a cota de proyecto.

Criterios Formales de Aceptación:

* La partida se considerará técnicamente aceptada cuando el 100% de los ensayos de laboratorio arrojen resultados conformes con las resistencias, densidades o presiones de diseño especificadas.
* Verificación geométrica favorable de alineamiento, cotas de nivel y recubrimientos libres según tolerancias de la norma ACI 117.
* Levantamiento total de observaciones y suscripción conforme del Protocolo de Liberación QA/QC por el Inspector o Supervisor de Obra.
Criterios y Procedimiento ante Rechazo o No Conformidad:

* Todo elemento que incumpla los parámetros de resistencia, presente segregaciones severas, fisuras no admisibles o desviaciones fuera de tolerancia será observado y paralizado mediante Notificación de No Conformidad.
* El Contratista deberá ejecutar ensayos complementarios no destructivos o destructivos (testigos diamantados, pruebas de carga) a su costo exclusivo.
* En caso de no superar las evaluaciones de seguridad estructural, el elemento será demolido y reconstruido íntegramente a entera cuenta y riesgo del Contratista.
---

---

## 7. Seguridad, Salud en el Trabajo, Medio Ambiente e Interfaces

La ejecución de la partida acatará de manera imperativa el Reglamento Nacional de Edificaciones (Norma Técnica G.050) y el D.S. N° 011-2019-TR:

Directrices Específicas de Seguridad y Salud:

Charla diaria 5 min, ATS diario, uso obligatorio de EPP básico y específico, cumplimiento del Plan SST RNE G.050.

Medidas Operativas y Protecciones Exigibles:

* Elaboración diaria obligatoria del Análisis de Trabajo Seguro (ATS) y charla de seguridad de 5 minutos antes del inicio de labores.
* Tramitación de Permiso Escrito para Trabajos de Alto Riesgo (PETAR) en tareas en altura (altura mayor a 1.80 m), excavaciones profundas o izaje crítico de cargas.
* Uso estricto de Equipo de Protección Individual (EPI) normado: casco con barbiquejo (ANSI Z89.1), calzado de seguridad con puntera de acero (ASTM F2413), lentes con protección lateral (ANSI Z87.1), guantes acordes a la labor y arnés de cuerpo entero con doble línea de vida (ANSI Z359.11).
* Instalación y mantenimiento permanente de protecciones colectivas: barandas rígidas perimetrales a una altura de 1.00 m, rodapiés de 15 cm, mallas de señalización, líneas de vida de acero certificadas y tapas resistentes en pases de losa.
* Gestión Ambiental y Residuos: Disposición diferenciada de Residuos de Construcción y Demolición (RCD) en cilindros codificados por color (NTP 900.058); prohibición absoluta de vertido de aguas residuales o lechadas de cemento al terreno natural o redes públicas sin neutralización previa en batea estanca.
---

---

## 8. Método de Medición y Base de Pago

### 8.1. Regla de Medición y Cómputo
La cuantificación volumétrica o métrica de la partida se realizará con sujeción a la Norma Técnica de Metrados para Obras de Edificación y Habilitaciones Urbanas (R.D. N° 073-2010/VIVIENDA/VMCS-DNC):

* Unidad Oficial de Medida: m3.
* Criterio Oficial de Medición: Volumen geométrico en banco de excavación a máquina. * Metrado Oficial Conciliado: 3200.00 m3, verificado en el modelo federado BIM y la planilla de metrados por niveles.
Reglas Oficiales de Deducción y Conciliación Geométrica:

* Se computarán estrictamente las dimensiones netas efectivas ejecutadas conforme a planos.
* En elementos de concreto armado, se aplicarán las deducciones de vanos, pases de tuberías mayores al límite normativo o intersecciones con elementos prioritarios.
* No se reconocerán sobre-anchos, sobre-excavaciones, desperdicios ni excesos atribuibles a métodos constructivos defectuosos del Contratista.
---

### 8.2. Base y Condiciones Contractuales de Pago
El metrado verificado y aprobado según el método de medición se valorizará al Precio Unitario Contractual (P.U.) por m3 establecido en el presupuesto de obra aprobado.

Condición Contractual de Pago:

Pago por unidad ejecutada (m3) previa conformidad firmada del Residente y Supervisor.

Inclusiones Integrales dentro del Precio Unitario:

El precio unitario de la partida constituye la retribución total y definitiva por concepto de:

1. Mano de obra calificada, técnica y peones, con inclusión de leyes sociales completas, gratificaciones, vacaciones, indemnizaciones y seguro complementario contra todo riesgo (SCTR).

2. Suministro, transporte, flete, mermas, acopio y manipuleo de la totalidad de materiales normados puestos a pie de obra.

3. Equipos, maquinarias, herramientas auxiliares, combustibles, lubricantes, repuestos y amortización de capital.

4. Ensayos obligatorios de control de calidad realizados por laboratorio acreditado ante INACAL.

5. Implementos de seguridad personal y colectiva, señalización, gestión ambiental y limpieza final del frente de trabajo.

6. Gastos generales directos e indirectos, imprevistos y utilidad contractual del Contratista.

Condición Previa Indispensable para la Valorización:

No se procesará valorización económica mensual alguna de esta partida sin la presentación y visación formal del Protocolo de Liberación de Calidad y el expediente de certificados de ensayos conformes suscrito por la Supervisión.

---

---

## 9. Matriz de Trazabilidad, Paquete de Evidencia y Respaldo Normativo

### 9.1. Interconexión Cuádruple Semántica
1. **Partida y requisito:** [[WBS-03.01]] · [[REQ-WBS-03.01]]
2. **Normas técnicas habilitadas (Carpeta 02):** [[MVCS-RD073-2010-METRADOS]], [[RNE-G050]], [[RNE-E050]], [[RNE-CE020]]
3. **Documentos y estudios fuente (Carpeta 01):** [[EMS-01]], [[MEM-CASCO-2026]], [[PLAN-TRAB-TEC-SSOMA-QAQC-2026]], [[BASE-DISENO-01]], [[planilla_metrados]]
4. **Planos asociados (Carpeta 01):** [[PL-TOP-01]]

**Referencias restringidas** (`NO_DISPONIBLE_PARA_EETT`; solo registran la brecha): [[ASTM-CONSTRUCCION-ASTM_D1557]]

### 9.2. Estado de Control y Brechas del Gate

**Conformidad de Gate:**
- ✅ Partida sin observaciones abiertas de consistencia. Datos verificados contra planos y memorias técnicas.


---

## Navegación

[[GENERALIDADES_EETT]] · [[MOC_EETT]] · [[MOC_REQUISITOS]] · [[MOC_PROYECTO]]
