---
id: "EETT-07.16"
tipo: "especificacion_tecnica_generada"
estado: "BORRADOR_TRAZABLE"
wbs: "WBS-07.16"
requisito: "REQ-WBS-07.16"
capitulo: "07.00"
unidad: "kg"
cantidad: 2457.0
estado_gate: "LISTO"
naturaleza_datos: "SINTETICO_APROXIMADO"
clasificacion_epistemica: "DATO_EXPRESO_DEL_PROYECTO+TEXTO_NORMATIVO+INFERENCIA"
tags: ["cerebro_digital", "eett_generada", "prompt_02"]
---

# EETT-07.16 — Escalera De Evacuación: Acero De Refuerzo Fy=4200 Kg/Cm2 Grado 60

> Partida [[WBS-07.16]] · Requisito [[REQ-WBS-07.16]] · Capítulo [[WBS-07.00]]  
> **Estado:** `BORRADOR_TRAZABLE` · **Naturaleza de datos:** `SINTETICO_APROXIMADO` · **Gate:** **LISTO**  
> Ver directivas marco en [[GENERALIDADES_EETT]].

---

## 1. Identificación y Metadatos de la Partida

| Parámetro | Valor Declarado | Fuente de Información |
|---|---|---|
| **Código EETT / WBS** | `EETT-07.16` / `[[WBS-07.16]]` | WBS Maestra del Proyecto |
| **Requisito Técnico** | `[[REQ-WBS-07.16]]` | Cerebro Digital Carpeta 02 |
| **Capítulo WBS** | `[[WBS-07.00]]` | Catálogo de Capítulos WBS |
| **Unidad de Medida** | `kg` | Norma Técnica Metrados MVCS RD-073-2010 |
| **Metrado Oficial** | **2457.0** | Planilla Maestra de Metrados |
| **Nivel de Criticidad** | Nivel 2 | Matriz de Criticidad de Obra |
| **Estado Gate de Madurez** | **LISTO** | Auditoría Automatizada Gate 02 |

---

## 2. Objeto y Alcance de la Especificación

Esta especificación técnica establece las condiciones técnicas, constructivas, normativas y de control de calidad para la ejecución de la partida Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60, correspondiente a la especialidad de Estructuras / Concreto Armado en Elevación, en el marco del proyecto de construcción del Edificio Educativo de 6 pisos, 2 sótanos y azotea ubicado en Jr. Las Gardenias 480, Surquillo.

Descripción Integral de la Actividad:

Ejecución integral de la partida Escalera de evacuación: Acero de refuerzo fy=4200 kg/cm2 Grado 60, conforme a las especificaciones técnicas de diseño estructural, arquitectura y normativas del RNE vigentes.

Delimitación Espacial y Frentes Operativos:

* Ubicación en el Edificio: Sótanos a Azotea, conforme a la sectorización de obra y las indicaciones de los planos de ingeniería PL-EST-08.
* Alcance Operativo Conciliado: Aplica a los niveles y sectores indicados en la matriz de metrados (Metrado oficial: 2457.0 kg), según planos de ingeniería correspondientes. Inclusiones Explícitas en el Alcance Contractual:

1. Suministro, transporte, almacenamiento y custodia técnica de la totalidad de materiales e insumos normados puestos al pie de obra.

2. Disposición de equipos mecánicos, herramientas especializadas y personal calificado con homologación técnica vigente.

3. Ejecución sistemática conforme a las tolerancias dimensionales, alineamiento, niveles y acabados estipulados en planos.

4. Implementación integral de medidas preventivas de Seguridad y Salud en el Trabajo (SST) y protocolos de control ambiental.

5. Ejecución obligatoria de los ensayos de control de calidad en laboratorio acreditado ante INACAL y emisión de protocolos liberados.

Exclusiones Explícitas:

* No se incluyen actividades correspondientes a partidas predecesoras o sucesoras cuantificadas independientemente en el catálogo WBS del presupuesto oficial.
* Quedan excluidas reparaciones por negligencia constructiva o sobrecostos derivados de trabajos ejecutados sin la debida liberación previa de la Supervisión.
---

---

## 3. Condiciones Previas y Prerrequisitos de Ejecución

1. **Liberación del Frente de Trabajo:** Antes de iniciar cualquier labor, el Contratista deberá verificar que las actividades predecesoras se encuentren formalmente concluidas y liberadas por la Supervisión.
2. **Permisos y Seguridad:** Cumplimiento imperativo del Análisis de Trabajo Seguro (ATS) y emisión de PETAR si la tarea involucra trabajos de alto riesgo.
3. **Condiciones Generales:** Rigen de manera estricta todas las disposiciones estipuladas en [[GENERALIDADES_EETT]] sobre orden de prelación, tolerancias y obligaciones generales.

---

## 4. Recursos y Requisitos Técnicos (Materiales, Equipos y Personal)

### 4.1. Materiales e Insumos Normados
Todos los materiales requeridos para la ejecución de la partida deberán ser de primer uso, libres de defectos y cumplir estrictamente con las especificaciones técnicas estipuladas en el RNE-E060 y estándares internacionales homologados (RNE-E030-2026-TEXTO (RM 183-2026) / ACI 318-19 / ACI 117).

Insumos y Materiales Principales:

Concreto premezclado f'c=280 kg/cm² (placas/columnas pisos 1-3) y f'c=210 kg/cm² (pisos 4-6, losas y vigas), encofrado fenólico de 18 mm con puntales metálicos de alta capacidad, acero de refuerzo ASTM A615 Gr. 60, ladrillo hueco de arcilla 15x30x30 cm para losa aligerada.

Criterio Técnico y Respaldo Geotécnico/Estructural:

* Memoria de Cálculo (MEM-CASCO-2026-REV-D): Estructuras - Armaduras de Circulación.
* Estudio Básico (SIS-01): Zona sísmica 4 (Z=0.45), Suelo S1 (S=1.0, TP=0.4s, TL=2.5s), Factor U=1.5 (Educativo), R=6. * Exigencia Normativa Concreta: Estribos cerrados con ganchos a 135° en zonas de confinamiento de columnas y placas, f'c=280 y 210 kg/cm². Certificaciones Exigibles por Lote:

* Certificados de calidad de fábrica originales o copias legalizadas emitidas por el fabricante para cada lote que ingrese a obra.
* Guías de remisión con indicación expresa de fecha de despacho, hora de preparación, dosificación de diseño y características técnicas.
* Fichas técnicas del fabricante y hojas de datos de seguridad (MSDS) para productos químicos o aditivos industriales.
---

### 4.2. Equipos, Maquinarias y Herramientas Asignadas
El Contratista dispondrá en obra del equipamiento mecánico idóneo y herramientas en perfecto estado de operatividad:

Relación de Equipos y Herramientas Asignadas:

Herramientas manuales especializadas, equipos de vibrado y mezclado, implementos de protección individual y colectiva acordes a RNE G.050.

Requisitos de Calibración y Mantenimiento Técnico:

* Todo equipo de medición, nivelación topográfica, control presurizado o ensayo deberá contar con Certificado de Calibración Técnica vigente, con antigüedad no mayor a seis (6) meses, emitido por laboratorio acreditado.
* Mantenimiento preventivo periódico de maquinaria pesada y equipos motorizados para evitar emanaciones excesivas de gases o fugas de fluidos hidráulicos.
* Disponibilidad obligatoria de equipos de respaldo o retén en obra para faenas críticas que demanden continuidad operativa ininterrumpida.
---

---

## 5. Procedimiento y Método de Ejecución Constructiva

La ejecución en campo se desarrollará bajo una secuencia técnica rigurosa y ordenada:

Secuencia Operativa de Ejecución:

1. Enfierrado de elementos verticales con estribos sísmicos cerrados a 135° según RNE E.060. 2. Encofrado aplomado con trípodes y vientos tensores. 3. Vaciado de columnas y placas. 4. Montaje de soleras, viguetas y fondo de vigas/losas con apuntalamiento continuo. 5. Tendido de ladrillos, fierro de viguetas, acero de temperatura y tuberías PVC embebidas. 6. Vaciado monolítico de losa y viga. 7. Desencofrado diferido (fondos de viga a 21 días o 75% f'c).

Protocolo de Ejecución en Cuatro Fases:

**Fase 1:**   Verificación Previa y Liberación del Frente: Limpieza profunda de la zona de trabajo, trazo topográfico milimétrico, inspección de armaduras o soportes y firma obligatoria del protocolo de inicio suscrito por la Supervisión.

**Fase 2:**   Colocación, Montaje o Procesamiento: Ejecución de la tarea aplicando las técnicas normadas, controlando espesores de capa, temperaturas, presiones o tiempos de fraguado según corresponda.

**Fase 3:**   Acabado, Curado y Protección: Protección inmediata del elemento frente a la intemperie, radiación solar o tránsito indebido; aplicación de curado húmedo continuo o químico durante el plazo reglamentario.

**Fase 4:**   Retiro de Protecciones y Limpieza Final: Desmovilización de encofrados o andamios previa verificación de resistencia alcanzada, retiro ordenado de residuos y entrega formal del frente liberado.

---

---

## 6. Control de Calidad, Ensayos y Criterios de Aceptación

### 6.1. Plan de Inspección y Ensayos (ITP)
| Control / Actividad | Criterio de Aceptación | Frecuencia / Registro Mínimo |
|---|---|---|
| Asentamiento (Slump) y Temperatura | Slump 4" a 6" (ASTM C143); Temperatura entre 10°C y 32°C | Cada camión mixer al arribo / Guía de remisión y reporte QA/QC |
| Resistencia a la compresión (f'c) | f'c ≥ 210 kg/cm² a los 28 días (ASTM C39 / NTP 339.034) | 4 probetas por cada 30 m³ o lote diario / Certificado INACAL |
| Inspección de colocación y vibrado | Capa máx. 50 cm, sin segregación ni cangrejeras, vibrador de aguja perpendicular | Continuo durante vaciado / Protocolo de Vaciado de Concreto |
| Curado húmedo o químico continuo | Mínimo 7 días continuos con agua o membrana química homologada (ASTM C309) | Diario durante 7 días / Registro de curado |


### 6.2. Tolerancias Dimensionales y Criterios de Aceptación / Rechazo
El aseguramiento de la calidad se regirá por el Plan de Control de Calidad del proyecto y las directrices vinculantes del RNE-E060 (Capítulo 21 - Disposiciones Especiales para Diseño Sísmico):

Ensayos Obligatorios de Laboratorio y Campo:

Compresión a 7, 14 y 28 días (f'c >= valor de diseño), control de doblado de acero ASTM A615.

Tolerancias Dimensionales Admisibles:

Desviación de plomo en placas y columnas: ±6 mm por entrepiso; deflexión losas <= L/480.

Criterios Formales de Aceptación:

* La partida se considerará técnicamente aceptada cuando el 100% de los ensayos de laboratorio arrojen resultados conformes con las resistencias, densidades o presiones de diseño especificadas.
* Verificación geométrica favorable de alineamiento, cotas de nivel y recubrimientos libres según tolerancias de la norma ACI 117.
* Levantamiento total de observaciones y suscripción conforme del Protocolo de Liberación QA/QC por el Inspector o Supervisor de Obra.
Criterios y Procedimiento ante Rechazo o No Conformidad:

* Todo elemento que incumpla los parámetros de resistencia, presente segregaciones severas, fisuras no admisibles o desviaciones fuera de tolerancia será observado y paralizado mediante Notificación de No Conformidad.
* El Contratista deberá ejecutar ensayos complementarios no destructivos o destructivos (testigos diamantados, pruebas de carga) a su costo exclusivo.
* En caso de no superar las evaluaciones de seguridad estructural, el elemento será demolido y reconstruido íntegramente a entera cuenta y riesgo del Contratista.
---

---

## 7. Seguridad, Salud en el Trabajo, Medio Ambiente e Interfaces

La ejecución de la partida acatará de manera imperativa el Reglamento Nacional de Edificaciones (Norma Técnica G.050) y el D.S. N° 011-2019-TR:

Directrices Específicas de Seguridad y Salud:

Charla diaria 5 min, ATS diario, uso obligatorio de EPP básico y específico, cumplimiento del Plan SST RNE G.050.

Medidas Operativas y Protecciones Exigibles:

* Elaboración diaria obligatoria del Análisis de Trabajo Seguro (ATS) y charla de seguridad de 5 minutos antes del inicio de labores.
* Tramitación de Permiso Escrito para Trabajos de Alto Riesgo (PETAR) en tareas en altura (altura mayor a 1.80 m), excavaciones profundas o izaje crítico de cargas.
* Uso estricto de Equipo de Protección Individual (EPI) normado: casco con barbiquejo (ANSI Z89.1), calzado de seguridad con puntera de acero (ASTM F2413), lentes con protección lateral (ANSI Z87.1), guantes acordes a la labor y arnés de cuerpo entero con doble línea de vida (ANSI Z359.11).
* Instalación y mantenimiento permanente de protecciones colectivas: barandas rígidas perimetrales a una altura de 1.00 m, rodapiés de 15 cm, mallas de señalización, líneas de vida de acero certificadas y tapas resistentes en pases de losa.
* Gestión Ambiental y Residuos: Disposición diferenciada de Residuos de Construcción y Demolición (RCD) en cilindros codificados por color (NTP 900.058); prohibición absoluta de vertido de aguas residuales o lechadas de cemento al terreno natural o redes públicas sin neutralización previa en batea estanca.
---

---

## 8. Método de Medición y Base de Pago

### 8.1. Regla de Medición y Cómputo
La cuantificación volumétrica o métrica de la partida se realizará con sujeción a la Norma Técnica de Metrados para Obras de Edificación y Habilitaciones Urbanas (R.D. N° 073-2010/VIVIENDA/VMCS-DNC):

* Unidad Oficial de Medida: kg.
* Criterio Oficial de Medición: Peso nominal de acero longitudinal y transversal de escaleras. * Metrado Oficial Conciliado: 2457.00 kg, verificado en el modelo federado BIM y la planilla de metrados por niveles.
Reglas Oficiales de Deducción y Conciliación Geométrica:

* Se computarán estrictamente las dimensiones netas efectivas ejecutadas conforme a planos.
* En elementos de concreto armado, se aplicarán las deducciones de vanos, pases de tuberías mayores al límite normativo o intersecciones con elementos prioritarios.
* No se reconocerán sobre-anchos, sobre-excavaciones, desperdicios ni excesos atribuibles a métodos constructivos defectuosos del Contratista.
---

### 8.2. Base y Condiciones Contractuales de Pago
El metrado verificado y aprobado según el método de medición se valorizará al Precio Unitario Contractual (P.U.) por kg establecido en el presupuesto de obra aprobado.

Condición Contractual de Pago:

Pago por unidad ejecutada (kg) previa conformidad firmada del Residente y Supervisor.

Inclusiones Integrales dentro del Precio Unitario:

El precio unitario de la partida constituye la retribución total y definitiva por concepto de:

1. Mano de obra calificada, técnica y peones, con inclusión de leyes sociales completas, gratificaciones, vacaciones, indemnizaciones y seguro complementario contra todo riesgo (SCTR).

2. Suministro, transporte, flete, mermas, acopio y manipuleo de la totalidad de materiales normados puestos a pie de obra.

3. Equipos, maquinarias, herramientas auxiliares, combustibles, lubricantes, repuestos y amortización de capital.

4. Ensayos obligatorios de control de calidad realizados por laboratorio acreditado ante INACAL.

5. Implementos de seguridad personal y colectiva, señalización, gestión ambiental y limpieza final del frente de trabajo.

6. Gastos generales directos e indirectos, imprevistos y utilidad contractual del Contratista.

Condición Previa Indispensable para la Valorización:

No se procesará valorización económica mensual alguna de esta partida sin la presentación y visación formal del Protocolo de Liberación de Calidad y el expediente de certificados de ensayos conformes suscrito por la Supervisión.

---

---

## 9. Matriz de Trazabilidad, Paquete de Evidencia y Respaldo Normativo

### 9.1. Interconexión Cuádruple Semántica
1. **Partida y requisito:** [[WBS-07.16]] · [[REQ-WBS-07.16]]
2. **Normas técnicas habilitadas (Carpeta 02):** [[MVCS-RD073-2010-METRADOS]], [[RNE-G050]], [[RNE-E020]], [[RNE-E030-2026-TEXTO]], [[RNE-E060]], [[RNE-A130]], [[RNE-A010]], [[RNE-A040]], [[RNE-A120]]
3. **Documentos y estudios fuente (Carpeta 01):** [[MEM-EST-01]], [[MEM-ARQ-01]], [[SIS-01]], [[MAT-01]], [[MEM-CASCO-2026]], [[PLAN-TRAB-TEC-SSOMA-QAQC-2026]], [[BASE-DISENO-01]], [[planilla_metrados]]
4. **Planos asociados (Carpeta 01):** [[PL-EST-08]]

**Referencias restringidas** (`NO_DISPONIBLE_PARA_EETT`; solo registran la brecha): [[ACI-CODE-318-19-22]], [[ACI-PRC-347R-14]], [[ACI-SPEC-301-20]], [[ASTM-CONSTRUCCION-ASTM_A615_A615M]], [[INACAL-NTP-NTP_341_031]], [[NFPA-PROTECCION-INCENDIOS-NFPA_101]]

### 9.2. Estado de Control y Brechas del Gate

**Conformidad de Gate:**
- ✅ Partida sin observaciones abiertas de consistencia. Datos verificados contra planos y memorias técnicas.


---

## Navegación

[[GENERALIDADES_EETT]] · [[MOC_EETT]] · [[MOC_REQUISITOS]] · [[MOC_PROYECTO]]
