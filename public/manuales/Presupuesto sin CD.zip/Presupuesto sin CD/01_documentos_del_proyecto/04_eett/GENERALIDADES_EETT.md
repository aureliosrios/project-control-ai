---
id: "GENERALIDADES_EETT"
tipo: "especificacion_tecnica_marco"
estado: "BORRADOR_TRAZABLE"
proyecto: "Edificio Educativo de 6 pisos, 2 sótanos y azotea"
codigo_expediente: "EXP-EDU-2026-06P-SURQUILLO"
revision: "Rev. D"
fecha: "2026-10-11"
naturaleza_datos: "SINTETICO_APROXIMADO"
tags: ["cerebro_digital", "eett", "generalidades", "prompt_02"]
---

# GENERALIDADES Y CONDICIONES COMUNES DE LAS ESPECIFICACIONES TÉCNICAS (EETT)

> **Documento Rector Marco:** Condiciones Generales, Marco Regulatorio, Calidad (QA/QC) y SST  
> **Proyecto:** Edificio Educativo de 6 pisos, 2 sótanos y azotea — EXP-EDU-2026-06P-SURQUILLO  
> **Ubicación:** Jr. Las Gardenias 480, Urb. La Calera de la Merced, Surquillo, Lima, Perú  
> **Estado:** `BORRADOR_TRAZABLE` · `SINTETICO_APROXIMADO`

---

## 1. Alcance y Carácter Contractual de las Especificaciones Técnicas

El presente documento marco establece las directrices comunes, metodológicas y operativas que rigen de manera imperativa sobre la totalidad de las 78 partidas de obra del proyecto (Capítulos 01.00 al 13.00). Cada especificación particular (`EETT-XX.YY.md`) se articula y complementa con lo estipulado en este documento rector.

Las Especificaciones Técnicas, los Planos de Ingeniería de Detalle, la Planilla Maestra de Metrados y las Memorias Descriptivas son interdependientes. Toda labor o material mostrado en los planos y no especificado en este texto, o viceversa, se considerará comprendido dentro del alcance contractual del Contratista como si estuviese detallado en ambos.

---

## 2. Marco Legal y Normativa Técnica Aplicable

La ejecución de todas las actividades debe ceñirse estrictamente a las normas oficiales peruanas del Reglamento Nacional de Edificaciones (RNE) aprobado por D.S. N° 011-2006-VIVIENDA, normas complementarias y códigos internacionales:

1. **RNE G.030:** Derechos y Responsabilidades de los Actores del Proceso Edificatorio.
2. **RNE G.050:** Seguridad durante la Construcción (D.S. N° 011-2019-TR).
3. **RNE E.020:** Cargas para Edificaciones.
4. **RNE E.030:** Norma Técnica de Diseño Sismorresistente (Texto oficial actualizado 2026 / D.S. 003-2016-VIVIENDA).
5. **RNE E.050:** Suelos y Cimentaciones (R.M. N° 406-2018-VIVIENDA).
6. **RNE E.060:** Concreto Armado (D.S. N° 010-2009-VIVIENDA).
7. **RNE E.070:** Albañilería.
8. **Norma Técnica de Metrados:** Reglamento de Metrados para Obras de Edificación y Habilitaciones Urbanas (R.D. N° 073-2010/VIVIENDA/VMCS-DNC).
9. **Normas Técnicas Peruanas (INACAL / NTP):** NTP 339.033, NTP 339.034, NTP 339.035, NTP 341.031, NTP 400.037.
10. **Estándares Internacionales (de referencia y complementarios):** ACI 318-19, ACI 301-20, ACI 347R-14, ASTM C94, ASTM C143, ASTM C31, ASTM C39, ASTM A615.

---

## 3. Orden de Prelación Documental

En caso de contradicción o discrepancia entre los documentos contractuales del proyecto, rige el siguiente orden de prelación técnica y jurídica:

1. **Planos de Ingeniería Oficiales:** Prevalecen las cotas acotadas sobre las escalas gráficas; los planos de detalle prevalecen sobre los planos generales.
2. **Especificaciones Técnicas Particulares (EETT-XX.YY) y Generalidades:** Prevalecen sobre criterios presuntivos.
3. **Planilla Maestra de Metrados Conciliada.**
4. **Memorias Descriptivas y de Cálculo de Especialidad.**
5. **Presupuesto de Obra y Análisis de Precios Unitarios (APU).**

Cualquier discrepancia no resuelta será elevada de inmediato por el Residente al Supervisor de Obra para su aclaración en el Cuaderno de Obra antes de ejecutar los trabajos.

---

## 4. Parámetros Globales de Ingeniería del Proyecto

- **Clasificación del Edificio:** Edificación Esencial Categoría A2 (U = 1.50) destinada a Instituto de Educación Superior Tecnológica.
- **Zonificación Sísmica:** Zona 4 ($Z = 0.45$), Suelo $S1$ ($S = 1.00$, $T_p = 0.40\text{ s}$). Deriva máxima admisible $\Delta/h \le 0.007$.
- **Capacidad Geotécnica Admisible:** $\sigma_{\text{adm}} = 4.00\text{ kg/cm}^2$ a cota de desplante $D_f = -5.80\text{ m}$ (Grava aluvial densa GP-GM).
- **Resistencias de Concreto ($f'c$):**
  - Solados y ciclópeos: $f'c = 140\text{ kg/cm}^2$.
  - Cimentaciones (Zapatas y vigas de cimentación): $f'c = 210\text{ kg/cm}^2$.
  - Muros pantalla, columnas, placas y cisterna: $f'c = 280\text{ kg/cm}^2$.
  - Vigas, losas aligeradas y escaleras: $f'c = 210\text{ kg/cm}^2$.
- **Acero de Refuerzo:** Grado 60, corrugado, $f_y = 4,200\text{ kg/cm}^2$ (ASTM A615). Prohibido el enderezado de barras dobladas.

---

## 5. Directivas Generales de Control de Calidad (QA/QC)

1. **Certificados de Calidad de Origen:** Todo insumo o material (cemento, agregados, acero, aditivos, tuberías, cables) debe contar con certificado de calidad de fábrica emitido dentro de los 30 días previos a su empleo.
2. **Laboratorios Autorizados:** Todos los ensayos destructivos y no destructivos se efectuarán exclusivamente en laboratorios acreditados ante el Instituto Nacional de Calidad (INACAL).
3. **Protocolos de Liberación Tripartitos:** Ninguna armadura, pase electromecánico o superficie podrá cubrirse con concreto u otro acabado sin la firma previa del Protocolo de Liberación por parte del Residente, el Ingeniero QA/QC y el Supervisor de Obra.
4. **Dossier de Calidad Final y As-Built:** Al culminar los trabajos, el Contratista entregará el Dossier de Calidad debidamente foliado y los planos As-Built en formato CAD y BIM.

---

## 6. Seguridad y Salud en el Trabajo (SST) y Protección Ambiental

1. **Permisos y Análisis de Riesgo:** Obligatoriedad diaria del Análisis de Trabajo Seguro (ATS), charla de seguridad de 5 minutos y tramitación de Permiso Escrito para Trabajos de Alto Riesgo (PETAR) para labores en altura (>1.80 m), excavaciones profundas e izajes críticos.
2. **Equipos de Protección Individual (EPI):** Uso ininterrumpido de casco con barbiquejo, calzado de seguridad con puntera de acero, lentes de protección UV y arnés de seguridad de cuerpo entero con doble línea de vida certificada.
3. **Gestión de Residuos:** Clasificación estricta de Residuos de Construcción y Demolición (RCD) en cilindros estandarizados según NTP 900.058 y retiro hacia botaderos autorizados por DIGESA/MTC.

---

## 7. Navegación en el Cerebro Digital

[[MOC_EETT]] · [[MOC_REQUISITOS]] · [[MOC_PROYECTO]] · [[MOC_WBS]]
