---
id: "MOC_EETT_GENERADAS"
tipo: "moc"
tags: ["cerebro_digital", "moc", "eett_generadas", "prompt_02"]
---

# MOC — Catálogo Maestro de Especificaciones Técnicas Generadas

> 78 Especificaciones Técnicas generadas en `03_cerebro_digital_eett/07_especificaciones_tecnicas_generadas/` conforme al Prompt N° 02.  
> Documento Rector: [[GENERALIDADES_EETT]] · Reporte de Control: [[PAQUETE_EVIDENCIA_Y_BRECHAS_EETT]].

---

## Capítulo [[WBS-01.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-01.01]]` | Movilización Y Desmovilización De Equipo Pesado En Cama Baja | glb | 1.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-01.02]]` | Instalaciones Provisionales De Agua, Energía Y Desagüe De Fa | glb | 1.0 | LISTO |
| `[[EETT-01.03]]` | Cerramiento Provisional Perimetral Con Parantes Tubulares De | m | 90.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-01.04]]` | Trazo, Niveles Y Replanteo Topográfico Con Estación Total Lá | m2 | 500.0 | LISTO |
| `[[EETT-01.05]]` | Protección Y Desvío De Interferencias De Redes De Servicios  | glb | 1.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-01.06]]` | Limpieza, Desbroce Manual Y Acondicionamiento Del Terreno | m2 | 450.0 | LISTO |

## Capítulo [[WBS-02.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-02.01]]` | Sostenimiento Perimetral Con Perforadora Hidráulica, Anclaje | m2 | 522.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-02.02]]` | Apuntalamiento Provisional De Estructuras Colindantes Con Pu | und | 12.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-02.03]]` | Instrumentación Geotécnica: Inclinómetros Biaxiales Profundo | glb | 1.0 | LISTO |
| `[[EETT-02.04]]` | Monitoreo Topográfico Continuo De Hitos Geodésicos En Colind | mes | 4.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-02.05]]` | Sistema Provisional De Bombeo Y Achique De Aguas De Escorren | glb | 1.0 | LISTO |

## Capítulo [[WBS-03.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-03.01]]` | Excavación Masiva Con Excavadora Sobre Orugas 200 Hp Hasta C | m3 | 3200.0 | LISTO |
| `[[EETT-03.02]]` | Excavación Manual Localizada Para Zapatas, Vigas De Cimentac | m3 | 250.0 | LISTO |
| `[[EETT-03.03]]` | Carguío Con Cargador Frontal Cat 950 Y Eliminación Con Volqu | m3 | 4100.0 | LISTO |
| `[[EETT-03.04]]` | Relleno Compactado Con Afirmado Seleccionado De Cantera Y Pl | m3 | 180.0 | LISTO |
| `[[EETT-03.05]]` | Perfilado Y Compactación De Fondo De Excavación (Subrasante) | m2 | 500.0 | LISTO |

## Capítulo [[WBS-04.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-04.01]]` | Solado De Concreto Premezclado F'C=140 Kg/Cm2 E=4" Para Zapa | m2 | 161.2 | LISTO |
| `[[EETT-04.02]]` | Cimientos Corridos De Concreto Premezclado F'C=140 Kg/Cm2 +  | m3 | 120.0 | LISTO |
| `[[EETT-04.03]]` | Sobrecimientos De Concreto Premezclado F'C=175 Kg/Cm2 + 25%  | m3 | 45.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-04.04]]` | Encofrado Y Desencofrado Modular Metálico Con Tablero Fenóli | m2 | 180.0 | LISTO_CON_OBSERVACIONES |

## Capítulo [[WBS-05.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-05.01]]` | Zapatas: Concreto Premezclado F'C=210 Kg/Cm2 Vaciado Con Bom | m3 | 83.76 | LISTO |
| `[[EETT-05.02]]` | Zapatas: Encofrado Y Desencofrado Modular Metálico | m2 | 137.44 | LISTO |
| `[[EETT-05.03]]` | Zapatas: Acero De Refuerzo Corrugado Fy=4200 Kg/Cm2 Grado 60 | kg | 7119.6 | LISTO |
| `[[EETT-05.04]]` | Vigas De Cimentación Y Amarre: Concreto Premezclado F'C=210  | m3 | 58.52 | LISTO |
| `[[EETT-05.05]]` | Vigas De Cimentación Y Amarre: Encofrado Y Desencofrado Modu | m2 | 258.4 | LISTO |
| `[[EETT-05.06]]` | Vigas De Cimentación Y Amarre: Acero De Refuerzo Fy=4200 Kg/ | kg | 6437.2 | LISTO |

## Capítulo [[WBS-06.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-06.01]]` | Muros De Contención / Pantalla: Concreto Premezclado F'C=280 | m3 | 156.6 | LISTO |
| `[[EETT-06.02]]` | Muros De Contención / Pantalla: Encofrado Modular Fenólico A | m2 | 1044.0 | LISTO |
| `[[EETT-06.03]]` | Muros De Contención / Pantalla: Acero De Refuerzo Fy=4200 Kg | kg | 14094.0 | LISTO |
| `[[EETT-06.04]]` | Losa De Contacto De Sótano 2 E=15 Cm Concreto Premezclado F' | m2 | 500.0 | LISTO |
| `[[EETT-06.05]]` | Cisterna Y Cuarto De Bombas: Estructura Monolítica De Concre | m3 | 42.5 | LISTO |
| `[[EETT-06.06]]` | Cisterna Y Cuarto De Bombas: Encofrado Modular Fenólico Impe | m2 | 168.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-06.07]]` | Rampa Vehicular Estructural: Losa Inclinada E=18 Cm Concreto | m2 | 125.0 | LISTO |
| `[[EETT-06.08]]` | Sellos Hidroexpansivos Sikaswell Y Cinta Waterstop De Pvc 6" | m | 180.0 | LISTO |

## Capítulo [[WBS-07.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-07.01]]` | Columnas: Concreto Premezclado F'C=280 Kg/Cm2 Con Bomba Tele | m3 | 48.6 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.02]]` | Columnas: Encofrado Y Desencofrado Modular Fenólico 18Mm Con | m2 | 324.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.03]]` | Columnas: Acero De Refuerzo Fy=4200 Kg/Cm2 Grado 60 Habilita | kg | 7290.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.04]]` | Placas De Concreto Armado: Concreto Premezclado F'C=280 Kg/C | m3 | 72.9 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.05]]` | Placas De Concreto Armado: Encofrado Modular Fenólico Trepan | m2 | 486.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.06]]` | Placas De Concreto Armado: Acero De Refuerzo Fy=4200 Kg/Cm2  | kg | 8748.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.07]]` | Vigas Principales Y Secundarias: Concreto Premezclado F'C=21 | m3 | 126.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.08]]` | Vigas Principales Y Secundarias: Encofrado Y Desencofrado Mo | m2 | 560.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.09]]` | Vigas Principales Y Secundarias: Acero De Refuerzo Fy=4200 K | kg | 15120.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.10]]` | Losas Aligeradas Unidireccionales E=20 Cm: Concreto Premezcl | m3 | 210.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.11]]` | Losas Aligeradas: Encofrado Y Desencofrado Con Vigas De Alum | m2 | 2400.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.12]]` | Losas Aligeradas: Acero De Refuerzo En Viguetas Y Temperatur | kg | 12600.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-07.13]]` | Losas Aligeradas: Ladrillo Hueco De Arcilla 15X30X30 Cm Para | und | 20400.0 | LISTO |
| `[[EETT-07.14]]` | Escalera De Evacuación Presurizada: Concreto Premezclado F'C | m3 | 18.9 | LISTO |
| `[[EETT-07.15]]` | Escalera De Evacuación: Encofrado Modular Y Pasos Con Moldes | m2 | 108.0 | LISTO |
| `[[EETT-07.16]]` | Escalera De Evacuación: Acero De Refuerzo Fy=4200 Kg/Cm2 Gra | kg | 2457.0 | LISTO |

## Capítulo [[WBS-08.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-08.01]]` | Losa De Techo De Azotea E=20 Cm Concreto Premezclado F'C=210 | m2 | 500.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-08.02]]` | Parapeto Perimetral De Concreto Armado F'C=210 H=1.10 M En A | m | 90.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-08.03]]` | Caseta De Sala De Máquinas De Ascensor Y Cuarto Técnico De B | m3 | 12.5 | LISTO |
| `[[EETT-08.04]]` | Juntas De Dilatación Sísmica Perimetral Con Tecnopor De 1" Y | m | 65.0 | REQUIERE_DECISION_PREVIA |

## Capítulo [[WBS-09.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-09.01]]` | Muro De Ladrillo Kk 18 Huecos De Arcilla Asentado Con Morter | m2 | 1850.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-09.02]]` | Columnetas Y Vigas De Amarre De Concreto F'C=210 Para Confin | m3 | 28.5 | LISTO_CON_OBSERVACIONES |
| `[[EETT-09.03]]` | Encofrado Y Desencofrado Modular Para Columnetas Y Vigas De  | m2 | 195.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-09.04]]` | Junta De Aislamiento Sísmico De 1" Entre Tabique Y Estructur | m | 420.0 | REQUIERE_DECISION_PREVIA |

## Capítulo [[WBS-10.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-10.01]]` | Pases Y Mangas Herméticas En Vigas Y Losas Para Montantes Sa | und | 96.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-10.02]]` | Red Colectora De Desagüe Colgada Pvc Sal 4" Y 2" En Sótanos | m | 280.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-10.03]]` | Montantes De Ventilación Y Desagüe Vertical Pvc Sal 4 | m | 195.0 | LISTO |
| `[[EETT-10.04]]` | Sumideros Con Trampa P, Cajas De Registro Prefabricadas De C | und | 24.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-10.05]]` | Red De Agua Contra Incendio (Aci): Tubería De Acero Ranurado | m | 350.0 | REQUIERE_DECISION_PREVIA |

## Capítulo [[WBS-11.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-11.01]]` | Pases Y Canalizaciones Embebidas En Losas Y Placas Para Alim | und | 120.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-11.02]]` | Tubería Conduit Pvc Sap 3/4" Y 1" Embebida Para Circuitos De | m | 1850.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-11.03]]` | Conductor De Cobre Libre De Halógenos Lsoh 2.5 Mm2 (Freetox  | m | 3200.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-11.04]]` | Cajas De Pase Modulares De F°G° Pesadas Para Sistemas De Ilu | und | 210.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-11.05]]` | Sistema De Puesta A Tierra Integral De Baja Resistencia (< 5 | und | 4.0 | REQUIERE_DECISION_PREVIA |

## Capítulo [[WBS-12.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-12.01]]` | Pases Estructurales Coordinados Bim Para Ductos De Presuriza | und | 18.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-12.02]]` | Canalizaciones Embebidas Para Sistema De Detección Y Alarma  | m | 850.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-12.03]]` | Anclajes Y Soportes Antivibratorios Para Equipos Electromecá | und | 8.0 | LISTO_CON_OBSERVACIONES |
| `[[EETT-12.04]]` | Sellado Cortafuego Firestop (Rf-120) En Todos Los Pases De L | und | 64.0 | REQUIERE_DECISION_PREVIA |

## Capítulo [[WBS-13.00]]

| EETT | Título de la Partida | Unidad | Metrado | Gate |
|---|---|:---:|:---:|:---:|
| `[[EETT-13.01]]` | Protocolos Tripartitos De Liberación De Pases Y Armaduras Pr | und | 144.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-13.02]]` | Ensayos De Resistencia A Compresión De Probetas De Concreto  | und | 65.0 | LISTO |
| `[[EETT-13.03]]` | Ensayos De Tracción Y Doblado De Acero De Refuerzo En Labora | und | 12.0 | LISTO |
| `[[EETT-13.04]]` | Pruebas Hidrostáticas Y De Estanqueidad Presurizada En Redes | glb | 1.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-13.05]]` | Ensayos De Densidad De Campo (Cono De Arena) En Rellenos Y S | und | 18.0 | REQUIERE_DECISION_PREVIA |
| `[[EETT-13.06]]` | Elaboración Y Entrega Del Dossier Final De Calidad Y Planos  | glb | 1.0 | LISTO |

