---
id: "PAQUETE_EVIDENCIA_Y_BRECHAS_EETT"
tipo: "reporte_evidencia_gate"
estado: "BORRADOR_TRAZABLE"
fecha: "2026-10-11"
tags: ["cerebro_digital", "gate", "evidencia", "brechas", "prompt_02"]
---

# PAQUETE DE EVIDENCIA, AUDITORÍA DE GATE Y REGISTRO DE BRECHAS

> **Documento de Auditoría y Respaldo:** Consolidado de las 78 partidas según Prompt N° 02  
> **Proyecto:** Edificio Educativo de 6 pisos, 2 sótanos y azotea (`EXP-EDU-2026-06P-SURQUILLO`)  
> **Dictamen Gate:** Integridad del Cerebro APROBADA · Preparación EETT CONDICIONADA

---

## 1. Resumen Ejecutivo del Gate de Madurez

| Estado de Madurez | Cantidad de Partidas | Porcentaje | Dictamen Operativo |
|---|:---:|:---:|---|
| **LISTO** | 34 | 43.6 % | Información completa, verificada y apta para ejecución |
| **LISTO_CON_OBSERVACIONES** | 28 | 35.9 % | Partidas viables con observaciones de precisión geométrica o documental |
| **REQUIERE_DECISION_PREVIA** | 16 | 20.5 % | Bloqueadas por discrepancia entre título de partida y regla/inclusión |
| **TOTAL** | **78** | **100.0 %** | Catálogo WBS oficial completo |

---

## 2. Detalle de Partidas en Estado `REQUIERE_DECISION_PREVIA` (16 Partidas)

Estas partidas presentan inconsistencias heredadas de la base sintética del expediente. Conforme a la regla del Prompt N° 02 (*"Los originales prevalecen sobre los derivados. No completar requisitos normativos desconocidos con hipótesis"*), se registran formalmente para decisión del Proyectista:

### Partida 06.06 (`EETT-06.06.md`)
- **Motivo de bloqueo:** El título WBS es 'Cisterna y cuarto de bombas: encofrado' (m²) pero la regla, inclusiones y elemento describen foso/sobre-recorrido de ascensor (sector S2-2, 'Suma global').
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 08.04 (`EETT-08.04.md`)
- **Motivo de bloqueo:** El título WBS son juntas de dilatación sísmica con tecnopor 1" y sellador (m); la regla e inclusiones describen manto asfáltico termosellado 4 mm. La partida 08.01 excluye 'impermeabilización con manto asfáltico (partida 08.04)'.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 09.01 (`EETT-09.01.md`)
- **Motivo de bloqueo:** El título indica ladrillo KK 18 huecos e = 15 cm tipo soga; la inclusión indica pandereta 10×12×24 cm y la regla mortero e = 1.5 cm.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 09.03 (`EETT-09.03.md`)
- **Motivo de bloqueo:** El título es encofrado de columnetas y vigas de amarre (m²); la regla e inclusiones describen dinteles de concreto f'c = 175 (metro lineal).
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 09.04 (`EETT-09.04.md`)
- **Motivo de bloqueo:** El título es junta de aislamiento sísmico de 1" (m); la regla e inclusiones describen picado, solaqueo y perfilado de superficies de concreto.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 10.02 (`EETT-10.02.md`)
- **Motivo de bloqueo:** El título es red colectora de desagüe PVC SAL (m); la regla e inclusiones describen bridas rompeaguas / pasamuros con waterstop.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 10.05 (`EETT-10.05.md`)
- **Motivo de bloqueo:** El título es red ACI con tubería ranurada Sch 40 y rociadores (m); la regla e inclusiones describen la prueba hidrostática a 100 psi como suma global.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 11.01 (`EETT-11.01.md`)
- **Motivo de bloqueo:** El título son pases y canalizaciones para alimentadores (und); la regla e inclusiones describen cable de cobre desnudo y soldadura exotérmica de la malla Ufer (m).
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 11.03 (`EETT-11.03.md`)
- **Motivo de bloqueo:** El título es conductor de cobre LSOH 2.5 mm² (m); la regla e inclusiones describen cajas galvanizadas octogonales/rectangulares.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 11.04 (`EETT-11.04.md`)
- **Motivo de bloqueo:** El título son cajas de pase modulares de F°G° (und); la regla e inclusiones describen pases verticales / mangas de gran calibre para shafts.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 11.05 (`EETT-11.05.md`)
- **Motivo de bloqueo:** El título es sistema de puesta a tierra integral < 5 Ω (und); la regla e inclusiones describen conduits de telecomunicaciones (m).
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 12.02 (`EETT-12.02.md`)
- **Motivo de bloqueo:** El título son canalizaciones embebidas para detección y alarma NFPA 72 (m); la regla e inclusiones describen mangas rectangulares de gran sección para extracción de CO.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 12.04 (`EETT-12.04.md`)
- **Motivo de bloqueo:** El título es sellado cortafuego Firestop RF-120; la regla e inclusiones describen mangas para tuberías de refrigeración con aislamiento elastomérico.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 13.01 (`EETT-13.01.md`)
- **Motivo de bloqueo:** El título son protocolos tripartitos de liberación (und 144); la regla e inclusiones describen control topográfico continuo en meses (TOP-01 §6 también la define como control topográfico).
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 13.04 (`EETT-13.04.md`)
- **Motivo de bloqueo:** El título son pruebas hidrostáticas y de estanqueidad 72 h (glb); la regla e inclusiones describen ensayo de densidad por cono de arena / Proctor.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

### Partida 13.05 (`EETT-13.05.md`)
- **Motivo de bloqueo:** El título son ensayos de densidad de campo (und 18); la regla e inclusiones describen actas de liberación tripartita previas al vaciado.
- **Acción requerida:** Aclaración formal del Proyectista respecto a unidad, alcance o elemento constructivo.

---

## 3. Matriz Consolidada de Evidencia por Partida (78 Partidas)

| Ítem WBS | EETT Generada | Unidad | Metrado | Estado Gate | Norma Principal | Plano Clave |
|---|---|:---:|:---:|:---:|---|---|
| `[[WBS-01.01]]` | `[[EETT-01.01]]` | glb | 1.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-TOP-01 |
| `[[WBS-01.02]]` | `[[EETT-01.02]]` | glb | 1.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-TOP-01 |
| `[[WBS-01.03]]` | `[[EETT-01.03]]` | m | 90.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-TOP-01 |
| `[[WBS-01.04]]` | `[[EETT-01.04]]` | m2 | 500.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-TOP-01 |
| `[[WBS-01.05]]` | `[[EETT-01.05]]` | glb | 1.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-TOP-01 |
| `[[WBS-01.06]]` | `[[EETT-01.06]]` | m2 | 450.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-TOP-01 |
| `[[WBS-02.01]]` | `[[EETT-02.01]]` | m2 | 522.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-02 |
| `[[WBS-02.02]]` | `[[EETT-02.02]]` | und | 12.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-02 |
| `[[WBS-02.03]]` | `[[EETT-02.03]]` | glb | 1.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-GEO-01 |
| `[[WBS-02.04]]` | `[[EETT-02.04]]` | mes | 4.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-QA-01 |
| `[[WBS-02.05]]` | `[[EETT-02.05]]` | glb | 1.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-03 |
| `[[WBS-03.01]]` | `[[EETT-03.01]]` | m3 | 3200.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-TOP-01 |
| `[[WBS-03.02]]` | `[[EETT-03.02]]` | m3 | 250.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-03 |
| `[[WBS-03.03]]` | `[[EETT-03.03]]` | m3 | 4100.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-01 |
| `[[WBS-03.04]]` | `[[EETT-03.04]]` | m3 | 180.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-01 |
| `[[WBS-03.05]]` | `[[EETT-03.05]]` | m2 | 500.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-01 |
| `[[WBS-04.01]]` | `[[EETT-04.01]]` | m2 | 161.2 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-03 |
| `[[WBS-04.02]]` | `[[EETT-04.02]]` | m3 | 120.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-09 |
| `[[WBS-04.03]]` | `[[EETT-04.03]]` | m3 | 45.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-ARQ-02 |
| `[[WBS-04.04]]` | `[[EETT-04.04]]` | m2 | 180.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-09 |
| `[[WBS-05.01]]` | `[[EETT-05.01]]` | m3 | 83.76 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-01 |
| `[[WBS-05.02]]` | `[[EETT-05.02]]` | m2 | 137.44 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-01 |
| `[[WBS-05.03]]` | `[[EETT-05.03]]` | kg | 7119.6 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-01 |
| `[[WBS-05.04]]` | `[[EETT-05.04]]` | m3 | 58.52 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-01 |
| `[[WBS-05.05]]` | `[[EETT-05.05]]` | m2 | 258.4 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-01 |
| `[[WBS-05.06]]` | `[[EETT-05.06]]` | kg | 6437.2 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-01 |
| `[[WBS-06.01]]` | `[[EETT-06.01]]` | m3 | 156.6 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-02 |
| `[[WBS-06.02]]` | `[[EETT-06.02]]` | m2 | 1044.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-02 |
| `[[WBS-06.03]]` | `[[EETT-06.03]]` | kg | 14094.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-02 |
| `[[WBS-06.04]]` | `[[EETT-06.04]]` | m2 | 500.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-ARQ-01 |
| `[[WBS-06.05]]` | `[[EETT-06.05]]` | m3 | 42.5 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-IS-01 |
| `[[WBS-06.06]]` | `[[EETT-06.06]]` | m2 | 168.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-EST-03 |
| `[[WBS-06.07]]` | `[[EETT-06.07]]` | m2 | 125.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-ARQ-01 |
| `[[WBS-06.08]]` | `[[EETT-06.08]]` | m | 180.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-03 |
| `[[WBS-07.01]]` | `[[EETT-07.01]]` | m3 | 48.6 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-04 |
| `[[WBS-07.02]]` | `[[EETT-07.02]]` | m2 | 324.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-04 |
| `[[WBS-07.03]]` | `[[EETT-07.03]]` | kg | 7290.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-04 |
| `[[WBS-07.04]]` | `[[EETT-07.04]]` | m3 | 72.9 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-04 |
| `[[WBS-07.05]]` | `[[EETT-07.05]]` | m2 | 486.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-04 |
| `[[WBS-07.06]]` | `[[EETT-07.06]]` | kg | 8748.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-04 |
| `[[WBS-07.07]]` | `[[EETT-07.07]]` | m3 | 126.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-06 |
| `[[WBS-07.08]]` | `[[EETT-07.08]]` | m2 | 560.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-06 |
| `[[WBS-07.09]]` | `[[EETT-07.09]]` | kg | 15120.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-05 |
| `[[WBS-07.10]]` | `[[EETT-07.10]]` | m3 | 210.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-07 |
| `[[WBS-07.11]]` | `[[EETT-07.11]]` | m2 | 2400.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-07 |
| `[[WBS-07.12]]` | `[[EETT-07.12]]` | kg | 12600.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-07 |
| `[[WBS-07.13]]` | `[[EETT-07.13]]` | und | 20400.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-07 |
| `[[WBS-07.14]]` | `[[EETT-07.14]]` | m3 | 18.9 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-08 |
| `[[WBS-07.15]]` | `[[EETT-07.15]]` | m2 | 108.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-08 |
| `[[WBS-07.16]]` | `[[EETT-07.16]]` | kg | 2457.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-EST-08 |
| `[[WBS-08.01]]` | `[[EETT-08.01]]` | m2 | 500.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-ARQ-04 |
| `[[WBS-08.02]]` | `[[EETT-08.02]]` | m | 90.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-ARQ-04 |
| `[[WBS-08.03]]` | `[[EETT-08.03]]` | m3 | 12.5 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-ARQ-04 |
| `[[WBS-08.04]]` | `[[EETT-08.04]]` | m | 65.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-ARQ-04 |
| `[[WBS-09.01]]` | `[[EETT-09.01]]` | m2 | 1850.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-EST-09 |
| `[[WBS-09.02]]` | `[[EETT-09.02]]` | m3 | 28.5 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-09 |
| `[[WBS-09.03]]` | `[[EETT-09.03]]` | m2 | 195.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-ARQ-05 |
| `[[WBS-09.04]]` | `[[EETT-09.04]]` | m | 420.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-ARQ-05 |
| `[[WBS-10.01]]` | `[[EETT-10.01]]` | und | 96.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-05 |
| `[[WBS-10.02]]` | `[[EETT-10.02]]` | m | 280.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-EST-03 |
| `[[WBS-10.03]]` | `[[EETT-10.03]]` | m | 195.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-IS-01 |
| `[[WBS-10.04]]` | `[[EETT-10.04]]` | und | 24.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-EST-03 |
| `[[WBS-10.05]]` | `[[EETT-10.05]]` | m | 350.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-QA-01 |
| `[[WBS-11.01]]` | `[[EETT-11.01]]` | und | 120.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-IE-01 |
| `[[WBS-11.02]]` | `[[EETT-11.02]]` | m | 1850.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-IE-01 |
| `[[WBS-11.03]]` | `[[EETT-11.03]]` | m | 3200.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-IE-01 |
| `[[WBS-11.04]]` | `[[EETT-11.04]]` | und | 210.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-IE-02 |
| `[[WBS-11.05]]` | `[[EETT-11.05]]` | und | 4.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-ARQ-06 |
| `[[WBS-12.01]]` | `[[EETT-12.01]]` | und | 18.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-IM-01 |
| `[[WBS-12.02]]` | `[[EETT-12.02]]` | m | 850.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-EST-05 |
| `[[WBS-12.03]]` | `[[EETT-12.03]]` | und | 8.0 | **LISTO_CON_OBSERVACIONES** | MVCS-RD073-2010-METRADOS | PL-ACI-01 |
| `[[WBS-12.04]]` | `[[EETT-12.04]]` | und | 64.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-ARQ-03 |
| `[[WBS-13.01]]` | `[[EETT-13.01]]` | und | 144.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-QA-01 |
| `[[WBS-13.02]]` | `[[EETT-13.02]]` | und | 65.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-QA-01 |
| `[[WBS-13.03]]` | `[[EETT-13.03]]` | und | 12.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-QA-01 |
| `[[WBS-13.04]]` | `[[EETT-13.04]]` | glb | 1.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-QA-01 |
| `[[WBS-13.05]]` | `[[EETT-13.05]]` | und | 18.0 | **REQUIERE_DECISION_PREVIA** | MVCS-RD073-2010-METRADOS | PL-QA-01 |
| `[[WBS-13.06]]` | `[[EETT-13.06]]` | glb | 1.0 | **LISTO** | MVCS-RD073-2010-METRADOS | PL-QA-01 |
