# SECUENCIA LÓGICA DE BLOQUES CONSTRUCTIVOS (A–H)

> **Clasificación de datos:** `SINTETICO_APROXIMADO`. Documento de simulación técnica basado en la Memoria Descriptiva Rev. D; no acredita medición de planos originales.

**Proyecto:** Edificio Educativo de 6 pisos, 2 sótanos y azotea  
**Documento:** BLOQ-CONST-2026-REV-D  
**Estado:** BASE DE DISEÑO APROBADA INTERNAMENTE (Vigente para descripción de actividades y metrados sintéticos)  
**Propósito:** Definir la precedencia constructiva, entregables técnicos, interfaces y protocolos de liberación previos a vaciado sin asociar fechas de calendario prematuras.

---

## 1. Mapa General de Precedencias Constructivas

```mermaid
graph TD
    A["Bloque A: Obras Preliminares y Desvío de Interferencias"] --> B["Bloque B: Excavación Masiva y Sostenimiento Perimetral"]
    B --> C["Bloque C: Cimentaciones Profundas y Vigas de Conexión"]
    C --> D["Bloque D: Estructuras Especiales de Sótanos 1 y 2"]
    D --> E["Bloque E: Superestructura Vertical (Columnas y Placas)"]
    D --> F["Bloque F: Superestructura Horizontal (Vigas y Losas)"]
    E --> F
    F --> G["Bloque G: Azotea Técnica, Parapetos e Impermeabilización"]
    F --> H["Bloque H: Albañilería Confinada, Interfaces MEP y Cierre de Casco"]
    G --> H
```

---

## 2. Detalle de Paquetes Constructivos Lógicos

### Bloque A: Trabajos Preliminares y Acondicionamiento
- **Alcance WBS:** Partidas 01.01 a 01.06.
- **Predecesor Técnico:** Entrega formal del terreno y replanteo de linderos.
- **Entregable:** Cerco perimetral instalado, servicios de faena operativos, red de BMs establecida y lote limpio.
- **Punto de Control QA/QC:** Acta de verificación de linderos y no afectación de redes públicas (TOP-01 / RES-01).
- **Condición de Liberación:** Aprobación de plan de desvío de interferencias e instalación de carteles de seguridad.

### Bloque B: Movimiento de Tierras y Sostenimiento Perimetral
- **Alcance WBS:** Partidas 02.01 a 02.05 y 03.01 a 03.05.
- **Predecesor Técnico:** Bloque A aprobado.
- **Entregable:** Excavación masiva hasta cota -5.80 m, entibado perimetral colocado, inclinómetros operativos e hitos medianeros auscultados.
- **Punto de Control QA/QC:** Ensayos de densidad de fondo de excavación (ASTM D1556) y lecturas basales de inclinometría (EMS-01 / COL-01).
- **Condición de Liberación:** Certificado de subrasante perfilada y compactada al 95 % del Proctor Modificado.

### Bloque C: Cimentaciones de Concreto Armado y Malla Ufer Ground
- **Alcance WBS:** Partidas 04.01 a 04.04, 05.01 a 05.06 y 11.01.
- **Predecesor Técnico:** Bloque B liberado.
- **Entregable:** Solados e=4", zapatas aisladas y combinadas vaciadas, vigas de cimentación y malla Ufer ground soldada exotérmicamente.
- **Punto de Control QA/QC:** Protocolo de liberación de armaduras de cimentación, dados de recubrimiento (7.5 cm) y medición de resistividad de puesta a tierra.
- **Condición de Liberación:** Ensayo de compresión de probetas a 7 días y verificación de cotas de desplante.

### Bloque D: Estructuras Especiales de Sótanos (Muros, Cisterna y Foso)
- **Alcance WBS:** Partidas 06.01 a 06.08, 10.02, 10.04.
- **Predecesor Técnico:** Bloque C liberado.
- **Entregable:** Muros de contención perimetrales estancos, cuba de cisterna 45 m³, foso de ascensor a cota -7.00 m, losa de contacto e=15 cm y rampa vehicular.
- **Punto de Control QA/QC:** Inspección de cintas waterstop de PVC en juntas frías, pasamuros rompeaguas y prueba de estanqueidad hidráulica de 72 horas en cisterna.
- **Condición de Liberación:** Acta de prueba hidráulica aprobada y liberación de encofrado trepante a dos caras.

### Bloque E: Superestructura Vertical (Columnas y Placas)
- **Alcance WBS:** Partidas 07.01 a 07.06, 12.01.
- **Predecesor Técnico:** Bloque D (para sótanos) o losa del nivel inferior desencofrada (para pisos 1 al 6).
- **Entregable:** Columnas C-1 a C-8 y placas PL-1 a PL-6 vaciadas con concreto f'c=280 kg/cm², pases de presurización de escaleras colocados.
- **Punto de Control QA/QC:** Control de verticalidad (plomo con tolerancia L/1000), estribaje sísmico en zonas de confinamiento y limpieza de fondo de columna con ventana de registro.
- **Condición de Liberación:** Protocolo Tripartito de Liberación previo al vaciado (Checklist de Pase de Concreto).

### Bloque F: Superestructura Horizontal (Vigas, Losas Aligeradas y Escaleras)
- **Alcance WBS:** Partidas 07.07 a 07.16, 10.01, 11.02, 11.03, 12.02, 12.03.
- **Predecesor Técnico:** Bloque E del mismo piso liberado.
- **Entregable:** Vigas principales y de amarre, losas aligeradas e=20 cm, ladrillos huecos colocados, núcleos de escalera EA-1 y EA-2 vaciados monolíticamente.
- **Punto de Control QA/QC:** Inspección de sleeves sanitarios en tercio central, conduits eléctricos pesados, cajas galvanizadas amarradas, nivelación de fondos y contra-flecha de vigas (L/500).
- **Condición de Liberación:** Acta de prueba de presión hidrostática de tuberías sanitarias embebidas y firma de autorización de bombeo de concreto.

### Bloque G: Azotea Técnica, Parapetos e Impermeabilización
- **Alcance WBS:** Partidas 08.01 a 08.04.
- **Predecesor Técnico:** Bloque F del Piso 6 liberado.
- **Entregable:** Losa de azotea con pendientes del 1 %, parapetos perimetrales h=1.20 m con juntas de dilatación cada 3 m, caseta de ascensor y manto asfáltico termosellado.
- **Punto de Control QA/QC:** Prueba de anegamiento de 48 horas sobre membrana asfáltica e inspección de sellos de poliuretano en juntas.
- **Condición de Liberación:** Certificado de estanqueidad de cubierta técnica.

### Bloque H: Albañilería Confinada, Interfaces MEP Finales y Dossier de Calidad
- **Alcance WBS:** Partidas 09.01 a 09.04, 10.03, 11.04, 11.05, 12.04, 13.01 a 13.06.
- **Predecesor Técnico:** Desencofrado de fondos de losas del piso superior correspondiente.
- **Entregable:** Tabiques de pandereta confinados con columnetas y vigas de amarre (E.070), dinteles en vanos, solaqueo primario, montantes en ductos y Dossier de Calidad final con planos As-Built.
- **Punto de Control QA/QC:** Verificación de aislamiento sísmico de tabiques (juntas de tecnopor de 1 pulg), ensayos a 28 días de concreto y compilación de los 144 protocolos de liberación.
- **Condición de Liberación:** Acta de Conformidad Técnica de Cierre de Casco Estructural.


---

## Vínculos de Trazabilidad
- [[01_documentos_del_proyecto/05_wbs_y_catalogo_partidas/05_wbs_maestra_unica|WBS Maestra Única]]
