# MEMORIA DE ARQUITECTURA, PROGRAMA EDUCATIVO Y EVACUACIÓN (MEM-ARQ-01)

> **Clasificación de datos:** `SINTETICO_APROXIMADO`. Documento de simulación técnica basado en la Memoria Descriptiva Rev. D; no acredita medición de planos originales.

**Proyecto:** Edificio Educativo de 6 pisos, 2 sótanos y azotea  
**Ubicación:** Jr. Las Gardenias 480, Urb. La Calera de la Merced, Surquillo, Lima  
**Código de Documento:** MEM-ARQ-01-REV-D  
**Fecha de Aprobación:** 26 de Agosto de 2026  
**Estado:** BASE DE DISEÑO APROBADA INTERNAMENTE (Vigente para descripción de actividades y metrados sintéticos)  
**Normas de Referencia:** RNE A.010 (Condiciones Generales), A.040 (Educación), A.130 (Requisitos de Seguridad), Ley 30512  

---

## 1. Cuadro General de Áreas Oficial Conciliado
| Nivel | Uso Principal | Área Techada (m²) | Área Libre (m²) |
|---|---|---|---|
| **Sótano 2** | Estacionamientos (12 plazas), Cisterna (45 m³) y Cuarto de Bombas | 500.00 | 0.00 |
| **Sótano 1** | Estacionamientos (10 plazas), Maestranza y Subestación Eléctrica | 500.00 | 0.00 |
| **Piso 1** | Hall de acceso, Recepción, Aulas teóricas A-101/102 y SSHH | 500.00 | 0.00 |
| **Piso 2** | Aulas teóricas A-201/204 y Tópico de Primeros Auxilios | 500.00 | 0.00 |
| **Piso 3** | Laboratorios de Cómputo y Redes LAB-301/302 | 500.00 | 0.00 |
| **Piso 4** | Talleres de Especialidad y Salas de Innovación | 500.00 | 0.00 |
| **Piso 5** | Biblioteca, Sala de Estudio Grupal y Archivo | 500.00 | 0.00 |
| **Piso 6** | Dirección Académica, Sala de Docentes y Administración | 500.00 | 0.00 |
| **Azotea** | Terraza técnica, Cuarto de máquinas de ascensor y Grupo Electrógeno | 500.00 | 0.00 |
| **TOTAL GENERAL** | **Edificio Educativo Completo (9 Niveles)** | **4,500.00** | **0.00** |

## 2. Cálculo de Aforo y Carga de Ocupación (Norma A.040 / A.130)
| Nivel / Ambiente | Coeficiente Normativo | Área Neta Útil (m²) | Aforo Calculado (Personas) |
|---|---|---|---|
| Sótanos 1 y 2 | 1 persona / 30 m² | 800.00 | 27 |
| Piso 1 (Aulas + Hall) | 1 persona / 1.5 m² (Aulas) | 380.00 | 120 |
| Pisos 2 al 4 (Aulas/Talleres)| 1 persona / 1.5 m² (Aulas) / 4.0 m² (Talleres) | 1,140.00 | 380 (126 pers/piso) |
| Piso 5 (Biblioteca) | 1 persona / 2.0 m² (Lectura) | 380.00 | 95 |
| Piso 6 (Administración) | 1 persona / 9.5 m² (Oficinas) | 380.00 | 40 |
| **AFORO MÁXIMO SIMULTÁNEO**| **Capacidad de Evacuación Total** | **-** | **662 Personas** |

## 3. Dimensionamiento del Sistema de Evacuación (Norma A.130)
- **Escaleras de Escape de Emergencia:** 2 núcleos independientes presurizados ($EA-1$ y $EA-2$) de concreto armado, ancho libre útil = 1.20 m cada una (total 2.40 m = 4.0 módulos de evacuación, capacidad para evacuar 800 personas > 662 aforo total).
- **Puertas cortafuego:** RF-90 minutos con barra antipánico en todos los accesos a escaleras.
- **Rutas de evacuación:** Distancia máxima de recorrido a una salida de escape $\le 45.00 m$ (cumple norma).

## 4. Interfaces con WBS
Cubre los Capítulos 08.00 (Azotea y caseta) y 09.00 (Albañilería de confinamiento y vanos de evacuación).
