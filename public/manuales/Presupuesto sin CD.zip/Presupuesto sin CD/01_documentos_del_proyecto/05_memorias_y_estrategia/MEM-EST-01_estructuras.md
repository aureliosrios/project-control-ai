# MEMORIA DE DISEÑO ESTRUCTURAL Y CASCO (MEM-EST-01)

> **Clasificación de datos:** `SINTETICO_APROXIMADO`. Documento de simulación técnica basado en la Memoria Descriptiva Rev. D; no acredita medición de planos originales.

**Proyecto:** Edificio Educativo de 6 pisos, 2 sótanos y azotea  
**Ubicación:** Jr. Las Gardenias 480, Urb. La Calera de la Merced, Surquillo, Lima  
**Código de Documento:** MEM-EST-01-REV-D  
**Fecha de Aprobación:** 26 de Agosto de 2026  
**Estado:** BASE DE DISEÑO APROBADA INTERNAMENTE (Vigente para descripción de actividades y metrados sintéticos)  
**Normas de Referencia:** RNE E.020 (Cargas), E.030 (Sismo), E.050 (Suelos), E.060 (Concreto Armado), E.070 (Albañilería)  

---

## 1. Descripción del Sistema Estructural
- **Subestructura (Sótanos 1 y 2):** Cimentación mediante zapatas aisladas y combinadas unidas por vigas de cimentación ($f'c = 210 kg/cm^2$) apoyadas sobre grava aluvial densa ($\sigma_{adm} = 4.0 kg/cm^2$ a cota -5.80 m). Muros de contención perimetrales de concreto armado ($f'c = 280 kg/cm^2$, $e = 25 cm - 30 cm$) con aditivo impermeabilizante y waterstop en juntas de construcción.
- **Superestructura (Pisos 1 al 6 y Azotea):** Sistema dual y muros de corte de concreto armado en ambas direcciones ortogonales.
  - Columnas rectangulares ($C-1$ a $C-8$) de concreto $f'c = 280 kg/cm^2$.
  - Placas estructurales ($PL-1$ a $PL-6$, $e = 25 cm - 30 cm$) de concreto $f'c = 280 kg/cm^2$.
  - Vigas principales y de amarre ($VP$, $VA$, $e = 25x50, 30x60 cm$) de concreto $f'c = 210 kg/cm^2$.
  - Losas aligeradas unidireccionales de $e = 20 cm$ con viguetas prefabricadas / vaciadas con concreto premezclado cada 40 cm y ladrillos huecos de arcilla 15x30x30 cm.
  - Cajas de ascensores y escaleras de escape de concreto armado monolítico.

## 2. Cargas de Diseño Adoptadas (NTE E.020 - Uso Educativo)
| Elemento / Ambiente | Carga Muerta ($CM$) | Sobrecarga Viva ($CV$) |
|---|---|---|
| Aulas y Salones de Clase | Peso propio + $100 kg/m^2$ acabados + tabiquería | $250 kg/m^2$ |
| Talleres, Laboratorios y Cómputo | Peso propio + $100 kg/m^2$ acabados + tabiquería | $300 kg/m^2$ |
| Pasajes, Corredores y Escaleras | Peso propio + $100 kg/m^2$ acabados | $400 kg/m^2$ |
| Biblioteca y Archivo Central | Peso propio + $100 kg/m^2$ acabados | $500 kg/m^2$ |
| Azotea Técnica / Techo | Peso propio + impermeabilización + $50 kg/m^2$ | $100 kg/m^2$ |
| Estacionamientos (Sótanos 1 y 2) | Peso propio + losa de contacto | $250 kg/m^2$ (Ligero) |

## 3. Resumen de Materiales y Resistencias
- Concreto en Cimentaciones y Vigas de Cimentación: $f'c = 210 kg/cm^2$.
- Concreto en Muros de Contención, Placas y Columnas: $f'c = 280 kg/cm^2$.
- Concreto en Vigas, Losas Aligeradas y Escaleras: $f'c = 210 kg/cm^2$.
- Acero de Refuerzo: Corrugado Grado 60, $f_y = 4200 kg/cm^2$ (ASTM A615).
- Ladrillo en Losas: Ladrillo hueco de arcilla 15x30x30 cm (NTP 331.017).
- Ladrillo en Tabiquería: Ladrillo King Kong 18 huecos de arcilla confinado con columnetas y vigas de amarre (según NTE E.070).

## 4. Interfaces con WBS
Cubre íntegramente los Capítulos 04.00, 05.00, 06.00, 07.00, 08.00 y 09.00 de la WBS Maestra.
