# MEMORIA DE INTERFACES E INSTALACIONES EMBEBIDAS (MEM-MEP-01)

> **Clasificación de datos:** `SINTETICO_APROXIMADO`. Documento de simulación técnica basado en la Memoria Descriptiva Rev. D; no acredita medición de planos originales.

**Proyecto:** Edificio Educativo de 6 pisos, 2 sótanos y azotea  
**Ubicación:** Jr. Las Gardenias 480, Urb. La Calera de la Merced, Surquillo, Lima  
**Código de Documento:** MEM-MEP-01-REV-D  
**Fecha de Aprobación:** 26 de Agosto de 2026  
**Estado:** BASE DE DISEÑO APROBADA INTERNAMENTE (Vigente para descripción de actividades y metrados sintéticos)  
**Normas de Referencia:** RNE IS.010, IS.020, EM.010, EM.030, CNE, NFPA 13, 14, 20, 72  

---

## 1. Alcance de las Interfaces MEP en la Etapa de Casco
Garantizar la correcta incorporación física, dimensional y estanca de todos los pases, mangas estructurales, pasamuros rompeaguas, insertos, montantes verticales, cajas de derivación y mallas de puesta a tierra antes del vaciado del concreto, previniendo picados o perforaciones posteriores que comprometan la capacidad resistente de los elementos estructurales.

## 2. Detalle de Interfaces por Especialidad

### 2.1 Instalaciones Sanitarias Embebidas (Capítulo 10.00)
- **Pases en Vigas y Losas:** 144 mangas de PVC pesado ubicadas estrictamente en el tercio central de vigas (zona de menor momento flexionante) según detalle E.060.
- **Pasamuros Estancos:** 18 bridas rompeaguas de fierro fundido/acero inoxidable con sello de neopreno en muros de cisterna y muros de contención.
- **Montantes y Drenaje:** 190 m de tuberías PVC-SAL pesadas alojadas en ductos técnicos exclusivos y 32 sumideros/canaletas con rejilla de fierro fundido en sótanos y azotea.
- **Pruebas de Estanqueidad:** Prueba hidrostática a 100 psi antes del cierre de encofrados.

### 2.2 Instalaciones Eléctricas y Comunicaciones Embebidas (Capítulo 11.00)
- **Malla Ufer Ground:** 110 m de cable de cobre desnudo $50 mm^2$ soldado exotérmicamente al acero de cimentación.
- **Conduits Embebidos:** 2,850 m de tuberías PVC-P pesado para circuitos de fuerza, tomacorrientes e iluminación fijados rígidamente a la armadura de losas y placas.
- **Cajas de Paso y Centros:** 620 cajas octogonales y rectangulares de fierro galvanizado pesado fijadas al encofrado.
- **Shafts y Ductos de Redes:** 36 pases para alimentadores principales y 1,400 m de ductería para cableado estructurado, CCTV y detección de incendios (DACI).

### 2.3 Interfaces Mecánicas, Ventilación y ACI (Capítulo 12.00)
- **Presurización de Escaleras:** 8 pases reforzados $\phi 500 mm$ con marco metálico en placas de escaleras $EA-1$ y $EA-2$.
- **Extracción de Monóxido de Carbono:** 16 pases rectangulares $600x400 mm$ en vigas y losas de sótanos 1 y 2.
- **Montante Contra Incendio (ACI):** 28 insertos metálicos de anclaje para montante vertical de $\phi 6"$ de tubería de acero cédula 40.
- **Ductos HVAC:** 24 mangas de reserva para sistemas de refrigeración y aire acondicionado en laboratorios.

## 3. Protocolo de Liberación Previo al Vaciado (QA/QC)
Toda interfase embebida debe contar con el **Protocolo Tripartito de Liberación (Checklist de Pase de Concreto)** firmado por Residente de Estructuras, Residente de Instalaciones y Supervisor de Calidad antes de autorizar el despacho y bombeo del concreto.
