# PLAN DE TRABAJO, ESTRATEGIA CONSTRUCTIVA, SEGURIDAD Y CALIDAD (LIMA 2026)

> **Clasificación de datos:** `SINTETICO_APROXIMADO`. Documento de simulación técnica basado en la Memoria Descriptiva Rev. D; no acredita medición de planos originales.

**Proyecto:** Edificio Educativo de 06 Pisos, 02 Sótanos y Azotea  
**Ubicación:** Jr. Las Gardenias 480, Urb. La Calera de la Merced, Surquillo, Lima  
**Código Documental:** PLAN-TRAB-TEC-SSOMA-QAQC-2026  
**Fecha de Aprobación:** 26 de Agosto de 2026  
**Estatus:** PLAN MAESTRO VIGENTE DE EJECUCIÓN TECNOLÓGICA  

---

## 1. FILOSOFÍA Y METODOLOGÍA DE GESTIÓN DE PRODUCCIÓN

### 1.1. Lean Construction y Last Planner System (LPS)
El proyecto se gestionará bajo los principios de **Construcción Sin Pérdidas (Lean Construction)**, orientados a maximizar el flujo continuo y eliminar actividades que no agregan valor:
- **Plan Maestro de Hitos (Master Schedule):** Plazo contractual de **7.5 meses** estructurado en fases críticas (Sostenimiento y Movimiento de Tierras, Casco de Sótanos, Casco de Superestructura, Cierre de Albañilería e Interfaces MEP).
- **Lookahead Planning (Ventana de 4 a 6 semanas):** Análisis de restricciones (materiales, planos RFI, cuadrillas, equipos e interfaces de subcontratas) para garantizar la confiabilidad del trabajo antes de su liberación a campo.
- **Plan Semanal de Producción y PPC (Porcentaje de Plan Cumplido):** Reuniones diarias de producción (Daily Huddles de 15 minutos) y medición semanal del PPC con análisis de causa raíz para desviaciones.
- **Sectorización y Trenes de Trabajo:** Cada nivel de $500.00\text{ m}^2$ se divide en **2 sectores balanceados** ($250.00\text{ m}^2$ por sector), estableciendo un ritmo diario de producción (Takt Time) para las cuadrillas de Encofrado, Acero, Instalaciones y Concreto.

### 1.2. Integración BIM 4D / 5D y Control de Interfaces MEP
- **Modelo Federado BIM LOD 350 / 400:** Coordinación previa de todas las especialidades (Estructuras, Arquitectura, Sanitarias, Eléctricas, HVAC y ACI).
- **Control de Pases y Shafts:** Cero picado de concreto endurecido. Todos los pases de losas y placas se ejecutan con mangas herméticas prefabricadas aprobadas mediante el modelo BIM.
- **Simulación Constructiva 4D:** Validación de la secuencia de izaje de la Grúa Torre y el radio de alcance de la Bomba Telescópica de Concreto para evitar interferencias espaciales con predios colindantes.

---

## 2. ESTÁNDAR TECNOLÓGICO DE EQUIPOS Y MAQUINARIA PESADA

Queda estrictamente prohibido el uso de técnicas artesanales o maquinaria obsoleta. El proyecto operará con el siguiente parque de maquinaria contemporánea (Lima 2026):

```mermaid
graph TD
    A["Parque Tecnológico Lima 2026"] --> B["Izaje y Vaciado"]
    A --> C["Sostenimiento y Tierra"]
    A --> D["Habilitación e Industrialización"]
    
    B --> B1["Grúa Torre 2.5 Tn / Pluma 45m"]
    B --> B2["Bomba Telescópica 36m (UNICON)"]
    B --> B3["100% Concreto Premezclado en Mixer"]
    
    C --> C1["Perforadora Hidráulica sobre Orugas (Casagrande)"]
    C --> C2["Excavadora CAT 320 (200 HP)"]
    C --> C3["Cargador CAT 950 + Volquetes 15m3"]
    
    D --> D1["Encofrado Modular Metálico Fenólico 18mm (ULMA/PERI)"]
    D --> D2["Banco CNC Eléctrico Cortadora/Dobladora 3 HP"]
    D --> D3["Puntales Telescópicos Multiprop y Vigas HEB"]
```

1. **Grúa Torre de Alta Eficiencia (2.5 Tn / Pluma 45m):**
   - Cobertura del 100% del área del predio ($20.00\text{ m} \times 25.00\text{ m}$).
   - Izaje continuo de paquetes de acero habilitado, paneles modulares de encofrado, bovedillas de techo y materiales de acabados, reduciendo los tiempos de transporte vertical en un 65%.
2. **Sistema de Concreto 100% Premezclado y Bombeo Continuo:**
   - Abastecimiento exclusivo desde plantas certificadas (UNICON / Firth) en camiones mixer de $8\text{ m}^3$.
   - Vaciado de sótanos y superestructura con **Bomba Telescópica de Concreto de 36m**, garantizando velocidades de colocación de $35 - 45\text{ m}^3/\text{hora}$ sin segregación.
   - Prohibición expresa de trompos y preparación de mezclas manuales en veredas o vías públicas.
3. **Encofrados 100% Industrializados (ULMA / PERI):**
   - Paneles modulares de marco metálico con tablero fenólico plastificado de $18\text{mm}$.
   - Cero uso de madera rústica o tablas clavadas. Acabado tipo caravista uniforme con reducción de desperdicios al 0%.
4. **Habilitación de Acero con Maquinaria Eléctrica CNC (3 HP):**
   - Banco de doblado y cortado automático en taller de obra, eliminando cizallas manuales y asegurando precisión milimétrica en ganchos sísmicos y estribos según norma E.060.

---

## 3. PLAN DE SOSTENIMIENTO PERIMETRAL Y MONITOREO GEOTÉCNICO

Dada la profundidad de excavación (-5.80 m para 2 sótanos) en entorno urbano consolidado:

1. **Muros Pantalla y Anclajes Activos:**
   - Perforación perimetral con equipo hidráulico autopropulsado sobre orugas (Soilmec / Casagrande).
   - Instalación de **Pernos de Anclaje Dywidag $32\text{mm} \ L=9\text{m}$** inyectados con lechada de cemento Portland Tipo I a presión controlada.
   - Tesado mediante gatos hidráulicos calibrados con lectura de manómetro certificada antes de proceder a la siguiente banqueta de excavación.
2. **Apuntalamiento de Predios Vecinos:**
   - Soporte preventivo de muros medianeros mediante **Puntales Telescópicos Metálicos de Alta Carga (Multiprop)** y perfiles metálicos HEB/IPN de distribución de cargas.
3. **Auscultación y Monitoreo Geotécnico Automatizado:**
   - **02 Inclinómetros Biaxiales Profundos:** Lectura semanal de desplazamientos horizontales en profundidad para detectar cualquier deformación milimétrica del terreno.
   - **01 Piezómetro Abierto PZ-1:** Control permanente del nivel freático y presiones de poros.
   - **08 Hitos Topográficos con Prismas Geodésicos Reflectores:** Medición geodésica continua con **Estación Total Láser Leica FlexLine** de precisión angular $1''$, con emisión de reportes semanales de estabilidad estructural.
4. **Sistema de Achique y Control de Escorrentías:**
   - Foso de bombeo temporal equipado con electrobomba sumergible de lodos de $5\text{ HP}$, sensor automático de nivel y descarga controlada a la red provisional.

---

## 4. PLAN DE SEGURIDAD, SALUD EN EL TRABAJO Y MEDIO AMBIENTE (SSOMA - NORMA G.050)

El proyecto mantiene una meta de **CERO ACCIDENTES (Zero Harm)** con estándares internacionales de seguridad:

1. **Cerramiento y Protección Urbana:**
   - Cerco perimetral con parantes tubulares de acero de $2'' \times 3.00\text{m}$, arriostres metálicos y **Malla Raschel 80%** de alta densidad para contención de polvos y partículas.
2. **Protección Colectiva contra Caídas a Distinto Nivel:**
   - Líneas de vida horizontales y verticales de cable de acero de $3/8''$ certificadas.
   - Barandas perimetrales rígidas modulares en bordes de losa, vacíos de ascensor y rampas vehiculares.
   - Redes de seguridad perimetrales tipo horca / ménsula en pisos superiores durante el avance del casco.
3. **Seguridad en Movimiento de Tierras e Izajes:**
   - Señalización y vigías permanentes (paleteros) para el ingreso y salida de camiones volquetes de $15\text{ m}^3$.
   - Radio de giro de la Grúa Torre señalizado con sirena y luz estroboscópica; riggeador / maniobrista capacitado con certificación Rigger.
4. **Gestión Ambiental y Residuos de Construcción (RCD):**
   - Eliminación de material excedente y desmonte exclusivamente hacia botaderos legalmente autorizados con certificación de disposición final.
   - Humedecimiento constante de subrasante y vías de tránsito interno para mitigación de emisiones de polvo.

---

## 5. PLAN DE ASEGURAMIENTO Y CONTROL DE CALIDAD (QA/QC - ISO 9001)

1. **Protocolo Tripartito de Liberación Previa al Vaciado (Checklist de Pase de Concreto):**
   - Ningún elemento se vacía sin la firma formal del protocolo por parte de:
     1. *Ingeniero Residente de Obra.*
     2. *Ingeniero de Calidad (QA/QC).*
     3. *Supervisor de Obra.*
   - Verificación de 4 ejes: Geometría y topografía, Armadura y recubrimientos sísmicos, Instalaciones MEP embebidas/pases y Estanqueidad de encofrado.
2. **Control Riguroso de Concreto en Estado Fresco y Endurecido:**
   - Medición de Asentamiento (Slump Test ASTM C143) y Temperatura (ASTM C1064) en el 100% de camiones mixer que ingresan a obra.
   - Toma de 04 probetas cilíndricas por cada $30\text{ m}^3$ de vaciado (roturas a 7, 14 y 28 días) ensayadas en **Laboratorio Acreditado por INACAL**.
3. **Control de Acero y Soldaduras:**
   - Certificados de calidad de colada de cada lote de Acero Grado 60 Aceros Arequipa.
   - Ensayos de tracción y doblado en probetas testigo.
4. **Pruebas de Estanqueidad y Presión:**
   - Cisterna y cuarto de bombas: Prueba de estanqueidad hidráulica durante **72 horas continuas** con sellos hidroexpansivos y cinta Waterstop de PVC $6''$.
   - Redes Sanitarias y ACI: Pruebas hidrostáticas presurizadas a $100\text{ psi}$ y $150\text{ psi}$ respectivamente antes del vaciado de losas.
5. **Dossier de Calidad y Planos As-Built:**
   - Compilación digital progresiva de certificados de calibración de equipos, protocolos de liberación, resultados de rotura de probetas y planos finales de replanteo As-Built en formato BIM/CAD.
