# MEMORIA DESCRIPTIVA GENERAL DE CASCO ESTRUCTURAL, ESTRATEGIA TECNOLÓGICA E INTERFACES

**Proyecto:** Edificio Educativo de 6 pisos, 2 sótanos y azotea  
**Ubicación:** Jr. Las Gardenias 480, Urb. La Calera de la Merced, Surquillo, Lima  
**Código:** MEM-CASCO-2026-REV-E  
**Fecha de Aprobación:** 26 de Agosto de 2026  
**Estado:** BASE DE DISEÑO Y ESTRATEGIA TECNOLÓGICA APROBADA (Línea Base Trazable 100%)  

---

## 1. Generalidades y Alcance Contractual
La presente memoria establece los criterios de diseño, normas técnicas, especificaciones geométricas y requisitos de ejecución para el **Casco Estructural, Obras Provisionales, Movimiento de Tierras, Cimentaciones, Sostenimiento Perimetral, Albañilería de Confinamiento, QA/QC e Interfaces Embebidas MEP** (Capítulos 01.00 al 13.00, 78 partidas de la WBS Maestra Oficial).

## 2. Cuadro de Áreas y Geometría
- **Área del Terreno:** 500.00 m² (Linderos: Frente 20.00 m, Fondo 25.00 m).
- **Área Techada Total:** 4,500.00 m² (9 niveles de 500.00 m²: Sótanos 1 y 2, Pisos 1 al 6 y Azotea).
- **Sectores de Trabajo:** 18 sectores de producción balanceada (2 sectores independientes por nivel: Sector 1 y Sector 2 de 250 m² c/u).

## 3. Directiva Tecnológica de Cero Mezclado Manual (100% Concreto Premezclado Industrial)
Queda **estrictamente prohibida la elaboración de concreto en obra mediante mezcladoras de trompo o mezclado manual**. Todo el concreto del proyecto, sin excepción, será suministrado por **Planta Industrial Certificada (UNICON / Firth)** en camiones mixer:
1. **Solados de Cimentación (04.01):** Concreto Premezclado $f'c = 140\text{ kg/cm}^2 \ (e=4'')$, colocado por canaleta o manga de bombeo a cota -5.80 m.
2. **Cimientos Corridos Ciclópeos (04.02):** Concreto Premezclado $f'c = 140\text{ kg/cm}^2$ con adición de 30% de piedra grande seleccionada de cantera (6" a 8") y compactación con vibrador de aguja de 4 HP.
3. **Sobrecimientos (04.03):** Concreto Premezclado $f'c = 175\text{ kg/cm}^2$ con adición de 25% de piedra mediana (3" a 4") y encofrado modular metálico-fenólico de 18mm.
4. **Cimentaciones Armadas y Superestructura (05.xx a 08.xx):** Concretos Premezclados $f'c = 210\text{ kg/cm}^2$ y $f'c = 280\text{ kg/cm}^2$ colocados con **Bomba Telescópica de 36m** e izaje con **Grúa Torre de 2.5 Tn (pluma 45m)**.

## 4. Plan de Trabajo Tecnológico, Seguridad y Calidad 2026
El proyecto incorpora como documento vinculante el **[[PLAN-TRABAJO-ESTRATEGIA-CONSTRUCTIVA-2026|Plan de Trabajo, Estrategia Constructiva, Seguridad y Calidad 2026]]**, el cual establece:
1. **Gestión de Producción:** Lean Construction, Last Planner System (LPS) y modelo federado BIM LOD 350/400.
2. **Equipamiento Contemporáneo:** Grúa Torre (2.5 Tn / 45m), Bombas Telescópicas de Concreto de 36m, Encofrados 100% Modulares Metálicos con Tablero Fenólico 18mm (ULMA/PERI) y Banco CNC Eléctrico de Acero 3 HP.
3. **Sostenimiento y Geotecnia:** Perforadora hidráulica sobre orugas, anclajes activos Dywidag inyectados, puntales Multiprop para colindancias y monitoreo continuo con inclinómetros, piezómetro PZ-1 y 8 hitos con prismas reflectores Leica.
4. **Seguridad Integral (G.050):** Cerramientos tubulares con Malla Raschel 80%, líneas de vida certificadas, redes perimetrales anti-caída y vigías en movimientos de tierra.
5. **Aseguramiento de Calidad (ISO 9001):** Ensayos en laboratorios acreditados INACAL (roturas a 7, 14, 28 días, 4 probetas cada 30 m³) y Protocolo Tripartito de Liberación previo a vaciados.

## 5. Normativa de Diseño y Construcción Aplicada
- **NTE E.020:** Cargas Gravitatorias (Sobrecargas educativas de 250 a 500 kg/m²).
- **NTE E.030:** Diseño Sismorresistente (Zona 4, Z=0.45, U=1.50 Esencial, Suelo S1, Rx=7, Ry=6).
- **NTE E.050:** Suelos y Cimentaciones ($\sigma_{adm} = 4.00 kg/cm^2$ a cota -5.80 m).
- **NTE E.060:** Concreto Armado (Resistencias f'c=140, 210 y 280 kg/cm², acero Grado 60).
- **NTE E.070:** Albañilería Estructural (Tabiques de ladrillo KK 18 huecos confinados con columnetas y aislamiento sísmico de 1 pulg).
- **NTE G.050:** Seguridad durante la Construcción.
- **RNE A.010, A.040, A.130:** Arquitectura, Educación y Seguridad/Evacuación (Aforo 662 personas).
- **CNE y RNE IS.010/EM.010:** Código Nacional de Electricidad e Instalaciones Sanitarias/Mecánicas.

## 6. Control de Calidad e Interfaces (QA/QC)
- Protocolo Tripartito de Liberación previo al vaciado (Checklist de Pase de Concreto) en los 144 vaciados principales.
- 65 grupos de ensayos de compresión de concreto a 7, 14 y 28 días certificados por laboratorio INACAL.
- Pruebas de estanqueidad de 72 horas en cisterna con sellos hidroexpansivos y waterstop de PVC.
- Dossier de Calidad final con certificados de materiales y planos As-Built.
